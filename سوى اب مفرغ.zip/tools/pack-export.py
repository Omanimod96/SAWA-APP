#!/usr/bin/env python3
"""حزم إصدار «سوى» في ملف zip واحد — نفس ترتيب حزم v25/v26.

الاستخدام: python3 tools/pack-export.py v27
يبني exports/sawa-app-<الإصدار>-<التاريخ>.zip بالهيكل:
  sawa-app/{README.md, DEPLOY-RUNBOOK.md, client/{src,public,dist}, server, qa, tools, documents}

ما لا يُحزم أبدًا: node_modules · __pycache__ · مخارج الفحص (*.out) · qa/iso ·
qa/shots · qa/.neg-src · data (بيانات المستخدم) · رموز الفحص (.token*.json).
"""
import os
import subprocess
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ver = (sys.argv[1] if len(sys.argv) > 1 else "dev").lstrip("v")
stamp = subprocess.run(["date", "-u", "+%Y-%m-%d"], capture_output=True, text=True,
                       cwd=ROOT).stdout.strip()
OUT = os.path.join(ROOT, "exports", f"sawa-app-v{ver}-{stamp}.zip")

SKIP_DIRS = {"node_modules", "__pycache__", "iso", "shots", ".neg-src", ".git", "data"}
SKIP_FILES = {".DS_Store"}
# مجلدات الفحص العابرة: خوادم مؤقتة ونسخ بيانات المستخدم داخل qa
SKIP_QA_DIRS = ("run", "run2", "probe", "refimg", "scratch", "tmp", "dist")
QA_MEDIA = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".wav", ".mp3", ".mp4", ".webm", ".zip")


def keep(name, rel):
    if name in SKIP_DIRS or name in SKIP_FILES:
        return False
    if name.endswith((".pyc", ".out", ".log")):
        return False
    if name.startswith(".token") or name.endswith(".token"):
        return False
    if rel.endswith(".tmp"):
        return False
    # لا نُحزم رموز الفحص العابرة ولا وسائطها الثقيلة
    if rel.startswith("qa/"):
        parts = rel.split("/")
        if len(parts) > 1 and parts[1].startswith(SKIP_QA_DIRS):
            return False
        if name.endswith(QA_MEDIA):
            return False
    return True


TREES = ["client/src", "client/public", "client/dist", "server", "qa", "tools", "documents"]
FILES = ["README.md", "DEPLOY-RUNBOOK.md"]

os.makedirs(os.path.dirname(OUT), exist_ok=True)
n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in FILES:
        p = os.path.join(ROOT, f)
        if os.path.isfile(p):
            z.write(p, f"sawa-app/{f}")
            n += 1
    for tree in TREES:
        base = os.path.join(ROOT, tree)
        for dirpath, dirnames, filenames in os.walk(base):
            dirnames[:] = [d for d in dirnames if keep(d, dirpath)]
            for fn in filenames:
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, ROOT)
                if not keep(fn, rel):
                    continue
                z.write(full, f"sawa-app/{rel}")
                n += 1

print(f"✓ {os.path.relpath(OUT, ROOT)} — {n} ملفًا · {os.path.getsize(OUT):,} بايت")

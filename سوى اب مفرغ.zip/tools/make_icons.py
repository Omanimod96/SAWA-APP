"""Generate PWA icons for سوى (Sawa) — blue gradient + yellow Kufi letter.

Style kept from the previous icon set: vertical blue gradient, rounded square
(radius 21.5%), soft radial highlight, yellow Kufi glyph, yellow presence dot.
"""
from PIL import Image, ImageDraw, ImageFont

FONT = "/usr/share/fonts/truetype/noto/NotoKufiArabic-Bold.ttf"
TOP = (0x1D, 0x4E, 0xD8)     # --primary
BOTTOM = (0x2F, 0x6B, 0xF0)  # lighter bottom for depth
YELLOW = (0xFA, 0xCC, 0x15)  # --accent
GLYPH = "س"


def gradient(size):
    img = Image.new("RGB", (size, size))
    d = ImageDraw.Draw(img)
    for y in range(size):
        t = y / (size - 1)
        d.line([(0, y), (size, y)], fill=tuple(round(a + (b - a) * t) for a, b in zip(TOP, BOTTOM)))
    return img


def highlight(img, size, strength=42):
    """Soft white radial highlight behind the glyph (as in the previous set)."""
    layer = Image.new("L", (size, size), 0)
    d = ImageDraw.Draw(layer)
    cx, cy, r = size * 0.5, size * 0.44, size * 0.42
    steps = 90
    for i in range(steps, 0, -1):
        rr = r * i / steps
        val = int(strength * (1 - i / steps) ** 2)
        d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], fill=val)
    return Image.composite(Image.new("RGB", (size, size), (255, 255, 255)), img, layer)


def glyph_mask(size, target_w_ratio, center=(0.5, 0.47)):
    """Render GLYPH as a mask scaled to target width ratio of the canvas, centred.

    Rendered on a 4x canvas and downsampled so the edges stay smooth at 180–192 px.
    """
    probe = 600
    font = ImageFont.truetype(FONT, probe)
    tmp = Image.new("L", (probe * 3, probe * 3), 0)
    ImageDraw.Draw(tmp).text((probe * 1.5, probe * 1.5), GLYPH, font=font, fill=255, anchor="mm")
    ink = tmp.crop(tmp.getbbox())

    target_w = round(size * target_w_ratio * 4)
    ink = ink.resize((target_w, max(1, round(ink.height * target_w / ink.width))), Image.LANCZOS)

    canvas = Image.new("L", (size * 4, size * 4), 0)
    canvas.paste(ink, (round(center[0] * size * 4 - ink.width / 2), round(center[1] * size * 4 - ink.height / 2)))
    return canvas.resize((size, size), Image.LANCZOS)


def rounded_mask(size, radius_ratio=0.215):
    m = Image.new("L", (size, size), 0)
    ImageDraw.Draw(m).rounded_rectangle([0, 0, size - 1, size - 1], radius=round(size * radius_ratio), fill=255)
    return m


def build(size, path, rounded=True, glyph_w=0.62, dot=True, center=(0.5, 0.47), dot_pos=(0.775, 0.775), dot_r=0.055):
    img = highlight(gradient(size), size)
    gm = glyph_mask(size, glyph_w, center)
    img.paste(Image.new("RGB", (size, size), YELLOW), (0, 0), gm)
    if dot:
        layer = Image.new("L", (size, size), 0)
        cx, cy, r = dot_pos[0] * size, dot_pos[1] * size, dot_r * size
        ImageDraw.Draw(layer).ellipse([cx - r, cy - r, cx + r, cy + r], fill=255)
        img.paste(Image.new("RGB", (size, size), YELLOW), (0, 0), layer)
    out = img.convert("RGBA")
    if rounded:
        out.putalpha(rounded_mask(size))
    out.save(path, optimize=True)
    print("wrote", path, out.size, "rounded" if rounded else "full-bleed")


if __name__ == "__main__":
    base = "sites/smart-social/client/public/icons"
    build(192, f"{base}/icon-192.png", rounded=True, glyph_w=0.62, dot_r=0.062, dot_pos=(0.775, 0.775))
    build(512, f"{base}/icon-512.png", rounded=True, glyph_w=0.62)
    build(180, f"{base}/apple-touch-icon.png", rounded=False, glyph_w=0.62)
    build(512, f"{base}/icon-512-maskable.png", rounded=False, glyph_w=0.50, center=(0.5, 0.48),
          dot_pos=(0.72, 0.72), dot_r=0.045)

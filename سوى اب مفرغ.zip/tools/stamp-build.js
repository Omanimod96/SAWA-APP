#!/usr/bin/env node
/**
 * يبصم ناتج البناء بعد الانتهاء منه: بصمة index.html + الحزم التي يشير إليها.
 *
 * السبب: عمليات نسخ/استعادة خارجية (مثل .tmp-restore) كانت تعيد ناتج بناء قديم
 * إلى client/dist — بما فيه أحيانًا index.html قديم يشير إلى حزمة غير موجودة،
 * وهو ما يُنتج صفحة بيضاء عند النشر. البصمة تجعل كشف هذا التلاعب لحظيًا.
 *
 * الاستخدام:  node tools/stamp-build.js   (يُستدعى تلقائيًا بعد vite build)
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DIST = path.join(__dirname, '..', 'client', 'dist');
const INDEX = path.join(DIST, 'index.html');
const STAMP = path.join(DIST, 'build-stamp.json');

if (!fs.existsSync(INDEX)) {
  console.error('✗ لا يوجد dist/index.html — شغّل البناء أولًا');
  process.exit(1);
}

const html = fs.readFileSync(INDEX, 'utf8');
const assets = [...html.matchAll(/assets\/[A-Za-z0-9_.-]+/g)].map((m) => path.basename(m[0]));
const missing = assets.filter((f) => !fs.existsSync(path.join(DIST, 'assets', f)));
if (!assets.length || missing.length) {
  console.error('✗ البناء غير مكتمل — مفقود: ' + (missing.join(', ') || '(لا مراجع)'));
  process.exit(1);
}

const doc = {
  at: new Date().toISOString(),
  indexMd5: crypto.createHash('md5').update(html).digest('hex'),
  assets: assets.map((f) => ({
    name: f,
    bytes: fs.statSync(path.join(DIST, 'assets', f)).size,
    md5: crypto.createHash('md5').update(fs.readFileSync(path.join(DIST, 'assets', f))).digest('hex'),
  })),
};
fs.writeFileSync(STAMP, JSON.stringify(doc, null, 2), 'utf8');
console.log(`✓ بصمة البناء: ${doc.indexMd5.slice(0, 8)} · ${doc.assets.map((a) => a.name).join(', ')}`);

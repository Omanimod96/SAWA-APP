#!/usr/bin/env node
/**
 * يحافظ على نظافة مجلد البناء قبل النشر: يزيل من client/dist/assets أي حزمة
 * لا يشير إليها dist/index.html.
 *
 * السبب: عمليات نسخ/استعادة خارجية (نسخ احتياطي، استعادة جلسة، سكربتات قديمة)
 * كانت تُعيد حزمًا بنيت سابقًا إلى مجلد البناء، فتُنشر مع الموقع بلا داعٍ
 * (‏٣ حزم JS و٤ ملفات CSS قديمة = ~١.٥ ميجابايت زائدة) وتُربك أي تشخيص لاحق
 * لأن أكثر من ملف يشبه «الحزمة الحالية».
 *
 * الاستخدام:  node tools/clean-dist.js
 */
const fs = require('fs');
const path = require('path');

const DIST = path.join(__dirname, '..', 'client', 'dist');
const INDEX = path.join(DIST, 'index.html');
const ASSETS = path.join(DIST, 'assets');

if (!fs.existsSync(INDEX)) {
  console.error('✗ لا يوجد dist/index.html — شغّل البناء أولًا (npm run build داخل client/)');
  process.exit(1);
}
if (!fs.existsSync(ASSETS)) {
  console.error('✗ لا يوجد dist/assets — البناء ناقص، لا تَنشر');
  process.exit(1);
}

const html = fs.readFileSync(INDEX, 'utf8');
const keep = new Set(
  [...html.matchAll(/assets\/[A-Za-z0-9_.-]+/g)].map((m) => path.basename(m[0])),
);

// إن وُجدت بصمة بناء (tools/stamp-build.js) فتأكد أن index.html هو نفسه الذي بُصم.
// سبب الفحص: نسخ/استعادة خارجية قد تُعيد index.html قديمًا إلى dist، وفي هذه الحالة
// نرفض النشر بدل نشر واجهة قديمة تشير إلى حزمة غير موجودة (صفحة بيضاء).
const STAMP = path.join(DIST, 'build-stamp.json');
if (fs.existsSync(STAMP)) {
  try {
    const stamp = JSON.parse(fs.readFileSync(STAMP, 'utf8'));
    const now = require('crypto').createHash('md5').update(html).digest('hex');
    if (stamp.indexMd5 && stamp.indexMd5 !== now) {
      console.error('✗ index.html تغيّر بعد البناء — أعد البناء (npm run build) قبل النشر');
      process.exit(1);
    }
  } catch (e) {
    console.error('✗ تعذّر قراءة بصمة البناء: ' + (e && e.message));
    process.exit(1);
  }
}

const missing = [...keep].filter((f) => !fs.existsSync(path.join(ASSETS, f)));
if (!keep.size || missing.length) {
  console.error('✗ مراجع البناء غير سليمة — مفقود: ' + (missing.join(', ') || '(لا مراجع)'));
  process.exit(1);
}

let removed = 0;
fs.readdirSync(ASSETS).forEach((f) => {
  if (keep.has(f)) return;
  fs.unlinkSync(path.join(ASSETS, f));
  removed += 1;
});

console.log(`✓ الحزم المُشار إليها: ${[...keep].join(', ')}`);
console.log(`✓ حُذف ${removed} ملفًا غير مُشار إليه من dist/assets`);

// ── تنظيف جذر dist من ملفات ليست من ناتج البناء ───────────────────────────────
// السبب: سكربتات الفحص تحفظ لقطات شاشة داخل مجلد البناء أحيانًا (`_c1.png`،
// `_ref7450.png` ~ ٩٠٠ ك.ب)، فتُنشر مع الموقع وتظهر في حزمة التنزيل.
// القائمة المسموح بها هي ما يبنيه Vite + أدوات البناء فقط.
const ROOT_OK_FILES = new Set([
  'index.html',
  'manifest.webmanifest',
  'sw.js',
  'build-stamp.json',
  '.igonre',
  'favicon.ico',
]);
const ROOT_OK_DIRS = new Set(['assets', 'icons']);

let swept = 0;
fs.readdirSync(DIST).forEach((entry) => {
  const full = path.join(DIST, entry);
  const isDir = fs.statSync(full).isDirectory();
  const ok = isDir ? ROOT_OK_DIRS.has(entry) : ROOT_OK_FILES.has(entry);
  if (ok) return;
  if (isDir) {
    console.warn(`⚠ مجلد غير متوقع في جذر البناء: ${entry} (تُرك كما هو)`);
    return;
  }
  try {
    fs.unlinkSync(full);
    swept += 1;
    console.log(`  · أُزيل من جذر البناء: ${entry}`);
  } catch (e) {
    console.warn(`⚠ تعذّر إزالة ${entry}: ${e && e.message}`);
  }
});
if (swept) console.log(`✓ نُظّف جذر dist: ${swept} ملفًا ليس من ناتج البناء`);

#!/usr/bin/env node
/**
 * ⛔ متوقَّف — لا تشغّله (١٨ سبتمبر ٢٠٢٦، الجولة الأخيرة).
 *
 * السبب: التعيين صار عبر المنصة نفسها. النشر بـ run_command
 * «cd ../../server && HOST=127.0.0.1 PORT=${PORT} node index.js >> run.log 2>&1»
 * يجعل المنصة تشغّل الخادم على المنفذ الذي تخصّصه وتمرّر /api إليه.
 * تسجيل نفس الموقع من هذا الحارس (POST /sites) يُنشئ خادمًا موازيًا، والخادم
 * الجديد يقتل القديم (takeover) فيتبدّل المنفذ وتُقطع الخدمة لحظات — شوهد فعلًا:
 * إعادة تسجيل كل ~٣٠ ثانية + خطأ 503 متقطّع. لذلك أُوقف الحارس نهائيًا.
 *
 * للتشخيص فقط: ما زال يقرأ سجل الوكيل ويطبع تقريرًا — لكن لا يُسجّل شيئًا.
 */
/**
 * حارس تشغيل «سوى» — يبقي الموقع مسجّلًا ومُشغَّلًا داخل الساندبوكس.
 *
 * دروس من عطل حقيقي (١٨ سبتمبر ٢٠٢٦): التسجيل في الوكيل **عاديّ التكرار** — إعادة
 * POST لنفس deploy_id تُعيد العملية القائمة نفسها ولا تُنشئ نسخة جديدة. لذلك لا
 * حاجة لقتل أي شيء قبل التسجيل، وقتل «النسخ الزائدة» في المسار الحرج كان يقتل
 * الخادم السليم نفسه كل دقيقة (توقف الموقع ثم إقلاع بارد متكرر). القاعدة الآن:
 *   ١) إن كان التسجيل موجودًا وصحيحًا والخادم يجيب → لا نلمس شيئًا.
 *   ٢) وإلا → POST واحد فقط (يعيد العملية القائمة أو يُنشئ واحدة).
 *   ٣) تنظيف النسخ الزائدة يقتصر على نسخ غير مسجّلة، ولمرة واحدة كل خمس دورات.
 *
 * التشغيل:  setsid nohup node tools/watch-site.js >> qa/watchdog.log 2>&1 &
 */
const http = require('http');
const fs = require('fs');
const { spawn } = require('child_process');
const path = require('path');

const DEPLOY_ID = 'b239a8a905a64208';
const AGENT = { host: '127.0.0.1', port: 9000 };
const WORKDIR = 'sites/sawa-app/server';
const RUN_CMD = 'node index.js';
const SERVER_DIR = path.resolve(__dirname, '..', 'server');
const INTERVAL = 10000; // الوكيل يفقد السجل عند إعادة تشغيله — نكتشفه سريعًا
const RESTART_COOLDOWN = 30000;
const PID_FILE = path.join(__dirname, '..', 'data', 'watchdog.pid');
// الرابط العام: نلمسه كل ~٣٠ ث لأن سجل الوكيل يُسقط الموقع الخامل (شوهد فعليًا:
// السطر يختفي بعد ~٧٠ ث بلا مرور، فتُعاد التسجيل بعملية جديدة = توقف لحظي وتبديل منفذ).
const PUBLIC = `https://${DEPLOY_ID}.preview.sanaabot.com/api/health`;

const log = (msg) => console.log('[' + new Date().toISOString() + '] ' + msg);

function req(method, urlPath, body) {
  return new Promise((resolve) => {
    const payload = body ? JSON.stringify(body) : null;
    const r = http.request(
      { host: AGENT.host, port: AGENT.port, path: urlPath, method, timeout: 10000,
        headers: payload ? { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } : {} },
      (res) => { let b = ''; res.on('data', (c) => (b += c)); res.on('end', () => resolve({ status: res.statusCode, body: b })); }
    );
    r.on('timeout', () => { r.destroy(); resolve({ status: 0, body: 'timeout' }); });
    r.on('error', (e) => resolve({ status: 0, body: e.message }));
    if (payload) r.write(payload);
    r.end();
  });
}

// ── نسخة واحدة فقط من الحارس ──
function claimSingleton() {
  let mine = 0;
  try { mine = Number(fs.readFileSync(PID_FILE, 'utf8').trim()) || 0; } catch (e) { /* لا ملف */ }
  if (mine && mine !== process.pid) {
    try { process.kill(mine, 0); log('حارس آخر يعمل (pid ' + mine + ') — إنهاء هذه النسخة'); process.exit(0); }
    catch (e) { /* القديم ميت */ }
  }
  // أي نسخة أخرى من هذا الملف تُنهى — تكرار الحارس كان يسبب قتلاً وإقلاعًا متبادلًا
  try {
    fs.readdirSync('/proc').forEach((n) => {
      const pid = Number(n);
      if (!pid || pid === process.pid) return;
      try {
        const cmd = fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').replace(/\0/g, ' ');
        if (!cmd.includes('watch-site.js')) return;
        process.kill(pid, 'SIGTERM');
        log('أُنهيت نسخة حارس مكررة (pid ' + pid + ')');
      } catch (e) { /* تجاهل */ }
    });
  } catch (e) { /* تجاهل */ }
  try { fs.writeFileSync(PID_FILE, String(process.pid)); } catch (e) { /* تجاهل */ }
}

// ── قراءة سجل الوكيل ──
// مهم: نفرّق بين ثلاث حالات، لأن خلطها كان يُنتج موجة إعادة تسجيل تُبدّل العملية
// كل ١٠ ثوانٍ (والوكيل يقتل العملية السابقة لنفس deploy_id عند التسجيل من جديد):
//   'miss'    → قرأنا السجل فعلًا ولا يوجد سطر لموقعنا: إعادة التسجيل صحيحة.
//   'entry'   → السجل موجود؛ نفحص العملية والمنفذ.
//   'unknown' → تعذّر قراءة السجل (مهلة/خطأ شبكة): لا نلمس شيئًا، ننتظر دورة أخرى.
async function siteEntry() {
  const r = await req('GET', '/sites');
  if (r.status !== 200) return { kind: 'unknown' };
  try {
    const list = JSON.parse(r.body).sites || [];
    const entry = list.find((s) => s && s.deploy_id === DEPLOY_ID) || null;
    return entry ? { kind: 'entry', entry } : { kind: 'miss' };
  } catch (e) { return { kind: 'unknown' }; }
}

// نبضة على الرابط العام تُبقي الموقع «نشطًا» في سجل الوكيل فلا يُسقط سطره
function keepWarm() {
  return new Promise((resolve) => {
    const req2 = require('https').get(PUBLIC, { timeout: 12000 }, (res) => {
      res.resume();
      res.on('end', () => resolve(res.statusCode === 200));
    });
    req2.on('timeout', () => { req2.destroy(); resolve(false); });
    req2.on('error', () => resolve(false));
  });
}

function answers(port) {
  return new Promise((resolve) => {
    if (!port) return resolve(false);
    const r = http.get({ host: '127.0.0.1', port, path: '/api/health', timeout: 6000 }, (res) => {
      let b = '';
      res.on('data', (c) => (b += c));
      res.on('end', () => {
        try { resolve(res.statusCode === 200 && JSON.parse(b).ok === true); }
        catch (e) { resolve(false); }
      });
    });
    r.on('timeout', () => { r.destroy(); resolve(false); });
    r.on('error', () => resolve(false));
  });
}

// ── خوادم «سوى» الحيّة (لا نلمس أي شيء آخر) ──
function liveServers() {
  const out = [];
  try {
    fs.readdirSync('/proc').forEach((n) => {
      const pid = Number(n);
      if (!pid) return;
      try {
        const cmd = fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').replace(/\0/g, ' ').trim();
        if (!/(^|[ /])index\.js(\s|$)/.test(cmd)) return;
        if (path.resolve(fs.readlinkSync(`/proc/${pid}/cwd`)) !== SERVER_DIR) return;
        out.push(pid);
      } catch (e) { /* تجاهل */ }
    });
  } catch (e) { /* تجاهل */ }
  return out;
}

// نسخة زائدة = عملية خادم لا يشير إليها سجل الوكيل (لا نقتل المسجَّلة أبدًا)
function pruneStrays(registeredPid) {
  const strays = liveServers().filter((p) => p !== registeredPid && p !== process.pid);
  strays.forEach((p) => { try { process.kill(p, 'SIGTERM'); } catch (e) { /* تجاهل */ } });
  return strays.length;
}

// ── صيانة دورية خفيفة: تُعيد ناتج البناء نظيفًا إن أعادته أي مزامنة خارجية ──
// مساحة العمل تُنسخ من مصدر خارجي، ووُجد بالتجربة أن الملفات المحذوفة تعود خلال
// ~١٥ ثانية. الوضع الآمن في prune يمسّ ناتج البناء ومخلفات الاستعادة فقط — لا
// يلمس مجلدات فحص جارية ولا خوادم ولا قاعدة البيانات.
function safeHygiene() {
  try {
    const p = spawn(process.execPath, [path.join(__dirname, 'prune.js'), '--safe'], {
      cwd: path.join(__dirname, '..'),
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    let out = '';
    p.stdout.on('data', (c) => (out += c));
    p.on('close', () => {
      const lines = out.split('\n').filter((l) => l.includes('حزمة بناء يتيمة') || l.includes('أرشيف'));
      if (lines.length) log('صيانة: ' + lines.length + ' ملفًا زائدًا أُزيل من ناتج البناء');
    });
  } catch (e) { /* تجاهل */ }
}

let round = 0;
let lastRestart = 0;

// عدّاد الفشل المتتابع: ننتظر دورتين قبل التدخّل حتى لا تُسبّب مهلة عابرة
// في قراءة السجل إعادة تسجيل تُبدّل العملية وتُسقط الموقع لحظات.
let misses = 0;
let lastKnown = null; // { pid, port } آخر تسجيل سليم — نفحصه مباشرة عند تعذّر السجل

async function tick() {
  round += 1;
  const res = await siteEntry();
  const site = res.kind === 'entry' ? res.entry : null;

  // تعذّر قراءة السجل: إن كان آخر منفذ معروف يجيب فكل شيء سليم — لا نلمس شيئًا.
  if (res.kind === 'unknown') {
    const still = lastKnown ? await answers(lastKnown.port) : false;
    if (still) { misses = 0; if (round % 5 === 1) log('تعذّر قراءة السجل لكن الخادم يجيب على المنفذ ' + lastKnown.port + ' — لا تدخّل'); }
    else { misses += 1; log('تعذّر قراءة السجل ولا إجابة على المنفذ المعروف (' + misses + '/3)'); }
    if (misses < 3) { setTimeout(tick, INTERVAL); return; }
  } else {
    misses = 0;
  }

  const healthy = site && site.alive ? await answers(site.port) : false;
  if (site && healthy) lastKnown = { pid: site.pid, port: site.port };

  if (healthy) {
    // كل خمس دورات (~٢.٥ دقيقة) نسجّل تقريرًا، وبقية الدورات صامتة
    if (round % 5 === 1) {
      const n = liveServers().length;
      log('الموقع يعمل: pid ' + site.pid + ' منفذ ' + site.port + ' — /api/health سليم' + (n > 1 ? ' (نسخ حيّة: ' + n + ')' : ''));
    }
    // كل ~٣٠ ثانية: نبضة عامة تُبقي سجل الوكيل حيًّا (تمنع الإسقاط الخامل)
    if (round % 3 === 0) {
      const warm = await keepWarm();
      if (!warm) log('نبضة الرابط العام لم تُجب — سنراقب الدورة القادمة');
    }
    if (round % 10 === 0) {
      const killed = pruneStrays(site.pid);
      if (killed) log('نظّفت ' + killed + ' نسخة خادم غير مسجّلة');
    }
    if (round % 3 === 0) safeHygiene(); // ~كل ٣٠ ثانية
  } else if (res.kind === 'unknown' && misses < 3) {
    // مهلة عابرة: ننتظر الدورة القادمة بدل إعادة تسجيل تُبدّل العملية
    if (round % 5 === 1) log('سجل الوكيل غير مقروء — انتظار دورة أخرى');
  } else if (res.kind === 'miss' && await keepWarm()) {
    // سجل الوكيل قد لا يُدرج المواقع المسجّلة عبر POST، والرابط العام يجيب —
    // فإعادة التسجيل هنا تعني خادمًا جديدًا كل ٣٠ ثانية (شوهد فعلًا) بلا حاجة.
    if (round % 10 === 1) log('سجل الوكيل لا يُدرج الموقع لكن الرابط العام يجيب — لا إعادة تسجيل');
    misses = 0;
  } else if (Date.now() - lastRestart > RESTART_COOLDOWN) {
    lastRestart = Date.now();
    log(res.kind === 'miss'
      ? 'الموقع غير مسجّل فعلًا (لا سطر في سجل الوكيل) والرابط العام لا يجيب — تسجيل'
      : 'التسجيل موجود (pid ' + (site && site.pid) + ') لكن لا إجابة على المنفذ ' + (site && site.port) + ' — إعادة تسجيل');
    const prev = lastKnown && lastKnown.pid;
    log('⛔ الحارس متوقَّف: لا إعادة تسجيل (النشر يتولّاه run_command في المنصة). الشكوى: '
      + (res.kind === 'miss' ? 'لا سطر في سجل الوكيل' : 'لا إجابة على المنفذ ' + (site && site.port)));
    lastKnown = null;
    setTimeout(tick, INTERVAL);
    return;
    let fresh = null;
    try { fresh = JSON.parse(r.body); } catch (e) { fresh = null; }
    if (fresh && fresh.pid) lastKnown = { pid: fresh.pid, port: fresh.port };
    // نسخة واحدة: العملية السابقة التي شغّلها الحارس تُنهى بعد نجاح الجديدة
    if (prev && fresh && fresh.pid && prev !== fresh.pid) {
      try { process.kill(prev, 'SIGTERM'); log('أُنهيت النسخة السابقة (pid ' + prev + ')'); }
      catch (e) { /* ماتت من نفسها */ }
    }
  }

  setTimeout(tick, INTERVAL);
}

claimSingleton();
log('بدء حارس تشغيل سوى (deploy ' + DEPLOY_ID + ')');
tick();

#!/usr/bin/env node
// مولّد ملفات الملصقات: يكتب SVG + فهرس server/stickers.json.
// التشغيل: node tools/make-stickers.js
//
// لماذا ملفات SVG على الخادم: الملصقات تُخدَم من الخادم فتُضاف حزمة جديدة مستقبلًا
// بكتابة ملف + إدخال في الفهرس، دون أي تعديل في التطبيق (بند ٥ من الطلب).
const fs = require('fs');
const path = require('path');

const OUT = path.join(__dirname, '..', 'server', 'assets', 'stickers');
const INDEX = path.join(__dirname, '..', 'server', 'stickers.json');
const SKIN = '#F7D9B6';
const LINE = '#B4794A';

const wrap = (inner) =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120" role="img">\n${inner}\n</svg>\n`;

// وجه أساسي: قرص + خدّان — التفاصيل تُضاف بحسب التعبير
const face = (inner, skin = SKIN, ring = LINE) =>
  `<circle cx="60" cy="60" r="50" fill="${skin}" stroke="${ring}" stroke-width="3"/>` +
  `<circle cx="30" cy="72" r="7" fill="#F4A9A0" opacity=".55"/>` +
  `<circle cx="90" cy="72" r="7" fill="#F4A9A0" opacity=".55"/>${inner}`;
const dot = (x, y, r = 5, c = '#3B2A20') => `<circle cx="${x}" cy="${y}" r="${r}" fill="${c}"/>`;
const arc = (d, c = '#3B2A20', w = 4) => `<path d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round"/>`;
const openMouth = (c = '#7A2C2C') => `<path d="M40 76q20 24 40 0q-20 8-40 0z" fill="${c}"/>`;
const smile = arc('M40 74q20 20 40 0');
const line = openMouth; // اسم مختصر للفم المفتوح

const heart = (c, c2, x = 0, y = 0, s = 1) =>
  `<g transform="translate(${x} ${y}) scale(${s})"><path d="M60 104C28 82 16 62 16 46a24 24 0 0 1 44-13A24 24 0 0 1 104 46c0 16-12 36-44 58z" fill="${c}"/>` +
  `<path d="M44 34a12 12 0 0 0-12 12" stroke="${c2}" stroke-width="4" fill="none" stroke-linecap="round"/></g>`;

const FACES = {
  smile: ['ابتسامة', face(dot(42, 52) + dot(78, 52) + smile)],
  laugh: ['ضحكة', face(dot(42, 50) + dot(78, 50) + arc('M36 68q10-8 20 0t24 0') + `<path d="M42 78q18 26 36 0z" fill="#7A2C2C"/>`)],
  wink: ['غمزة', face(arc('M32 52q10-10 20 0') + dot(78, 52) + arc('M42 76q18 16 36-2'))],
  love: ['حب', face(`<path d="M42 48a10 10 0 0 1 10 10a10 10 0 0 1 10-10a10 10 0 0 1 10 10c0 8-10 15-20 22c-10-7-20-14-20-22a10 10 0 0 1 10-10z" fill="#E23B57"/>` + arc('M46 84q14 10 28 0'))],
  sad: ['حزن', face(dot(42, 52) + dot(78, 52) + arc('M42 84q18-16 36 0') + `<path d="M78 62q6 12 0 12q-6 0 0-12z" fill="#79C2E8"/>`)],
  angry: ['غضب', face(`<path d="M30 44l22 8M90 44l-22 8" stroke="#3B2A20" stroke-width="4" fill="none" stroke-linecap="round"/>` + dot(44, 58) + dot(76, 58) + arc('M44 86q16-12 32 0'))],
  wow: ['اندهاش', face(dot(42, 50, 6) + dot(78, 50, 6) + `<ellipse cx="60" cy="78" rx="12" ry="14" fill="#7A2C2C"/>`)],
  sleepy: ['نعسان', face(arc('M32 54q10 6 20 0') + arc('M68 54q10 6 20 0') + `<ellipse cx="60" cy="80" rx="10" ry="12" fill="#7A2C2C"/>` + `<text x="86" y="34" font-size="20" fill="#7C6B5E" font-family="sans-serif">z</text>`)],
  cool: ['رائع', face(`<rect x="24" y="44" width="72" height="20" rx="8" fill="#2B3A55"/>` + arc('M44 82q16 12 32 0'))],
  shy: ['خجل', face(arc('M34 52q10-8 18 0') + arc('M68 52q10-8 18 0') + arc('M48 78q12 8 24 0'))],
  think: ['تفكير', face(dot(42, 52) + dot(78, 52) + arc('M44 80h28') + `<circle cx="96" cy="30" r="1"/>` + `<path d="M92 40a9 9 0 1 1 12-8" stroke="#B4794A" stroke-width="3" fill="none"/><path d="M96 34l8-2-1 8z" fill="#B4794A"/>`)],
  cry: ['بكاء', face(dot(42, 50) + dot(78, 50) + `<path d="M38 56q-6 16 0 18q6-2 0-18z" fill="#79C2E8"/><path d="M82 56q6 16 0 18q-6-2 0-18z" fill="#79C2E8"/>` + arc('M42 86q18-12 36 0'))],
};

const HEARTS = {
  heart: ['قلب', heart('#E23B57', '#FFD3DA')],
  love_eyes: ['عينان قلب', face(`<path d="M36 46a8 8 0 0 1 8 8a8 8 0 0 1 8-8a8 8 0 0 1 8 8c0 6-8 12-16 18c-8-6-16-12-16-18a8 8 0 0 1 8-8z" fill="#E23B57"/><path d="M74 46a8 8 0 0 1 8 8a8 8 0 0 1 8-8a8 8 0 0 1 8 8c0 6-8 12-16 18c-8-6-16-12-16-18a8 8 0 0 1 8-8z" fill="#E23B57"/>` + openMouth())],
  broken: ['قلب مكسور', heart('#C2415A', '#F6C6CE') + `<path d="M60 40l-10 20h16l-8 22" stroke="#FFF" stroke-width="4" fill="none" stroke-linejoin="round"/>`],
  spark: ['قلب يلمع', heart('#E23B57', '#FFD3DA') + `<path d="M96 26l4 10 10 4-10 4-4 10-4-10-10-4 10-4z" fill="#F5B942"/>`],
  hug: ['عناق', face(dot(40, 52) + dot(80, 52) + smile + `<path d="M8 66q14-18 30-8M112 66q-14-18-30-8" stroke="#E8A87C" stroke-width="5" fill="none" stroke-linecap="round"/>`)],
  clap: ['تصفيق', `<circle cx="44" cy="62" r="20" fill="${SKIN}" stroke="${LINE}" stroke-width="3"/><circle cx="78" cy="62" r="20" fill="${SKIN}" stroke="${LINE}" stroke-width="3"/><path d="M30 40l-8-10M52 36l4-12M74 36l-4-12M96 40l8-10" stroke="#F5B942" stroke-width="4" stroke-linecap="round"/>`],
  thanks: ['شكرًا', face(dot(42, 52) + dot(78, 52) + smile) + `<path d="M14 78l14-6M106 78l-14-6" stroke="#E8A87C" stroke-width="4" stroke-linecap="round"/>`],
  peace: ['سلام', face(dot(42, 52) + dot(78, 52) + smile) + `<path d="M18 96q22-10 44 4" stroke="#7CB342" stroke-width="5" fill="none" stroke-linecap="round"/>`],
  ok: ['تمام', face(dot(42, 52) + dot(78, 52) + smile) + `<circle cx="96" cy="90" r="18" fill="#7CB342"/><path d="M88 90l6 6 12-14" stroke="#FFF" stroke-width="4" fill="none" stroke-linecap="round"/>`],
};

const TIME = {
  coffee: ['قهوة', `<path d="M28 46h56v26a18 18 0 0 1-18 18H46a18 18 0 0 1-18-18z" fill="#8D5B3F"/><path d="M84 54h10a10 10 0 0 1 0 20H84" stroke="#8D5B3F" stroke-width="5" fill="none"/><path d="M28 40h56v8H28z" fill="#F3E3D3"/><path d="M44 30q6-8 0-14M60 30q6-8 0-14" stroke="#C9B7A6" stroke-width="4" fill="none" stroke-linecap="round"/>`],
  tea: ['شاي', `<path d="M36 40h44l-8 62H44z" fill="#E6D3B3" stroke="#B4794A" stroke-width="3"/><path d="M40 56h44l-3 22H43z" fill="#C98B4B"/><path d="M78 60l14-10" stroke="#B4794A" stroke-width="4" stroke-linecap="round"/>`],
  sea: ['بحر', `<path d="M6 70q16-12 32 0t32 0 32 0 12 0" stroke="#3C8DBC" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M6 88q16-12 32 0t32 0 32 0 12 0" stroke="#7CC3E0" stroke-width="6" fill="none" stroke-linecap="round"/><circle cx="88" cy="30" r="14" fill="#F5B942"/>`],
  palm: ['نخلة', `<path d="M58 106q2-40-6-64" stroke="#8D5B3F" stroke-width="8" fill="none" stroke-linecap="round"/><path d="M52 40q-24-8-40 6q22-4 40 4M52 40q10-26 34-24q-20 8-26 24M52 40q26-8 40 8q-22-4-38 4M52 40q-8-24-34-22q20 8 30 22" fill="#5B9A4B"/>`],
  rain: ['مطر', `<path d="M34 62a20 20 0 0 1 2-39a26 26 0 0 1 50 4a16 16 0 0 1-2 35z" fill="#B9CEDA"/><path d="M40 76l-6 14M60 76l-6 14M80 76l-6 14" stroke="#6FA8D0" stroke-width="5" fill="none" stroke-linecap="round"/>`],
  sun: ['شمس', `<circle cx="60" cy="60" r="24" fill="#F5B942"/><path d="M60 14v14M60 92v14M14 60h14M92 60h14M28 28l10 10M82 82l10 10M92 28l-10 10M38 82l-10 10" stroke="#F5B942" stroke-width="5" stroke-linecap="round"/>`],
  moon: ['ليل', `<path d="M74 14a46 46 0 1 0 0 92A38 38 0 0 1 74 14z" fill="#3B5C86"/><path d="M88 24l3 8 8 3-8 3-3 8-3-8-8-3 8-3z" fill="#F5D98B"/>`],
  gift: ['هدية', `<rect x="24" y="52" width="72" height="46" rx="6" fill="#E2745C"/><rect x="58" y="52" width="10" height="46" fill="#F3D9A4"/><path d="M60 52c-14-4-22-16-14-22s16 8 14 22zm0 0c14-4 22-16 14-22s-16 8-14 22z" fill="#E2745C" stroke="#B8503F" stroke-width="2"/>`],
};

const REPLY = {
  shukran: ['شكرًا', `<rect x="10" y="30" width="100" height="56" rx="22" fill="#F6E1C8" stroke="#D9A876" stroke-width="3"/><path d="M34 86l-6 14 18-14z" fill="#F6E1C8" stroke="#D9A876" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="30" font-family="system-ui,'Segoe UI',sans-serif" fill="#8D5B3F">شكرًا</text>`],
  tamam: ['تمام', `<rect x="10" y="30" width="100" height="56" rx="22" fill="#DCEFE1" stroke="#7FAE8C" stroke-width="3"/><path d="M86 86l6 14-18-14z" fill="#DCEFE1" stroke="#7FAE8C" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="30" font-family="system-ui,'Segoe UI',sans-serif" fill="#3F6B4F">تمّ</text>`],
  minfadlik: ['من فضلك', `<rect x="6" y="30" width="108" height="56" rx="22" fill="#E7E6F5" stroke="#8F8DBF" stroke-width="3"/><path d="M34 86l-6 14 18-14z" fill="#E7E6F5" stroke="#8F8DBF" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="24" font-family="system-ui,'Segoe UI',sans-serif" fill="#4E4C7C">من فضلك</text>`],
  qariban: ['قريبًا', `<rect x="6" y="30" width="108" height="56" rx="22" fill="#FDF0D5" stroke="#D8B36A" stroke-width="3"/><path d="M86 86l6 14-18-14z" fill="#FDF0D5" stroke="#D8B36A" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="24" font-family="system-ui,'Segoe UI',sans-serif" fill="#8A6A22">قريبًا</text>`],
  raie: ['رائع', `<rect x="10" y="30" width="100" height="56" rx="22" fill="#FCE3E8" stroke="#D88AA0" stroke-width="3"/><path d="M34 86l-6 14 18-14z" fill="#FCE3E8" stroke="#D88AA0" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="30" font-family="system-ui,'Segoe UI',sans-serif" fill="#A34A63">رائع!</text>`],
  haq: ['معك حق', `<rect x="6" y="30" width="108" height="56" rx="22" fill="#E2EFF7" stroke="#7FA6C0" stroke-width="3"/><path d="M86 86l6 14-18-14z" fill="#E2EFF7" stroke="#7FA6C0" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="24" font-family="system-ui,'Segoe UI',sans-serif" fill="#3F6B8A">معك حق</text>`],
  asif: ['آسف', `<rect x="10" y="30" width="100" height="56" rx="22" fill="#F1E7DC" stroke="#B79B84" stroke-width="3"/><path d="M34 86l-6 14 18-14z" fill="#F1E7DC" stroke="#B79B84" stroke-width="3"/><text x="60" y="66" text-anchor="middle" font-size="30" font-family="system-ui,'Segoe UI',sans-serif" fill="#6E5643">آسف</text>`],
  yasalam: ['يا سلام', `<rect x="6" y="30" width="108" height="56" rx="22" fill="#FFF3D6" stroke="#E0B357" stroke-width="3"/><path d="M86 86l6 14-18-14z" fill="#FFF3D6" stroke="#E0B357" stroke-width="3"/><text x="60" y="64" text-anchor="middle" font-size="22" font-family="system-ui,'Segoe UI',sans-serif" fill="#8A6A22">يا سلام</text>`],
};

const pack = (id, name, st) => ({ id, name, stickers: Object.entries(st).map(([sid, [title, body]]) => ({ id: sid, title, body })) });
const PACKS = [
  pack('wajh', 'وجوه', FACES),
  pack('qalb', 'قلوب ومشاعر', HEARTS),
  pack('waqt', 'أوقات وأماكن', TIME),
  pack('rudud', 'ردود سريعة', REPLY),
];

let written = 0;
const catalog = { version: Number(process.env.STICKERS_VERSION || 2), updatedAt: new Date().toISOString(), packs: [] };
PACKS.forEach((p) => {
  const dir = path.join(OUT, p.id);
  fs.mkdirSync(dir, { recursive: true });
  const stickers = p.stickers.map((s) => {
    fs.writeFileSync(path.join(dir, `${s.id}.svg`), wrap(s.body), 'utf8');
    written += 1;
    return { id: s.id, title: s.title };
  });
  catalog.packs.push({ id: p.id, name: p.name, stickers });
});
fs.writeFileSync(INDEX, JSON.stringify(catalog, null, 2) + '\n', 'utf8');
console.log(`✓ ${written} ملصقًا في ${catalog.packs.length} حزم → ${INDEX}`);

#!/bin/sh
# استعادة موقع «سوى» داخل الساندبوكس — أمر واحد.
# الاستخدام:  sh tools/launch.sh
#
# لا نُشغّل الخادم يدويًا هنا: وكيل الساندبوكس هو من يُشغّله عند التسجيل (وتسجيله
# عاديّ التكرار: إعادة الطلب تُعيد العملية القائمة نفسها). تشغيل نسخة يدوية كان
# يُنتج خادمين على منفذين مختلفين ويتشوّش أي تشخيص لاحق.
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
APP=$(cd "$HERE/.." && pwd)
AGENT=http://127.0.0.1:9000
DEPLOY=b239a8a905a64208

echo "— 0/4 تنظيف آمن (يمنع تراكم الحزم اليتيمة ومجلدات الفحص) —"
cd "$APP" && node tools/prune.js 2>&1 | tail -4 || echo "  (تعذّر التنظيف — نكمل)"

echo "— 1/4 تحقّق من صدفة الفتح الواحد —"
if [ ! -f "$APP/server/shell.html" ]; then
  echo "  لا توجد server/shell.html — أنشئها: (cd client && npm run build)"
else
  echo "  موجودة: $(wc -c < "$APP/server/shell.html") بايت"
fi

echo "— 2/4 تسجيل الموقع في وكيل الساندبوكس —"
curl -s -m 30 -X POST "$AGENT/sites" -H 'Content-Type: application/json' \
  -d "{\"deploy_id\":\"$DEPLOY\",\"workdir\":\"sites/sawa-app/server\",\"run_cmd\":\"node index.js\"}"
echo

echo "— 3/4 تشغيل الحارس (يبقيه مسجّلًا ويعمل) —"
cd "$APP"
setsid nohup node tools/watch-site.js >> "$APP/qa/watchdog.log" 2>&1 < /dev/null &
sleep 4

echo "— الحالة —"
curl -s -m 10 "$AGENT/sites" | head -c 300; echo
echo "الرابط: https://$DEPLOY.preview.sanaabot.com/"
echo "السجل:  tail -f qa/watchdog.log"

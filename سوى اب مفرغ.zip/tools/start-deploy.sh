#!/bin/sh
# نقطة تشغيل بديلة لخادم «سوى» في بيئة النشر/الساندبوكس.
# تُستخدم إن شغّل المشغّل هذا الملف بدل الأمر المباشر:
#   cd sites/sawa-app/server && node index.js
# المنفذ من البيئة (PORT) كما يُعطيه الوكيل، والخادم نفسه يتولّى البقية.
LOG_DIR=$(cd "$(dirname "$0")/.." && pwd)
LOG="$LOG_DIR/qa/deploy-env.log"
log() { echo "[$(date -u +%H:%M:%S)] $*" >> "$LOG" 2>/dev/null; echo "[$(date -u +%H:%M:%S)] $*"; }

log "start cwd=$(pwd) PORT=${PORT:-<unset>} HOST=${HOST:-<unset>}"

# 1) مجلد الخادم: أولًا بجانب هذا السكربت، ثم مسار نسبي من مساحة العمل
SRV="$LOG_DIR/server"
if [ ! -d "$SRV" ]; then
  SRV=$(find / -maxdepth 7 -type d -path '*sites/sawa-app/server' 2>/dev/null | head -1)
fi
if [ ! -d "$SRV" ]; then
  log "FATAL server dir not found"
  exit 1
fi
cd "$SRV" || exit 1
log "using dir=$(pwd)"

# 2) المنفذ: من البيئة، وإلا الافتراضي داخل الخادم
if [ -z "$PORT" ]; then
  PORT=5056
  log "PORT unset -> default $PORT"
fi
export PORT
# تنظيف آمن قبل الإقلاع: يمنع تراكم حزم البناء اليتيمة ومجلدات الفحص المؤقتة.
# لا يلمس data/db.json ولا data/uploads — راجع tools/prune.js
if command -v node >/dev/null 2>&1 && [ -f "$SRV/../tools/prune.js" ]; then
  (cd "$SRV/.." && node tools/prune.js 2>&1 | tail -3) >> "$LOG" 2>&1 || true
fi
log "exec node index.js with PORT=$PORT HOST=${HOST:-0.0.0.0}"
exec node index.js

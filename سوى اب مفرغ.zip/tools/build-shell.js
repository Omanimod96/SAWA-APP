#!/usr/bin/env node
/**
 * يبني «الصدفة الواحدة» (server/shell.html) من ناتج البناء client/dist.
 *
 * السبب: وكيل الساندبوكس يخدم الطلبات واحدًا واحدًا بمعدل ~٢ ثانية للطلب الواحد
 * (قياس: ٥ طلبات متوازية استغرقت ٨.٥–٩.٢ ثانية لملف واحد صغير). فكل طلب إضافي
 * يعني ~٢ ثانية تأخير في الفتح. بدمج CSS وJS داخل صفحة واحدة يصبح فتح التطبيق
 * طلبًا واحدًا فقط بدل أربعة، ثم يتولّى عامل الخدمة تخزينها فيصير الفتح التالي فوريًا.
 *
 * الاستخدام:  node tools/build-shell.js
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const crypto = require('crypto');

const ROOT = path.join(__dirname, '..');
const DIST = path.join(ROOT, 'client', 'dist');
const OUT = path.join(ROOT, 'server', 'shell.html');
const META = path.join(ROOT, 'server', 'shell.json');
const INDEX = path.join(DIST, 'index.html');
const TOKEN = '__SAWA_BOOT_JSON__';

if (!fs.existsSync(INDEX)) {
  console.error('✗ لا يوجد dist/index.html — شغّل البناء أولًا (npm run build داخل client/)');
  process.exit(1);
}

const html = fs.readFileSync(INDEX, 'utf8');
const assetPath = (f) => path.join(DIST, 'assets', path.basename(f));

const jsRefs = [...new Set([...html.matchAll(/assets\/[A-Za-z0-9_.-]+\.js/g)].map((m) => m[0]))];
const cssRefs = [...new Set([...html.matchAll(/assets\/[A-Za-z0-9_.-]+\.css/g)].map((m) => m[0]))];

if (jsRefs.length !== 1 || cssRefs.length !== 1) {
  console.error(`✗ البناء ليس حزمة واحدة (js=${jsRefs.length} css=${cssRefs.length}) — أعد البناء`);
  process.exit(1);
}

const missing = [...jsRefs, ...cssRefs].filter((r) => !fs.existsSync(assetPath(r)));
if (missing.length) {
  console.error('✗ مراجع البناء مفقودة: ' + missing.join(', '));
  process.exit(1);
}

// منع إغلاق الوسم داخل النص المُدمج (‏</script> أو </style> داخل الشيفرة)
const safeJs = (s) => s.replace(/<\/script/gi, '<\\/script').replace(/<!--/g, '<\\!--');
const safeCss = (s) => s.replace(/<\/style/gi, '<\\/style');

const js = safeJs(fs.readFileSync(assetPath(jsRefs[0]), 'utf8'));
const css = safeCss(fs.readFileSync(assetPath(cssRefs[0]), 'utf8'));

// بصمة الصدفة: تُطبع داخل الصفحة وفي /api/health، فيعرف أي إصدار يخدم فعلًا بلا
// تخمين — تُلزمنا بها شكوى «الحزمة القديمة المخزّنة» التي يصعب كشفها من الخارج.
const BUILT_AT = new Date().toISOString();
const STAMP = crypto.createHash('md5').update(js).digest('hex').slice(0, 10);
const BUILD_TAG = `${STAMP}.${Buffer.byteLength(js)}`;
const buildMeta = `<meta name="sawa-build" content="${BUILD_TAG}">`;

// حارس الصياغة: أي تغيير في شيفرة الحزمة أثناء التضمين يُسقط التطبيق بصمت
// (تعلّمناها من عطل «الشاشة العالقة»: String.replace يفسّر $$ و $& داخل نص
//  الاستبدال، فتحوّل $$typeof في React إلى $typeof → SyntaxError وبقيت الصدفة).
function assertJsSyntax(code) {
  const tmp = path.join(os.tmpdir(), 'sawa-shell-check-' + process.pid + '.mjs');
  try {
    fs.writeFileSync(tmp, code, 'utf8');
    const r = spawnSync(process.execPath, ['--check', tmp], { encoding: 'utf8' });
    if (r.status !== 0) {
      console.error('✗ شيفرة الحزمة لا تجتاز فحص الصياغة — أوقفنا البناء:');
      console.error((r.stderr || '').split('\n').slice(0, 6).join('\n'));
      process.exit(1);
    }
  } finally {
    try { fs.unlinkSync(tmp); } catch (e) { /* تجاهل */ }
  }
}
assertJsSyntax(js);

// نُزيل وسوم الملفات الخارجية ثم نُدمجها في مكانها
let out = html
  .replace(/<link[^>]+rel="stylesheet"[^>]*assets\/[^>]*>\s*/gi, '')
  .replace(/<script[^>]+src="[^"]*assets\/[^"]*"[^>]*><\/script>\s*/gi, '');

const splash = `
    <div class="boot-splash" id="boot-splash">
      <div class="boot-mark">سوى</div>
      <div class="boot-line">نجمع دائرتك…</div>
    </div>`;
if (out.includes('<div id="root"></div>')) out = out.split('<div id="root"></div>').join(`<div id="root">${splash}</div>`);

const styleTag = `<style>\n${css}\n</style>`;
const bootTag = `<script>window.__SAWA_BOOT__=${TOKEN};</script>`;
const jsTag = `<script type="module">\n${js}\n</script>`;

// إدراج بالتقطيع لا بـ replace: نص الاستبدال في String.replace يفسّر $$ و $& و $`
const insertBefore = (hay, needle, insert) => {
  const i = hay.indexOf(needle);
  if (i < 0) return null;
  return hay.slice(0, i) + insert + hay.slice(i);
};

const withCss = insertBefore(out, '</head>', `${buildMeta}\n  ${styleTag}\n  `);
if (withCss === null) { console.error('✗ لا يوجد </head> في القالب'); process.exit(1); }
const withTags = insertBefore(withCss, '</body>', `${bootTag}\n${jsTag}\n  `);
if (withTags === null) { console.error('✗ لا يوجد </body> في القالب'); process.exit(1); }
out = withTags;

if (!out.includes(TOKEN)) {
  console.error('✗ تعذّر إدراج موضع بيانات الإقلاع — تحقّق من dist/index.html');
  process.exit(1);
}

// تحقّق نهائي: الشيفرة المُدمجة يجب أن تكون مطابقة حرفيًا للحزمة المصدرية
if (!out.includes(js)) {
  console.error('✗ الشيفرة المُدمجة تغيّرت أثناء التضمين — أوقفنا البناء');
  process.exit(1);
}

fs.writeFileSync(OUT, out, 'utf8');
fs.writeFileSync(
  META,
  JSON.stringify(
    {
      builtAt: BUILT_AT,
      stamp: STAMP,
      shellBytes: Buffer.byteLength(out),
      js: jsRefs[0],
      jsBytes: Buffer.byteLength(js),
      css: cssRefs[0],
      cssBytes: Buffer.byteLength(css),
    },
    null,
    2
  ),
  'utf8'
);

const kb = (n) => (n / 1024).toFixed(1);
console.log(`  بصمة الصدفة: ${BUILD_TAG} · ${BUILT_AT}`);
console.log(`✓ صدفة واحدة: server/shell.html (${kb(Buffer.byteLength(out))} ك.ب)`);
console.log(`  JS مُدمج: ${jsRefs[0]} (${kb(Buffer.byteLength(js))} ك.ب)`);
console.log(`  CSS مُدمج: ${cssRefs[0]} (${kb(Buffer.byteLength(css))} ك.ب)`);
console.log('  الفتح الآن: طلب واحد للصفحة كاملة بدل ٤ طلبات');

#!/usr/bin/env node
/**
 * تنظيف آمن وقابل للتكرار لمشروع «سوى اب».
 *
 * السبب: عمليات نسخ/استعادة خارجية (‏.tmp-restore، استعادة الجلسة، أرشيفات قديمة)
 * كانت تُعيد إلى المشروع ملفات لا يحتاجها أحد: ١٦ حزمة بناء يتيمة في
 * client/dist/assets (~١.٥ م.ب)، ومجلدات فحص مؤقتة في qa/ تُنشئها سكربتات الفحص
 * نفسها من جديد (‏qa/iso وqa/run معًا ~٧٥ م.ب)، ونسخًا قديمة من قاعدة البيانات
 * وأرشيفات تجاوزها الزمن. لذلك صار التنظيف خطوة مُقادة بالسكربت لا بالنقر اليدوي.
 *
 * آمن بالتصميم:
 *  - لا يلمس الكود المصدري ولا data/db.json ولا data/uploads أبدًا.
 *  - لا يحذف حزمة بناء يشير إليها client/dist/index.html.
 *  - الوضع الآمن (--safe، يُستدعى من الحارس كل ~٣٠ ثانية) يقتصر على ناتج البناء
 *    ومخلفات الاستعادة: لا يمسّ الأرشيفات في backups/ ولا مجلدات فحص جارية ولا خوادم.
 *  - في الوضع الكامل: أي أرشيف موثَّق في MANIFEST لا يُحذف أبدًا (لقطة مقصودة)،
 *    ويُبقى أحدث أرشيف احتياطي دائمًا (‏--keep-archives، الافتراضي ٢).
 *  - يقتل فقط خوادم الفحص المتروكة (‏SAWA_DATA_DIR داخل qa/) ولا يقترب من
 *    الخادم المسجَّل للموقع ولا من الحارس tools/watch-site.js.
 *
 * الاستخدام:
 * ويشمل أيضًا: مخلفات الفحص النصية واللقطات في qa/ (‏*.out و*.png و__pycache__
 * وqa/shots وqa/scratch)، والنسخ المستخرجة من حزم الإصدارات في exports/، ولقطات
 * الفحص في downloads/، ومخلفات جذر مساحة العمل (.tmp-*، demo_build، المهملات،
 * ذاكرة npm). كلها ليست من الكود ولا من ناتج البناء.
 *
 * الاستخدام:
 *   node tools/prune.js            # تنظيف فعلي
 *   node tools/prune.js --dry-run  # عرض ما سيُحذف بلا حذف
 */
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const DRY = process.argv.includes('--dry-run');
// الوضع الآمن: ينظّف ناتج البناء ومخلفات الاستعادة فقط — يُستدعى من الحارس كل دورة
// لأنه لا يمسّ شيئًا يعمل الآن (لا مجلدات فحص جارية، لا خوادم، لا نسخ قاعدة).
const SAFE = process.argv.includes('--safe');
const keepArg = process.argv.indexOf('--keep-archives');
const parsed = keepArg > -1 ? Number(process.argv[keepArg + 1]) : NaN;
const KEEP_ARCHIVES = Number.isFinite(parsed) && parsed >= 0 ? parsed : 2;
let freed = 0;
const actions = [];

const kb = (n) => (n / 1024).toFixed(0) + ' ك.ب';

function sizeOf(p) {
  try {
    const st = fs.lstatSync(p);
    if (!st.isDirectory()) return st.size;
  } catch {
    return 0;
  }
  let total = 0;
  const walk = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const fp = path.join(dir, e.name);
      if (e.isDirectory()) walk(fp);
      else if (e.isFile()) {
        try {
          total += fs.lstatSync(fp).size;
        } catch {}
      }
    }
  };
  try {
    walk(p);
  } catch {}
  return total;
}

function rm(p, why) {
  if (!fs.existsSync(p)) return false;
  const s = sizeOf(p);
  freed += s;
  if (DRY) {
    actions.push(`[عرض] ${path.relative(ROOT, p)} — ${why} (${kb(s)})`);
    return true;
  }
  try {
    fs.rmSync(p, { recursive: true, force: true });
    actions.push(`✓ ${path.relative(ROOT, p)} — ${why} (${kb(s)})`);
    return true;
  } catch (e) {
    actions.push(`✗ تعذّر حذف ${path.relative(ROOT, p)}: ${e.message}`);
    return false;
  }
}

// ── ١) ناتج البناء: أبقِ ما يشير إليه index.html فقط ──────────────────────────
const DIST = path.join(ROOT, 'client', 'dist');
const ASSETS = path.join(DIST, 'assets');
const INDEX = path.join(DIST, 'index.html');
if (fs.existsSync(ASSETS) && fs.existsSync(INDEX)) {
  const html = fs.readFileSync(INDEX, 'utf8');
  const keep = new Set(
    [...html.matchAll(/assets\/[A-Za-z0-9_.-]+/g)].map((m) => path.basename(m[0])),
  );
  if (!keep.size) {
    actions.push('⏭ client/dist/assets — لا مراجع في index.html، تخطّيت الحذف');
  } else {
    for (const f of fs.readdirSync(ASSETS)) {
      if (!keep.has(f)) rm(path.join(ASSETS, f), 'حزمة بناء يتيمة');
    }
  }
} else {
  actions.push('⏭ client/dist/assets — غير موجود، تخطّيت');
}

// ── ٢) مجلدات الفحص المؤقتة (سكربتات الفحص تُنشئها من جديد) ──────────────────
const QA_SCRATCH = SAFE
  ? []
  : [
      'qa/iso', 'qa/run', 'qa/run2', 'qa/sweep', 'qa/live', 'qa/perf', 'qa/data-before-athar',
    ];
for (let i = 0; i <= 9; i++) if (!SAFE) QA_SCRATCH.push(`qa/probe${i ? i : ''}`);
for (const rel of QA_SCRATCH) rm(path.join(ROOT, rel), 'مجلد فحص مؤقت');

if (!SAFE)
  for (const e of fs.existsSync(path.join(ROOT, 'qa'))
    ? fs.readdirSync(path.join(ROOT, 'qa'), { withFileTypes: true })
    : []) {
    if (e.isDirectory() && /^backup-\d{8}-\d{6}$/.test(e.name)) {
      rm(path.join(ROOT, 'qa', e.name), 'لقطة فحص قديمة');
    }
  }

// ── ٣) نسخ قاعدة البيانات القديمة في qa/ (يبقيها live_check.py عند كل تشغيل) ──
const qaDir = path.join(ROOT, 'qa');
if (!SAFE && fs.existsSync(qaDir)) {
  const dumps = fs
    .readdirSync(qaDir)
    .filter((f) => /^(db-before-|db-backup-|backup-before-|backup-index\.js\.)/.test(f))
    .sort();
  for (const f of dumps) rm(path.join(qaDir, f), 'نسخة قاعدة قديمة');
  for (const f of fs.readdirSync(qaDir)) {
    if (/^(live-preview-|live-athar-|ui-states)/.test(f) && f.endsWith('.png')) {
      rm(path.join(qaDir, f), 'لقطة شاشة قديمة');
    }
  }
}

// ── ٤) قاعدة بيانات تالفة في data/ (ملفات db.broken-*) ───────────────────────
for (const f of (SAFE ? [] : fs.readdirSync(path.join(ROOT, 'data')))) {
  if (/^db\.broken-\d+\.json$/.test(f)) rm(path.join(ROOT, 'data', f), 'قاعدة تالفة');
}

// ── ٥) الأرشيفات: نسخة واحدة معتمدة + الأحدث من كل عائلة ─────────────────────
// العمليات الخارجية (مزامنة الجلسة) تُنشئ أرشيفات جديدة وتُعيد القديم منها،
// فنجمعها في عائلتين: restore (الاستعادة المعتمدة) وkeepset (لقطة المزامنة)،
// ونُبقي الأحدث في كل عائلة فقط. أي أرشيف يحمل مجلدات فحص مؤقتة أو
// node_modules يُعدّ تالف المحتوى ويُحذف مهما كان اسمه.
const BAK = path.join(ROOT, 'backups');
const JUNK_IN_ARCHIVE = /(^|\/)(qa\/(iso|run2?|probe\d*|sweep|live)\/|node_modules\/)/;
function archiveHasJunk(file) {
  try {
    const out = spawnSync('tar', ['-tzf', path.join(BAK, file)], {
      encoding: 'utf8',
      maxBuffer: 32 * 1024 * 1024,
    });
    return JUNK_IN_ARCHIVE.test(out.stdout || '');
  } catch {
    return false;
  }
}
if (!SAFE && fs.existsSync(BAK)) {
  const all = fs
    .readdirSync(BAK)
    .filter((f) => f.endsWith('.tar.gz'))
    .map((f) => ({ f, t: fs.statSync(path.join(BAK, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);
  // ٥‑٠) أرشيف مُوثَّق في بيان (MANIFEST) = لقطة مقصودة بيد المستخدم/الوكيل —
  // لا يُحذف أبدًا. السبب: تنظيف تلقائي حذف في 18 سبتمبر لقطة sawa-contacts-…tar.gz
  // بعائلة «other» لأن الحدّ كان ٢، والبيان بقي بلا أرشيف.
  const manifests = fs
    .readdirSync(BAK)
    .filter((f) => /^MANIFEST-.*\.md$/.test(f))
    .map((f) => { try { return fs.readFileSync(path.join(BAK, f), 'utf8'); } catch { return ''; } })
    .join('\n');
  const documented = (f) => manifests.includes(f);
  // ٥‑أ) تالف المحتوى (يحمل مجلدات فحص) — يُحذف دائمًا
  const junk = all.filter((a) => archiveHasJunk(a.f));
  for (const a of junk) rm(path.join(BAK, a.f), 'أرشيف يحمل مجلدات فحص مؤقتة');
  const clean = all.filter((a) => !junk.includes(a));
  // ٥‑ب) الأحدث فقط في كل عائلة (والموثَّق مستثنى)
  const family = (f) => (/restore/.test(f) ? 'restore' : /keepset/.test(f) ? 'keepset' : 'other');
  const seen = {};
  for (const a of clean) {
    if (documented(a.f)) continue;
    const k = family(a.f);
    seen[k] = (seen[k] || 0) + 1;
    const limit = k === 'other' ? KEEP_ARCHIVES : 1;
    if (seen[k] > limit) {
      rm(path.join(BAK, a.f), `أرشيف قديم من عائلة ${k} (نُبقي الأحدث ${limit})`);
    }
  }
}

// ── ٦) مخلفات الاستعادة الخارجية ─────────────────────────────────────────────
rm('/workspace/.tmp-restore', 'مخلفات استعادة خارجية');

// ── ٦‑ب) نسخة الاستعادة المعتمدة: تُبنى إن غابت أو حُذف تالفها ────────────────
// المحتوى: الكود + data/db.json + الوسائط + سكربتات الفحص (بلا node_modules
// وبلا مجلدات فحص مؤقتة)، فلا تُعيد الاستعادة أي نفايات إلى المشروع.
const FORCE_RESTORE = process.argv.includes('--build-restore');
if (!DRY && fs.existsSync(BAK)) {
  const hasRestore = fs.readdirSync(BAK).some((f) => /sawa-restore-.*\.tar\.gz$/.test(f));
  if (FORCE_RESTORE || !hasRestore) {
    const stamp = new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '').replace(/(\d{8})(\d{4})/, '$1-$2');
    const name = `sawa-restore-${stamp}.tar.gz`;
    const items = ['README.md', 'DEPLOY-RUNBOOK.md', 'cmd_info.txt', 'client/src', 'client/public',
      'client/index.html', 'client/package.json', 'client/vite.config.js', 'server', 'data/db.json',
      'data/uploads', 'tools', 'qa'];
    const r = spawnSync('tar', [
      '--exclude=node_modules', '--exclude=qa/iso', '--exclude=qa/run', '--exclude=qa/run2',
      '--exclude=qa/probe*', '--exclude=*.log', '-czf', path.join(BAK, name),
      '-C', ROOT, ...items.filter((i) => fs.existsSync(path.join(ROOT, i))),
    ]);
    if (r.status === 0) {
      const kb = (fs.statSync(path.join(BAK, name)).size / 1024).toFixed(0);
      actions.push(`✓ بُنيت نسخة الاستعادة المعتمدة ${name} (${kb} ك.ب)`);
      for (const f of fs.readdirSync(BAK)) {
        if (/sawa-restore-.*\.tar\.gz$/.test(f) && f !== name) {
          rm(path.join(BAK, f), 'نسخة استعادة أقدم');
        }
      }
    } else {
      actions.push(`✗ تعذّر بناء نسخة الاستعادة: ${(r.stderr || '').toString().trim().split('\n')[0]}`);
    }
  }
}

// ── ٧) خوادم الفحص المتروكة (لا يقتل الموقع ولا الحارس) ──────────────────────
// سكربتات الفحص تُشغّل خادمًا على qa/iso/<اسم>؛ إن لم يُقتل بعد الفحص يبقى
// حاجزًا لمنفذه بلا فائدة. نقتل فقط ما يشير SAWA_DATA_DIR فيه إلى qa/.
function killLeakedServers() {
  let pids = [];
  try {
    pids = fs
      .readdirSync('/proc')
      .filter((d) => /^\d+$/.test(d))
      .map(Number);
  } catch {
    return;
  }
  for (const pid of pids) {
    if (pid === process.pid) continue;
    let env = '';
    let cmd = '';
    try {
      env = fs.readFileSync(`/proc/${pid}/environ`, 'utf8');
      cmd = fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8');
    } catch {
      continue;
    }
    if (!/index\.js/.test(cmd.replace(/\0/g, ' '))) continue;
    if (/watch-site\.js/.test(cmd)) continue;
    const m = env.match(/SAWA_DATA_DIR=([^\0]+)/);
    if (!m) continue;
    const dataDir = m[1];
    const isQa = /sites\/sawa-app\/qa\/|sites\/sawa-app\/qa$/.test(dataDir);
    if (!isQa) continue;
    try {
      process.kill(pid, 'SIGKILL');
      actions.push(`✓ أنهيت خادم فحص متروك pid=${pid} (${path.relative('/workspace', dataDir)})`);
    } catch (e) {
      actions.push(`✗ تعذّر إنهاء pid=${pid}: ${e.message}`);
    }
  }
}
if (!SAFE) killLeakedServers();

// ── ٨) مخلفات الفحص داخل qa/: نصوص ولقطات ومجلدات يولّدها كل تشغيل ────────────
// السبب: سكربتات الفحص تكتب في qa/ ملفات .out وسجلات ولقطات .png ومجلدات
// shots/scratch و__pycache__ بمعدل عشرات الميغابايت في الجلسة الواحدة، ولا
// يحتاجها أي فحص لاحق لأنه يعيد إنشاءها بنفسه. لا تُمَس السكربتات (*.py/*.sh/
// *.mjs/*.js) ولا qa/fixtures (ملفات الإدخال التي تستعملها الفحوص).
if (!SAFE) {
  const QA = path.join(ROOT, 'qa');
  for (const d of ['shots', 'scratch', 'sweep', 'run2']) rm(path.join(QA, d), 'مجلد مخرجات فحص');
  if (fs.existsSync(QA)) {
    for (const e of fs.readdirSync(QA, { withFileTypes: true })) {
      const p = path.join(QA, e.name);
      if (e.isDirectory()) {
        if (e.name === '__pycache__') rm(p, 'ذاكرة بايثون المؤقتة');
        else if (e.name === '.neg-src') rm(p, 'نسخة مصدرية لحالة فحص سلبية');
        continue;
      }
      if (/\.(out|log)$/.test(e.name)) rm(p, 'سجل تشغيل فحص');
      else if (/\.png$/.test(e.name)) rm(p, 'لقطة فحص');
      else if (/^\.token.*\.json$/.test(e.name)) rm(p, 'رمز جلسة فحص');
      else if (/^\.(run\.lock|marker-test\.txt|prune-test\.txt)$/.test(e.name))
        rm(p, 'قفل/علامة فحص');
    }
  }
}

// ── ٩) حزم الإصدارات: أبقِ الأرشيف المضغوط، أزل ما استُخرج منه ────────────────
const EXP = path.join(ROOT, 'exports');
if (!SAFE && fs.existsSync(EXP)) {
  for (const e of fs.readdirSync(EXP, { withFileTypes: true })) {
    if (e.isDirectory()) rm(path.join(EXP, e.name), 'نسخة مستخرجة من حزمة إصدار');
  }
}

// ── ١٠) لقطات الفحص المحفوظة داخل المشروع (downloads/) ──────────────────────
if (!SAFE) rm(path.join(ROOT, 'downloads'), 'لقطات فحص داخل مجلد المشروع');

// ── ١١) مخلفات مساحة العمل خارج المشروع ─────────────────────────────────────
// السبب: الجولات السابقة والمنصة تُخلّف مجلدات مؤقتة بجذر مساحة العمل (.tmp-*،
// demo_build، مجلد المهملات، ذاكرة npm). لا علاقة لها بالتطبيق ولا بالكود المنشور،
// وحذفها لا يمسّ أي ملف مصدري — ذاكرة npm وحدها ~٢٣٠ م.ب وتُعاد تعبئتها عند الحاجة
// (السجل npm متاح: تحقّقنا من الوصول إليه).
const WS = '/workspace';
const trash = path.join(WS, '.sanaa-trash');
if (fs.existsSync(trash))
  for (const e of fs.readdirSync(trash)) rm(path.join(trash, e), 'مهملات المنصة');
for (const rel of ['.sanaa-tmp', '.tmp-hostpkg', '.tmp-inspect', 'demo_build', 'WRITE_TEST.txt'])
  rm(path.join(WS, rel), 'مخلفات جولة سابقة بجذر مساحة العمل');
const driveTmp = path.join(WS, '.drive-tmp');
if (fs.existsSync(driveTmp))
  for (const e of fs.readdirSync(driveTmp)) {
    const p = path.join(driveTmp, e);
    try {
      if (Date.now() - fs.statSync(p).mtimeMs > 3600e3) rm(p, 'مخلفات رفع مؤقتة (أقدم من ساعة)');
    } catch {}
  }
rm(path.join(WS, '.npm', '_cacache'), 'ذاكرة npm المؤقتة (تُنزَّل الحزم عند الحاجة)');

// ── التقرير ──────────────────────────────────────────────────────────────────
const mode = SAFE ? 'آمن (ناتج البناء فقط)' : DRY ? 'عرض فقط (بلا حذف)' : 'تنفيذ';
if (SAFE && !actions.length) process.exit(0); // الحارس: صامت إن كان كل شيء نظيفًا
console.log(`══ تنظيف «سوى اب» — ${mode} ══`);
if (!actions.length) console.log('  لا شيء للحذف — المشروع نظيف أصلًا');
else {
  const shown = actions.slice(0, 40);
  for (const a of shown) console.log('  ' + a);
  if (actions.length > shown.length) console.log(`  … و${actions.length - shown.length} عنصرًا آخر`);
}
console.log(
  `── الإجمالي: ${actions.filter((a) => a.startsWith('✓') || a.startsWith('[عرض]')).length} عنصرًا · ` +
    `${(freed / 1048576).toFixed(1)} م.ب ${DRY ? '(سيُحرَّر)' : 'حُرِّرت'}`,
);
if (!DRY) {
  const after = sizeOf(ROOT);
  console.log(`── حجم المشروع الآن: ${(after / 1048576).toFixed(1)} م.ب`);
}
console.log('── لم يُلمس: server/ · client/src · data/db.json · data/uploads · tools/ · qa/*.py|js|sh');

#!/usr/bin/env bash
# إعادة تشغيل خادم النشر محليًا على المنفذ نفسه إن لم تُعِده المنصة.
# الاستخدام: bash tools/relaunch-local.sh <PORT>
set -u
PORT="${1:-50733}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT/server" || exit 1
if curl -sf -m 2 "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then
  echo "الخادم يعمل أصلًا على $PORT"; exit 0
fi
setsid env HOST=127.0.0.1 PORT="$PORT" nohup node index.js >> run.log 2>&1 < /dev/null &
sleep 3
if curl -sf -m 3 "http://127.0.0.1:$PORT/api/health" >/dev/null 2>&1; then
  echo "✓ أُعيد التشغيل على $PORT (pid $(pgrep -f "PORT=$PORT node index.js" | head -1))"
else
  echo "✗ فشل إعادة التشغيل"; exit 1
fi

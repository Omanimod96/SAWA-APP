#!/bin/sh
# نقطة إقلاع موحّدة لخادم «سوى» داخل الساندبوكس/النشر.
#
# تُشغَّل عند كل إقلاع، فتعالج ثلاث مشاكل معروفة الأثر:
#   ١) node_modules لا تُحفظ مع الاستعادة → تُثبَّت تلقائيًا إن كانت ناقصة
#   ٢) حزم بناء قديمة تعود إلى client/dist/assets → تُنظَّف قبل الخدمة
#   ٣) مخلفات فحص مؤقتة تتراكم في qa/ → تنظيف آمن في الخلفية (لا يلمس data/)
#
# الاستخدام:  sh tools/boot.sh        (PORT من البيئة، وإلا 5056)
set -u
HERE=$(cd "$(dirname "$0")" && pwd)
APP=$(cd "$HERE/.." && pwd)
mkdir -p "$APP/qa"
LOG="$APP/qa/boot.log"
say() { echo "[$(date -u +%FT%TZ)] $*"; echo "[$(date -u +%FT%TZ)] $*" >> "$LOG" 2>/dev/null; }

cd "$APP" || exit 1
say "boot: app=$APP port=${PORT:-unset} host=${HOST:-unset}"

command -v node >/dev/null 2>&1 || { say "FATAL: node missing"; exit 1; }

# ── ١) الاعتماديات ────────────────────────────────────────────────────────────
if [ ! -d "$APP/server/node_modules/express" ]; then
  say "deps: installing (normal after a sandbox restore)"
  (cd "$APP/server" && npm ci --omit=dev --no-audit --no-fund >>"$LOG" 2>&1) \
    || (cd "$APP/server" && npm install --omit=dev --no-audit --no-fund >>"$LOG" 2>&1) \
    || say "deps: install failed"
fi
if [ -d "$APP/server/node_modules/express" ]; then say "deps: ok"; else say "deps: MISSING"; fi

# ── ٢) نظافة مجلد البناء (قبل الخدمة، سريع) ───────────────────────────────────
if [ -f "$APP/client/dist/index.html" ]; then
  if node "$APP/tools/clean-dist.js" >>"$LOG" 2>&1; then say "dist: clean"; else say "dist: clean skipped (see log)"; fi
fi

# ── ٣) تنظيف آمن لمخلفات الفحص (≈٢ ثانية، لا يلمس data/) ─────────────────────
if [ -f "$APP/tools/prune.js" ]; then
  if node "$APP/tools/prune.js" >>"$LOG" 2>&1; then say "prune: ok"; else say "prune: skipped"; fi
fi

# ── ٤) الإقلاع ────────────────────────────────────────────────────────────────
PORT="${PORT:-5056}"
export PORT
say "exec: node index.js on ${HOST:-0.0.0.0}:$PORT"
cd "$APP/server" || exit 1
exec node index.js >>"$APP/run.log" 2>&1

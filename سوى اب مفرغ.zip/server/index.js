const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const store = require('./store');
const geo = require('./geo');
const auth = require('./auth');
const privLayer = require('./privacy');
const v31 = require('./v31');
const rtc = require('./rtc');
const voice = require('./voice');
const stickers = require('./stickers');

// مركز المدينة الافتراضي (مسقط) — يُستخدم لوصف بُعد الأثر عند غياب الموقع
const CITY_CENTER = { lat: 23.588, lng: 58.3829 };

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0';
// المنفذ الذي استُمع عليه فعلًا — يُظهره /api/health للتشخيص
let boundPort = 0;

// لا نضغط في الخادم: وكيل الساندبوكس يضغط بنفسه عند طلب المتصفح، لكنه يُسقط
// ترويسة Content-Encoding من استجابتنا — فيصل الجسم مضغوطًا بلا تعريف ويتعطّل
// العرض (ظهر ذلك فعليًا: صفحة مشوّهة بلا #root). نترك الضغط للوكيل.

app.use(cors());
app.use(express.json({ limit: '16mb' }));

// ── الدخول بالهاتف: /api/auth/* ثم بوابة اختيارية على بقية /api ──
app.use('/api/auth', auth.router);
app.use('/api', auth.gate);
// v31: طبقة الخصوصية الجديدة — هوية إلزامية على كل مسار، والفلترة لحظة القراءة
app.use('/api/v31', v31.router);
// v32: الاتصال الصوتي والمرئي — إشارات مكالمة بهوية إلزامية وقناة دفع حيّة
app.use('/api/rtc', rtc.router);
if (auth.info().demo) {
  console.warn(`[smart-social] وضع التجربة: رمز التحقق ثابت ${auth.info().demoCode} — لا تستخدمه في الإنتاج (SAWA_DEMO_OTP=off للتعطيل)`);
}
if (auth.STRICT) console.warn('[smart-social] SAWA_AUTH=strict: كل /api تحتاج جلسة صالحة');

// ── وسائط الحالات: صورة / فيديو / صوت ──
const DATA_DIR = process.env.SAWA_DATA_DIR
  ? path.resolve(process.env.SAWA_DATA_DIR)
  : path.join(__dirname, '..', 'data');
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ── تهيئة المخزن عند الإقلاع ──
// db.json كان يُنشأ عند أول قراءة بيانات فقط، فيظهر /api/health بـ db:false
// على خادم لم يُخدم فيه أي طلب مخزن بعد. الآن نُهيّئه قبل الاستماع.
const BOOT = (() => {
  try {
    store.init();
    // ترحيل v31: لا يبقى رقم هاتف خام على القرص، وتُهيّأ مجموعات الطبقة الجديدة
    store.mutate((d) => { privLayer.ensure(d); privLayer.migrateAccounts(d); voice.ensure(d); return d; });
    const bytes = fs.statSync(store.DB_FILE).size;
    console.log(`[smart-social] المخزن جاهز: ${store.DB_FILE} (${bytes} بايت)`);
    return { ok: true, bytes, error: null };
  } catch (e) {
    console.error('[smart-social] تعذّر تهيئة المخزن:', e && e.message);
    return { ok: false, bytes: -1, error: (e && e.message) || 'unknown' };
  }
})();

app.use('/api/media', express.static(UPLOAD_DIR, { maxAge: '1h', acceptRanges: true }));

// ملصقات الحزم: ملفات SVG ثابتة تُخدَم كوسائط (يحتاجها <img> بلا ترويسة رمز)
app.use('/api/stickers/files', express.static(stickers.DIR, {
  maxAge: '7d',
  immutable: true,
  setHeaders: (res) => res.setHeader('Cache-Control', 'public, max-age=604800, immutable'),
}));

// ── التسجيلات الصوتية: ملفات على القرص بروابط موقّعة ومحصورة بجلسة صالحة ────
// لا قاعدة بيانات تحمل صوتًا، ولا وصول مباشر إلى تسجيل غيره: الرابط يحمل توقيع
// HMAC بصلاحية محدودة، والملف المطلوب بلا توقيع صحيح يُرفض قبل أي قرص (٩).
const VOICE_DIR = path.join(UPLOAD_DIR, 'voice');
if (!fs.existsSync(VOICE_DIR)) fs.mkdirSync(VOICE_DIR, { recursive: true });

app.get('/api/stickers', (req, res) => {
  if (!auth.accountOfToken(auth.tokenOf(req)) && auth.STRICT) {
    return res.status(401).json({ error: 'سجّل الدخول أولًا', code: 'no_session' });
  }
  return ok(res, stickers.forClient());
});

app.post('/api/voice', (req, res) => {
  const acc = auth.accountOfToken(auth.tokenOf(req));
  if (!acc) return fail(res, 401, 'سجّل الدخول أولًا');
  let saved = null;
  try {
    store.mutate((d) => {
      voice.ensure(d);
      const out = voice.save(d, acc.id, { ...(req.body || {}), dir: VOICE_DIR });
      saved = out;
      return d;
    });
  } catch (e) {
    return fail(res, 500, 'تعذّر حفظ التسجيل');
  }
  if (!saved || !saved.ok) return fail(res, saved ? saved.code : 400, saved ? saved.error : 'تعذّر حفظ التسجيل');
  return ok(res, { url: saved.url, file: saved.file, mime: saved.mime, size: saved.size, durationMs: saved.durationMs });
});

// تشغيل تسجيل: جلسة صالحة + توقيع صحيح. ويدعم النطاقات لأن iOS لا يشغّل صوتًا بلا Range.
app.get('/api/voice/:file', (req, res) => {
  const acc = auth.accountOfToken(auth.tokenOf(req));
  if (!acc) return fail(res, 401, 'سجّل الدخول أولًا');
  const file = String(req.params.file || '');
  if (!/^[A-Za-z0-9._-]+$/.test(file) || file.includes('..')) return fail(res, 400, 'اسم ملف غير صالح');
  const link = voice.checkLink(file, req.query.k, req.query.e);
  if (!link.ok) return fail(res, link.code, link.code === 410 ? 'انتهت صلاحية الرابط' : 'رابط غير صالح');
  const abs = path.join(VOICE_DIR, file);
  let st = null;
  try { st = fs.statSync(abs); } catch (e) { return fail(res, 404, 'التسجيل غير موجود'); }
  const row = voice.ownerOf(store.read(), file);
  const ext = path.extname(file).slice(1);
  const MIME = { webm: 'audio/webm', ogg: 'audio/ogg', m4a: 'audio/mp4', mp4: 'audio/mp4', mp3: 'audio/mpeg', wav: 'audio/wav' };
  res.setHeader('Content-Type', (row && row.mime) || MIME[ext] || 'application/octet-stream');
  res.setHeader('Cache-Control', 'private, max-age=3600');
  res.setHeader('Accept-Ranges', 'bytes');
  const range = String(req.headers.range || '');
  const m = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (m) {
    let start = m[1] === '' ? st.size - Number(m[2] || 0) : Number(m[1]);
    let end = m[1] === '' || m[2] === '' ? st.size - 1 : Number(m[2]);
    start = Math.max(0, Math.min(start, st.size - 1));
    end = Math.max(start, Math.min(end, st.size - 1));
    res.status(206);
    res.setHeader('Content-Range', `bytes ${start}-${end}/${st.size}`);
    res.setHeader('Content-Length', end - start + 1);
    return fs.createReadStream(abs, { start, end }).pipe(res);
  }
  res.setHeader('Content-Length', st.size);
  return fs.createReadStream(abs).pipe(res);
});


const EXT_BY_MIME = {
  'image/png': 'png', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/webp': 'webp',
  'image/gif': 'gif', 'image/avif': 'avif', 'image/svg+xml': 'svg',
  'video/mp4': 'mp4', 'video/webm': 'webm', 'video/quicktime': 'mov',
  'audio/webm': 'webm', 'audio/ogg': 'ogg', 'audio/mpeg': 'mp3',
  'audio/mp4': 'm4a', 'audio/x-m4a': 'm4a', 'audio/wav': 'wav', 'audio/x-wav': 'wav',
  // مستندات: تُشارَك في المحادثات (المشاركة تُفتح بالطلب مرة واحدة من جهاز المستخدم)
  'application/pdf': 'pdf',
  'application/msword': 'doc',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': 'docx',
  'application/vnd.ms-excel': 'xls',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'xlsx',
  'application/vnd.ms-powerpoint': 'ppt',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation': 'pptx',
  'text/plain': 'txt', 'text/csv': 'csv', 'application/zip': 'zip',
};
const CAP_MB = { image: 6, video: 12, audio: 6, doc: 8 };

app.post('/api/media', (req, res) => {
  const { type, dataUrl } = req.body || {};
  const kind = ['image', 'video', 'audio', 'doc'].includes(type) ? type : null;
  if (!kind) return fail(res, 400, 'نوع الوسائط غير مدعوم');
  const m = /^data:([^;]+);base64,([\s\S]+)$/.exec(String(dataUrl || ''));
  if (!m) return fail(res, 400, 'الملف غير صالح');
  const mime = m[1].toLowerCase().trim();
  const fallback = kind === 'image' ? 'jpg' : kind === 'video' ? 'mp4' : kind === 'audio' ? 'm4a' : 'bin';
  const buf = Buffer.from(m[2], 'base64');
  if (buf.length > CAP_MB[kind] * 1024 * 1024) {
    return fail(res, 413, `حجم الملف أكبر من ${CAP_MB[kind]} ميجابايت`);
  }
  const prefix = kind === 'image' ? 'img' : kind === 'video' ? 'vid' : kind === 'audio' ? 'aud' : 'doc';
  const file = `${store.id(prefix)}.${EXT_BY_MIME[mime] || fallback}`;
  fs.writeFileSync(path.join(UPLOAD_DIR, file), buf);
  ok(res, { url: `api/media/${file}`, type: kind, mime, size: buf.length });
});

const ok = (res, data) => res.json(data);
const fail = (res, code, message) => res.status(code).json({ error: message });

function bootstrap() {
  const db = store.mutate((d) => {
    store.tick(d);
    return d;
  });
  const payload = store.withMeta(db);
  // معلومة شاشة الدخول (وضع تجريبي / عدد أرقام الرمز) بلا أي بيانات حساب
  payload.auth = auth.info();
  return refreshVoiceUrls(payload);
}

// بصمة الإصدار: تُبنى مرة عند الإقلاع لتأكيد أي نسخة تخدم الطلب فعلًا
const REV = (() => {
  try {
    return require('crypto')
      .createHash('md5')
      .update(fs.readFileSync(__filename))
      .digest('hex')
      .slice(0, 10);
  } catch (e) { return 'unknown'; }
})();

// فحص الصحة عام على مسار /api/health، لذا لا نُظهر منه إلا ما يفيد المراقبة:
// بصمة البناء والحزمة المخدومة وحالة المخزن. التفاصيل التشغيلية (pid، المنفذ،
// المسارات، عدد الملفات، حالة المصادقة، ورمز التجربة) تُحجب عن الطلبات غير المحلية —
// كان الرابط العام يكشف `otpFixed: 123456` و`authDemo: true` لأي زائر.
function isLocalDiag(req) {
  try {
    const ra = (req.socket && (req.socket.remoteAddress || '')) || '';
    const loop = ra === '127.0.0.1' || ra === '::1' || ra === '::ffff:127.0.0.1' || ra === '';
    const proxied = Boolean(req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || req.headers['x-forwarded-host']);
    return loop && !proxied;
  } catch (e) { return false; }
}
app.get('/api/health', (req, res) => {
  // shell.json يُقرأ لحظة الطلب لا لحظة الإقلاع: الخادم يخدم الصدفة الحيّة من
  // القرص (shellSource تتبع mtime)، فبعد كل نشر جديد كان /api/health يعلن حزمة
  // قديمة ويتظاهر بأن الموقع يخدم بناءً سابقًا — تشخيص خاطئ يضيّع وقتًا في التفتيش
  // عن عطل غير موجود (شوهد فعلًا: بناء v30 جديد والحالة تعلن حزمة ما قبل النشر).
  const meta = shellMeta();
  const body = {
    build: meta.stamp || null,    // بصمة الصدفة التي يخدمها هذا الخادم فعلًا
    shellAt: meta.builtAt || null,
    clientBundle: meta.js || null,
    ok: true,
    service: 'smart-social',
    ts: Date.now(),
    upSec: Math.round(process.uptime()),
    db: BOOT.ok && fs.existsSync(store.DB_FILE),
    dbBytes: (() => {
      // حجم حيّ لا قيمة مُلتقطة عند الإقلاع: كان الرقم يظل قديمًا بعد أي كتابة على المخزن
      try { return fs.statSync(store.DB_FILE).size; } catch (e) { return -1; }
    })(),
  };
  if (isLocalDiag(req)) {
    body.diag = {
      rev: REV,
      pid: process.pid,
      port: boundPort || null,
      dataDir: path.basename(DATA_DIR),
      root: path.basename(path.join(__dirname, '..')),
      uploads: fs.existsSync(UPLOAD_DIR) ? fs.readdirSync(UPLOAD_DIR).length : -1,
      dbError: BOOT.error,
      dataPath: DATA_DIR,
      authDemo: auth.info().demo,
      otpFixed: auth.info().demoCode || null,
      authStrict: auth.STRICT,
      rtc: rtc.info(),
      voiceFiles: fs.existsSync(path.join(UPLOAD_DIR, 'voice')) ? fs.readdirSync(path.join(UPLOAD_DIR, 'voice')).length : -1,
    };
  }
  return ok(res, body);
});

app.get('/api/bootstrap', (req, res) => ok(res, bootstrap()));

// ── «أثر»: خريطة الذكريات وومضاتها ──
const ATHAR_RADIUS = { def: 60, min: 5, max: 60 }; // السقف ٦٠ كم — قرار المنتج
const CLUSTER_KM = 2; // ما دون كيلومترين يُعدّ «المكان نفسه»

// موقع الناظر: من المتصفح أولًا، ثم من الملف الشخصي، ثم مركز المدينة
function viewerPoint(pick, db) {
  return pick('lat', 'lng')
    || geo.validPoint(db.me && db.me.lat, db.me && db.me.lng)
    || CITY_CENTER;
}

function atharPayload(db, center, radiusKm) {
  const now = Date.now();
  const all = store.visibleAthar(db, now);
  const near = all
    .map((a) => {
      const km = geo.distanceKm(center, a.place);
      return { ...a, distanceKm: Math.round(km * 10) / 10, distanceLabel: geo.distanceLabel(km) };
    })
    .filter((a) => a.distanceKm <= radiusKm)
    .sort((a, b) => a.distanceKm - b.distanceKm || Date.parse(b.createdAt) - Date.parse(a.createdAt));

  const pulses = geo.buildPulses(near, { now, clusteringKm: CLUSTER_KM })
    .map((p) => ({ ...p, distanceLabel: geo.distanceLabel(geo.distanceKm(center, p)) }));

  // حلقة النطاق — مضلّع حقيقي يحترم انحناء الكرة بدل دائرة مسطّحة
  const ring = Array.from({ length: 48 }, (_, i) => geo.destination(center, (i * 360) / 48, radiusKm));

  const items = near.map((a) => ({
    id: a.id,
    author: a.author,
    authorName: a.authorName,
    authorColor: a.authorColor,
    authorRelation: a.authorRelation,
    mine: a.mine,
    text: a.text,
    media: a.media || null,
    // لون البطاقة النصّية السادة (يُهمَل عندما توجد وسائط)
    bg: a.bg || null,
    place: a.place,
    createdAt: a.createdAt,
    ageLabel: a.ageLabel,
    distanceKm: a.distanceKm,
    distanceLabel: a.distanceLabel,
    visits: a.visits || 0,
    // رباط الذكرى: من كان معك ومتى كانت — تُعرض مع البطاقة لا في الأرشيف فقط
    companions: a.companions || [],
    companionView: a.companionView || [],
    companionNames: a.companionNames || [],
    whenAt: a.whenAt || null,
    whenLabel: a.whenLabel || null,
    audienceLabel: (a.audienceView && a.audienceView.label) || 'دائرتك',
    audienceScope: (a.audience && a.audience.scope) || 'circle',
  }));

  const mine = items.filter((a) => a.mine);
  return {
    center,
    radiusKm,
    pulses,
    items,
    ring,
    legend: geo.TIERS.map((t) => ({ label: t.label, hex: t.hex })),
    summary: {
      total: items.length,
      mine: mine.length,
      places: pulses.length,
      visits: mine.reduce((s, a) => s + (a.visits || 0), 0),
      beyond: all.length - items.length,
      latest: items.slice().sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt))[0] || null,
    },
  };
}

const pickFrom = (src) => (k1, k2) => geo.validPoint(src && src[k1], src && src[k2]);

app.get('/api/athar', (req, res) => {
  const db = store.mutate((d) => { store.tick(d); return d; });
  const center = viewerPoint(pickFrom(req.query), db);
  const raw = Number(req.query.radiusKm !== undefined ? req.query.radiusKm : req.query.radius);
  const radiusKm = Math.min(ATHAR_RADIUS.max, Math.max(ATHAR_RADIUS.min, Number.isFinite(raw) && raw > 0 ? raw : ATHAR_RADIUS.def));
  ok(res, atharPayload(db, center, radiusKm));
});

app.post('/api/athar', (req, res) => {
  const body = req.body || {};
  const place = body.place || {};
  const point = geo.validPoint(place.lat, place.lng);
  if (!point) return fail(res, 400, 'حدّد موقع الأثر على الخريطة');
  const text = String(body.text || '').trim();
  if (!text) return fail(res, 400, 'اكتب ما تريد أن يبقى في هذا المكان');
  const name = String(place.name || '').trim() || 'مكان على الخريطة';
  const whenRes = store.memoryWhen(body.when);
  if (!whenRes.ok) return fail(res, 400, whenRes.reason);

  // بند ٨.٢ + ٣.٦: لا نشر بلا اختيار صريح للدائرة، و«كل الدوائر» ليست افتراضيًا.
  // الفرض خادمي (١.٤): لو اعتمدنا على الواجهة وحدها لكفى أي عميل آخر لتجاوزه.
  // ولا تحويل صامت: طلبُ دائرة غير موجودة لا يصبح «كل الدوائر» — يُرفض.
  const wantScope = (body.audience && body.audience.scope) || null;
  if (!wantScope || !['circle', 'groups', 'people'].includes(wantScope)) {
    return fail(res, 400, 'اختر من يرى هذا الأثر: دائرة أو أشخاصًا');
  }
  {
    const now = store.read();
    const norm = store.normalizeAudience(now.me, now.people, body.audience);
    if (norm.scope !== wantScope) return fail(res, 400, 'اختر من يرى هذا الأثر: دائرة أو أشخاصًا');
  }

  const item = {
    id: store.id('a'),
    author: 'u-me',
    text: text.slice(0, 600),
    media: body.media && body.media.url ? {
      type: body.media.type,
      url: body.media.url,
      view: cleanView(body.media.view),
      ...(cleanDims(body.media.w, body.media.h) || {}),
    } : null,
    // لون سادة لبطاقة الأثر النصّية (نفس قائمة الحالات)
    bg: body.media && body.media.url ? null : cleanBg(body.bg),
    place: { name, lat: point.lat, lng: point.lng },
    companions: store.cleanCompanions(store.read().people, body.companions),
    when: whenRes.iso,
    createdAt: new Date().toISOString(),
    audience: { scope: 'circle', groups: [], people: [] },
    visits: 0,
  };

  const db = store.mutate((d) => {
    item.audience = store.normalizeAudience(d.me, d.people, body.audience);   // مفحوص أعلاه
    d.athar.unshift(item);
    // الرفاق يُذكرون بالإسم في الإشعار: الأثر صار ذكرى مشتركة لا منشورًا فرديًا
    const withNames = item.companions
      .map((pid) => (((d.people || []).find((p) => p.id === pid) || {}).name || '').split(' ')[0])
      .filter(Boolean);
    const who = withNames.length === 0
      ? ''
      : withNames.length === 1
        ? ` مع ${withNames[0]}`
        : ` مع ${withNames[0]} و${withNames.length - 1} آخرين`;
    store.notify(d, `وثّقت أثرًا جديدًا في «${name}»${who} — سيظهر وميضًا على الخريطة لهذا المكان.`, 'athar', {
      atharId: item.id, place: name, companions: item.companions,
    });
    store.tick(d);
    return d;
  });
  ok(res, { created: item.id, athar: atharPayload(db, viewerPoint(pickFrom(body), db), Number(body.radiusKm) || ATHAR_RADIUS.def) });
});

app.post('/api/athar/:id/visit', (req, res) => {
  const found = store.read().athar.find((x) => x.id === req.params.id);
  if (!found) return fail(res, 404, 'الأثر غير موجود');
  if (!store.canSeeAthar(found, store.read().me, store.read().people)) return fail(res, 403, 'هذا الأثر خارج دائرتك');
  // الزيارات تُحسب من دائرة صاحب الأثر — زيارتك لأثرك أنت لا تُضاف
  if (found.author === 'u-me') {
    return ok(res, { id: found.id, visits: found.visits || 0, counted: false, mine: true });
  }
  const db = store.mutate((d) => {
    const a = d.athar.find((x) => x.id === req.params.id);
    if (a) a.visits = (Number(a.visits) || 0) + 1;
    return d;
  });
  const item = db.athar.find((x) => x.id === req.params.id);
  ok(res, { id: item.id, visits: item.visits, counted: true, mine: false });
});

// ── الحالات التفاعلية ──
// ألوان «الحالة النصية»: لون سادة واحد لكل حالة. قائمة مغلقة يتحقق منها الخادم
// (لا نصّ حر) حتى لا تُخزَّن أي قيمة تُفسد العرض على شاشة العرض.
const STORY_BG = {
  LAYL: '#0B1F3F', BAHR: '#0F766E', GHUROUB: '#5B2A6E', TURAB: '#9A3412',
  WAHA: '#14532D', HAJAR: '#334155', WARD: '#9F1239', ASAL: '#B45309',
};
const STORY_BG_SET = new Set(Object.values(STORY_BG));
const cleanBg = (v) => {
  const s = String(v || '').trim().toUpperCase();
  return STORY_BG_SET.has(s) ? s : null;
};

// قصّ/تنسيق الوسائط (تدوير · قلب · فلتر · إطار قصّ): تُحفظ مع الوسائط وتُطبَّق في
// العارض كما رآها صاحبها في المحرّر — بقيم محدودة ومُتحقَّق منها.
const VIEW_FILTERS = new Set(['none', 'warm', 'cool', 'mono', 'pop']);
const numOr = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);
const cleanView = (v) => {
  if (!v || typeof v !== 'object') return null;
  const rot = [0, 90, 180, 270].includes(Number(v.rot)) ? Number(v.rot) : 0;
  const flipH = !!v.flipH;
  const flipV = !!v.flipV;
  const filter = VIEW_FILTERS.has(v.filter) ? v.filter : 'none';
  let crop = null;
  if (v.crop && typeof v.crop === 'object') {
    const x = Math.min(1, Math.max(0, numOr(v.crop.x, 0)));
    const y = Math.min(1, Math.max(0, numOr(v.crop.y, 0)));
    const w = Math.min(1 - x, Math.max(0.08, numOr(v.crop.w, 1)));
    const h = Math.min(1 - y, Math.max(0.08, numOr(v.crop.h, 1)));
    if (x > 0.004 || y > 0.004 || w < 0.996 || h < 0.996) crop = { x, y, w, h };
  }
  if (!rot && !flipH && !flipV && filter === 'none' && !crop) return null;
  return { rot, flipH, flipV, filter, crop };
};
const cleanDims = (w, h) => {
  const W = Math.round(Number(w));
  const H = Math.round(Number(h));
  const okDim = (n) => Number.isFinite(n) && n >= 16 && n <= 8000;
  return okDim(W) && okDim(H) ? { w: W, h: H } : null;
};

app.post('/api/states', (req, res) => {
  const { text, kind, question, options, hours, place, geo: geoRaw, threshold, media, audience, bg, companions, when } = req.body || {};
  const bgHex = cleanBg(bg);
  const clean = String(text || '').trim();
  const story = media && media.url
    ? {
      type: ['image', 'video', 'audio'].includes(media.type) ? media.type : 'image',
      url: String(media.url),
      // طبقات الرسم والملصقات والنصّ فوق المقاطع: صورة شفافة تُعرض فوق الوسائط
      overlay: media.overlay ? String(media.overlay) : null,
      view: cleanView(media.view),
      ...(cleanDims(media.w, media.h) || {}),
      durationMs: Number(media.durationMs) || null,
      size: Number(media.size) || null,
    }
    : null;
  if (!clean && !story) return fail(res, 400, 'أضف نصًا أو صورة أو مقطعًا للحالة');
  const isAthar = kind === 'memory';
  // «أثر» يُفعَّل من الحالة، فتُحفظ الحالة ومعها موقع مثبّت على الخريطة.
  const point = geo.validPoint(
    geoRaw && geoRaw.lat !== undefined ? geoRaw.lat : null,
    geoRaw && geoRaw.lng !== undefined ? geoRaw.lng : null,
  );
  if (isAthar && !point) {
    return fail(res, 400, 'أثر بلا موقع لا يظهر على الخريطة — فعّل الموقع والتقط مكانك أولًا');
  }
  const placeName = String(place || '').trim() || (isAthar ? 'مكان بلا اسم' : '');
  // حقل «متى كانت الذكرى» يُفحص قبل أي كتابة حتى لا تُنشأ حالة مرفوضة
  const whenRes = isAthar ? store.memoryWhen(when) : { ok: true, iso: null };
  if (!whenRes.ok) return fail(res, 400, whenRes.reason);
  const db = store.mutate((d) => {
    const state = {
      id: store.id('s'),
      author: 'u-me',
      kind: kind || (story ? 'moment' : 'activity'),
      text: clean,
      // لون الحالة السادة (حالة نصية) — null يعني الشكل السابق بتدرّج النوع
      bg: story ? null : bgHex,
      media: story,
      seconds: story ? (story.type === 'image' ? 7 : 15) : 6,
      seen: true,
      question: question || 'من معنا؟',
      options: options && options.length ? options : [
        { key: 'yes', label: 'أنا معك' },
        { key: 'maybe', label: 'يمكن' },
        { key: 'no', label: 'ما أقدر' },
      ],
      tally: { yes: 0, maybe: 0, no: 0 },
      myChoice: null,
      threshold: Number(threshold) || (story ? 0 : 5),
      createdAt: new Date().toISOString(),
      expiresIn: new Date(Date.now() + Math.min(24, Math.max(1, Number(hours) || 24)) * 3600 * 1000).toISOString(),
      place: placeName ? { name: placeName, km: point ? Math.round(geo.distanceKm(CITY_CENTER, point) * 10) / 10 : Math.round(Math.random() * 20 * 10) / 10 } : null,
      audience: store.normalizeAudience(d.me, d.people, audience),
      layer: isAthar ? 'أثر' : 'الحالات التفاعلية',
      whispers: [],
      roomId: null,
      acted: false,
      authorIsMe: true,
      geo: point || null,
    };
    d.states.unshift(state);
    // الأثر يُحفظ في أرشيف «أثر» فورًا بمكانه ودائرته، ويبقى بعد انتهاء الحالة
    if (isAthar) {
      d.athar.unshift({
        id: store.id('a'),
        author: 'u-me',
        stateId: state.id,
        text: clean,
        media: story,
        bg: story ? null : bgHex,
        place: { name: placeName, lat: point.lat, lng: point.lng },
        companions: store.cleanCompanions(d.people, companions),
        when: whenRes.iso,
        createdAt: state.createdAt,
        audience: state.audience,
        visits: 0,
      });
      store.notify(d, `ثُبّت أثر في «${placeName}» — يظهر لمن يمر بالمكان في نطاق ٦٠ كم.`, 'memory', { atharId: state.id, place: placeName });
    }
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/states/:id/respond', (req, res) => {
  const { choice } = req.body || {};
  const found = store.read().states.find((x) => x.id === req.params.id);
  if (!found) return fail(res, 404, 'الحالة غير موجودة');
  if (found.author === 'u-me' || found.authorIsMe) {
    return fail(res, 403, 'هذه حالتك — الردود تأتي من دائرتك');
  }
  if (choice !== undefined && !['yes', 'maybe', 'no'].includes(choice)) {
    return fail(res, 400, 'خيار غير معروف — اختر: أنا معك / يمكن / ما أقدر');
  }
  if (new Date(found.expiresIn).getTime() <= Date.now()) {
    return fail(res, 409, 'انتهت مدة الحالة — الردود مغلقة');
  }
  if (found.roomId || found.acted) {
    return fail(res, 409, 'اكتمل النصاب — الردود تتابع داخل الغرفة');
  }
  const db = store.mutate((d) => {
    const s = d.states.find((x) => x.id === req.params.id);
    if (!s) return d;
    const key = choice === 'maybe' ? 'maybe' : choice === 'no' ? 'no' : 'yes';
    if (!s.myChoice) s.tally[key] = (s.tally[key] || 0) + 1;
    else if (s.myChoice !== key) {
      s.tally[s.myChoice] = Math.max(0, (s.tally[s.myChoice] || 0) - 1);
      s.tally[key] = (s.tally[key] || 0) + 1;
    }
    s.myChoice = key;
    if (s.threshold && (s.tally.yes || 0) >= s.threshold && !s.roomId) {
      const room = {
        id: store.id('r'),
        stateId: s.id,
        owner: s.author || 'u-me',
        title: (s.place && s.place.name) || 'غرفة نشاط',
        kind: 'نشاط',
        place: s.place ? s.place.name : 'يُحدَّد',
        members: ['u-me', 'u4', 'u1', 'u8'].slice(0, Math.max(2, Math.min(4, s.tally.yes))),
        capacity: Math.max(6, s.tally.yes + 2),
        status: 'open',
        openedAt: new Date().toISOString(),
        closesAt: new Date(Date.now() + 8 * 3600 * 1000).toISOString(),
        memories: [],
        agenda: ['تحديد الموعد', 'تأكيد المكان', 'التذكير قبل الساعة'],
        unread: 0,
        messages: [{
          id: store.id('rm'),
          from: 'sys',
          text: `فُتحت الغرفة تلقائيًا بعد اكتمال النصاب — ${s.tally.yes} من دائرتك معك.`,
          at: new Date().toISOString(),
        }],
      };
      d.rooms.unshift(room);
      s.roomId = room.id;
      s.acted = true;
      store.notify(d, `اكتمل النصاب في «${s.question}» — فُتحت غرفة «${room.title}» تلقائيًا.`, 'room');
    }
    return d;
  });
  ok(res, bootstrap());
});

// ── الستوري: تعليمها كمُشاهدة أو حذفها إن كانت لك ──
app.post('/api/states/:id/seen', (req, res) => {
  if (!store.read().states.some((x) => x.id === req.params.id)) {
    return fail(res, 404, 'الحالة غير موجودة');
  }
  store.mutate((d) => {
    const s = d.states.find((x) => x.id === req.params.id);
    if (s) s.seen = true;
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/states/:id/delete', (req, res) => {
  let removed = false;
  store.mutate((d) => {
    const s = d.states.find((x) => x.id === req.params.id);
    if (s && (s.author === 'u-me' || s.authorIsMe)) {
      d.states = d.states.filter((x) => x.id !== s.id);
      removed = true;
    }
    return d;
  });
  if (!removed) {
    const exists = store.read().states.some((x) => x.id === req.params.id);
    return exists ? fail(res, 403, 'يمكنك حذف حالاتك فقط') : fail(res, 404, 'الحالة غير موجودة');
  }
  ok(res, bootstrap());
});

// ── الهمسات: محادثة كاملة — لا رسالة عابرة داخل الحالة ──
// القاعدة التي يقوم عليها كل ما يلي: مَن وصلته الهمسة لا يعرف صاحبها.
// الخادم هو من يحجب الاسم والمعرّف (انظر whisperView في store.js)، فلا تستطيع
// الواجهة — ولا أي متطفّل يقرأ حمولة الشبكة — أن يعرف من كتب قبل أن يكشف نفسه.

// يفتح محادثة همسة مع شخص (أو يضيف إلى محادثته القائمة) ويعيد معرّفها
function whisperStart(d, to, text, stateId) {
  if (!Array.isArray(d.whispers)) d.whispers = [];
  const state = stateId ? d.states.find((s) => s.id === stateId) : null;
  let w = d.whispers.find((x) => x.peerId === to && x.direction === 'out'
    && (x.stateId || null) === (stateId || null));
  if (!w) {
    w = {
      id: store.id('w'),
      direction: 'out',
      peerId: to,
      stateId: stateId || null,
      fromState: state ? String(state.text || '').slice(0, 60) : '',
      revealOnAsk: true,
      revealed: false, revealAsked: false, revealState: 'idle', peerAsked: false,
      reaction: null,
      unread: 0,
      createdAt: new Date().toISOString(),
      messages: [],
    };
    d.whispers.unshift(w);
  }
  w.messages.push({
    id: store.id('wm'), from: 'u-me', text: String(text).trim().slice(0, 2000),
    kind: 'text', at: new Date().toISOString(),
  });
  w.updatedAt = new Date().toISOString();
  return w;
}

// بدء همسة: من بطاقة حالة أو من أي مكان — النص أول رسالة في المحادثة
app.post('/api/whispers', (req, res) => {
  const { to, text, stateId } = req.body || {};
  if (!text || !String(text).trim()) return fail(res, 400, 'نص الهمسة مطلوب');
  const person = store.read().people.find((p) => p.id === to);
  if (!person) return fail(res, 404, 'لا يوجد شخص بهذا المعرّف في دائرتك');
  store.mutate((d) => {
    const w = whisperStart(d, to, text, stateId || null);
    store.notify(d, `أرسلت همسة إلى ${person.name} — لا يراها غيركما.`, 'whisper', { whisperId: w.id });
    return d;
  });
  ok(res, bootstrap());
});

// ردّ داخل محادثة الهمسة
app.post('/api/whispers/:id/send', (req, res) => {
  const body = String((req.body || {}).text || '').trim().slice(0, 2000);
  if (!body) return fail(res, 400, 'نص الرسالة مطلوب');
  const exists = (store.read().whispers || []).some((w) => w.id === req.params.id);
  if (!exists) return fail(res, 404, 'محادثة الهمسة غير موجودة');
  store.mutate((d) => {
    const w = d.whispers.find((x) => x.id === req.params.id);
    w.messages.push({ id: store.id('wm'), from: 'u-me', text: body, kind: 'text', at: new Date().toISOString() });
    w.updatedAt = new Date().toISOString();
    return d;
  });
  ok(res, bootstrap());
});

// تقييم الهمسة: أعجبني / لم يعجبني — والضغط على الزرّ نفسه يلغي التقييم
app.post('/api/whispers/:id/react', (req, res) => {
  const kind = String((req.body || {}).kind || '');
  if (kind !== 'like' && kind !== 'dislike') return fail(res, 400, 'التقييم إما like أو dislike');
  const exists = (store.read().whispers || []).some((w) => w.id === req.params.id);
  if (!exists) return fail(res, 404, 'محادثة الهمسة غير موجودة');
  store.mutate((d) => {
    const w = d.whispers.find((x) => x.id === req.params.id);
    w.reaction = w.reaction === kind ? null : kind;
    // تقييم واحد فقط في السجل: نُزيل تقييماتي السابقة ثم نُثبت الحالي (أو لا شيء)
    w.messages = w.messages.filter((m) => !(m.from === 'u-me' && (m.kind === 'like' || m.kind === 'dislike')));
    if (w.reaction) {
      w.messages.push({ id: store.id('wm'), from: 'u-me', text: '', kind: w.reaction, at: new Date().toISOString() });
    }
    w.updatedAt = new Date().toISOString();
    return d;
  });
  ok(res, bootstrap());
});

// «من صاحب الهمسة؟» — سؤال لا كشف: نُبلغ صاحبها، وهو من يقرّر أن يعرّف بنفسه
app.post('/api/whispers/:id/ask', (req, res) => {
  const w0 = (store.read().whispers || []).find((w) => w.id === req.params.id);
  if (!w0) return fail(res, 404, 'محادثة الهمسة غير موجودة');
  if (w0.direction !== 'in') return fail(res, 409, 'هذه همسة أنت بدأتها — صاحبها يعرفك');
  if (w0.revealed) return fail(res, 409, 'صاحب الهمسة عرّف بنفسه بالفعل');
  if (w0.revealState === 'asked') return fail(res, 409, 'سألته بالفعل — بانتظار جوابه');
  store.mutate((d) => {
    const w = d.whispers.find((x) => x.id === req.params.id);
    w.revealAsked = true;
    w.revealState = 'asked';
    w.messages.push({ id: store.id('wm'), from: 'u-me', text: '', kind: 'ask', at: new Date().toISOString() });
    w.updatedAt = new Date().toISOString();
    return d;
  });
  ok(res, bootstrap());
});

// الباب المعاكس: صاحب الهمسة يسألك «من أنت؟» — فإما تعرّف بنفسك أو تبقى مجهولًا
app.post('/api/whispers/:id/reveal', (req, res) => {
  const yes = (req.body || {}).yes !== false;
  const w0 = (store.read().whispers || []).find((w) => w.id === req.params.id);
  if (!w0) return fail(res, 404, 'محادثة الهمسة غير موجودة');
  if (w0.direction !== 'out') {
    return fail(res, 409, 'هذه همسة وصلتك أنت — الكشف بيد صاحبها لا بيدك');
  }
  store.mutate((d) => {
    const w = d.whispers.find((x) => x.id === req.params.id);
    w.revealState = yes ? 'granted' : 'declined';
    w.revealed = yes;
    w.peerAsked = false;
    w.messages.push({
      id: store.id('wm'), from: 'u-me',
      text: yes ? `أنا ${d.me.name} — سامحني على الهمسة.` : '',
      kind: yes ? 'reveal' : 'deny',
      at: new Date().toISOString(),
    });
    w.updatedAt = new Date().toISOString();
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/whispers/:id/read', (req, res) => {
  const exists = (store.read().whispers || []).some((w) => w.id === req.params.id);
  if (!exists) return fail(res, 404, 'محادثة الهمسة غير موجودة');
  store.mutate((d) => {
    const w = d.whispers.find((x) => x.id === req.params.id);
    w.unread = 0;
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/whispers/:id/delete', (req, res) => {
  const exists = (store.read().whispers || []).some((w) => w.id === req.params.id);
  if (!exists) return fail(res, 404, 'محادثة الهمسة غير موجودة');
  store.mutate((d) => {
    d.whispers = d.whispers.filter((w) => w.id !== req.params.id);
    return d;
  });
  ok(res, bootstrap());
});

// إرسال همسة من داخل حالة: صار يفتح محادثة همسة (أو يضيف إلى القائمة)
app.post('/api/states/:id/whisper', (req, res) => {
  const { to, text } = req.body || {};
  if (!text || !String(text).trim()) return fail(res, 400, 'نص الهمسة مطلوب');
  const target = store.read().states.find((x) => x.id === req.params.id);
  if (!target) return fail(res, 404, 'الحالة غير موجودة');
  if (new Date(target.expiresIn).getTime() <= Date.now()) {
    return fail(res, 409, 'انتهت مدة الحالة — لا يمكن إرسال همسة');
  }
  const person = store.read().people.find((p) => p.id === (to || target.author));
  if (!person) return fail(res, 404, 'لا يوجد شخص بهذا المعرّف في دائرتك');
  store.mutate((d) => {
    const w = whisperStart(d, person.id, text, target.id);
    store.notify(d, `أرسلت همسة إلى ${person.name} — لا يراها غيركما.`, 'whisper', { whisperId: w.id });
    return d;
  });
  ok(res, bootstrap());
});

// ── أثر: حذف أثر تملكه وحدك ──

app.post('/api/athar/:id/delete', (req, res) => {
  const found = store.read().athar.find((x) => x.id === req.params.id);
  if (!found) return fail(res, 404, 'الأثر غير موجود');
  if (found.author !== 'u-me') return fail(res, 403, 'لا يمكنك حذف أثر شخص آخر');
  const db = store.mutate((d) => {
    d.athar = d.athar.filter((x) => x.id !== req.params.id);
    return d;
  });
  ok(res, store.withMeta(db));
});

// ── الغرف المؤقتة ──
app.post('/api/rooms', (req, res) => {
  const { title, place, capacity, hours, kind } = req.body || {};
  if (!title) return fail(res, 400, 'اسم الغرفة مطلوب');
  store.mutate((d) => {
    d.rooms.unshift({
      id: store.id('r'),
      stateId: null,
      owner: 'u-me',
      title: String(title),
      kind: kind || 'نشاط',
      place: place || 'يُحدَّد',
      members: ['u-me'],
      capacity: Number(capacity) || 8,
      status: 'open',
      openedAt: new Date().toISOString(),
      closesAt: new Date(Date.now() + (Number(hours) || 6) * 3600 * 1000).toISOString(),
      memories: [],
      agenda: ['دعوة الدائرة', 'تحديد الموعد'],
      unread: 0,
      messages: [{
        id: store.id('rm'),
        from: 'sys',
        text: 'أنشأت الغرفة — ادعُ دائرتك وابدأوا الدردشة داخلها.',
        at: new Date().toISOString(),
      }],
    });
    store.notify(d, `فُتحت غرفة مؤقتة «${title}» — تُقفل تلقائيًا بعد مدتها.`, 'room');
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/rooms/:id/join', (req, res) => {
  const found = store.read().rooms.find((x) => x.id === req.params.id);
  if (!found) return fail(res, 404, 'الغرفة غير موجودة');
  if (found.status !== 'open') return fail(res, 409, 'الغرفة مغلقة — لا يمكن الانضمام الآن');
  if (!found.members.includes('u-me') && found.members.length >= found.capacity) {
    return fail(res, 409, 'اكتمل عدد الغرفة — جرّب غرفة أخرى');
  }
  store.mutate((d) => {
    const r = d.rooms.find((x) => x.id === req.params.id);
    if (!r || r.status !== 'open') return d;
    if (!Array.isArray(r.messages)) r.messages = [];
    if (!r.members.includes('u-me')) {
      if (r.members.length >= r.capacity) return d;
      r.members.push('u-me');
      r.messages.push({
        id: store.id('rm'),
        from: 'sys',
        text: `انضممت إلى الغرفة — صرت داخل الدردشة مع ${r.members.length - 1} من الأعضاء.`,
        at: new Date().toISOString(),
      });
      r.unread = 0;
    }
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/rooms/:id/read', (req, res) => {
  if (!store.read().rooms.some((x) => x.id === req.params.id)) {
    return fail(res, 404, 'الغرفة غير موجودة');
  }
  store.mutate((d) => {
    const r = d.rooms.find((x) => x.id === req.params.id);
    if (r) r.unread = 0;
    return d;
  });
  ok(res, bootstrap());
});

// ── دردشة الغرفة: رسالة جماعية يراها كل من دخل الغرفة ──
const ROOM_REPLIES = [
  'تمام، أنا معكم 👍',
  'وصلت! أنتظركم عند المدخل.',
  'أنا متأخر ١٠ دقائق، ابدأوا بدوني.',
  'خذوا مكان واسع، العدد يكبر 😄',
  'متفقين، نلتقي هناك.',
  'ذكّرتني — أجيب معي الماء للجميع.',
];

app.post('/api/rooms/:id/messages', (req, res) => {
  const clean = String((req.body || {}).text || '').trim();
  if (!clean) return fail(res, 400, 'نص الرسالة مطلوب');
  const existing = store.read().rooms.find((x) => x.id === req.params.id);
  if (!existing) return fail(res, 404, 'الغرفة غير موجودة');
  if (existing.status !== 'open') return fail(res, 409, 'الغرفة مغلقة — الدردشة للقراءة فقط');
  const others = [];
  const db = store.mutate((d) => {
    const r = d.rooms.find((x) => x.id === req.params.id);
    if (!r) return d;
    if (!Array.isArray(r.messages)) r.messages = [];
    if (!r.members.includes('u-me')) r.members.push('u-me');
    r.messages.push({ id: store.id('rm'), from: 'u-me', text: clean, at: new Date().toISOString() });
    r.unread = 0;
    others.push(...r.members.filter((id) => id !== 'u-me'));
    return d;
  });
  const room = db.rooms.find((x) => x.id === req.params.id);
  if (!room) return fail(res, 404, 'الغرفة غير موجودة');
  // ردّ تجريبي من أحد أعضاء الغرفة ليبدو الحوار حيًّا (يتوقف عند إقفال الغرفة)
  if (others.length) {
    const who = others[Math.floor(Math.random() * others.length)];
    const line = ROOM_REPLIES[Math.floor(Math.random() * ROOM_REPLIES.length)];
    setTimeout(() => {
      try {
        store.mutate((d) => {
          const r = d.rooms.find((x) => x.id === req.params.id);
          if (!r || r.status !== 'open') return d;
          if (new Date(r.closesAt).getTime() < Date.now()) return d;
          if (!Array.isArray(r.messages)) r.messages = [];
          r.messages.push({ id: store.id('rm'), from: who, text: line, at: new Date().toISOString() });
          r.unread = (r.unread || 0) + 1;
          return d;
        });
      } catch (e) { /* تجاهل */ }
    }, 4500 + Math.round(Math.random() * 4000));
  }
  ok(res, bootstrap());
});

app.post('/api/rooms/:id/close', (req, res) => {
  const found = store.read().rooms.find((x) => x.id === req.params.id);
  if (!found) return fail(res, 404, 'الغرفة غير موجودة');
  if (found.status !== 'open') return fail(res, 409, 'الغرفة مغلقة بالفعل');
  store.mutate((d) => {
    const r = d.rooms.find((x) => x.id === req.params.id);
    if (!r) return d;
    r.status = 'closed';
    r.memories.push({
      text: `أُقفلت يدويًا — حضر ${r.members.length} من ${r.capacity}. أُرشفت في أثر.`,
      at: new Date().toISOString(),
    });
    if (!Array.isArray(r.messages)) r.messages = [];
    r.messages.push({
      id: store.id('rm'),
      from: 'sys',
      text: 'أُقفلت الغرفة — الدردشة صارت للقراءة فقط.',
      at: new Date().toISOString(),
    });
    store.notify(d, `أُقفلت «${r.title}» وأُرشفت في أثر.`, 'memory');
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/rooms/:id/memory', (req, res) => {
  const { text } = req.body || {};
  if (!text) return fail(res, 400, 'نص الأثر مطلوب');
  if (!store.read().rooms.some((x) => x.id === req.params.id)) {
    return fail(res, 404, 'الغرفة غير موجودة');
  }
  store.mutate((d) => {
    const r = d.rooms.find((x) => x.id === req.params.id);
    if (!r) return d;
    r.memories.push({ text: String(text), at: new Date().toISOString() });
    return d;
  });
  ok(res, bootstrap());
});

// ── إدارة الاجتماعات: تصويت على وقت، أو موعد ثابت بتذكير ──
const cleanList = (v) => (Array.isArray(v) ? v.map((x) => String(x).trim()).filter(Boolean) : []);
const cleanReminders = (v) => {
  const list = (Array.isArray(v) ? v : []).map(Number).filter((n) => n > 0 && n <= 2880);
  return list.length ? [...new Set(list)] : store.REMIND_DEFAULT.slice();
};
const parseAt = (v) => {
  if (!v) return null;
  const t = Date.parse(v);
  return Number.isNaN(t) ? null : new Date(t).toISOString();
};
const reminderText = (m) => store.remindersOf(m).map(store.remindLabel).join(' و ');

app.post('/api/meetings', (req, res) => {
  const { title, kind, slots: slotsRaw, places, attendees, at, place, reminders } = req.body || {};
  if (!title || !String(title).trim()) return fail(res, 400, 'عنوان الاجتماع مطلوب');
  const mode = kind === 'fixed' ? 'fixed' : 'vote';
  if (at && !parseAt(at)) return fail(res, 400, 'صيغة التاريخ والوقت غير صحيحة');
  const atIso = parseAt(at);
  if (mode === 'fixed' && !atIso) return fail(res, 400, 'حدّد التاريخ والوقت للموعد');

  const slots = cleanList(slotsRaw);
  const placesList = cleanList(places);
  const placeText = String(place || '').trim() || placesList[0] || 'يُحدَّد لاحقًا';
  const list = cleanReminders(reminders);

  const meeting = {
    id: store.id('m'),
    title: String(title).trim(),
    host: 'u-me',
    kind: mode,
    attendees: Number(attendees) || 5,
    slots: mode === 'vote'
      ? (slots.length ? slots : ['الخميس 9:00 مساءً', 'الجمعة 5:00 مساءً']).map((l, i) => ({ id: 't' + (i + 1), label: l, votes: 0 }))
      : [],
    places: mode === 'vote' ? (placesList.length ? placesList : ['يُحدَّد لاحقًا']) : [placeText],
    place: mode === 'vote' ? (placesList[0] || null) : placeText,
    status: mode === 'vote' ? 'voting' : 'scheduled',
    at: atIso,
    confirmed: null,
    reminders: list,
    sentReminders: [],
    reminder: '',
  };
  meeting.reminder = reminderText(meeting);
  store.primeReminders(meeting);

  store.mutate((d) => {
    if (!Array.isArray(d.meetings)) d.meetings = [];
    d.meetings.unshift(meeting);
    store.notify(
      d,
      mode === 'vote'
        ? `طُرح «${meeting.title}» للتصويت — سيُحسم تلقائيًا عند أغلبية الأصوات.`
        : `أُضيف موعد «${meeting.title}» بلا تصويت — سيصلك تذكير ${meeting.reminder}.`,
      'meeting',
      { meetingId: meeting.id, at: meeting.at, place: meeting.place, label: mode === 'vote' ? 'تصويت' : 'موعد' },
    );
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/meetings/:id/vote', (req, res) => {
  const { slotId } = req.body || {};
  const found = store.read().meetings.find((x) => x.id === req.params.id);
  if (!found) return fail(res, 404, 'الاجتماع غير موجود');
  if (found.status === 'confirmed') return fail(res, 409, 'حُسم الموعد — التصويت مغلق');
  if (found.status !== 'voting') return fail(res, 409, 'هذا موعد ثابت — لا يحتاج تصويتًا');
  store.mutate((d) => {
    const m = d.meetings.find((x) => x.id === req.params.id);
    if (!m || m.status !== 'voting') return d;
    m.slots.forEach((s) => {
      if (s.id === m.myVote) s.votes = Math.max(0, s.votes - 1);
    });
    const slot = m.slots.find((s) => s.id === slotId);
    if (!slot) return d;
    slot.votes += 1;
    m.myVote = slot.id;
    const total = m.slots.reduce((a, s) => a + s.votes, 0);
    const top = m.slots.slice().sort((a, b) => b.votes - a.votes)[0];
    if (total >= m.attendees && top.votes > total / 2) {
      m.status = 'confirmed';
      m.at = m.at || new Date(Date.now() + 36 * 3600 * 1000).toISOString();
      m.confirmed = { slotId: top.id, place: m.place || m.places[0], at: m.at };
      m.place = m.confirmed.place;
      m.reminders = store.remindersOf(m);
      m.reminder = reminderText(m);
      store.primeReminders(m);
      store.notify(d, `حُسم «${m.title}» على ${top.label} — ${m.confirmed.place}. تذكير ${m.reminder}.`, 'meeting', {
        meetingId: m.id, at: m.at, place: m.confirmed.place, label: 'موعد',
      });
    }
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/meetings/:id/confirm', (req, res) => {
  const { slotId, place, at, reminders } = req.body || {};
  if (at && !parseAt(at)) return fail(res, 400, 'صيغة التاريخ والوقت غير صحيحة');
  const atIso = parseAt(at);
  const target = store.read().meetings.find((x) => x.id === req.params.id);
  if (!target) {
    return fail(res, 404, 'الاجتماع غير موجود');
  }
  // حماية من التكرار: الموعد المحسوم يُثبَّت مرة واحدة (لا نداء متكرر ولا بطاقة قديمة في المتصفح)
  if (target.status === 'confirmed') {
    return fail(res, 409, 'تم تأكيد هذا الموعد مسبقًا');
  }
  store.mutate((d) => {
    const m = d.meetings.find((x) => x.id === req.params.id);
    if (!m) return d;
    const top = m.slots.slice().sort((a, b) => b.votes - a.votes)[0];
    const chosen = slotId || (top && top.id) || (m.slots[0] && m.slots[0].id) || null;
    if (reminders !== undefined) m.sentReminders = [];
    if (reminders !== undefined || !Array.isArray(m.reminders) || !m.reminders.length) {
      m.reminders = cleanReminders(reminders !== undefined ? reminders : m.reminders);
    }
    const when = atIso || m.at || new Date(Date.now() + 36 * 3600 * 1000).toISOString();
    m.kind = m.kind || 'vote';
    m.status = 'confirmed';
    m.at = when;
    m.confirmed = {
      slotId: chosen,
      place: String(place || '').trim() || m.place || (m.places && m.places[0]) || 'يُحدَّد لاحقًا',
      at: when,
    };
    m.place = m.confirmed.place;
    m.reminder = reminderText(m);
    store.primeReminders(m);
    store.notify(d, `تأكّد «${m.title}» — ${m.confirmed.place} · تذكير ${m.reminder}.`, 'meeting', {
      meetingId: m.id, at: when, place: m.confirmed.place, label: 'موعد',
    });
    return d;
  });
  ok(res, bootstrap());
});

// ── المحادثات: تواصل مباشر مع من أضفتهم في دائرتك ──
// المرفقات: صورة أو مقطع أو صوت أو مستند. لا نقبل إلا مسارات وسائط خادمنا
// (بلا روابط خارجية)، والتسجيل الصوتي يُقبل من صاحبه وحده.
const CHAT_MEDIA_TYPES = ['image', 'video', 'audio', 'doc'];
const CHAT_TYPES = ['text', 'image', 'video', 'audio', 'sticker', 'doc'];
function chatAttachment(raw, db, accountId) {
  if (!raw || typeof raw !== 'object') return null;
  const url = String(raw.url || '').trim().split('?')[0];
  const m = /^api\/(media|voice)\/([A-Za-z0-9_.-]+)$/.exec(url);
  if (!m) return null;
  if (m[1] === 'voice') {
    const row = voice.ownerOf(db, m[2]);
    if (!row || row.ownerId !== accountId) return null; // تسجيل غيره لا يُرسَل باسمه
    return {
      url,
      type: 'audio',
      voice: true,
      durationMs: Number((raw.durationMs || row.durationMs)) || 0,
      name: 'تسجيل صوتي',
      size: row.size || 0,
    };
  }
  const type = CHAT_MEDIA_TYPES.includes(raw.type) ? raw.type : 'doc';
  return {
    url,
    type,
    name: String(raw.name || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, 80),
    size: Number(raw.size) || 0,
  };
}

// تسجيلات الصوت تُوقَّع لحظة القراءة: الرابط المخزَّن ثابت، والتوقيع طازج في كل رد،
// فلا ينتهي الرابط بعد ساعات ولا يحتاج العميل إلى تجديده (بند ٤ و ٩).
function refreshVoiceUrls(payload) {
  (payload.chats || []).forEach((c) => {
    (c.messages || []).forEach((m) => {
      const md = m && m.media;
      if (!md || !md.voice) return;
      const f = /^api\/voice\/([A-Za-z0-9_.-]+)$/.exec(String(md.url || ''));
      if (f) md.url = voice.signedUrl(f[1]);
    });
  });
  return payload;
}

app.post('/api/chats/:personId/send', (req, res) => {
  const { text, media, type, sticker } = req.body || {};
  const body = String(text || '').trim().slice(0, 4000);
  const acc = auth.accountOfToken(auth.tokenOf(req));
  const db0 = store.read();
  // نوع الرسالة صريح ومحدود: text · image · video · audio · sticker
  // (وديعة المستند تُقبل كما كانت، وسجلّ المكالمة يُكتب من الخادم وحده)
  const wanted = CHAT_TYPES.includes(String(type || '')) ? String(type) : '';
  let st = null;
  if (wanted === 'sticker' || (sticker && !media)) {
    st = stickers.resolve(sticker && sticker.pack, sticker && sticker.id);
    if (!st) return fail(res, 400, 'ملصق غير معروف');
  }
  let att = null;
  if (media) {
    att = chatAttachment(media, db0, acc && acc.id);
    if (!att) return fail(res, 400, 'المرفق غير صالح');
  }
  if (!body && !att && !st) return fail(res, 400, 'نص الرسالة مطلوب');
  const msgType = st ? 'sticker' : att ? att.type : 'text';
  if (wanted && !st && !att && wanted !== 'text') return fail(res, 400, 'نوع الرسالة لا يطابق مرفقها');
  const personId = req.params.personId;
  const db = store.mutate((d) => {
    const person = d.people.find((p) => p.id === personId);
    if (!person) return d;
    let chat = d.chats.find((c) => c.personId === personId);
    if (!chat) {
      chat = { id: store.id('c'), personId, unread: 0, messages: [] };
      d.chats.unshift(chat);
    }
    chat.messages.push({
      id: store.id('mg'),
      from: 'u-me',
      text: body,
      type: msgType,
      ...(att ? { media: att } : {}),
      ...(st ? { sticker: { pack: st.pack, id: st.id, title: st.title, url: st.url } } : {}),
      at: new Date().toISOString(),
    });
    chat.unread = 0;
    return d;
  });
  const found = db.chats.find((c) => c.personId === personId);
  if (!found) return fail(res, 404, 'لا يوجد شخص بهذا المعرّف في دائرتك');
  // الطرف الآخر يرى الرسالة فورًا إن كان متصلًا (بلا انتظار تحديث دوري)
  rtc.notifyChat(personId, null);
  ok(res, refreshVoiceUrls(bootstrap()));
});

app.post('/api/chats/:personId/read', (req, res) => {
  if (!store.read().people.some((p) => p.id === req.params.personId)) {
    return fail(res, 404, 'لا يوجد شخص بهذا المعرّف في دائرتك');
  }
  store.mutate((d) => {
    const chat = d.chats.find((c) => c.personId === req.params.personId);
    if (chat) chat.unread = 0;
    return d;
  });
  ok(res, bootstrap());
});

// ── الملف الشخصي والإشعارات ──
app.post('/api/me', (req, res) => {
  const { name, city, privacy, prefs, username, avatar } = req.body || {};
  // اسم المستخدم هنا يُعدَّل من «ملفي» بنفس قواعد الإنشاء وبنفس فحص الحجز
  const uname = username === undefined ? null : auth.normalizeUsername(username);
  if (uname && !uname.ok) return fail(res, 400, uname.error);
  const meAcc = auth.accountOfToken(auth.tokenOf(req));
  if (uname && uname.ok && meAcc) {
    const owner = auth.usernameOwner(store.read(), uname.username, meAcc.id);
    if (owner) return fail(res, 409, `الاسم @${uname.username} محجوز — جرّب غيره`);
  }
  // الصورة: رابط داخلي من وسائط التطبيق، أو '' لإزالتها
  let pic = null;
  if (avatar !== undefined) {
    pic = auth.cleanAvatar(avatar);
    if (String(avatar).trim() && !pic) return fail(res, 400, 'صورة العرض غير صالحة');
  }
  store.mutate((d) => {
    // الهوية من الجلسة لا من مقارنة رقم: المخزن لم يعد يحمل أرقامًا خامة
    const sid = (auth.accountOfToken(auth.tokenOf(req)) || {}).id || null;
    const sync = () => (sid ? (d.accounts || []).find((x) => x.id === sid) : null);
    if (name) {
      d.me.name = String(name);
      const a = sync(); if (a) a.name = String(name);
    }
    if (city) d.me.city = String(city);
    if (privacy) d.me.privacy = { ...d.me.privacy, ...privacy };
    if (prefs) d.me.prefs = { ...d.me.prefs, ...prefs };
    if (pic !== null) {
      d.me.avatar = pic;
      const a = sync(); if (a) a.avatar = pic;
    }
    if (uname && uname.ok) {
      d.me.username = uname.username;
      d.me.handle = '@' + uname.username;
      const a = sync();
      if (a) { a.username = uname.username; a.handle = '@' + uname.username; }
    }
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/notifications/read', (req, res) => {
  store.mutate((d) => {
    d.notifications.forEach((n) => { n.read = true; });
    return d;
  });
  ok(res, bootstrap());
});

app.post('/api/circle/invite', (req, res) => {
  const { name, relation } = req.body || {};
  if (!name) return fail(res, 400, 'الاسم مطلوب');
  store.mutate((d) => {
    d.people.unshift({
      id: store.id('u'),
      name: String(name),
      city: d.me.city,
      relation: relation || 'دائرة قريبة',
      lastSeen: 'الآن',
      color: '#0F766E',
      verified: false,
      invited: true,
    });
    return d;
  });
  ok(res, bootstrap());
});

// ── التواصل باسم المستخدم ────────────────────────────────────────────────
// سبب وجود اسم المستخدم: شخصان لا يملك أحدهما رقم هاتف الآخر. فيعطي أحدهما
// اسمه المستخدم فقط (@sawa4567) فيبدأ بينهما تواصل — والرقم يبقى مخفيًا.
app.get('/api/people/lookup', (req, res) => {
  const uname = auth.normalizeUsername((req.query || {}).username);
  if (!uname.ok) return fail(res, 400, uname.error);
  const db = store.read();
  const acc = (db.accounts || []).find((a) => a.username === uname.username) || null;
  if (!acc) return fail(res, 404, `لا يوجد حساب بالاسم @${uname.username}`);
  const meAcc = auth.accountOfToken(auth.tokenOf(req));
  if (meAcc && meAcc.id === acc.id) return fail(res, 400, 'هذا اسمك أنت — شاركه مع من تريد');
  const known = (db.people || []).find((p) => p.username === acc.username) || null;
  return ok(res, {
    person: {
      id: known ? known.id : null,
      name: acc.name,
      username: acc.username,
      avatar: acc.avatar || '',
      city: acc.city || '',
      color: acc.color || '#0F766E',
      known: Boolean(known),
    },
  });
});

// إضافة شخص بالاسم المستخدم: يُضاف إلى دائرتي وتُفتح محادثة مباشرة — بلا رقم هاتف
app.post('/api/circle/from-username', (req, res) => {
  const uname = auth.normalizeUsername((req.body || {}).username);
  if (!uname.ok) return fail(res, 400, uname.error);
  const db0 = store.read();
  const acc = (db0.accounts || []).find((a) => a.username === uname.username) || null;
  if (!acc) return fail(res, 404, `لا يوجد حساب بالاسم @${uname.username}`);
  let personId = null;
  let created = false;
  const meAcc = auth.accountOfToken(auth.tokenOf(req));
  store.mutate((d) => {
    d.people = d.people || [];
    d.chats = d.chats || [];
    let p = d.people.find((x) => x.username === acc.username) || null;
    if (!p) {
      p = {
        id: store.id('u'),
        name: acc.name,
        username: acc.username,
        avatar: acc.avatar || '',
        city: acc.city || '',
        relation: 'من اسم مستخدم',
        lastSeen: 'الآن',
        color: acc.color || '#0F766E',
        verified: true,
        viaUsername: true,
      };
      d.people.unshift(p);
      created = true;
    }
    personId = p.id;
    if (!d.chats.some((c) => c.personId === p.id)) {
      d.chats.unshift({ id: store.id('c'), personId: p.id, unread: 0, messages: [] });
    }
    // العضوية الخادمية (v31): من تضيفه باسم المستخدم يدخل دائرتك الافتراضية،
    // فيصير مسموحًا لك الاتصال به (بند ٩ من طلب الاتصال) — وبلا هذا تبقى
    // المكالمة ممنوعة لأن العضوية هي ما يمنح الإذن، لا وجود الاسم في القائمة.
    if (meAcc) {
      privLayer.ensure(d);
      const circle = (d.circles || []).find((c) => c.ownerId === meAcc.id && c.seed)
        || (d.circles || []).find((c) => c.ownerId === meAcc.id);
      if (circle) {
        circle.memberIds = circle.memberIds || [];
        if (!circle.memberIds.includes(acc.id)) circle.memberIds.push(acc.id);
      }
    }
    return d;
  });
  const out = bootstrap();
  out.added = { personId, created, person: (store.read().people || []).find((p) => p.id === personId) || null };
  return ok(res, out);
});

// مسح المخزن: مسار تشغيلي لا يعمل إلا بطلب صريح من مشغّل الخادم.
// كان مفتوحًا لأي زائر (تأكيد في الجسم فقط) — وبعد إزالة البذرة صار المسح يعني
// ضياع كل ما بناه المستخدمون فعلًا، فلا يُترك باب بمفتاح منشور على الإنترنت.
// للتشغيل: SAWA_ALLOW_WIPE=1 في بيئة الخادم مع جلسة صالحة وconfirm:"reset".
app.post('/api/reset', (req, res) => {
  if (process.env.SAWA_ALLOW_WIPE !== '1') {
    return fail(res, 403, 'المسح معطّل على هذا الخادم (يُفعّل بـ SAWA_ALLOW_WIPE=1 عند الحاجة)');
  }
  const who = auth.accountOfToken(auth.tokenOf(req));
  if (!who) {
    return fail(res, 401, 'سجّل الدخول أولًا', 'no_session');
  }
  if (String((req.body || {}).confirm || '') !== 'reset') {
    return fail(res, 400, 'المسح يحتاج تأكيدًا صريحًا (confirm: "reset")');
  }
  const { DB_FILE } = store;
  if (fs.existsSync(DB_FILE)) fs.unlinkSync(DB_FILE);
  store.init();
  console.warn('[smart-social] مُسح المخزن بطلب من الحساب ' + who.id);
  return ok(res, { ok: true, wiped: true });
});

// ── تقديم الواجهة: «صدفة واحدة» مُدمجة (server/shell.html) = طلب واحد للفتح ──
// السبب: وكيل الساندبوكس يخدم الطلب الواحد في ~٢ ثانية ويُسلسل الطلبات، فدمج
// CSS + JS + بيانات الإقلاع في صفحة واحدة يجعل الفتح طلبًا واحدًا بدل أربعة.
const DIST = path.join(__dirname, '..', 'client', 'dist');
const SHELL_META_FILE = path.join(__dirname, 'shell.json');
let shellMetaCache = { mtime: 0, data: {} };
function shellMeta() { // يُقرأ مرة عند أول طلب، ويُعاد قراءته إن تغيّر الملف (نشر جديد)
  try {
    const st = fs.statSync(SHELL_META_FILE);
    if (shellMetaCache.mtime !== st.mtimeMs) {
      shellMetaCache = { mtime: st.mtimeMs, data: JSON.parse(fs.readFileSync(SHELL_META_FILE, 'utf8')) };
    }
    return shellMetaCache.data;
  } catch (e) { return {}; }
}
const SHELL_FILE = path.join(__dirname, 'shell.html');
const BOOT_TOKEN = '__SAWA_BOOT_JSON__';

let shellFile = { mtime: 0, text: '' };
function shellSource() {
  try {
    const st = fs.statSync(SHELL_FILE);
    if (shellFile.mtime !== st.mtimeMs) {
      shellFile = { mtime: st.mtimeMs, text: fs.readFileSync(SHELL_FILE, 'utf8') };
    }
    return shellFile.text;
  } catch (e) { return ''; }
}

// بيانات الإقلاع تُحقن في الصفحة نفسها: الرسم الأول بلا أي طلب API إضافي.
// ونُخزّن آخر صفحة مُركّبة بالمحتوى نفسه كي لا نُعيد البناء لأجل لا شيء.
let built = { hash: '', body: '' };
function renderShell(req) {
  const src = shellSource();
  if (!src) return '';
  let json = 'null';
  try {
    // في الوضع الصارم: لا بيانات إقلاع قبل الدخول — الواجهة تُظهر شاشة الدخول
    const allowed = !auth.STRICT || Boolean(auth.accountOfToken(auth.tokenOf(req || { headers: {} })));
    json = allowed ? JSON.stringify(bootstrap()).replace(/</g, '\\u003c') : 'null';
  } catch (e) { json = 'null'; }
  const hash = require('crypto').createHash('md5').update(src.length + '|' + json).digest('hex');
  if (built.hash === hash) return built.body;
  // split/join لا replace: نص الاستبدال يفسّر $$ و $& و $` فيُفسد الشيفرة أو JSON
  const body = src.split(BOOT_TOKEN).join(json);
  built = { hash, body };
  return body;
}

function serveShell(req, res) {
  const body = renderShell(req);
  if (!body) return res.sendFile(path.join(DIST, 'index.html'));
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache');
  res.send(body);
}

if (fs.existsSync(DIST)) {
  app.get('/', serveShell);
  app.get('/index.html', serveShell);
  // الأصول الثابتة (أيقونات، عامل الخدمة، manifest) — بلا index لئلا يسبق الصدفة
  app.use(express.static(DIST, {
    index: false,
    setHeaders: (res, filePath) => {
      if (filePath.includes(`${path.sep}assets${path.sep}`)) {
        res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      } else {
        res.setHeader('Cache-Control', 'no-cache');
      }
    },
  }));
  // مسارات الأصول والملفات لا تُخدَم بالصدفة: طلب حزمة غير موجودة يُعيد 404
  // لا صفحة HTML برمز 200. السبب: صفحة قديمة محفوظة (أو عامل خدمة قديم) تطلب
  // حزمة بحاشية سابقة كانت تحصل على HTML فيتوقف المتصفح بخطأ «Unexpected token '<'»
  // بدل أن يكتشف العميل النسخة القديمة ويعيد التحديث.
  const ASSET_DIR_RE = /^\/(?:assets|icons)\//;
  const FILE_EXT_RE = /\.(?:js|mjs|css|map|png|jpe?g|gif|webp|avif|svg|ico|wav|mp3|m4a|webm|mp4|json|txt|xml|webmanifest|woff2?|ttf|otf)$/i;
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    if (ASSET_DIR_RE.test(req.path) || FILE_EXT_RE.test(req.path)) {
      res.setHeader('Cache-Control', 'no-store');
      return res.status(404).json({ error: 'asset not found', path: req.path });
    }
    serveShell(req, res);
  });
} else {
  app.get('/', (req, res) => res.send('smart-social API is running. Build the client first.'));
}

app.use((err, req, res, next) => {
  if (err && (err.type === 'entity.too.large' || err.status === 413)) {
    return res.status(413).json({ error: 'حجم الوسائط أكبر من الحد المسموح — اختر ملفًا أصغر.' });
  }
  console.error('[smart-social] handler error:', err && (err.stack || err.message || err));
  if (err) return res.status(400).json({ error: 'طلب غير صالح' });
  return next();
});

app.use((req, res) => res.status(404).json({ error: 'not found', path: req.path }));

// إغلاق الغرف المنتهية تلقائيًا
setInterval(() => {
  try {
    store.mutate((d) => { store.tick(d); return d; });
  } catch (e) { /* ignore */ }
}, 60 * 1000);

// ── الإقلاع: منفذ واحد فقط + خادم واحد لكل مجلد بيانات ──
// القاعدة: إذا حدّدت المنصة PORT نلتزم به وحده (لا منافذ احتياطية تشغل مساحة
// الساندبوكس)، وإلا نجرّب منافذ التطوير الشائعة عند التشغيل المحلي.
const CANDIDATES = [];
const envPort = Number(process.env.PORT);
if (envPort > 0 && envPort < 65536) CANDIDATES.push(envPort);
else if (process.env.PORT_SINGLE !== '1') {
  [5056, 5000, 3000, 8080].forEach((p) => CANDIDATES.push(p));
}
if (!CANDIDATES.length) CANDIDATES.push(PORT);

const PID_FILE = path.join(DATA_DIR, 'server.pids.json');
const ROOT_DIR = path.join(__dirname, '..');

const readPids = () => {
  try {
    const list = JSON.parse(fs.readFileSync(PID_FILE, 'utf8'));
    return Array.isArray(list) ? list : [];
  } catch (e) { return []; }
};

const alive = (pid) => {
  try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; }
};

const sameServer = (pid) => {
  try {
    const cmd = fs.readFileSync(`/proc/${pid}/cmdline`, 'utf8').replace(/\0/g, ' ').trim();
    // صيغتا التشغيل: «node server/index.js» من جذر المشروع و«node index.js» من مجلد
    // الخادم (وهي صيغة وكيل الساندبوكس). كان الفحص يقبل الأولى فقط، فلم يكن الخادم
    // يُنظّف نسخه القديمة وتراكمت عدة عمليات على المنافذ.
    if (!/(^|[ /])index\.js(\s|$)/.test(cmd)) return false;
    const cwd = path.resolve(fs.readlinkSync(`/proc/${pid}/cwd`));
    return cwd === path.resolve(__dirname) || cwd === path.resolve(ROOT_DIR);
  } catch (e) { return false; }
};

// نسخة فحص/تطوير: لا تلمس سجل الخوادم ولا تقتل أحدًا (SAWA_NO_TAKEOVER=1).
const NO_TAKEOVER = process.env.SAWA_NO_TAKEOVER === '1';
// تنظيف قسري لكل نسخ نفس المجلد (SAWA_TAKEOVER=force) — للأدوات اليدوية فقط.
const TAKEOVER_FORCE = process.env.SAWA_TAKEOVER === 'force';

// قاعدة السلامة: لا نقتل خادمًا يعمل على **منفذ آخر**. الحادثة التي أوجبت هذا:
// نسخة فحص ربطت منفذًا عشوائيًا ثم قتلت خادم المنصة (منفذ آخر) فظهر 503 متقطّع.
// من يشغل منفذ المنصة يُستبدل في مسار EADDRINUSE أدناه — لا هنا.
function takeover() {
  if (NO_TAKEOVER) return;
  const mine = { pid: process.pid, port: boundPort, root: ROOT_DIR, startedAt: Date.now(), rev: REV };
  const others = readPids().filter((e) => e && e.pid && e.pid !== process.pid);
  const survivors = others.filter((e) => alive(e.pid));
  const targets = survivors.filter((e) => {
    if (e.root && e.root !== ROOT_DIR) return false; // خادم مشروع آخر — لا نمسّه
    if (!sameServer(e.pid)) return false;
    if (TAKEOVER_FORCE) return true;
    return Number(e.port) === Number(boundPort); // نفس منفذنا فقط
  });
  const rest = survivors.filter((e) => !targets.includes(e));
  if (targets.length) {
    console.log(`[smart-social] تنظيف ${targets.length} خادمًا قديمًا`);
    targets.forEach((e) => { try { process.kill(e.pid, 'SIGTERM'); } catch (err) { /* تجاهل */ } });
    setTimeout(() => {
      targets.forEach((e) => {
        if (!alive(e.pid) || !sameServer(e.pid)) return;
        try { process.kill(e.pid, 'SIGKILL'); } catch (err) { /* تجاهل */ }
      });
      writePids([mine, ...rest]);
    }, 700);
  } else {
    if (survivors.length) console.log(`[smart-social] نسخة أخرى تعمل على منفذ مختلف — لا نمسّها (${survivors.length})`);
    writePids([mine, ...survivors]);
  }
}

function writePids(list) {
  try { fs.writeFileSync(PID_FILE, JSON.stringify(list, null, 2), 'utf8'); } catch (e) { /* تجاهل */ }
}

function listen(index) {
  const port = CANDIDATES[index];
  if (port === undefined) {
    console.error('[smart-social] لا منفذ متاح — إيقاف');
    process.exit(1);
    return;
  }
  const srv = app.listen(port, HOST, () => {
    boundPort = port;
    console.log(`[smart-social] listening on http://${HOST}:${port} (rev ${REV}, pid ${process.pid})`);
    takeover();
  });
  // v32: قناة إشارات المكالمة على نفس المنفذ (/ws/rtc) — والبديل SSE إن حجب الوكيل الترقية
  try {
    rtc.attachWs(srv);
  } catch (e) {
    console.error('[smart-social] تعذّر تركيب قناة الإشارات:', e && e.message);
  }
  srv.on('error', (err) => {
    console.log(`[smart-social] port ${port} unavailable (${err.code})`);
    // منفذ المنصة مشغول بخادم سابق: نستبدله بدل تشغيل نسخة صامتة
    if (err.code === 'EADDRINUSE' && index === 0 && envPort > 0) {
      const stale = readPids().find((e) => e && e.port === port && e.pid !== process.pid && alive(e.pid) && sameServer(e.pid));
      if (stale) {
        console.log(`[smart-social] استبدال خادم قديم على المنفذ ${port} (pid ${stale.pid})`);
        try { process.kill(stale.pid, 'SIGTERM'); } catch (e2) { /* تجاهل */ }
        return setTimeout(() => listen(index), 800);
      }
    }
    listen(index + 1);
  });
}

listen(0);

const shutdown = () => {
  try {
    writePids(readPids().filter((e) => e && e.pid !== process.pid));
  } catch (e) { /* تجاهل */ }
  process.exit(0);
};
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

process.on('uncaughtException', (err) => {
  console.log('[smart-social] uncaught:', err && err.message);
});

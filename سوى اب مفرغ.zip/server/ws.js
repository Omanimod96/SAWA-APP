// ─────────────────────────────────────────────────────────────────────────────
// ws.js — خادم WebSocket مصغّر (RFC 6455) بلا أي اعتمادية خارجية.
//
// لماذا لا نضيف حزمة `ws`: الإقلاع في الساندبوكس/النشر يُعيد تثبيت اعتماديات
// الخادم من package-lock عند كل استعادة، وأي اعتمادية جديدة = نقطة فشل إقلاع
// إضافية. إشارات المكالمة نصوص صغيرة (SDP/ICE) لا تحتاج أكثر من هذا.
//
// ما يُدعم: الإطار النصّي، ping/pong، close، تجزيء الإطارات الصغيرة (continuation)،
// وإخفاء العميل (mask) كما يفرضه المعيار. الحد الأقصى للرسالة محدود (DoS).
// ─────────────────────────────────────────────────────────────────────────────
const crypto = require('crypto');

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_MESSAGE = 64 * 1024;   // إشارات المكالمة صغيرة؛ حماية من رسالة ضخمة
const MAX_BUFFER = 256 * 1024;   // سقف المخزن المؤقت قبل إغلاق الاتصال

const OP = { CONT: 0x0, TEXT: 0x1, BIN: 0x2, CLOSE: 0x8, PING: 0x9, PONG: 0xa };

const accept = (key) => crypto.createHash('sha1').update(key + GUID).digest('base64');

// إطار واحد من الخادم إلى العميل (بلا إخفاء — الخادم لا يُخفي)
function encode(payload, opcode) {
  const data = Buffer.isBuffer(payload) ? payload : Buffer.from(String(payload), 'utf8');
  const len = data.length;
  let head;
  if (len < 126) {
    head = Buffer.alloc(2);
    head[1] = len;
  } else if (len < 65536) {
    head = Buffer.alloc(4);
    head[1] = 126;
    head.writeUInt16BE(len, 2);
  } else {
    head = Buffer.alloc(10);
    head[1] = 127;
    head.writeUInt32BE(0, 2);
    head.writeUInt32BE(len, 6);
  }
  head[0] = 0x80 | opcode; // FIN + opcode
  return Buffer.concat([head, data]);
}

// ── جلسة واحدة: واجهة صغيرة تفصل بقية الخادم عن تفاصيل الإطار ──
class Conn {
  constructor(socket, info) {
    this.socket = socket;
    this.info = info || {};
    this.alive = true;
    this.closed = false;
    this.listeners = { message: [], close: [] };
    this.buf = Buffer.alloc(0);
    this.frag = { opcode: 0, chunks: [], size: 0 };
    socket.on('data', (chunk) => this.feed(chunk));
    socket.on('error', () => this.destroy());
    // 'end' ثم 'close': مقبس الترقية يأتي من خادم HTTP بسلوك half-open، فيصل 'end'
    // عند انقطاع العميل بلا 'close'. تجاهل 'end' كان يُبقي جلسة ميتة في السجلّ
    // (شوهد فعلًا: مكالمة تظل «رنين» إلى الأبد لأن الخادم لم يلاحظ انقطاع الطرف).
    socket.on('end', () => this.destroy());
    socket.on('close', () => this.fire('close'));
    socket.setTimeout(0);
    socket.setNoDelay(true);
  }

  on(name, fn) { (this.listeners[name] || (this.listeners[name] = [])).push(fn); return this; }

  fire(name, arg) {
    const list = this.listeners[name] || [];
    this.listeners[name] = [];
    list.forEach((fn) => { try { fn(arg); } catch (e) { /* مستمع معطوب لا يُسقط الاتصال */ } });
  }

  send(obj) {
    if (this.closed) return false;
    const text = typeof obj === 'string' ? obj : JSON.stringify(obj);
    try { this.socket.write(encode(text, OP.TEXT)); return true; } catch (e) { this.destroy(); return false; }
  }

  ping() {
    if (this.closed) return;
    try { this.socket.write(encode(Buffer.alloc(0), OP.PING)); } catch (e) { this.destroy(); }
  }

  close(code) {
    if (this.closed) return;
    this.closed = true;
    try {
      const body = Buffer.alloc(2);
      body.writeUInt16BE(code || 1000, 0);
      this.socket.write(encode(body, OP.CLOSE));
      this.socket.end();
    } catch (e) { /* تجاهل */ }
    setTimeout(() => this.destroy(), 1500).unref?.();
  }

  destroy() {
    if (!this.closed) { this.closed = true; }
    try { this.socket.destroy(); } catch (e) { /* تجاهل */ }
    this.fire('close');
  }

  // تقطيع الإطارات: الرأس أولًا ثم الحمولة (mask إن وُجد)
  feed(chunk) {
    if (this.closed) return;
    this.buf = this.buf.length ? Buffer.concat([this.buf, chunk]) : chunk;
    if (this.buf.length > MAX_BUFFER) { this.close(1009); return; }
    for (;;) {
      const frame = this.readFrame();
      if (!frame) return;
      if (frame.error) { this.close(1002); return; }
    }
  }

  readFrame() {
    const b = this.buf;
    if (b.length < 2) return null;
    const fin = (b[0] & 0x80) !== 0;
    const rsv = b[0] & 0x70;
    const opcode = b[0] & 0x0f;
    const masked = (b[1] & 0x80) !== 0;
    let len = b[1] & 0x7f;
    let off = 2;
    if (rsv) return { error: true };
    if (len === 126) {
      if (b.length < off + 2) return null;
      len = b.readUInt16BE(off); off += 2;
    } else if (len === 127) {
      if (b.length < off + 8) return null;
      const hi = b.readUInt32BE(off);
      const lo = b.readUInt32BE(off + 4);
      if (hi !== 0 || lo > MAX_MESSAGE) return { error: true };
      len = lo; off += 8;
    }
    if (len > MAX_MESSAGE) return { error: true };
    let mask = null;
    if (masked) {
      if (b.length < off + 4) return null;
      mask = b.slice(off, off + 4); off += 4;
    }
    if (b.length < off + len) return null;
    let payload = b.slice(off, off + len);
    if (mask) {
      const out = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i += 1) out[i] = payload[i] ^ mask[i & 3];
      payload = out;
    }
    this.buf = b.slice(off + len);
    this.handle(opcode, payload, fin);
    return { ok: true };
  }

  handle(opcode, payload, fin) {
    if (opcode === OP.PING) { try { this.socket.write(encode(payload, OP.PONG)); } catch (e) { /* تجاهل */ } return; }
    if (opcode === OP.PONG) { this.alive = true; return; }
    if (opcode === OP.CLOSE) { this.close(1000); return; }
    if (opcode === OP.TEXT || opcode === OP.BIN) {
      this.frag = { opcode, chunks: [payload], size: payload.length };
    } else if (opcode === OP.CONT) {
      if (!this.frag.opcode) { this.close(1002); return; }
      this.frag.chunks.push(payload);
      this.frag.size += payload.length;
      if (this.frag.size > MAX_MESSAGE) { this.close(1009); return; }
    } else return;
    if (!fin) return;
    const full = Buffer.concat(this.frag.chunks).toString('utf8');
    this.frag = { opcode: 0, chunks: [], size: 0 };
    let data = null;
    try { data = JSON.parse(full); } catch (e) { return; } // لا نمرّر نصًّا غير JSON (العقد: JSON فقط)
    if (!data || typeof data !== 'object') return;
    (this.listeners.message || []).forEach((fn) => { try { fn(data); } catch (e) { /* تجاهل */ } });
  }
}

// يُثبَّت على خادم HTTP: يلتقط ترقية المسارات المُعلنة وحدها
function attach(server, options) {
  const opts = options || {};
  const routes = opts.routes || {};
  const conns = new Set();

  server.on('upgrade', (req, socket, head) => {
    const url = (() => { try { return new URL(req.url, 'http://localhost'); } catch (e) { return null; } })();
    const handler = url && routes[url.pathname];
    const key = req.headers['sec-websocket-key'];
    if (!handler || !key || String(req.headers.upgrade || '').toLowerCase() !== 'websocket') {
      socket.write('HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }
    let outcome = null;
    try { outcome = handler(req, url); } catch (e) { outcome = { reject: 500 }; }
    if (!outcome || outcome.reject) {
      const code = (outcome && outcome.reject) || 401;
      const why = code === 403 ? 'Forbidden' : code === 500 ? 'Internal Server Error' : 'Unauthorized';
      socket.write(`HTTP/1.1 ${code} ${why}\r\nConnection: close\r\n\r\n`);
      socket.destroy();
      return;
    }
    socket.write(
      'HTTP/1.1 101 Switching Protocols\r\n' +
      'Upgrade: websocket\r\n' +
      'Connection: Upgrade\r\n' +
      `Sec-WebSocket-Accept: ${accept(key)}\r\n\r\n`,
    );
    if (head && head.length) socket.unshift(head);
    const conn = new Conn(socket, outcome.info);
    conns.add(conn);
    conn.on('close', () => conns.delete(conn));
    // نبض الحياة: PING كل ٣٠ ثانية، والمتصفح يردّ PONG تلقائيًا. غياب الردّ
    // يعني وصلة ميتة (شبكة انقطعت بلا إغلاق) — نُغلقها بدل إبقاء جلسة وهمية.
    const timer = setInterval(() => {
      if (conn.closed) { clearInterval(timer); return; }
      if (conn.alive === false) { conn.destroy(); clearInterval(timer); return; }
      conn.alive = false;
      conn.ping();
    }, 30000);
    timer.unref?.();
    try { outcome.onOpen(conn); } catch (e) { conn.close(1011); }
  });

  return { conns, encode, OP };
}

module.exports = { attach, encode, OP, MAX_MESSAGE };

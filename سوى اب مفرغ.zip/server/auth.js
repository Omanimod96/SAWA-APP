/**
 * الدخول إلى «سوى» برقم الهاتف + رمز تحقق (OTP) + إنشاء الحساب.
 *
 *   رقم الهاتف → رمز التحقق → إنشاء الحساب
 *
 * ── وضع التجربة ─────────────────────────────────────────────────────────────
 * الرمز الآن **ثابت 123456** لكل الأرقام، لأن التطبيق في مرحلة تجربة العرض.
 * للعودة إلى رمز عشوائي حقيقي: SAWA_DEMO_OTP=off ثم ربط مزوّد رسائل (SMS).
 * الخادم يطبع تحذيرًا عند الإقلاع حين يكون الوضع التجريبي مُفعّلًا، ويُظهره
 * في /api/health حتى لا ينتقل هذا الوضع إلى الإنتاج من حيث لا نعلم.
 *
 * ── ملاحظات تصميم ───────────────────────────────────────────────────────────
 * • رمز التحقق قيد الانتظار يُحفظ في ذاكرة العملية لا في المخزن: رمز عمره دقائق
 *   ولا معنى لكتابته على القرص (وكتابة القرص لكل طلب رمز تُبطئ وتُنشئ تنازعًا).
 * • الجلسات تُحفظ في المخزن لأنها تعيش ٣٠ يومًا ويجب أن تصمد لإعادة تشغيل الخادم.
 * • لا نُرسل الرمز الصحيح أبدًا في أي رد إلا في وضع التجربة صراحةً (demoCode).
 */
const express = require('express');
const crypto = require('crypto');
const store = require('./store');
const privacy = require('./privacy');

const CODE_LEN = 6;

// أرقام عربية/فارسية → لاتينية. لوحة المفاتيح العربية تُنتج «١٢٣٤٥٦» و«٩١٢٣٤٥٦٧»،
// و`\d` في جافاسكربت لا يراها أرقامًا فتُحذف كلها: يبقى الرمز فارغًا أو الرقم ناقصًا
// ويُرفض الطلب بلا سبب مفهوم. نُطبّع في مكان واحد قبل كل تحقّق.
const toLatinDigits = (s) => String(s == null ? '' : s).replace(/[\u0660-\u0669\u06F0-\u06F9]/g, (ch) => {
  const a = '٠١٢٣٤٥٦٧٨٩'.indexOf(ch);
  if (a > -1) return String(a);
  const p = '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch);
  return p > -1 ? String(p) : ch;
});
const rawOtp = process.env.SAWA_DEMO_OTP === undefined ? '123456' : String(process.env.SAWA_DEMO_OTP).trim();
const DEMO = rawOtp !== '' && rawOtp !== 'off' && rawOtp !== '0';
const DEMO_OTP = DEMO ? (/^\d{6}$/.test(rawOtp) ? rawOtp : '123456') : null;

const OTP_TTL_MS = 5 * 60 * 1000;        // صلاحية رمز التحقق
const SESSION_TTL_MS = 30 * 24 * 3600 * 1000;
const MAX_TRIES = 6;                      // محاولات إدخال الرمز لكل تحدٍّ
const SEND_WINDOW_MS = 10 * 60 * 1000;
const MAX_SEND_PER_PHONE = 5;             // طلبات رمز لكل رقم في ١٠ دقائق
const MAX_SEND_PER_IP = 25;

const COLORS = ['#1D4ED8', '#0F766E', '#7C3AED', '#B45309', '#0891B2', '#4F46E5', '#15803D', '#BE185D'];

// ── اسم المستخدم: قناة التواصل مع من لا تعرف رقمه ──────────────────────────
// الفكرة: رقم الهاتف يبقى سرًّا ولا يظهر لأحد، ويصبح **اسم المستخدم** هو العنوان
// الذي يعطي به الشخص غيره ليتواصلوا. لذلك: حروف إنجليزية صغيرة وأرقام و _ فقط،
// بلا مسافات ولا حروف عربية (يُكتب بسهولة على أي لوحة مفاتيح ويُنسخ شفهيًا)،
// و٣–٢٠ حرفًا، ويبدأ بحرف.
const USERNAME_RE = /^[a-z][a-z0-9_]{2,19}$/;
const RESERVED = new Set(['sawa', 'sana', 'admin', 'support', 'help', 'me', 'you', 'official', 'sawaapp', 'system']);

function normalizeUsername(raw) {
  const u = String(raw == null ? '' : raw).trim().replace(/^@+/, '').toLowerCase();
  if (!u) return { ok: false, error: 'اختر اسم مستخدم' };
  if (/[^a-z0-9_]/.test(u)) return { ok: false, error: 'حروف إنجليزية صغيرة وأرقام و _ فقط' };
  if (u.length < 3) return { ok: false, error: 'ثلاثة أحرف على الأقل' };
  if (!USERNAME_RE.test(u)) return { ok: false, error: 'يبدأ بحرف، وحتى ٢٠ حرفًا' };
  if (RESERVED.has(u)) return { ok: false, error: 'اسم محجوز — جرّب غيره' };
  return { ok: true, username: u };
}

const usernameOwner = (db, username, exceptId) =>
  ((db && db.accounts) || []).find((a) => a.username === username && a.id !== exceptId) || null;

// اقتراح جاهز للواجهة: sawa + آخر أربعة أرقام من هاتفه
const suggestUsername = (local) => `sawa${String(local || '').slice(-4)}`.slice(0, 20);

// صورة العرض: رابط داخلي من وسائط التطبيق فقط — لا روابط خارجية تُتبَّع أو تتغيّر
function cleanAvatar(raw) {
  const u = String(raw == null ? '' : raw).trim();
  if (!u) return '';
  if (u.length > 200) return '';
  if (!/^api\/media\/[A-Za-z0-9._-]+$/.test(u)) return '';
  if (u.includes('..')) return '';
  return u;
}

// ── تطبيع رقم الهاتف ──
// يقبل: 91234567 · 091234567 · 96891234567 · +968 9123 4567 · 00968 91234567
function normalizePhone(input) {
  let digits = toLatinDigits(input).replace(/[^\d]/g, '');
  if (!digits) return { ok: false, error: 'أدخل رقم الهاتف' };
  if (digits.startsWith('00')) digits = digits.slice(2);
  if (digits.startsWith('968')) digits = digits.slice(3);
  if (digits.length > 8 && digits.startsWith('0')) digits = digits.replace(/^0+/, '');
  if (!/^[1-9]\d{7}$/.test(digits)) {
    return {
      ok: false,
      error: digits.length > 8
        ? 'الرقم أطول من المعتاد — ٨ أرقام بلا مقدّمة الدولة (مثال: 91234567)'
        : 'رقم غير مكتمل — ٨ أرقام (مثال: 91234567)',
    };
  }
  return { ok: true, phone: `968${digits}`, local: digits };
}

// عرض مقنّع للرقم في الواجهة: 9•••4567
const maskPhone = (local) => `${local.slice(0, 1)}•••${local.slice(-4)}`;

// ── تحدّيات التحقق (في الذاكرة) ──
const challenges = new Map(); // phone → { code, expiresAt, tries, sentAt }
const sendLog = new Map();    // مفتاح → [أوقات]

function sweep(now) {
  challenges.forEach((c, phone) => { if (c.expiresAt < now) challenges.delete(phone); });
  sendLog.forEach((list, key) => {
    const kept = list.filter((t) => now - t < SEND_WINDOW_MS);
    if (kept.length) sendLog.set(key, kept); else sendLog.delete(key);
  });
}
setInterval(() => sweep(Date.now()), 60 * 1000).unref();

// فحص الحدّ بلا تسجيل، والتسجيل منفصل — لأن طلبًا مرفوضًا لا يجب أن يُحتسب
function limitHit(key, limit) {
  const now = Date.now();
  const list = (sendLog.get(key) || []).filter((t) => now - t < SEND_WINDOW_MS);
  if (list.length >= limit) return Math.max(1, Math.ceil((SEND_WINDOW_MS - (now - list[0])) / 60000));
  return 0;
}

function record(key) {
  const now = Date.now();
  const list = (sendLog.get(key) || []).filter((t) => now - t < SEND_WINDOW_MS);
  list.push(now);
  sendLog.set(key, list);
}

// ── الجلسات ──
const newToken = () => crypto.randomBytes(24).toString('hex');

function tokenOf(req) {
  const h = req && req.headers ? req.headers : {};
  const raw = h['x-sawa-token'] || h['X-Sawa-Token'] || h.authorization || '';
  const m = /^Bearer\s+(.+)$/i.exec(String(raw));
  return String(m ? m[1] : raw).trim();
}

function accountOfToken(token) {
  if (!token) return null;
  const db = store.read();
  const s = (db.sessions || []).find((x) => x.token === token);
  if (!s) return null;
  if (s.expiresAt && Date.parse(s.expiresAt) < Date.now()) return null;
  return (db.accounts || []).find((a) => a.id === s.accountId) || null;
}

function sessionOf(req) {
  const account = accountOfToken(tokenOf(req));
  return account ? { account } : null;
}

// لا يُعاد رقم خام إلى الواجهة: المقنَّع وحده (بند ٢.٢ و ٧.٢)
const publicAccount = (a) => (a ? {
  id: a.id,
  phone: a.phoneMasked || maskPhone(String(a.phone || '').slice(3)),
  display: a.phoneMasked || maskPhone(String(a.phone || '').slice(3)),
  name: a.name,
  username: a.username || '',
  handle: a.handle || (a.username ? '@' + a.username : ''),
  avatar: a.avatar || '',
  city: a.city,
  color: a.color,
  createdAt: a.createdAt,
} : null);

function startSession(db, account, req) {
  const now = Date.now();
  const token = newToken();
  // تنظيف الجلسات المنتهية قبل الإضافة — لا تتراكم إلى ما لا نهاية
  db.sessions = (db.sessions || []).filter((s) => !s.expiresAt || Date.parse(s.expiresAt) > now);
  // جلسة واحدة فقط: كل جلسات هذا الحساب تُبطَل قبل إضافة الجديدة، فخروج الجهاز
  // القديم يصير حتميًا لحظة الدخول الجديد لا انتظارًا لانتهاء مدته.
  revokeSessionsOf(db, account.id, 'new-login');
  db.sessions.push({
    token,
    accountId: account.id,
    createdAt: new Date(now).toISOString(),
    expiresAt: new Date(now + SESSION_TTL_MS).toISOString(),
    device: deviceLabel(req),
    ip: clientIp(req),
  });
  return token;
}

// ── جلسة واحدة نشطة لكل حساب ───────────────────────────────────────────────
// السياسة: لا أكثر من جلسة واحدة. أي دخول جديد يُغلق السابقة فورًا. الرمز المُبطَل
// يُحفظ في sessionGraves أسبوعًا حتى نستطيع أن نقول للجهاز القديم **لماذا** خرج
// («دخلت من مكان آخر») بدل رسالة «لا جلسة» الغامضة، ثم يُنظَّف تلقائيًا.
const GRAVE_TTL_MS = 7 * 24 * 3600 * 1000;
const GRAVE_MAX = 200;

function revokeSessionsOf(db, accountId, reason, keepToken) {
  const now = Date.now();
  db.sessionGraves = (db.sessionGraves || []).filter((g) => now - Date.parse(g.at) < GRAVE_TTL_MS);
  const keep = [];
  (db.sessions || []).forEach((s) => {
    if (s.accountId !== accountId || (keepToken && s.token === keepToken)) { keep.push(s); return; }
    db.sessionGraves.push({
      token: s.token, accountId, reason, at: new Date(now).toISOString(), device: s.device || '',
    });
  });
  if (db.sessionGraves.length > GRAVE_MAX) db.sessionGraves = db.sessionGraves.slice(-GRAVE_MAX);
  db.sessions = keep;
}

// لماذا خرجت هذه الجلسة؟ (جلسة أُبطِلت بدخول جديد · خروج صريح · لا شيء)
function graveOfToken(token) {
  if (!token) return null;
  const now = Date.now();
  return ((store.read().sessionGraves) || [])
    .find((g) => g.token === token && now - Date.parse(g.at) < GRAVE_TTL_MS) || null;
}

// وصف مبسّط للجهاز — يظهر في رسالة الخروج، ولا يُخزَّن شيء يخصّ هوية صاحبه
function deviceLabel(req) {
  const ua = String((req && req.headers && req.headers['user-agent']) || '');
  if (!ua) return 'جهاز غير معروف';
  const os = /iPhone|iPad|iPod/i.test(ua) ? 'iPhone' : /Android/i.test(ua) ? 'Android'
    : /Macintosh/i.test(ua) ? 'Mac' : /Windows/i.test(ua) ? 'Windows' : /Linux/i.test(ua) ? 'Linux' : 'جهاز';
  const br = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Chrome\//.test(ua) ? 'Chrome'
    : /Safari\//.test(ua) ? 'Safari' : /Firefox\//.test(ua) ? 'Firefox' : 'متصفح';
  return `${os} · ${br}`;
}

function clientIp(req) {
  const f = String((req && req.headers && (req.headers['x-forwarded-for'] || '')) || '').split(',')[0].trim();
  return f || (req && req.socket && req.socket.remoteAddress) || '';
}


// جسم الردّ الموحّد لجلسة لم تعد صالحة: يفرّق بين «دخلت من مكان آخر» و«لا جلسة»
function endedBody(token) {
  const g = graveOfToken(token);
  if (g && g.reason === 'new-login') {
    return {
      code: 'session_replaced',
      error: 'دخلت إلى سوى من مكان آخر — أُغلقت هذه الجلسة تلقائيًا',
      endedAt: g.at,
      newDevice: g.device || '',
    };
  }
  return { code: 'no_session', error: 'لا توجد جلسة صالحة' };
}

// يُطبّق الحساب على الملف الشخصي النشط في التطبيق (التطبيق أحادي المستخدم في هذه المرحلة)
function applyToMe(db, account) {
  if (!db.me) return;
  db.me.name = account.name;
  db.me.city = account.city || db.me.city;
  db.me.phoneMasked = account.phoneMasked || maskPhone(String(account.phone || '').slice(3));
  db.me.phone = '';
  db.me.avatarColor = account.color || db.me.avatarColor;
  db.me.username = account.username || db.me.username || '';
  db.me.handle = account.username ? '@' + account.username : (account.handle || db.me.handle);
  db.me.avatar = account.avatar || db.me.avatar || '';
  db.me.lastLoginAt = new Date().toISOString();
}

// ── المسارات ──
const router = express.Router();

const hintFor = () => (DEMO
  ? `وضع التجربة: رمز التحقق ثابت ${DEMO_OTP}`
  : 'سيصلك رمز مكوّن من ٦ أرقام في رسالة نصية');

// الخطوة ١: رقم الهاتف → إنشاء رمز التحقق
router.post('/otp', (req, res) => {
  const norm = normalizePhone((req.body || {}).phone);
  if (!norm.ok) return res.status(400).json({ error: norm.error });

  const ip = String((req.headers['x-forwarded-for'] || '').split(',')[0]).trim() || req.ip || 'local';
  const wait = limitHit(`p:${norm.phone}`, MAX_SEND_PER_PHONE) || limitHit(`i:${ip}`, MAX_SEND_PER_IP);
  if (wait) return res.status(429).json({ error: `طلبات كثيرة لهذا الرقم — أعد المحاولة بعد ${wait} دقيقة` });

  if (!DEMO && !process.env.SAWA_SMS_URL) {
    return res.status(501).json({ error: 'إرسال الرسائل النصية غير مربوط بعد — الرمز مطلوب من مزوّد SMS' });
  }

  record(`p:${norm.phone}`);
  record(`i:${ip}`);
  const code = DEMO ? DEMO_OTP : String(crypto.randomInt(100000, 1000000)).padStart(CODE_LEN, '0');
  challenges.set(norm.phone, { code, expiresAt: Date.now() + OTP_TTL_MS, tries: 0, sentAt: Date.now() });

  const account = (store.read().accounts || []).find((a) => privacy.phoneMatches(a, norm.phone)) || null;
  console.log(`[auth] رمز ${DEMO ? 'تجريبي ثابت' : 'عشوائي'} → ${maskPhone(norm.local)}`);

  return res.json({
    ok: true,
    phone: norm.phone,
    display: maskPhone(norm.local),
    isNew: !account,
    name: account ? account.name : null,
    username: account ? account.username || '' : '',
    avatar: account ? account.avatar || '' : '',
    suggestedUsername: suggestUsername(norm.local),
    digits: CODE_LEN,
    expiresInSec: Math.round(OTP_TTL_MS / 1000),
    demo: DEMO,
    demoCode: DEMO ? DEMO_OTP : undefined,
    hint: hintFor(),
  });
});

// الخطوة ٢ و٣: الرمز → دخول، أو (حساب جديد) طلب الاسم ثم إنشاء الحساب
router.post('/verify', (req, res) => {
  const body = req.body || {};
  const norm = normalizePhone(body.phone);
  if (!norm.ok) return res.status(400).json({ error: norm.error });

  const code = toLatinDigits(body.code).replace(/\D/g, '');
  const pending = challenges.get(norm.phone);
  if (!pending || pending.expiresAt < Date.now()) {
    challenges.delete(norm.phone);
    return res.status(410).json({ error: 'انتهت صلاحية الرمز — اطلب رمزًا جديدًا' });
  }
  if (code.length !== CODE_LEN) return res.status(400).json({ error: `الرمز ${CODE_LEN} أرقام` });
  if (code !== pending.code) {
    pending.tries += 1;
    if (pending.tries >= MAX_TRIES) {
      challenges.delete(norm.phone);
      return res.status(429).json({ error: 'محاولات كثيرة على هذا الرمز — اطلب رمزًا جديدًا' });
    }
    return res.status(401).json({ error: 'الرمز غير صحيح', triesLeft: MAX_TRIES - pending.tries });
  }

  const name = String(body.name || '').trim();
  const city = String(body.city || '').trim();          // صار اختياريًا: يُعدَّل من «ملفي»
  const uname = normalizeUsername(body.username);
  const avatar = cleanAvatar(body.avatar);

  let out = { created: false, needsProfile: false };

  // حساب جديد يحتاج الاسم واسم المستخدم معًا؛ نُبقي الرمز صالحًا ونطلب الناقص.
  // (نفحص قبل الكتابة حتى لا نُنشئ حسابًا نصف جاهز، ثم نُعيد الفحص داخل الكتابة)
  const existing0 = (store.read().accounts || []).find((a) => privacy.phoneMatches(a, norm.phone)) || null;
  if (!existing0) {
    const needName = name.length < 2;
    const needUser = !uname.ok;
    if (needName || needUser) {
      return res.json({
        ok: true,
        needsProfile: true,
        isNew: true,
        phone: norm.phone,
        display: maskPhone(norm.local),
        nameError: needName ? 'اكتب الاسم الذي تراه به دائرتك' : null,
        usernameError: uname.ok ? null : uname.error,
        username: uname.ok ? uname.username : '',
        suggestedUsername: suggestUsername(norm.local),
        hint: hintFor(),
      });
    }
  } else if (uname.ok) {
    const owner = usernameOwner(store.read(), uname.username, existing0.id);
    if (owner) {
      return res.status(409).json({
        error: `الاسم @${uname.username} محجوز — جرّب غيره`,
        field: 'username',
        username: uname.username,
      });
    }
  }
  if (name.length >= 2 && !uname.ok && !existing0) {
    return res.status(400).json({ error: uname.error, field: 'username' });
  }

  const db = store.mutate((d) => {
    d.accounts = d.accounts || [];
    d.sessions = d.sessions || [];
    let account = d.accounts.find((a) => privacy.phoneMatches(a, norm.phone)) || null;

    // حساب جديد بلا اسم أو بلا اسم مستخدم: نُبلغ الواجهة لتطلبهما ونُبقي الرمز صالحًا
    if (!account && (name.length < 2 || !uname.ok)) { out = { needsProfile: true }; return d; }
    // سباق نادر: الاسم حُجز بين الفحص والكتابة — نُبطل العملية بدل أن نكرّر الاسم
    if (!account && usernameOwner(d, uname.username)) { out = { taken: true }; return d; }

    if (!account) {
      const digitSum = norm.local.split('').reduce((s, c) => s + Number(c), 0);
      const fp = privacy.fingerprint(norm.phone);
      account = {
        id: store.id('acc'),
        phoneKey: fp.phoneKey,
        phoneHash: fp.phoneHash,
        phoneMasked: privacy.maskTail(norm.phone),
        name: name.slice(0, 40),
        username: uname.username,
        handle: '@' + uname.username,
        avatar: avatar || '',
        city: city ? city.slice(0, 40) : (d.me && d.me.city) || 'مسقط',
        color: COLORS[digitSum % COLORS.length],
        createdAt: new Date().toISOString(),
        verified: true,
      };
      d.accounts.push(account);
      out = { created: true };
    } else {
      if (name.length >= 2) account.name = name.slice(0, 40);
      if (city) account.city = city.slice(0, 40);
      // تحديث اسم المستخدم والصورة للحساب القائم إن أُرسلا
      if (uname.ok && (!account.username || account.username !== uname.username)) {
        account.username = uname.username;
        account.handle = '@' + uname.username;
      }
      if (avatar) account.avatar = avatar;
      out = { created: false };
    }

    account.lastLoginAt = new Date().toISOString();
    applyToMe(d, account);
    const token = startSession(d, account, req);
    out = { ...out, token, account: publicAccount(account) };
    return d;
  });

  if (out.needsProfile) {
    return res.json({
      ok: true,
      needsProfile: true,
      isNew: true,
      phone: norm.phone,
      display: maskPhone(norm.local),
      usernameError: uname.ok ? null : uname.error,
      suggestedUsername: suggestUsername(norm.local),
      hint: hintFor(),
    });
  }
  if (out.taken) {
    return res.status(409).json({
      error: `الاسم @${uname.username} حُجز للحظة — جرّب غيره`,
      field: 'username',
      username: uname.username,
    });
  }

  challenges.delete(norm.phone);
  // بيانات الإقلاع تُعاد مع نفس الرد: الدخول يفتح التطبيق بطلب واحد لا طلبين
  return res.json({ ok: true, ...out, hint: hintFor(), boot: store.withMeta(db) });
});

// جلسة قائمة: الواجهة تسأل بها عند كل فتح قبل عرض التطبيق.
// 401 يعني: إمّا لا جلسة، وإمّا جلسة أُغلقت لأن الحساب دخل من مكان آخر — والفرق
// مهم للواجهة حتى تقول للمستخدم السبب الحقيقي بدل «سجّل الدخول» المجرّدة.
router.get('/session', (req, res) => {
  const token = tokenOf(req);
  const account = accountOfToken(token);
  if (!account) return res.status(401).json(endedBody(token));
  return res.json({ ok: true, account: publicAccount(account), boot: store.withMeta(store.read()) });
});

router.post('/logout', (req, res) => {
  const token = tokenOf(req);
  if (token) {
    store.mutate((d) => {
      const gone = (d.sessions || []).find((s) => s.token === token);
      d.sessions = (d.sessions || []).filter((s) => s.token !== token);
      if (gone) {
        d.sessionGraves = (d.sessionGraves || []).filter((g) => Date.now() - Date.parse(g.at) < GRAVE_TTL_MS);
        d.sessionGraves.push({ token, accountId: gone.accountId, reason: 'logout', at: new Date().toISOString(), device: gone.device || '' });
      }
      return d;
    });
  }
  return res.json({ ok: true });
});

// فحص توفّر اسم المستخدم — تستدعيه الواجهة أثناء الكتابة (بلا بيانات حساب)
// يُرجع نفس صيغة الخطأ التي سيُرفض بها الاسم عند الإنشاء، فلا يتبدّل الحكم بين الخطوتين.
router.get('/username', (req, res) => {
  const uname = normalizeUsername((req.query || {}).u || (req.query || {}).username);
  if (!uname.ok) return res.json({ ok: true, username: '', available: false, error: uname.error });
  const owner = usernameOwner(store.read(), uname.username);
  return res.json({
    ok: true,
    username: uname.username,
    available: !owner,
    error: owner ? 'الاسم محجوز — جرّب غيره' : null,
  });
});

// معلومة عامة لشاشة الدخول: هل الرمز تجريبي وما هو؟ (بلا رقم هاتف)
router.get('/demo', (req, res) => res.json({
  ok: true,
  demo: DEMO,
  demoCode: DEMO ? DEMO_OTP : undefined,
  digits: CODE_LEN,
  hint: hintFor(),
}));

// ── بوابة صارمة (اختيارية): SAWA_AUTH=strict ──
// مطفأة افتراضيًا: هذه نسخة عرض ببيانات تجريبية، وإجبار الجلسة على كل مسار
// يكسر «الصدفة الواحدة» (البيانات تُحقن في الصفحة قبل وجود رمز) وكل حزم الفحص.
// حين تُشغَّل: كل /api/* تحتاج جلسة صالحة ما عدا الصحة والوسائط ومسارات الدخول،
// والصفحة تُخدَم بلا بيانات إقلاع حتى تُسجّل الدخول.
const STRICT = String(process.env.SAWA_AUTH || '').trim().toLowerCase() === 'strict';
const OPEN = ['/auth', '/health', '/media'];

function gate(req, res, next) {
  if (!STRICT) return next();
  if (OPEN.some((p) => req.path === p || req.path.startsWith(p + '/'))) return next();
  if (accountOfToken(tokenOf(req))) return next();
  const b = endedBody(tokenOf(req));
  return res.status(401).json(
    b.code === 'session_replaced' ? { ...b, auth: 'required' } : { error: 'سجّل الدخول أولًا', code: 'no_session', auth: 'required' },
  );
}

module.exports = {
  router,
  gate,
  STRICT,
  sessionOf,
  sessionStateOf: (req) => {
    const token = tokenOf(req);
    const account = accountOfToken(token);
    if (account) return { state: 'active', account };
    const g = graveOfToken(token);
    if (g && g.reason === 'new-login') return { state: 'replaced', at: g.at, device: g.device || '' };
    return { state: 'none' };
  },
  endedBody,
  accountOfToken,
  tokenOf,
  normalizePhone,
  toLatinDigits,
  normalizeUsername,
  cleanAvatar,
  suggestUsername,
  usernameOwner,
  publicAccount,
  info: () => ({
    demo: DEMO,
    demoCode: DEMO ? DEMO_OTP : undefined,
    digits: CODE_LEN,
    hint: hintFor(),
    strict: STRICT,
  }),
};

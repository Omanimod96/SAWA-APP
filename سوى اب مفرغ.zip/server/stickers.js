// ─────────────────────────────────────────────────────────────────────────────
// stickers.js — فهرس حزم الملصقات من الخادم.
//
// الحزم تُقرأ من server/stickers.json وملفاتها SVG في server/assets/stickers.
// إضافة حزمة جديدة مستقبلًا = ملفات + إدخال في الفهرس، بلا أي تعديل في التطبيق.
// الخادم هو المرجع: الرسالة تُخزَّن برابط يبنيه الخادم من الفهرس، فلا يستطيع
// عميل أن يُرسل رابطًا خارجيًا ولا ملفًا غير موجود في حزمة معلنة.
// ─────────────────────────────────────────────────────────────────────────────
const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, 'stickers.json');
const DIR = path.join(__dirname, 'assets', 'stickers');
let cache = null;
let stamp = 0;

const EMPTY = { version: 1, updatedAt: '', packs: [] };

function catalog() {
  try {
    const s = fs.statSync(FILE);
    if (cache && s.mtimeMs === stamp) return cache;
    const parsed = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    const packs = Array.isArray(parsed.packs) ? parsed.packs : [];
    cache = {
      version: Number(parsed.version) || 1,
      updatedAt: parsed.updatedAt || '',
      packs: packs
        .filter((p) => p && p.id && Array.isArray(p.stickers) && p.stickers.length)
        .map((p) => ({
          id: String(p.id),
          name: String(p.name || p.id),
          stickers: p.stickers
            .filter((s) => s && s.id)
            .map((s) => ({
              id: String(s.id),
              title: String(s.title || ''),
              url: `api/stickers/files/${p.id}/${s.id}.svg`,
            })),
        })),
    };
    stamp = s.mtimeMs;
    return cache;
  } catch (e) {
    return cache || EMPTY;
  }
}

// واجهة الواجهة الأمامية: الحزم مع رابط الغلاف (أول ملصق) — بلا مسار نظام ملفات
function forClient() {
  const c = catalog();
  return {
    version: c.version,
    updatedAt: c.updatedAt,
    packs: c.packs.map((p) => ({
      id: p.id,
      name: p.name,
      cover: p.stickers[0] ? p.stickers[0].url : '',
      stickers: p.stickers.map((s) => ({ id: s.id, title: s.title, url: s.url })),
    })),
  };
}

// التحقق من ملصق وارد في رسالة: يُقبل فقط ما هو معلن في الفهرس
function resolve(packId, stickerId) {
  const p = catalog().packs.find((x) => x.id === String(packId || ''));
  if (!p) return null;
  const s = p.stickers.find((x) => x.id === String(stickerId || ''));
  if (!s) return null;
  return { pack: p.id, packName: p.name, id: s.id, title: s.title, url: s.url };
}

// حارس ملفات الملصقات: منع أي خروج عن مجلد الحزم (لا مسارات نسبية ولا مطلقة)
function safeFile(packId, name) {
  const pack = String(packId || '');
  const file = String(name || '');
  if (!/^[a-z0-9_-]+$/.test(pack) || !/^[a-z0-9_-]+\.svg$/.test(file)) return null;
  const abs = path.join(DIR, pack, file);
  if (!abs.startsWith(DIR + path.sep)) return null;
  return fs.existsSync(abs) ? abs : null;
}

module.exports = { catalog, forClient, resolve, safeFile, DIR, FILE };

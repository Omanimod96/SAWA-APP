// ── طبقة «أثر» الجغرافية ──
// حساب المسافات، تجميع الآثار القريبة في ومضة واحدة، وتحويل الحجم إلى وهج.

const R_EARTH_KM = 6371;

const toRad = (deg) => (deg * Math.PI) / 180;
const toDeg = (rad) => (rad * 180) / Math.PI;

function validPoint(lat, lng) {
  const a = Number(lat);
  const b = Number(lng);
  if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
  if (a < -90 || a > 90 || b < -180 || b > 180) return null;
  if (a === 0 && b === 0) return null;
  return { lat: Math.round(a * 1e6) / 1e6, lng: Math.round(b * 1e6) / 1e6 };
}

// المسافة بين نقطتين بالكيلومترات (هافرساين)
function distanceKm(a, b) {
  if (!a || !b) return null;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s = Math.sin(dLat / 2) ** 2
    + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R_EARTH_KM * Math.asin(Math.min(1, Math.sqrt(s)));
}

// نقطة على مسافة معيّنة وبزاوية معيّنة من مركز (لرسم دائرة النطاق)
function destination(point, bearingDeg, km) {
  const d = km / R_EARTH_KM;
  const br = toRad(bearingDeg);
  const lat1 = toRad(point.lat);
  const lng1 = toRad(point.lng);
  const lat2 = Math.asin(Math.sin(lat1) * Math.cos(d) + Math.cos(lat1) * Math.sin(d) * Math.cos(br));
  const lng2 = lng1 + Math.atan2(
    Math.sin(br) * Math.sin(d) * Math.cos(lat1),
    Math.cos(d) - Math.sin(lat1) * Math.sin(lat2),
  );
  return { lat: toDeg(lat2), lng: ((toDeg(lng2) + 540) % 360) - 180 };
}

// وصف المسافة بالعربية كما تُقرأ على الشاشة
function distanceLabel(km) {
  if (km === null || km === undefined) return '';
  if (km < 1) return `${Math.max(50, Math.round((km * 1000) / 50) * 50)} م`;
  if (km < 10) return `${Math.round(km * 10) / 10} كم`;
  return `${Math.round(km)} كم`;
}

// «قبل ٣ ساعات» — عمر الأثر كما يراه المستخدم
function ageLabel(iso, now) {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '';
  const mins = Math.max(0, Math.round(((now || Date.now()) - t) / 60000));
  if (mins < 5) return 'الآن';
  if (mins < 60) return `قبل ${mins} دقيقة`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `قبل ${hours === 1 ? 'ساعة' : hours === 2 ? 'ساعتين' : `${hours} ساعات`}`;
  const days = Math.round(hours / 24);
  if (days < 30) return `قبل ${days === 1 ? 'يوم' : days === 2 ? 'يومين' : `${days} أيام`}`;
  const months = Math.round(days / 30);
  if (months < 12) return `قبل ${months === 1 ? 'شهر' : months === 2 ? 'شهرين' : `${months} أشهر`}`;
  const years = Math.round(months / 12);
  return `قبل ${years === 1 ? 'سنة' : years === 2 ? 'سنتين' : `${years} سنوات`}`;
}

// ── الوهج: من عدد الآثار في المكان إلى شدة (0..1) وإيقاع نبض ──
const GLOW_MAX_COUNT = 7; // سبعة آثار أو أكثر = وهج كامل

function intensityOf(count) {
  const n = Math.max(1, Number(count) || 1);
  return Math.min(1, Math.log(1 + n) / Math.log(1 + GLOW_MAX_COUNT));
}

// الإيقاع: الذكرى الطازجة تنبض بسرعة ثم تسكن مع الأيام (بالمللي ثانية)
function periodOf(latestAt, now) {
  const t = Date.parse(latestAt);
  const hours = Number.isNaN(t) ? 720 : Math.max(0, ((now || Date.now()) - t) / 3600000);
  if (hours < 6) return 2400;
  if (hours < 24) return 3600;
  if (hours < 72) return 5200;
  if (hours < 24 * 14) return 7400;
  if (hours < 24 * 120) return 9600;
  return 12000;
}

// لون الومضة: يتغيّر بتغيّر حجم المشاركة في المكان (سلّم واضح لا تدرّج موحل)
const TIERS = [
  { max: 1, hex: '#60A5FA', label: 'أثر وحيد' },
  { max: 3, hex: '#FCD34D', label: 'بضعة آثار' },
  { max: 5, hex: '#FB923C', label: 'مكان محبوب' },
  { max: Infinity, hex: '#F97316', label: 'مكان مشتعل' },
];

function tierOf(count) {
  const n = Math.max(1, Number(count) || 1);
  return TIERS.find((t) => n <= t.max) || TIERS[TIERS.length - 1];
}

function toneOf(count) {
  const tier = tierOf(count);
  const rgb = [1, 3, 5].map((i) => parseInt(tier.hex.slice(i, i + 2), 16));
  return { hex: tier.hex, rgb, label: tier.label };
}


// تجميع الآثار القريبة (أقل من سقف المسافة بينها) في ومضة واحدة
// clusteringKm: أقصى مسافة بين أثرين ليُعتبرا في المكان نفسه
function clusterItems(items, clusteringKm) {
  const limit = Number(clusteringKm) || 1.5;
  const clusters = [];
  items.forEach((item) => {
    let best = null;
    let bestD = Infinity;
    clusters.forEach((c) => {
      const d = distanceKm(c.center, item.place);
      if (d !== null && d < limit && d < bestD) { best = c; bestD = d; }
    });
    if (best) {
      best.items.push(item);
      const n = best.items.length;
      best.center = {
        lat: (best.center.lat * (n - 1) + item.place.lat) / n,
        lng: (best.center.lng * (n - 1) + item.place.lng) / n,
      };
    } else {
      clusters.push({ center: { lat: item.place.lat, lng: item.place.lng }, items: [item] });
    }
  });
  return clusters;
}

// بناء الومضات الجاهزة للعرض من آثار ظاهرة + موقع المستخدم
function buildPulses(items, opts) {
  const now = (opts && opts.now) || Date.now();
  const clusteringKm = (opts && opts.clusteringKm) || 2;
  const clusters = clusterItems(items, clusteringKm);
  const pulses = clusters.map((c, index) => {
    const sorted = c.items.slice().sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
    const count = c.items.length;
    const intensity = intensityOf(count);
    const tier = toneOf(count);
    const people = [...new Set(c.items.map((i) => i.author))];
    const visits = c.items.reduce((sum, i) => sum + (i.visits || 0), 0);
    const latestAt = sorted[0].createdAt;
    const name = (sorted[0].place && sorted[0].place.name) || 'مكان بلا اسم';
    return {
      id: 'p' + (index + 1),
      lat: Math.round(c.center.lat * 1e6) / 1e6,
      lng: Math.round(c.center.lng * 1e6) / 1e6,
      placeName: name,
      count,
      peopleCount: people.length,
      mine: c.items.some((i) => i.mine),
      authorIds: people,
      firstAt: sorted[sorted.length - 1].createdAt,
      latestAt,
      ageLabel: ageLabel(latestAt, now),
      intensity: Math.round(intensity * 1000) / 1000,
      tone: tier.hex,
      tierLabel: tier.label,
      period: periodOf(latestAt, now),
      visits,
      items: sorted.map((i) => i.id),
    };
  });
  return pulses.sort((a, b) => b.intensity - a.intensity || Date.parse(b.latestAt) - Date.parse(a.latestAt));
}

module.exports = {
  validPoint, distanceKm, distanceLabel, ageLabel, destination,
  intensityOf, periodOf, toneOf, tierOf, TIERS, clusterItems, buildPulses, GLOW_MAX_COUNT, R_EARTH_KM,
};

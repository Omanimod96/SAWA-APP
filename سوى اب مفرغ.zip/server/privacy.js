// ─────────────────────────────────────────────────────────────────────────────
// privacy.js — طبقة البيانات الخادمية لـ v31
//
// المبدأ الحاكم (بند ١ من أمر التعديل):
//   • الخادم يحفظ: سجلّات الأثر · عضوية الدوائر · قائمة الحجب · صف انتظار مؤقت
//     للرسائل غير المسلَّمة · عناوين الأجهزة والمفاتيح العامة · حالة الحضور.
//   • الخادم لا يحفظ: محادثات، ولا نصّ همسة، ولا دفتر جهات، ولا أرقام هواتف خامة.
//   • كل فلترة تُنفَّذ في استعلام الخادم، لحظة القراءة لا لحظة النشر ولا الانضمام.
//
// لا سجلّ ولا قياس هنا: لا تُكتب معرّفات ولا أرقام في ملفات السجلّات (بند ٦.٤).
// ─────────────────────────────────────────────────────────────────────────────
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const store = require('./store');
const geo = require('./geo');

const HOUR = 3600 * 1000;
const DAY = 24 * HOUR;

const OUTBOX_TTL_MS = Number(process.env.SAWA_WHISPER_TTL_H || 24) * HOUR; // بند ٥.٣
const PURGE_KEEP_MS = 30 * DAY;      // توابع الحذف تُحفظ بالمعرّف وحده، ثم تُطرح
const KEY_ROTATE_MS = 30 * DAY;      // بند ٢.٢: مفتاح بصمات دوري
const GRID = 3;                      // ٣ منازل عشرية ≈ ١١٠ م: مربّع تقريبي بلا نصّ (بند ٤.٣)
const PAD = 512;                     // بند ٧.٢: حشو أحجام الحزم
const MAX_MEM_PER_OWNER = 5000;
const MAX_MEMBERS = 200;
const MAX_FINGERPRINTS = 2000;       // سقف بصمات في الطلب الواحد (خنق هجوم القاموس)
const MAX_SEALED_BYTES = 8192;       // نصّ الهمسة مُغلَّف من الجهاز، والخادم لا يفكّه

// ── مفتاح البصمات (٢.٢) ──────────────────────────────────────────────────────
// المفتاح ليس في db.json: تسريب ملف المخزن وحده لا يفتح قاموسًا عكسيًا على الأرقام.
// (حماية ضد تسريب المخزن، لا ضد سارق القرص كاملًا — ذاك يحتاج تشفير قرص، بند ٧.١.)
const KEY_FILE = path.join(store.DATA_DIR, '.privacy-key');

function readKeyFile() {
  try {
    const raw = fs.readFileSync(KEY_FILE, 'utf8').trim();
    if (raw) return JSON.parse(raw);
  } catch (e) { /* لا ملف بعد */ }
  return null;
}

function writeKeyFile(meta) {
  const tmp = KEY_FILE + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(meta), { encoding: 'utf8', mode: 0o600 });
  fs.renameSync(tmp, KEY_FILE);
  try { fs.chmodSync(KEY_FILE, 0o600); } catch (e) { /* أنظمة بلا صلاحيات */ }
}

let KEYS = null;

function keys() {
  if (KEYS) return KEYS;
  const env = String(process.env.SAWA_PRIV_KEY || '').trim();
  if (env) {
    const meta = { cur: env, prev: '', rotatedAt: Date.now(), source: 'env' };
    KEYS = meta;
    return KEYS;
  }
  let meta = readKeyFile();
  const stale = !meta || !meta.cur || (Date.now() - Number(meta.rotatedAt || 0) > KEY_ROTATE_MS);
  if (!meta || !meta.cur) meta = { cur: crypto.randomBytes(32).toString('base64url'), prev: '', rotatedAt: Date.now() };
  else if (stale) meta = { cur: crypto.randomBytes(32).toString('base64url'), prev: meta.cur, rotatedAt: Date.now() };
  meta.source = 'file';
  try { writeKeyFile(meta); } catch (e) { /* نعمل بالمفتاح في الذاكرة */ }
  KEYS = meta;
  return KEYS;
}

const keyId = (k) => (k ? crypto.createHash('sha256').update(k).digest('hex').slice(0, 8) : '');
const hmac = (k, v) => crypto.createHmac('sha256', k).update(String(v)).digest('base64url');

// بصمة رقم: تُخزَّن بدل الرقم. الدوران لا يقطع الدخول — الحساب يبقى على مفتاحه
// القديم حتى يدخل مرة أخرى بالرقم فيُعاد بصمه على المفتاح الحالي.
function fingerprint(e164) {
  const k = keys();
  return { phoneKey: keyId(k.cur), phoneHash: hmac(k.cur, e164) };
}

// مطابقة رقم داخِل بالبصمة المخزَّنة (بلا تخزين الرقم نفسه)
function phoneMatches(account, e164) {
  if (!account || !e164) return false;
  const k = keys();
  if (account.phoneHash && account.phoneKey) {
    const key = account.phoneKey === keyId(k.cur) ? k.cur : (account.phoneKey === keyId(k.prev) ? k.prev : null);
    if (!key) return false;
    const a = Buffer.from(hmac(key, e164));
    const b = Buffer.from(String(account.phoneHash));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  return Boolean(account.phone) && String(account.phone) === String(e164); // مخزن قديم لم يُرحَّل
}

const maskTail = (e164) => '•••• ' + String(e164 || '').slice(-4);

// ── المجموعات الجديدة: تُضاف بلا مساس بأي بيانات قائمة ──────────────────────
const COLLECTIONS = ['circles', 'blocks', 'devices', 'memories', 'pairs', 'outbox', 'purges'];

function ensure(db) {
  let changed = false;
  COLLECTIONS.forEach((k) => {
    if (!Array.isArray(db[k])) { db[k] = []; changed = true; }
  });
  // بذرة: الدوائر الديموغرافية القديمة كانت أسماء نسب (relation) لا عضوية.
  // الإصدار ٣١ يفرض العضوية خادميًا — فالحساب الذي لا دائرة له يُمنح دائرة
  // «الأقربون» أضيق نطاقًا (بند ٣.٦: الافتراضي أضيق، والتوسيع اختيار واعٍ).
  (db.accounts || []).forEach((a) => {
    if (!a || !a.id) return;
    if (!db.circles.some((c) => c.ownerId === a.id && c.seed)) {
      db.circles.push({
        id: store.id('cir'), ownerId: a.id, name: 'الأقربون',
        kind: 'athar', memberIds: [], seed: true, createdAt: new Date().toISOString(),
      });
      changed = true;
    }
  });
  return changed;
}

const found = (list, pred) => (list || []).find(pred) || null;
const circleById = (db, id) => found(db.circles, (c) => c.id === id);
const circlesOf = (db, ownerId) => (db.circles || []).filter((c) => c.ownerId === ownerId);
const membersOf = (db, circleId) => {
  const c = circleById(db, circleId);
  return c ? (c.memberIds || []).slice() : [];
};
// العضوية تُقرأ دائما من الصفّ الحالي: الإخراج يُخفي ما مضى فورًا (بند ٣.٣)
const isMember = (db, circleId, accountId) => Boolean(
  accountId && circleById(db, circleId) && (circleById(db, circleId).memberIds || []).includes(accountId),
);

// ── الحجب: خادمي، ويُطبَّق في الاتجاهين ─────────────────────────────────────
function isBlocked(db, ownerId, otherId) {
  if (!ownerId || !otherId) return false;
  return Boolean(found(db.blocks, (b) => b.ownerId === ownerId && b.blockedId === otherId));
}
const blockedEitherWay = (db, a, b) => isBlocked(db, a, b) || isBlocked(db, b, a);

// ── الحضور والأجهزة: عنوان الجهاز ومفتاحه العام فقط، بلا عنوان شبكة ─────────
function registerDevice(db, accountId, raw) {
  const deviceId = String((raw && raw.deviceId) || '').slice(0, 64);
  if (!deviceId) return null;
  const now = new Date().toISOString();
  let d = found(db.devices, (x) => x.accountId === accountId && x.deviceId === deviceId);
  if (!d) {
    d = { accountId, deviceId, label: String((raw && raw.label) || '').slice(0, 40),
      publicKey: String((raw && raw.publicKey) || '').slice(0, 512), at: now, lastSeenAt: now };
    db.devices.push(d);
  } else {
    d.lastSeenAt = now;
    if (raw && raw.label) d.label = String(raw.label).slice(0, 40);
    if (raw && raw.publicKey) d.publicKey = String(raw.publicKey).slice(0, 512);
  }
  return d;
}

const ONLINE_MS = 3 * 60 * 1000;
const presenceOf = (db, accountId) => {
  const list = (db.devices || []).filter((d) => d.accountId === accountId);
  const last = list.reduce((mx, d) => Math.max(mx, Date.parse(d.lastSeenAt || 0) || 0), 0);
  return { devices: list.length, online: last > 0 && Date.now() - last < ONLINE_MS, lastSeenAt: last || null };
};

// ── حشو أحجام الحزم (٧.٢): استجابة بلا حشو تُفشي حجم النصّ من طول الحزمة ─────
// الحساب بالبايتات لا بالمحارف: النصّ العربي ثلاثة بايتات للمحرف، وقياس المحارف
// كان يُقصّر الحشو فتصل الحزمة 510 بايت — أي غير مضاعفة للكتلة، وهو ما يُفشي الحجم.
function pad(payload) {
  const body = JSON.stringify(payload);
  let need = (PAD - (Buffer.byteLength(body, 'utf8') % PAD)) % PAD;
  // `,"_pad":"…"` يضيف ١٠ بايتات حول القيمة؛ فرق أصغر من ذلك يستدعي كتلة كاملة
  if (need < 10) need += PAD;
  return { ...payload, _pad: 'x'.repeat(need - 10) };
}

// ── الأثر: سجل دائم، قراءته تُرشَّح بهوية الطالب ─────────────────────────────
// حقول السجل (بند ٤.٢): المعرّف · صاحبها · الدائرة · النص · الإحداثيات ·
// نصف قطر الفتح · وقت الإنشاء · وقت المزامنة. و«من كان معك» و«متى» رباط
// الذكرى بالمكان والشخص والوقت (بند ٨.٣).
function createMemory(db, ownerId, input) {
  const raw = input || {};
  const circle = circleById(db, raw.circleId);
  // لا نشر بلا دائرة مُسمّاة: «كل الدوائر» ليس افتراضيًا ولا قيمة ضمنية (بند ٨.٢)
  if (!circle || circle.ownerId !== ownerId) return { ok: false, code: 400, error: 'اختر دائرة الأثر' };
  const point = geo.validPoint(raw.lat, raw.lng);
  if (!point) return { ok: false, code: 400, error: 'إحداثيات الأثر غير صالحة' };
  const text = String(raw.text || '').trim().slice(0, 1200);
  if (!text && !raw.media) return { ok: false, code: 400, error: 'اكتب الذكرى أو أضف صورة' };
  const mine = (db.memories || []).filter((m) => m.ownerId === ownerId).length;
  if (mine >= MAX_MEM_PER_OWNER) return { ok: false, code: 413, error: 'بلغتَ سقف الأثر لهذا الحساب' };

  const when = raw.when ? store.memoryWhen(raw.when) : { ok: true, iso: null };
  if (!when.ok) return { ok: false, code: 400, error: when.reason };

  const radius = Math.max(50, Math.min(1000, Number(raw.radiusM) || 150));
  const now = new Date().toISOString();
  const mem = {
    id: store.id('am'),
    ownerId,
    circleId: circle.id,
    text,
    media: raw.media || null,
    bg: raw.bg || null,
    place: { name: String(raw.placeName || '').slice(0, 80), lat: point.lat, lng: point.lng },
    radiusM: radius,
    companions: (db.accounts || []).filter((a) => (raw.companions || []).includes(a.id)).map((a) => a.id).slice(0, 8),
    when: when.iso,
    createdAt: now,
    syncedAt: now,
  };
  db.memories.push(mem);
  return { ok: true, memory: mem };
}

// الفلتر الوحيد المعتبر: يُنادى في كل قراءة لهذا الحساب
function canRead(db, mem, viewerId) {
  if (!mem || mem.deleted) return false;
  if (!viewerId) return false;
  if (mem.ownerId === viewerId) return true;
  if (blockedEitherWay(db, viewerId, mem.ownerId)) return false;
  const c = circleById(db, mem.circleId);
  if (!c || c.ownerId !== mem.ownerId) return false;      // دائرة غيره لا تفتح أبدًا
  return (c.memberIds || []).includes(viewerId);
}

const visibleMemories = (db, viewerId) => (db.memories || []).filter((m) => canRead(db, m, viewerId));

// عرض عام: اسم العرض (بلا رقم، بلا هاتف) — والبصمة الزمنية تُقرَّب لغير صاحبها
function ownerView(db, ownerId) {
  const a = found(db.accounts, (x) => x.id === ownerId);
  if (!a) return { id: ownerId, name: 'من دائرتك', username: '', avatar: '', color: '#64748B' };
  return { id: a.id, name: a.name || 'من دائرتك', username: a.username || '', avatar: a.avatar || '', color: a.color || '#1D4ED8' };
}

const roundHour = (iso) => {
  const t = Date.parse(iso);
  return Number.isFinite(t) ? new Date(Math.floor(t / HOUR) * HOUR).toISOString() : null;
};

function memoryView(db, mem, viewerId) {
  const mine = mem.ownerId === viewerId;
  const c = circleById(db, mem.circleId);
  return {
    id: mem.id,
    owner: ownerView(db, mem.ownerId),
    mine,
    circleId: mem.circleId,
    circleName: mine ? (c ? c.name : '') : null,          // اسم دائرة غيري ليس شأني
    text: mem.text,
    media: mem.media || null,
    bg: mem.bg || null,
    place: { name: mem.place && mem.place.name, lat: mem.place && mem.place.lat, lng: mem.place && mem.place.lng },
    radiusM: mem.radiusM,
    companions: (mem.companions || []).map((id) => ownerView(db, id)),
    when: mem.when || null,
    createdAt: mine ? mem.createdAt : roundHour(mem.createdAt),
    syncedAt: mem.syncedAt || mem.createdAt,
  };
}

// ── فهرس المربّعات: ما يحمله الجهاز بلا نصوص ولا أسماء (٤.٣) ────────────────
const cellOf = (lat, lng) => ({
  gx: Math.round(Number(lat) * (10 ** GRID)) / (10 ** GRID),
  gy: Math.round(Number(lng) * (10 ** GRID)) / (10 ** GRID),
});

function gridOf(db, viewerId) {
  const cells = new Map();
  visibleMemories(db, viewerId).forEach((m) => {
    const c = cellOf(m.place.lat, m.place.lng);
    const key = c.gx + '|' + c.gy;
    const cur = cells.get(key) || { gx: c.gx, gy: c.gy, count: 0, openRadiusM: 0 };
    cur.count += 1;
    cur.openRadiusM = Math.max(cur.openRadiusM, m.radiusM || 150);
    cells.set(key, cur);
  });
  return { cellDegrees: GRID, cells: [...cells.values()] };  // بلا نصّ، بلا اسم، بلا معرّف
}

function cellRecords(db, viewerId, gx, gy) {
  const x = Number(gx); const y = Number(gy);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return [];
  return visibleMemories(db, viewerId)
    .filter((m) => { const c = cellOf(m.place.lat, m.place.lng); return c.gx === x && c.gy === y; })
    .map((m) => memoryView(db, m, viewerId));
}

// المزامنة (٤.٤): جهاز جديد ينزل ما سُمح له فقط، خلال دقائق من الدخول
function syncSince(db, viewerId, sinceMs) {
  const t = Number(sinceMs) || 0;
  return visibleMemories(db, viewerId)
    .filter((m) => Date.parse(m.syncedAt || m.createdAt || 0) > t)
    .map((m) => memoryView(db, m, viewerId));
}

// ── الحذف (٤.٥): حقيقي وفوري؛ ويبقى المعرّف وحده في توابع الحذف ليُطهر الجهاز ──
function deleteMemory(db, id, accountId) {
  const i = (db.memories || []).findIndex((m) => m.id === id);
  if (i < 0) return { ok: false, code: 404, error: 'الأثر غير موجود' };
  const mem = db.memories[i];
  if (mem.ownerId !== accountId) return { ok: false, code: 403, error: 'الأثر ليس لك' };
  db.memories.splice(i, 1);
  db.purges = (db.purges || []).filter((p) => Date.now() - Date.parse(p.at || 0) < PURGE_KEEP_MS);
  db.purges.push({ id, at: new Date().toISOString() });
  // نُبلّغ الأجهزة المتصلة أن الأثر سُحب: رسالة صفّ نظيفة بلا نصّ الذكرى
  (db.outbox || []).forEach((o) => { if (o.topic === id) o.state = 'revoked'; });
  return { ok: true, id };
}

function purgesSince(db, sinceMs) {
  const t = Number(sinceMs) || 0;
  return (db.purges || []).filter((p) => Date.parse(p.at || 0) > t).map((p) => ({ id: p.id, at: roundHour(p.at) }));
}

// زيارة الفتح: عدّاد مجمّع بلا هوية الزائر وبلا توقيته (٤.٦ + ٧.٢)
function visitAggregate(db, id) {
  const mem = (db.memories || []).find((m) => m.id === id);
  if (!mem) return null;
  mem.visits = (mem.visits || 0) + 1;
  mem.visitsDay = new Date().toISOString().slice(0, 10);
  return mem.visits;
}

// ── اكتشاف جهات الاتصال (٢.٢ – ٢.٥) ────────────────────────────────────────
// ما يُخزَّن: زوج معرّفَين فقط. لا رقم، ولا اسم، ولا بصمة. والبصمات تُطرح فور
// المطابقة في الذاكرة. الإفصاح متبادل: لا يُخبَر «ب» بأن «أ» على سوى اب إلا
// إذا كان «أ» يحمل رقم «ب» أيضًا — أي إذا بحث كلٌّ منهما عن الآخر.
function matchFingerprints(db, accountId, fingerprints) {
  const list = (Array.isArray(fingerprints) ? fingerprints : [])
    .map((f) => String(f || '').trim()).filter((f) => f && f.length <= 128).slice(0, MAX_FINGERPRINTS);
  const others = (db.accounts || []).filter((a) => a.id !== accountId && a.discoverable !== false);
  const hits = new Set();
  const k = keys();
  const cur = keyId(k.cur);
  const prev = keyId(k.prev);
  list.forEach((fp) => {
    others.forEach((a) => {
      if (!a.phoneHash || !a.phoneKey) return;
      // المفتاح الدوري يخدم فقط الحسابات التي لم تدخل بعد الدوران
      if (a.phoneKey !== cur && a.phoneKey !== prev) return;
      const x = Buffer.from(fp);
      const y = Buffer.from(String(a.phoneHash));
      if (x.length === y.length && crypto.timingSafeEqual(x, y)) hits.add(a.id); // مطابقة في الذاكرة، ثم تُطرح البصمة
    });
  });
  const now = new Date().toISOString();
  let waiting = 0;
  hits.forEach((otherId) => {
    if (blockedEitherWay(db, accountId, otherId)) return;
    const lo = accountId < otherId ? accountId : otherId;
    const hi = accountId < otherId ? otherId : accountId;
    let pair = found(db.pairs, (p) => p.a === lo && p.b === hi);
    if (!pair) { pair = { a: lo, b: hi, aSaw: false, bSaw: false, at: now }; db.pairs.push(pair); }
    if (accountId === lo) pair.aSaw = true; else pair.bSaw = true;
    if (!(pair.aSaw && pair.bSaw)) waiting += 1;
  });
  return { saw: hits.size, mutual: hits.size - waiting, waiting };
}

const mutualPairs = (db, accountId) => (db.pairs || []).filter(
  (p) => p.aSaw && p.bSaw && (p.a === accountId || p.b === accountId),
);

function matchesFor(db, accountId) {
  return mutualPairs(db, accountId)
    .map((p) => (p.a === accountId ? p.b : p.a))
    .filter((id) => !blockedEitherWay(db, accountId, id))
    .map((id) => ({ ...ownerView(db, id), presence: presenceOf(db, id) }));
}

// ── صفّ انتظار الهمسة (٥.٢، ٥.٣) ───────────────────────────────────────────
// نصّ الهمسة لا يُخزَّن خامة على الخادم: يُسلَّم مباشرة، ويُحفظ فقط ما لم يُسلَّم
// وعمره ٢٤ ساعة، ثم يُحذف ويُعلَن للمرسل أن التسليم فشل.
const ACK_KEEP_MS = 7 * DAY;

function enqueue(db, fromId, toId, raw) {
  if (!fromId || !toId || fromId === toId) return { ok: false, code: 400, error: 'وجهة الهمسة غير صالحة' };
  if (!found(db.accounts, (a) => a.id === toId)) return { ok: false, code: 404, error: 'لا حساب لهذه الوجهة' };
  if (blockedEitherWay(db, fromId, toId)) return { ok: false, code: 403, error: 'لا يمكن إيصال هذه الهمسة' };
  const connected = circlesOf(db, fromId).some((c) => (c.memberIds || []).includes(toId))
    || circlesOf(db, toId).some((c) => (c.memberIds || []).includes(fromId));
  if (!connected) return { ok: false, code: 403, error: 'الهمسة تكون لمن في دائرتك' };
  const sealed = String((raw && raw.sealed) || '');
  if (!sealed || sealed.length > MAX_SEALED_BYTES) return { ok: false, code: 400, error: 'نصّ الهمسة غير صالح' };
  const now = Date.now();
  const row = {
    id: store.id('ob'), fromId, toId, sealed, kind: String((raw && raw.kind) || 'text').slice(0, 16),
    topic: raw && raw.topic ? String(raw.topic).slice(0, 64) : null,
    createdAt: new Date(now).toISOString(),
    expiresAt: new Date(now + OUTBOX_TTL_MS).toISOString(),
    state: 'queued',
  };
  db.outbox.push(row);
  return { ok: true, id: row.id, expiresAt: row.expiresAt };
}

// التسليم: يُسلَّم الغلاف ويُمسح نصّه من الخادم في الحركة نفسها
function deliver(db, accountId) {
  const now = Date.now();
  const rows = (db.outbox || []).filter((o) => o.toId === accountId && o.state === 'queued');
  const out = [];
  rows.forEach((o) => {
    if (Date.parse(o.expiresAt) < now) { o.state = 'failed'; o.failedAt = new Date(now).toISOString(); o.sealed = null; return; }
    out.push({ id: o.id, from: ownerView(db, o.fromId), kind: o.kind, topic: o.topic, sealed: o.sealed, at: roundHour(o.createdAt) });
    o.state = 'delivered';
    o.deliveredAt = new Date(now).toISOString();
    o.sealed = null;   // لا يبقى نصّ على الخادم بعد التسليم
  });
  return out;
}

function expireOutbox(db, now) {
  let changed = false;
  (db.outbox || []).forEach((o) => {
    if (o.state === 'queued' && Date.parse(o.expiresAt || 0) < now) {
      o.state = 'failed'; o.failedAt = new Date(now).toISOString(); o.sealed = null; changed = true;
    }
  });
  const keep = (db.outbox || []).filter((o) => now - Date.parse(o.createdAt || 0) < ACK_KEEP_MS);
  if (keep.length !== (db.outbox || []).length) { db.outbox = keep; changed = true; }
  return changed;
}

// تقرير التسليم للمرسل: فشل صريح بدل انتظار غير محدود — بلا نصّ في الحالتين
function outboxStatus(db, accountId) {
  return (db.outbox || [])
    .filter((o) => o.fromId === accountId && (o.state === 'failed' || o.state === 'delivered') && !o.acked)
    .map((o) => ({ id: o.id, to: ownerView(db, o.toId), state: o.state, at: roundHour(o.failedAt || o.deliveredAt || o.createdAt) }));
}

const ackOutbox = (db, accountId, ids) => {
  const set = new Set(Array.isArray(ids) ? ids.map(String) : []);
  let n = 0;
  (db.outbox || []).forEach((o) => {
    if (o.fromId === accountId && set.has(o.id)) { o.acked = true; n += 1; }
  });
  return n;
};

// ── الدوائر: العضوية خادمية لأن الفرض خادمي (٣.١) ───────────────────────────
function createCircle(db, ownerId, raw) {
  const name = String((raw && raw.name) || '').trim().slice(0, 40);
  if (!name) return { ok: false, code: 400, error: 'اكتب اسم الدائرة' };
  if (circlesOf(db, ownerId).length >= 24) return { ok: false, code: 413, error: 'بلغتَ سقف الدوائر' };
  const circle = {
    id: store.id('cir'), ownerId, name,
    kind: raw && raw.kind === 'state' ? 'state' : 'athar',
    memberIds: [], createdAt: new Date().toISOString(),
  };
  db.circles.push(circle);
  return { ok: true, circle: circleView(db, circle) };
}

function addMembers(db, ownerId, circleId, ids) {
  const c = circleById(db, circleId);
  if (!c || c.ownerId !== ownerId) return { ok: false, code: 404, error: 'الدائرة غير موجودة' };
  const list = Array.isArray(ids) ? ids.map(String) : [];
  let added = 0;
  list.forEach((id) => {
    if (c.memberIds.length >= MAX_MEMBERS) return;
    if (!db.accounts.some((a) => a.id === id)) return;      // لا عضوية لغير حساب حقيقي
    if (c.memberIds.includes(id)) return;
    c.memberIds.push(id);
    added += 1;
  });
  // بند ٣.٤: لا إشعار لأي عضو بأنه أُضيف أو أُخرج — لا نكتب صفًّا ولا نرسل شيئًا
  return { ok: true, added, circle: circleView(db, c) };
}

function removeMember(db, ownerId, circleId, accountId) {
  const c = circleById(db, circleId);
  if (!c || c.ownerId !== ownerId) return { ok: false, code: 404, error: 'الدائرة غير موجودة' };
  const i = c.memberIds.indexOf(String(accountId));
  if (i < 0) return { ok: false, code: 404, error: 'العضو ليس في هذه الدائرة' };
  c.memberIds.splice(i, 1);   // الإخراج فوري، وما مضى من أثر يُخفي عنه لحظة القراءة (٣.٣)
  return { ok: true, circle: circleView(db, c) };
}

function deleteCircle(db, ownerId, circleId) {
  const c = circleById(db, circleId);
  if (!c || c.ownerId !== ownerId) return { ok: false, code: 404, error: 'الدائرة غير موجودة' };
  const held = (db.memories || []).filter((m) => m.circleId === c.id).length;
  if (held) return { ok: false, code: 409, error: `في هذه الدائرة ${held} من الأثر — انقلها أو احذفها أولًا` };
  db.circles = db.circles.filter((x) => x.id !== c.id);
  return { ok: true, id: circleId };
}

function circleView(db, c) {
  const members = (c.memberIds || []).map((id) => ({ ...ownerView(db, id), presence: presenceOf(db, id) }));
  return {
    id: c.id, name: c.name, kind: c.kind, mine: true,
    members, memberCount: members.length,
    memories: (db.memories || []).filter((m) => m.circleId === c.id).length,
    createdAt: c.createdAt, seed: Boolean(c.seed),
  };
}

// «من يرى أثري» (٨.٢): حساب بمجموع من بلغهم أثرك، ومنعزله من حُجب
function whoSees(db, ownerId) {
  const circles = circlesOf(db, ownerId).map((c) => circleView(db, c));
  const ids = new Set();
  circles.forEach((c) => c.members.forEach((m) => ids.add(m.id)));
  (db.blocks || []).filter((b) => b.ownerId === ownerId).forEach((b) => ids.delete(b.blockedId));
  const people = [...ids].map((id) => ({ ...ownerView(db, id), presence: presenceOf(db, id) }));
  const blocked = (db.blocks || []).filter((b) => b.ownerId === ownerId)
    .map((b) => ({ ...ownerView(db, b.blockedId), at: roundHour(b.at) }));
  return {
    circles,
    people,
    blocked,
    reach: people.length,
    memories: (db.memories || []).filter((m) => m.ownerId === ownerId).length,
    // بند ٤.٥: حدود الحذف تُقال صراحةً في الواجهة — وهذا نصّها الخادمي
    deleteLimit: 'الحذف فوري من الخادم ومن الأجهزة المتصلة؛ ولا يمكن سحب نسخة ظهرت سابقًا على جهاز غير متصل.',
  };
}

// ── ترحيل الحسابات: لا يبقى رقم هاتف خام على القرص (٢.٢) ───────────────────
// يُنادى عند الإقلاع: كل رقم قائم يُستبدل ببصمته ومقنّعه، ويُمحى الرقم.
// الدخول لا ينقطع: phoneMatches تقبل البصمة، وتقبل الرقم القديم إن بقي مخزن لم يُرحَّل.
function migrateAccounts(db) {
  if (String(process.env.SAWA_KEEP_PHONE || '') === '1') return false;
  let changed = false;
  (db.accounts || []).forEach((a) => {
    if (a && a.phone && !a.phoneHash) {
      const fp = fingerprint(a.phone);
      a.phoneKey = fp.phoneKey;
      a.phoneHash = fp.phoneHash;
      a.phoneMasked = maskTail(a.phone);
      delete a.phone;
      changed = true;
    } else if (a && a.phone && a.phoneHash) {
      delete a.phone;
      changed = true;
    }
  });
  if (db.me) {
    if (db.me.phone && !db.me.phoneMasked) { db.me.phoneMasked = maskTail(db.me.phone); changed = true; }
    if (db.me.phone !== undefined && db.me.phone !== '') { db.me.phone = ''; changed = true; }
  }
  return changed;
}

module.exports = {
  ensure, migrateAccounts, keys, fingerprint, phoneMatches, maskTail, keyId,
  circleById, circlesOf, membersOf, isMember, circleView, createCircle, addMembers, removeMember, deleteCircle, whoSees,
  isBlocked, blockedEitherWay, registerDevice, presenceOf,
  createMemory, canRead, visibleMemories, memoryView, ownerView, gridOf, cellRecords, cellOf,
  syncSince, deleteMemory, purgesSince, visitAggregate, pad,
  matchFingerprints, matchesFor, mutualPairs,
  enqueue, deliver, outboxStatus, ackOutbox, expireOutbox,
  OUTBOX_TTL_MS, GRID, MAX_FINGERPRINTS,
};

// ─────────────────────────────────────────────────────────────────────────────
// rtc.js — الاتصال الصوتي والمرئي: إشارات، وحالة مكالمة، وسجلّها في المحادثة.
//
// المعمارية (بند ٣ من الطلب):
//   • الإشارات → خادم، لا نقطة لنقطة: كل حدث يمرّ من هنا ويُحقَّق فيه.
//   • الصعود (عميل ← خادم) عبر POST /api/rtc/signal — يعمل في كل بيئة، ويحمل
//     رمز الجلسة في ترويسة (لا رمز في رابط).
//   • النزول (خادم ← عميل) عبر قناة دفع واحدة: WebSocket على /ws/rtc، وإن حجب
//     الوكيل الترقية → SSE على /api/rtc/stream. لا polling إطلاقًا.
//   • الوسائط نفسها لا تمرّ من الخادم: WebRTC نقطة لنقطة، والخادم ينسّق فقط.
//   • TURN/STUN: تُقرأ من بيئة الخادم وتُسلَّم للعميل عند الطلب — أي سرّ يبقى هنا.
//
// الحالة في الذاكرة: المكالمة عمرها ثوانٍ ودقائق، ولا معنى لكتابتها على القرص،
// لكن **سجلّها** يُكتب في المحادثة كرسالة من نوع call (بند ٨).
// ─────────────────────────────────────────────────────────────────────────────
const express = require('express');
const crypto = require('crypto');
const store = require('./store');
const auth = require('./auth');
const privacy = require('./privacy');
const ws = require('./ws');

const RING_MS = Number(process.env.SAWA_RING_SEC || 45) * 1000;
const GRACE_MS = Number(process.env.SAWA_CALL_GRACE_SEC || 15) * 1000; // مهلة عودة الشبكة
const KEEP_MS = 3 * 60 * 1000;  // كم تبقى مكالمة منتهية في الذاكرة لتُجيب على طلب متأخر
const MAX_SDP = 40 * 1024;
const DROP_AFTER_MS = 20 * 1000; // مكالمة نشطة وكل طرفها انقطع: تُغلق

// ── إعداد ICE ───────────────────────────────────────────────────────────────
// STUN افتراضيًا، وTURN إن وُجد في بيئة الخادم (اتصالات لا تنجح مباشرة).
// لا يُكتب أي منها في ملف العميل: تُسلَّم عند الطلب لجلسة صالحة (بند ٩).
function iceConfig() {
  const list = (v) => String(v || '').split(',').map((s) => s.trim()).filter(Boolean);
  const stun = list(process.env.SAWA_STUN_URLS || 'stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302');
  const turn = list(process.env.SAWA_TURN_URLS);
  const iceServers = [];
  if (stun.length) iceServers.push({ urls: stun });
  if (turn.length) {
    iceServers.push({
      urls: turn,
      username: process.env.SAWA_TURN_USER || '',
      credential: process.env.SAWA_TURN_PASS || '',
    });
  }
  return {
    iceServers,
    hasTurn: turn.length > 0,
    ttlMinutes: Number(process.env.SAWA_ICE_TTL_MIN || 30),
  };
}

// ── مركز الاتصالات: قناة دفع واحدة لكل حساب (WS أو SSE، والواجهة واحدة) ─────
function createHub() {
  const conns = new Map();      // connId → session
  const byAccount = new Map();  // accountId → Set<connId>

  function add(conn) {
    conns.set(conn.id, conn);
    if (!byAccount.has(conn.accountId)) byAccount.set(conn.accountId, new Set());
    byAccount.get(conn.accountId).add(conn.id);
    return conn;
  }

  function drop(connId) {
    const s = conns.get(connId);
    if (!s) return null;
    conns.delete(connId);
    const set = byAccount.get(s.accountId);
    if (set) { set.delete(connId); if (!set.size) byAccount.delete(s.accountId); }
    return s;
  }

  const sessionsOf = (accountId) =>
    [...(byAccount.get(accountId) || [])].map((id) => conns.get(id)).filter(Boolean);

  function send(accountId, msg) {
    let n = 0;
    sessionsOf(accountId).forEach((s) => { try { s.send(msg); n += 1; } catch (e) { /* تجاهل */ } });
    return n;
  }

  return {
    add,
    drop,
    send,
    sessionsOf,
    isOnline: (accountId) => byAccount.has(accountId),
    onlineAccounts: () => [...byAccount.keys()],
    count: () => conns.size,
    kinds: () => [...conns.values()].reduce((a, s) => { a[s.kind] = (a[s.kind] || 0) + 1; return a; }, {}),
  };
}

// خنق بسيط في الذاكرة لكل حساب — يمنع إغراق الإشارات بلا حدّ
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const list = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (list.length >= max) { hits.set(key, list); return true; }
  list.push(now);
  hits.set(key, list);
  return false;
}

const bad = (code, error) => ({ code, error });

// معرّف «أنا» في هذا التطبيق: بطاقة المستخدم نفسه في الواجهة. يُستعمل لمنع
// الاتصال بالذات ولتمييز الرسائل الصادرة في المحادثة.
const SELF_ID = 'u-me';

const hub = createHub();
const calls = new Map(); // callId → المكالمة (في الذاكرة فقط — عمرها دقائق)

const accountById = (db, id) => (db.accounts || []).find((a) => a.id === id) || null;
const accountByName = (db, u) => (db.accounts || []).find((a) => a.username === u) || null;
const personById = (db, id) => (db.people || []).find((p) => p.id === id) || null;
const personFor = (db, acc) => (db.people || []).find((p) => p.username === acc.username) || null;

// الوجه العام للطرف: ما يظهر في شاشة المكالمة وسجلّها — بلا رقم هاتف ولا معرّف جهاز
const face = (acc) => ({
  accountId: acc.id, username: acc.username, name: acc.name,
  avatar: acc.avatar || '', color: acc.color || '#0F766E',
});

const activeOf = (accountId) => [...calls.values()].find(
  (c) => !c.done && (c.caller.accountId === accountId || c.callee.accountId === accountId),
);
const otherParty = (call, accountId) => (call.caller.accountId === accountId ? call.callee : call.caller);
const durationOf = (call) => {
  if (!call.answeredAt) return 0;
  const end = call.endedAt ? Date.parse(call.endedAt) : Date.now();
  return Math.max(0, Math.round((end - Date.parse(call.answeredAt)) / 1000));
};

// ما يراه هذا الحساب عن المكالمة (لا يرى تفاصيل الطرف الآخر الداخلية)
function callView(call, accountId) {
  const role = call.caller.accountId === accountId ? 'caller' : 'callee';
  const peer = role === 'caller' ? call.callee : call.caller;
  return {
    id: call.id,
    kind: call.kind,
    state: call.state,
    role,
    peer: { name: peer.name, username: peer.username, avatar: peer.avatar || '', color: peer.color || '' },
    createdAt: call.at,
    answeredAt: call.answeredAt || null,
    endedAt: call.endedAt || null,
    status: call.status || '',
    reason: call.reason || '',
    durationSec: durationOf(call),
    chatPersonId: call.chatPersonId,
    peerMuted: Boolean((call.media || {})[peer.accountId] && call.media[peer.accountId].audio === false),
    peerVideoOff: Boolean((call.media || {})[peer.accountId] && call.media[peer.accountId].video === false),
  };
}

const push = (accountId, msg) => {
  const n = hub.send(accountId, msg);
  if (process.env.SAWA_RTC_TRACE) console.log('[rtc] push', msg && msg.ev, '→', accountId, 'delivered', n);
  return n;
};

// ── سجلّ المكالمة في المحادثة (بند ٨) ──────────────────────────────────────
// تُكتب رسالة واحدة بنوع call: النوع والحالة والمدة والطرفان والتوقيت.
// لا يُخزَّن شيء من الوسائط: الوسائط لا تمرّ من الخادم أصلًا.
function logCall(call) {
  const row = {
    id: store.id('mg'),
    from: SELF_ID,
    text: '',
    type: 'call',
    at: new Date().toISOString(),
    media: null,
    call: {
      id: call.id,
      kind: call.kind,
      status: call.status || 'ended',
      durationSec: durationOf(call),
      caller: { name: call.caller.name, username: call.caller.username },
      callee: { name: call.callee.name, username: call.callee.username },
      at: call.at,
      answeredAt: call.answeredAt || null,
      endedAt: call.endedAt || null,
      reason: call.reason || '',
    },
  };
  try {
    const db = store.mutate((d) => {
      d.chats = d.chats || [];
      d.people = d.people || [];
      let chat = d.chats.find((c) => c.personId === call.chatPersonId);
      if (!chat) {
        chat = { id: store.id('c'), personId: call.chatPersonId, unread: 0, messages: [] };
        d.chats.unshift(chat);
      }
      const person = d.people.find((p) => p.id === call.chatPersonId);
      if (person && person.username === call.caller.username) row.from = person.id;
      chat.messages.push(row);
      return d;
    });
    return db;
  } catch (e) {
    console.error('[rtc] تعذّر تسجيل المكالمة:', e && e.message);
    return null;
  }
}

// إغلاق مكالمة بحالة نهائية: الطرفان يُبلَّغان، والسجلّ يُكتب، والذاكرة تُنظَّف لاحقًا
function finish(call, status, reason) {
  if (call.done) return call;
  call.done = true;
  call.state = 'ended';
  call.status = status;
  call.reason = reason || '';
  call.endedAt = new Date().toISOString();
  if (call.timer) clearTimeout(call.timer);
  if (process.env.SAWA_RTC_TRACE) console.log('[rtc] finish', call.id, status, reason, 'caller', call.caller.accountId, 'callee', call.callee.accountId);
  logCall(call);
  [call.caller.accountId, call.callee.accountId].forEach((id) => {
    push(id, { ev: 'call:ended', call: callView(call, id) });
  });
  push(call.caller.accountId, { ev: 'chat:changed', personId: call.chatPersonId });
  push(call.callee.accountId, { ev: 'chat:changed', personId: call.chatPersonId });
  const t = setTimeout(() => calls.delete(call.id), KEEP_MS);
  if (t.unref) t.unref();
  return call;
}

const newCallId = () => `call_${crypto.randomBytes(8).toString('hex')}`;

// ── بدء مكالمة: التحقق الكامل قبل أي إشارة (بند ٩) ─────────────────────────
function invite(acc, personId, kind, peerNameHint) {
  if (kind !== 'audio' && kind !== 'video') return bad(400, 'نوع المكالمة غير معروف');
  const db = store.read();
  if (!acc.username) return bad(403, 'أكمل ملفك باسم مستخدم أولًا ليتمكّن من تريد الاتصال بك');
  if (!personId) return bad(400, 'اختر شخصًا للاتصال');
  // ٠) نفسي: لا مكالمة مع الذات — يُفحَص أولًا لأن بطاقة «أنا» قد لا تكون في
  //    قائمة الأشخاص أصلًا، ورسالة «لا يوجد شخص بهذا المعرّف» تُضلّل هنا.
  const me = personFor(db, acc);
  if (personId === SELF_ID || (me && personId === me.id)) return bad(400, 'لا يمكنك الاتصال بنفسك');

  // ١) الشخص يجب أن يكون في دائرة المتصل — لا مكالمة مع غير مصرّح له
  const person = personById(db, personId);
  if (!person) return bad(404, 'لا يوجد شخص بهذا المعرّف في دائرتك');
  // ٢) الطرف الآخر يجب أن يكون حسابًا حقيقيًا في سوى (لا اتصال بشخص غير مسجّل)
  const peer = person.username ? accountByName(db, person.username) : null;
  if (!peer) return bad(409, `${person.name} ليس في سوى بعد — لا يمكن الاتصال به`);
  if (peer.id === acc.id) return bad(400, 'لا يمكنك الاتصال بنفسك');
  // ٣) العضوية شرط: من ليس في دائرة المتصل لا يُتَّصل به (بند ٩) — تُفحَص
  //    العضوية الخادمية في v31 وهي لكل حساب، لا قائمة أسماء مشتركة.
  const mine = privacy.circlesOf(db, acc.id);
  const member = mine.some((c) => (c.memberIds || []).includes(peer.id));
  if (!member) return bad(403, `${person.name} ليس في دائرتك — أضفه أولًا ثم اتصل به`);
  // ٤) الحجب في الاتجاهين يقطع المكالمة (طبقة v31)
  if (privacy.isBlocked(db, peer.id, acc.id) || privacy.isBlocked(db, acc.id, peer.id)) {
    return bad(403, 'لا يمكن إجراء هذه المكالمة');
  }
  // ٥) لا مكالمتين معًا من الجهاز نفسه
  if (activeOf(acc.id)) return bad(409, 'أنت في مكالمة أخرى — أنهاها أولًا');

  // مشغول بطرف آخر؟ الطرف المُتَّصل به يقرّر — لا نقطع مكالمته القائمة.
  // الفحص قبل إدخال هذه المكالمة في السجلّ، وإلا عدّت نفسها مكالمة قائمة.
  const peerBusy = activeOf(peer.id);
  const peerOnline = hub.isOnline(peer.id);

  const call = {
    id: newCallId(),
    kind,
    state: 'ringing',
    status: '',
    reason: '',
    at: new Date().toISOString(),
    answeredAt: null,
    endedAt: null,
    done: false,
    media: {},
    chatPersonId: person.id,
    caller: face(acc),
    callee: face(peer),
    timer: null,
  };
  calls.set(call.id, call);

  if (peerBusy) { finish(call, 'busy', 'peer-busy'); return { ok: true, call, busy: true }; }
  if (!peerOnline) { finish(call, 'unreachable', 'peer-offline'); return { ok: true, call, offline: true }; }

  const n = push(peer.id, { ev: 'call:incoming', call: callView(call, peer.id), from: call.caller });
  if (!n) { finish(call, 'unreachable', 'peer-offline'); return { ok: true, call, offline: true }; }

  call.timer = setTimeout(() => finish(call, 'missed', 'no-answer'), RING_MS);
  if (call.timer.unref) call.timer.unref();
  return { ok: true, call, ringing: true, devices: n };
}

// قبول: من الطرف المُتَّصل به وحده، ومن حالة رنين فقط
function accept(acc, callId) {
  const call = calls.get(callId);
  if (!call || call.done) return bad(404, 'المكالمة انتهت');
  if (call.callee.accountId !== acc.id) return bad(403, 'لست طرفًا في هذه المكالمة');
  if (call.state !== 'ringing') return bad(409, 'المكالمة ليست في حالة رنين');
  call.state = 'active';
  call.answeredAt = new Date().toISOString();
  if (call.timer) clearTimeout(call.timer);
  push(call.caller.accountId, { ev: 'call:accepted', call: callView(call, call.caller.accountId) });
  push(call.callee.accountId, { ev: 'call:accepted', call: callView(call, call.callee.accountId) });
  return { ok: true, call };
}

function reject(acc, callId, reason) {
  const call = calls.get(callId);
  if (!call || call.done) return bad(404, 'المكالمة انتهت');
  if (call.callee.accountId !== acc.id) return bad(403, 'لست طرفًا في هذه المكالمة');
  if (call.state !== 'ringing') return bad(409, 'لا يمكن الرفض بعد بدء المكالمة');
  finish(call, 'rejected', reason || 'declined');
  return { ok: true, call };
}

function end(acc, callId, reason) {
  const call = calls.get(callId);
  if (!call || call.done) return bad(404, 'المكالمة انتهت');
  if (call.caller.accountId !== acc.id && call.callee.accountId !== acc.id) {
    return bad(403, 'لست طرفًا في هذه المكالمة');
  }
  if (call.state === 'active') finish(call, 'ended', reason || 'hangup');
  else finish(call, call.caller.accountId === acc.id ? 'canceled' : 'rejected', reason || 'hangup');
  return { ok: true, call };
}

// تمرير SDP/ICE: من طرف إلى طرفه وحده، وفي مكالمة قائمة، وبحجم محدود
function relay(acc, callId, ev, payload) {
  const call = calls.get(callId);
  if (!call || call.done) return bad(404, 'المكالمة انتهت');
  if (call.caller.accountId !== acc.id && call.callee.accountId !== acc.id) {
    return bad(403, 'لست طرفًا في هذه المكالمة');
  }
  const to = otherParty(call, acc.id);
  if (ev === 'sdp') {
    const sdp = String((payload && payload.description && payload.description.sdp) || '');
    const type = String((payload && payload.description && payload.description.type) || '');
    if (!sdp || sdp.length > MAX_SDP) return bad(400, 'وصف الاتصال غير صالح');
    if (type !== 'offer' && type !== 'answer') return bad(400, 'نوع الوصف غير معروف');
    push(to.accountId, { ev: 'call:sdp', callId: call.id, from: acc.id, description: { type, sdp } });
    return { ok: true };
  }
  if (ev === 'ice') {
    const c = payload && payload.candidate;
    if (!c || typeof c !== 'object') return { ok: true };
    const line = String(c.candidate || '');
    if (line.length > 1200) return bad(400, 'مرشّح غير صالح');
    push(to.accountId, {
      ev: 'call:ice',
      callId: call.id,
      from: acc.id,
      candidate: { candidate: line, sdpMid: String(c.sdpMid || ''), sdpMLineIndex: Number(c.sdpMLineIndex) || 0 },
    });
    return { ok: true };
  }
  if (ev === 'media') {
    call.media[acc.id] = { audio: payload.audio !== false, video: payload.video !== false };
    push(to.accountId, { ev: 'call:media', callId: call.id, media: call.media[acc.id] });
    return { ok: true };
  }
  if (ev === 'resume') {
    push(to.accountId, { ev: 'call:peer-back', callId: call.id });
    return { ok: true };
  }
  return bad(400, 'حدث إشارة غير معروف');
}

// انقطاع قناة أحد الطرفين: مهلة قصيرة للعودة، ثم إغلاق المكالمة بسببها
function sessionClosed(accountId) {
  if (hub.isOnline(accountId)) return;
  const call = activeOf(accountId);
  if (!call) return;
  const peer = otherParty(call, accountId);
  const wasRinging = call.state === 'ringing';
  if (process.env.SAWA_RTC_TRACE) console.log('[rtc] sessionClosed', accountId, 'call', call.id, wasRinging);
  if (!wasRinging) push(peer.accountId, { ev: 'call:peer-connecting', callId: call.id });
  const t = setTimeout(() => {
    if (call.done) return;
    if (hub.isOnline(accountId)) { push(peer.accountId, { ev: 'call:peer-back', callId: call.id }); return; }
    if (wasRinging) {
      finish(call, call.callee.accountId === accountId ? 'missed' : 'canceled', 'offline');
      return;
    }
    finish(call, 'dropped', 'network');
  }, wasRinging ? Math.min(GRACE_MS, 8000) : GRACE_MS);
  if (t.unref) t.unref();
}

// ── قناة الدفع: تُفتح مع WS أو SSE، والواجهة واحدة ─────────────────────────
function onlineUsernames() {
  const db = store.read();
  const names = new Set((db.people || []).map((p) => p.username).filter(Boolean));
  return hub.onlineAccounts()
    .map((id) => accountById(db, id))
    .filter((a) => a && names.has(a.username))
    .map((a) => a.username);
}

function presencePing(username, online, exceptId) {
  const msg = { ev: 'presence', username, online };
  hub.onlineAccounts().forEach((id) => { if (id !== exceptId) hub.send(id, msg); });
}

function openSession(conn) {
  const s = hub.add(conn);
  if (process.env.SAWA_RTC_TRACE) console.log('[rtc] openSession', s.id, s.accountId, s.kind);
  const call = activeOf(conn.accountId);
  conn.send({
    ev: 'ready',
    at: new Date().toISOString(),
    ice: iceConfig(),
    online: onlineUsernames(),
    call: call ? callView(call, conn.accountId) : null,
    resumable: Boolean(call),
  });
  presencePing(conn.username, true, conn.accountId);
  // من كان متصلًا قبل فتحي للقناة: تُرسل إليه هذه القناة وحدها لقطة حضور،
  // فمعرفة «من معي الآن» لا تتطلّب إعادة قراءة الحالة عند كل فتح (لا polling).
  onlineUsernames().forEach((u) => {
    if (u && u !== conn.username) conn.send({ ev: 'presence', username: u, online: true });
  });
  return s;
}

function closeSession(s) {
  if (!s) return;
  if (process.env.SAWA_RTC_TRACE) console.log('[rtc] closeSession', s.id, s.accountId);
  hub.drop(s.id);
  presencePing(s.username, false, null);
  sessionClosed(s.accountId);
}

// إشعار تغيّر محادثة (رسالة جديدة أو سجلّ مكالمة) — يُنادي من مسار الإرسال
function notifyChat(personId, accountId) {
  const msg = { ev: 'chat:changed', personId: personId || null };
  if (accountId) hub.send(accountId, msg);
  else hub.onlineAccounts().forEach((id) => hub.send(id, msg));
}

// ── المسارات: كلها تتطلّب جلسة صالحة (بند ٩) ───────────────────────────────
const router = express.Router();
router.use((req, res, next) => {
  const account = auth.accountOfToken(auth.tokenOf(req));
  if (!account) {
    return res.status(401).json({ error: 'سجّل الدخول أولًا', code: 'no_session', auth: 'required' });
  }
  req.sawa = { accountId: account.id, account };
  return next();
});
const ok = (res, data) => res.json(data);
const fail = (res, out) => res.status(out.code || 400).json({ error: out.error });

// إعداد ICE لجلسة صالحة فقط (TURN لا يظهر في أي ملف عميل)
router.get('/ice', (req, res) => ok(res, iceConfig()));

// حالة واحدة عند الفتح أو بعد عودة الشبكة: من متصل؟ أمكالمة قائمة؟ — لا polling
router.get('/state', (req, res) => {
  const acc = req.sawa.account;
  const call = activeOf(acc.id);
  return ok(res, {
    ice: iceConfig(),
    online: onlineUsernames(),
    call: call ? callView(call, acc.id) : null,
    sessions: hub.sessionsOf(acc.id).length,
    channels: hub.kinds(),
  });
});

// سجلّ المكالمات: يُقرأ من رسائل المحادثة نفسها (نوع call) — بلا جدول موازٍ
router.get('/history', (req, res) => {
  const pid = String(req.query.personId || '');
  const db = store.read();
  const chats = (db.chats || []).filter((c) => !pid || c.personId === pid);
  if (pid && !chats.length) return fail(res, bad(404, 'لا محادثة بهذا المعرّف'));
  const rows = [];
  chats.forEach((c) => {
    (c.messages || []).forEach((m) => {
      if (m && m.type === 'call' && m.call) rows.push({ ...m.call, personId: c.personId, messageId: m.id, from: m.from });
    });
  });
  rows.sort((a, b) => Date.parse(b.at || 0) - Date.parse(a.at || 0));
  return ok(res, { calls: rows.slice(0, 60) });
});

// قناة الدفع البديلة (SSE): تُستعمل تلقائيًا حين لا يسمح الوكيل بترقية WebSocket
router.get('/stream', (req, res) => {
  const acc = req.sawa.account;
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
  });
  if (typeof res.flushHeaders === 'function') res.flushHeaders();
  res.write(': سوى — قناة إشارات حيّة\n\n');
  const send = (msg) => {
    try { res.write(`data: ${JSON.stringify(msg)}\n\n`); } catch (e) { /* تجاهل */ }
  };
  const session = openSession({
    id: crypto.randomBytes(6).toString('hex'),
    accountId: acc.id,
    username: acc.username || '',
    name: acc.name || '',
    kind: 'sse',
    send,
    close: () => { try { res.end(); } catch (e) { /* تجاهل */ } },
  });
  const beat = setInterval(() => {
    try { res.write(`: نبض ${Date.now()}\n\n`); } catch (e) { /* تجاهل */ }
  }, 20000);
  if (beat.unref) beat.unref();
  const done = () => { clearInterval(beat); closeSession(session); };
  // الجلسة تُفحص دوريًا: رمز أُبطل بدخول من مكان آخر لا يبقى على قناة مفتوحة.
  // نُبلّغ السبب صراحةً ثم نُنهي القناة (العميل لا يعيد المحاولة بالرمز نفسه).
  const watch = setInterval(() => {
    if (auth.accountOfToken(auth.tokenOf(req))) return;
    send({ ev: 'session', ...auth.endedBody(auth.tokenOf(req)), auth: 'required' });
    done();
  }, 15000);
  if (watch.unref) watch.unref();
  req.on('close', () => clearInterval(watch));
  res.on('close', () => clearInterval(watch));
  res.on('error', () => clearInterval(watch));
  req.on('close', done);
  res.on('close', done);
  res.on('error', done);
});

// الجزء الصاعد: كل إشارة مشروع قرار يمرّ من هنا (لأن الترويسة تحمل رمز الجلسة)
router.post('/signal', (req, res) => {
  const acc = req.sawa.account;
  if (limited('sig:' + acc.id, 240, 60000)) {
    return res.status(429).json({ error: 'إشارات كثيرة — أعد المحاولة', code: 'rate' });
  }
  const body = req.body || {};
  const ev = String(body.ev || '');
  const out = (() => {
    switch (ev) {
      case 'invite': return invite(acc, String(body.personId || ''), String(body.kind || ''), body.name);
      case 'ring': {
        const call = calls.get(String(body.callId || ''));
        if (!call || call.done) return bad(404, 'المكالمة انتهت');
        if (call.caller.accountId !== acc.id) return bad(403, 'لست طرفًا في هذه المكالمة');
        return { ok: true, call };
      }
      case 'accept': return accept(acc, String(body.callId || ''));
      case 'reject': return reject(acc, String(body.callId || ''), body.reason);
      case 'end': return end(acc, String(body.callId || ''), body.reason);
      case 'sdp': case 'ice': case 'media': case 'resume':
        return relay(acc, String(body.callId || ''), ev, body);
      default: return bad(400, 'حدث إشارة غير معروف');
    }
  })();
  if (!out.ok) return fail(res, out);
  return ok(res, {
    ok: true,
    call: out.call ? callView(out.call, acc.id) : null,
    ringing: Boolean(out.ringing),
    busy: Boolean(out.busy),
    offline: Boolean(out.offline),
    devices: out.devices || 0,
  });
});

// ── WebSocket: القناة الأساسية إن سمح الوكيل بالترقية ─────────────────────
function attachWs(server) {
  return ws.attach(server, {
    routes: {
      '/ws/rtc': (req, url) => {
        const token = url.searchParams.get('token') || '';
        const acc = auth.accountOfToken(token);
        if (!acc) return { reject: 401 };
        return {
          info: { accountId: acc.id, username: acc.username || '' },
          onOpen: (conn) => {
            const wrapper = {
              id: crypto.randomBytes(6).toString('hex'),
              accountId: acc.id,
              username: acc.username || '',
              name: acc.name || '',
              kind: 'ws',
              send: (msg) => conn.send(msg),
              close: () => conn.close(),
            };
            const session = openSession(wrapper);
            // الجلسة تُفحص لحظة القراءة لا عند الترقية فقط: رمز أُبطل بدخول من مكان
            // آخر لا يبقى على قناة حيّة. نُبلّغ السبب صراحةً («دخلت من مكان آخر») ثم
            // نُغلق بـ 4401 — إغلاق مهذّب بلا ردّ 401، فلا يظهر خطأ في طرفية المتصفح.
            let authTimer = null;
            const sessionGone = () => {
              if (auth.accountOfToken(token)) return false;
              const b = auth.endedBody(token);
              try { conn.send({ ev: 'session', ...b, auth: 'required' }); } catch (e) { /* تجاهل */ }
              closeSession(session);
              conn.close(4401);
              return true;
            };
            authTimer = setInterval(() => { if (sessionGone()) clearInterval(authTimer); }, 15000);
            authTimer.unref?.();
            conn.on('message', (msg) => {
              // الجزء الصاعد عبر WS مدعوم أيضًا (نفس تحقّقات POST) — لا مسار بلا حراسة
              if (sessionGone()) { clearInterval(authTimer); return; }
              if (msg && msg.ev === 'ping') { conn.send({ ev: 'pong', at: Date.now() }); return; }
              if (limited('ws:' + acc.id, 240, 60000)) { conn.send({ ev: 'error', error: 'إشارات كثيرة' }); return; }
              const out = msg && msg.ev === 'media'
                ? relay(acc, String(msg.callId || ''), 'media', msg)
                : msg && (msg.ev === 'sdp' || msg.ev === 'ice')
                  ? relay(acc, String(msg.callId || ''), msg.ev, msg)
                  : null;
              if (out && out.ok) conn.send({ ev: 'ack', for: msg.ev, callId: msg.callId || '' });
            });
            conn.on('close', () => { clearInterval(authTimer); closeSession(session); });
          },
        };
      },
    },
  });
}

module.exports = {
  router,
  attachWs,
  notifyChat,
  info: () => ({ sessions: hub.count(), calls: calls.size, channels: hub.kinds(), turn: iceConfig().hasTurn }),
};

/**
 * حكم الجلسات — **جلسة واحدة نشطة لكل حساب**.
 *
 * القاعدة المطلوبة في التطبيق:
 *   • لكل حساب جلسة نشطة واحدة على الأكثر.
 *   • الدخول من جهاز جديد لا يطرد الجهاز القديم بصمت، بل:
 *       ١) الجلسة الجديدة تبدأ «قيد التأكيد» (pending) — لا تصل إلى بيانات الدائرة.
 *       ٢) الجلسة القديمة تصير «مُتحدّاة» (challenged)، ويعرض عليها التطبيق:
 *          «تم تسجيل الدخول إلى حسابك من جهاز جديد — هل كنت أنت؟»
 *       ٣) «نعم، كنت أنا» → تُنهى القديمة، وتصير الجديدة هي النشطة.
 *       ٤) «لا، ليس أنا»  → تُبطَل الجديدة وترجع القديمة نشطة كما كانت.
 *       ٥) لا جواب خلال المهلة (افتراضيًا ١٨٠ ثانية، SAWA_SESSION_CHALLENGE_SEC)
 *          → تُعتمد الجديدة، لأن الأرجح أن الجهاز القديم مغلق أو مفقود.
 *
 * لماذا لا تُنهى القديمة في اللحظة نفسها؟ لأن السؤال يجب أن يُطرح على الجهاز
 * القديم نفسه؛ لو أنهينا جلسته أولًا لما وصل إليه السؤال أصلًا. فالخروج «الفوري»
 * الذي يراه المستخدم على الجهاز القديم هو هذه الحالة: التطبيق يُقفل ويظهر السؤال.
 *
 * الحالة كلها في db.sessions و db.sessionNotes (في المخزن لا في الذاكرة) لتصمد
 * لإعادة تشغيل الخادم. الكتابة على القرص تحدث **فقط عند تغيّر حقيقي** — لا عند
 * كل استطلاع، لأن ملف المخزن واحد ويُكتب كاملًا.
 */
const crypto = require('crypto');
const express = require('express');
const store = require('./store');

const WINDOW_MS = Math.max(30, Number(process.env.SAWA_SESSION_CHALLENGE_SEC || 180)) * 1000;
const SESSION_TTL_MS = 30 * 24 * 3600 * 1000; // ٣٠ يومًا
const NOTE_TTL_MS = 24 * 3600 * 1000;         // ملاحظة سبب الخروج تُقرأ يومًا واحدًا
const TOUCH_MS = 5 * 60 * 1000;               // لا نكتب lastSeenAt أكثر من مرة كل ٥ د

const nowMs = () => Date.now();
const iso = (t) => new Date(t).toISOString();
const statusOf = (s) => (s && s.status ? s.status : 'active'); // جلسات ما قبل هذه الميزة = نشطة
const newToken = () => crypto.randomBytes(24).toString('hex');
const newId = () => 'ses' + crypto.randomBytes(5).toString('hex');

// ── رمز الجلسة من الطلب ──
function tokenOf(req) {
  const h = (req && req.headers) || {};
  const raw = h['x-sawa-token'] || h['X-Sawa-Token'] || h.authorization || '';
  const m = /^Bearer\s+(.+)$/i.exec(String(raw));
  return String(m ? m[1] : raw).trim();
}

// ── وصف الجهاز بلا بصمة دقيقة: نظام + متصفح فقط، بالعربية ──
function deviceOf(req) {
  const h = (req && req.headers) || {};
  const ua = String(h['user-agent'] || '');
  const plat = String(h['sec-ch-ua-platform'] || '').replace(/"/g, '');
  let os = '';
  if (/iPhone|iPod/.test(ua)) os = 'آيفون';
  else if (/iPad/.test(ua)) os = 'آيباد';
  else if (/Android/.test(ua)) os = 'أندرويد';
  else if (/Windows|Win32|Win64/i.test(ua) || /Windows/i.test(plat)) os = 'ويندوز';
  else if (/Macintosh|Mac OS X/.test(ua) || /macOS/i.test(plat)) os = 'ماك';
  else if (/Linux|X11/.test(ua) || /Linux/i.test(plat)) os = 'لينكس';
  let app = '';
  if (/CriOS/.test(ua)) app = 'كروم';
  else if (/FxiOS|Firefox/.test(ua)) app = 'فايرفوكس';
  else if (/EdgiOS|Edg\//.test(ua)) app = 'إج';
  else if (/OPR\/|Opera/.test(ua)) app = 'أوبرا';
  else if (/Chrome|Chromium/.test(ua)) app = 'كروم';
  else if (/Safari/.test(ua)) app = 'سفاري';
  const label = [os, app].filter(Boolean).join(' · ');
  return { os: os || null, app: app || null, label: label || 'جهاز غير معروف' };
}

// ── من أين: عنوان الشبكة مقنّعًا — لا نعرض عنوانًا كاملًا ولا نحفظه ──
function whereOf(req) {
  const h = (req && req.headers) || {};
  const raw = String((h['x-forwarded-for'] || '').split(',')[0] || h['x-real-ip'] || (req && req.ip) || '').trim();
  const ip = raw.replace(/^::ffff:/, '');
  if (!ip || ip === '::1' || /^(127|10)\./.test(ip) || /^192\.168\./.test(ip) || /^172\.(1[6-9]|2\d|3[01])\./.test(ip)) {
    return { label: 'شبكة داخلية', ip: '' };
  }
  if (ip.includes(':')) return { label: 'شبكة IPv6', ip: ip.slice(0, 6) + '…' };
  const p = ip.split('.');
  return { label: p.slice(0, 3).join('.') + '.•', ip: p.slice(0, 3).join('.') + '.•' };
}

// الوصف الذي تراه الواجهة: بلا رمز الجلسة أبدًا
const publicOf = (s) => (s ? {
  id: s.id,
  device: (s.device && s.device.label) || 'جهاز غير معروف',
  where: (s.where && s.where.label) || '',
  at: s.createdAt,
} : null);

// ── أدوات الحالة (تعمل على نسخة من المصفوفة قبل الكتابة) ──
const alive = (s, t = nowMs()) => Boolean(s && s.token && (!s.expiresAt || Date.parse(s.expiresAt) > t));

function pruneMem(sessions, notes) {
  const t = nowMs();
  let dirty = false;
  for (let i = sessions.length - 1; i >= 0; i -= 1) {
    if (!alive(sessions[i], t)) { sessions.splice(i, 1); dirty = true; }
  }
  Object.keys(notes).forEach((k) => {
    const at = Date.parse((notes[k] && notes[k].at) || 0);
    if (!at || t - at > NOTE_TTL_MS) { delete notes[k]; dirty = true; }
  });
  return dirty;
}

// يُنهي جلسة ويترك ملاحظة سببها (تُقرأ مرة واحدة على الجهاز الذي خرج)
function endMem(sessions, notes, s, reason, device) {
  s.status = 'ended';
  s.endedAt = iso(nowMs());
  notes[s.token] = { reason, at: s.endedAt, device: device || null };
  return s;
}

function dropEnded(sessions, notes) {
  for (let i = sessions.length - 1; i >= 0; i -= 1) {
    const s = sessions[i];
    if (statusOf(s) !== 'ended') continue;
    if (!notes[s.token]) notes[s.token] = { reason: s.endReason || 'ended', at: s.endedAt || iso(nowMs()), device: null };
    sessions.splice(i, 1);
  }
}

const forAccount = (sessions, accountId) => sessions.filter((s) => s.accountId === accountId);

// انتهت مهلته بلا جواب → تُعتمد الجلسة الجديدة وتُنهى القديمة
function resolveMem(sessions, notes, accountId) {
  const t = nowMs();
  let dirty = false;
  sessions.filter((s) => statusOf(s) === 'challenged' && (!accountId || s.accountId === accountId)).forEach((old) => {
    const at = Date.parse((old.challenge && old.challenge.at) || 0);
    if (!at || t - at < WINDOW_MS) return;
    const pending = forAccount(sessions, old.accountId).find((s) => statusOf(s) === 'pending' && s.id === (old.challenge.sessionId || ''));
    endMem(sessions, notes, old, 'timeout', pending ? pending.device : null);
    if (pending) { pending.status = 'active'; pending.challenge = null; pending.activatedAt = iso(t); }
    dirty = true;
  });
  return dirty;
}
// ── الدخول: تُفتح الجلسة، وتُحدَّى القديمة إن وُجدت ──
// تُنادى داخل store.mutate (المخزن مقروء ومملوك للمستدعي).
function start(db, account, req) {
  const sessions = db.sessions || (db.sessions = []);
  const notes = db.sessionNotes || {};
  const t = nowMs();
  pruneMem(sessions, notes);
  resolveMem(sessions, notes, account.id);

  const mine = forAccount(sessions, account.id);
  // طلب دخول سابق لم يُحسم بعد: يُبطَل، فلا يبقى معلّقًا إلا واحد
  mine.filter((s) => statusOf(s) === 'pending').forEach((s) => endMem(sessions, notes, s, 'replaced-by-new-login', null));
  const actives = mine.filter((s) => statusOf(s) === 'active').sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt));
  const old = actives[0] || null;
  // أكثر من نشطة (بيانات قديمة): البقية تُنهى — القاعدة واحدة نشطة
  actives.slice(1).forEach((s) => endMem(sessions, notes, s, 'superseded', null));

  const fresh = {
    token: newToken(),
    id: newId(),
    accountId: account.id,
    createdAt: iso(t),
    expiresAt: iso(t + SESSION_TTL_MS),
    lastSeenAt: iso(t),
    device: deviceOf(req),
    where: whereOf(req),
    status: old ? 'pending' : 'active',
  };
  if (old) old.status = 'challenged';
  sessions.push(fresh);
  if (old) {
    old.challenge = {
      at: iso(t), sessionId: fresh.id, device: fresh.device, where: fresh.where,
      windowSec: Math.round(WINDOW_MS / 1000),
    };
  }
  dropEnded(sessions, notes);
  if (Object.keys(notes).length) db.sessionNotes = notes;
  return { session: fresh, state: statusOf(fresh), public: publicOf(fresh), challenger: old ? publicOf(fresh) : null };
}

// ── الجواب على السؤال: يُنادى من الجلسة القديمة («نعم كنت أنا» / «لا ليس أنا») ──
function answer(db, token, approve) {
  const sessions = db.sessions || [];
  const notes = db.sessionNotes || {};
  const t = nowMs();
  pruneMem(sessions, notes);
  resolveMem(sessions, notes, null);
  const mine = sessions.find((s) => s.token === token && statusOf(s) === 'challenged');
  if (!mine) {
    const ended = (db.sessionNotes || {})[token];
    return { ok: false, state: 'gone', note: ended || null, error: 'لا يوجد طلب تأكيد قائم' };
  }
  const pending = forAccount(sessions, mine.accountId).find((s) => statusOf(s) === 'pending') || null;

  if (approve) {
    endMem(sessions, notes, mine, 'replaced-by-new-device', pending ? pending.device : null);
    if (pending) { pending.status = 'active'; pending.challenge = null; pending.activatedAt = iso(t); }
    dropEnded(sessions, notes);
    db.sessions = sessions;
    db.sessionNotes = notes;
    return { ok: true, state: 'ended', approved: true, session: pending ? publicOf(pending) : null };
  }

  // «لا»: يُسجَّل خروج الجهاز الجديد وترجع هذه الجلسة نشطة كما كانت
  if (pending) endMem(sessions, notes, pending, 'rejected-by-owner', mine.device);
  mine.status = 'active';
  mine.challenge = null;
  mine.resumedAt = iso(t);
  dropEnded(sessions, notes);
  db.sessions = sessions;
  if (Object.keys(notes).length) db.sessionNotes = notes;
  return { ok: true, state: 'active', approved: false, session: publicOf(mine) };
}
// ── قراءة الحالة ──
function stateOf(db, token) {
  const t = nowMs();
  const s = (db.sessions || []).find((x) => x.token === token);
  if (!s || !alive(s, t)) {
    return { state: 'gone', session: null, note: (db.sessionNotes || {})[token] || null };
  }
  const st = statusOf(s);
  if (st === 'pending') {
    const left = Math.max(0, Math.round((WINDOW_MS - (t - Date.parse(s.createdAt))) / 1000));
    return { state: 'pending', session: s, me: publicOf(s), secondsLeft: left };
  }
  if (st === 'challenged') {
    const at = Date.parse((s.challenge && s.challenge.at) || 0) || t;
    const left = Math.max(0, Math.round((WINDOW_MS - (t - at)) / 1000));
    const challenger = s.challenge ? publicOf({
      id: s.challenge.sessionId, device: s.challenge.device, where: s.challenge.where, createdAt: s.challenge.at,
    }) : null;
    return { state: 'challenged', session: s, me: publicOf(s), challenge: challenger, secondsLeft: left };
  }
  return { state: 'active', session: s, me: publicOf(s) };
}

function writeState(sessions, notes) {
  store.mutate((d) => {
    d.sessions = sessions;
    if (Object.keys(notes).length) d.sessionNotes = notes; else delete d.sessionNotes;
    return d;
  });
}

// قراءة تُطبّق ما يجب تطبيقه (انتهاء مهل + تنظيف) وتكتب **فقط** إن تغيّر شيء
function step(token) {
  const db = store.read();
  const sessions = (db.sessions || []).map((s) => ({ ...s }));
  const notes = { ...(db.sessionNotes || {}) };
  let dirty = pruneMem(sessions, notes);
  if (resolveMem(sessions, notes, null)) { dropEnded(sessions, notes); dirty = true; }
  const view = stateOf({ sessions, notes }, token);
  const s = view.session;
  if (s && (!s.lastSeenAt || nowMs() - Date.parse(s.lastSeenAt) > TOUCH_MS)) {
    s.lastSeenAt = iso(nowMs());
    dirty = true;
  }
  if (dirty) writeState(sessions, notes);
  return view;
}

// خروج جلسة واحدة: جلسة هذا الجهاز فقط — لا يمسّ بقية الأجهزة
function end(token) {
  store.mutate((d) => {
    const sessions = d.sessions || [];
    const notes = d.sessionNotes || {};
    const s = sessions.find((x) => x.token === token);
    if (!s) return d;
    const wasChallenged = statusOf(s) === 'challenged';
    endMem(sessions, notes, s, 'logged-out', null);
    if (wasChallenged) {
      const pending = forAccount(sessions, s.accountId).find((x) => statusOf(x) === 'pending');
      if (pending) { pending.status = 'active'; pending.challenge = null; pending.activatedAt = iso(nowMs()); }
    }
    dropEnded(sessions, notes);
    d.sessions = sessions;
    if (Object.keys(notes).length) d.sessionNotes = notes;
    return d;
  });
  return { ok: true };
}

const statusOfToken = (token) => {
  if (!token) return null;
  const db = store.read();
  const s = (db.sessions || []).find((x) => x.token === token);
  return s && alive(s) ? statusOf(s) : null;
};
// ── المسارات: تُركَّب على /api/auth ──
const router = express.Router();

// استطلاع خفيف من التطبيق المفتوح: هل جلستي ما زالت هي النشطة؟
router.get('/watch', (req, res) => {
  const token = tokenOf(req);
  const view = step(token);
  if (view.state === 'gone') {
    return res.status(401).json({
      ok: false,
      state: 'gone',
      error: view.note && view.note.reason === 'rejected-by-owner' ? 'رُفض الدخول من هذا الجهاز'
        : view.note && view.note.reason === 'replaced-by-new-device' ? 'دخل حسابك من جهاز جديد'
          : view.note && view.note.reason === 'timeout' ? 'انتهت مهلة التأكيد — دخل حسابك من جهاز جديد'
            : 'انتهت الجلسة',
      reason: (view.note && view.note.reason) || null,
      note: view.note || null,
    });
  }
  return res.json({
    ok: true,
    state: view.state,
    me: view.me || null,
    challenge: view.challenge || null,
    secondsLeft: view.secondsLeft == null ? null : view.secondsLeft,
    windowSec: Math.round(WINDOW_MS / 1000),
  });
});

// الجواب على سؤال التأكيد — من الجهاز القديم فقط (الجلسة المتحدّاة)
router.post('/challenge', (req, res) => {
  const token = tokenOf(req);
  if (!token) return res.status(401).json({ ok: false, error: 'لا جلسة' });
  const approve = Boolean((req.body || {}).approve);
  const out = answer(store.read(), token, approve);
  if (!out.ok) {
    return res.status(409).json({
      ok: false, state: out.state, approved: false,
      error: out.error || 'انتهت المهلة قبل الجواب', note: out.note || null,
    });
  }
  return res.json({
    ok: true, approved: out.approved,
    state: out.state,
    message: out.approved
      ? 'خرجنا من هذا الجهاز — الجلسة الآن على الجهاز الجديد'
      : 'أُبطل الدخول من الجهاز الجديد — جلستك كما هي',
  });
});

module.exports = {
  router, WINDOW_MS, SESSION_TTL_MS, statusOf, publicOf, statusOfToken, step, stateOf,
  start, answer, end, tokenOf, deviceOf, whereOf, newToken, newId,
};

#!/bin/sh
# مشغّل نشر سوى: يسجّل بيئة التشغيل ثم يشغّل الخادم على المنفذ الذي توفّره المنصة.
LOG=/workspace/sites/sawa-app/qa/runner.log
{
  echo "=== run $(date -u +%FT%TZ) ==="
  echo "cwd=$(pwd)"
  echo "script=$0"
  echo "PORT=$PORT HOST=$HOST PORT_SINGLE=$PORT_SINGLE"
  env | grep -iE 'port|deploy|site|origin|public|sanaa' | sort
} >> "$LOG" 2>&1
cd "$(dirname "$0")" || exit 1
exec node index.js >> "$LOG" 2>&1

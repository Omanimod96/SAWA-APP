// ─────────────────────────────────────────────────────────────────────────────
// v31.js — واجهة الخادم لطبقة الخصوصية الجديدة: /api/v31/*
//
// كل مسار هنا يتطلّب هوية حساب صالحة. لا هوية ⇒ 401. وحين تُتاح الهوية،
// كل قراءة تُرشَّح بها لحظة القراءة (بند ١.٤ و ١.٥) — الواجهة لا تستلم
// ما لا يحق لها استلامه.
//
// قاعدة الكتابة: كل ما يُمرَّر إلى store.mutate يجب أن يُعيد المخزن نفسه
// (return db) — لأن mutate يكتب ما يُعاد إليه. والواجهات تُبنى من المخزن
// العائد بعد الطفرة، لا من داخل الطفرة.
// ─────────────────────────────────────────────────────────────────────────────
const express = require('express');
const store = require('./store');
const auth = require('./auth');
const privacy = require('./privacy');

const router = express.Router();

// ── التحقق من الهوية: إلزامي على كل مسار في هذه الواجهة ────────────────────
router.use((req, res, next) => {
  const account = auth.accountOfToken(auth.tokenOf(req));
  if (!account) {
    return res.status(401).json({ error: 'سجّل الدخول أولًا', code: 'no_session', auth: 'required' });
  }
  req.sawa = { accountId: account.id, account };
  return next();
});

const ok = (res, data) => res.json(data);
const fail = (res, out) => res.status(out.code || 400).json({ error: out.error });

// خنق بسيط في الذاكرة — بلا كتابة أي مفتاح على القرص (بند ٦.٤)
const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const list = (hits.get(key) || []).filter((t) => now - t < windowMs);
  if (list.length >= max) { hits.set(key, list); return true; }
  list.push(now);
  hits.set(key, list);
  return false;
}

// كل طفرة تمرّ من هنا: تُهيّئ المجموعات، تُنظّف الصفّ المؤقت، وتُعيد المخزن
function withDb(fn) {
  return store.mutate((db) => {
    privacy.ensure(db);
    // التنظيف قبل بناء الواجهة: صفٌّ مضى عمره يجب أن يظهر «فشل» في هذا الردّ
    // نفسه، لا في الردّ التالي (شوهد فعلًا: تقرير التسليم تأخّر ردًّا واحدًا).
    privacy.expireOutbox(db, Date.now());
    fn(db);
    return db;
  });
}

// تلميح حضور: وقت آخر ظهور فقط، بلا عنوان شبكة ولا سجلّ فتح (بند ٧.٢)
function touch(db, accountId) {
  const d = (db.devices || []).filter((x) => x.accountId === accountId).sort(
    (a, b) => Date.parse(b.lastSeenAt || 0) - Date.parse(a.lastSeenAt || 0),
  )[0];
  if (d) d.lastSeenAt = new Date().toISOString();
}

// ── لوحة الحساب: دوائره وحدود أثره ─────────────────────────────────────────
router.get('/state', (req, res) => {
  const me = req.sawa.accountId;
  const db = withDb((d) => touch(d, me));
  const view = privacy.whoSees(db, me);
  return ok(res, {
    me: privacy.ownerView(db, me),
    presence: privacy.presenceOf(db, me),
    circles: view.circles,
    reach: view.reach,
    memories: view.memories,
    deleteLimit: view.deleteLimit,
    whisperTtlHours: Math.round(privacy.OUTBOX_TTL_MS / 3600000),
  });
});

// ── الدوائر ────────────────────────────────────────────────────────────────
router.get('/circles', (req, res) => {
  const me = req.sawa.accountId;
  const db = withDb(() => {});
  const view = privacy.whoSees(db, me);
  return ok(res, privacy.pad({ circles: view.circles, blocked: view.blocked, reach: view.reach }));
});

router.post('/circles', (req, res) => {
  const me = req.sawa.accountId;
  let out = null;
  const db = withDb((d) => { out = privacy.createCircle(d, me, req.body); });
  if (!out.ok) return fail(res, out);
  return ok(res, { circle: privacy.circleView(db, privacy.circleById(db, out.circle.id)) });
});

router.post('/circles/:id/members', (req, res) => {
  const me = req.sawa.accountId;
  let out = null;
  const db = withDb((d) => {
    const raw = req.body || {};
    const ids = raw.memberIds || (raw.username ? [raw.username] : []);
    // اسم المستخدم يُقبل كمدخل، لكن ما يُخزَّن معرّف الحساب الدائم (بند ٢.٥)
    const resolved = ids.map((x) => {
      const a = (d.accounts || []).find((y) => y.id === x || y.username === x);
      return a ? a.id : null;
    }).filter(Boolean);
    out = privacy.addMembers(d, me, req.params.id, resolved);
  });
  if (!out.ok) return fail(res, out);
  return ok(res, { added: out.added, circle: privacy.circleView(db, privacy.circleById(db, out.circle.id)) });
});

router.post('/circles/:id/remove', (req, res) => {
  const me = req.sawa.accountId;
  let out = null;
  const db = withDb((d) => {
    const raw = req.body || {};
    const a = (d.accounts || []).find((y) => y.id === raw.accountId || y.username === raw.accountId);
    out = privacy.removeMember(d, me, req.params.id, a ? a.id : raw.accountId);
  });
  if (!out.ok) return fail(res, out);
  return ok(res, { circle: privacy.circleView(db, privacy.circleById(db, out.circle.id)) });
});

router.post('/circles/:id/delete', (req, res) => {
  const me = req.sawa.accountId;
  let out = null;
  withDb((d) => { out = privacy.deleteCircle(d, me, req.params.id); });
  if (!out.ok) return fail(res, out);
  return ok(res, { id: out.id });
});

// ── الحجب (٣.٧): خادمي، ويمنع الأثر في الاتجاهين لحظة القراءة ──────────────
router.post('/blocks', (req, res) => {
  const me = req.sawa.accountId;
  const raw = req.body || {};
  let out = null;
  const db = withDb((d) => {
    const target = (d.accounts || []).find((y) => y.id === raw.accountId || y.username === raw.accountId);
    if (!target || target.id === me) { out = { ok: false, code: 400, error: 'حساب غير صالح' }; return; }
    if (raw.block === false) {
      d.blocks = (d.blocks || []).filter((b) => !(b.ownerId === me && b.blockedId === target.id));
      out = { ok: true, blocked: false };
      return;
    }
    if (!privacy.isBlocked(d, me, target.id)) {
      d.blocks.push({ ownerId: me, blockedId: target.id, at: new Date().toISOString() });
      // الحجب يقطع دوائر الطرفين: لا يبقى له أثرٌ عندي (ولحظة القراءة تحكم لا الحذف)
      privacy.circlesOf(d, me).forEach((c) => {
        const i = c.memberIds.indexOf(target.id);
        if (i >= 0) c.memberIds.splice(i, 1);
      });
    }
    out = { ok: true, blocked: true };
  });
  if (!out.ok) return fail(res, out);
  return ok(res, { blocked: out.blocked, blockedId: (req.body || {}).accountId || null });
});

// ── «من يرى أثري» (٨.٢) ───────────────────────────────────────────────────
router.get('/who-sees', (req, res) => {
  const me = req.sawa.accountId;
  const db = withDb(() => {});
  return ok(res, privacy.pad(privacy.whoSees(db, me)));
});

// ── الأجهزة والحضور (١.٣) ──────────────────────────────────────────────────
router.post('/devices', (req, res) => {
  const me = req.sawa.accountId;
  const raw = req.body || {};
  let out = null;
  const db = withDb((d) => { out = privacy.registerDevice(d, me, raw); });
  if (!out) return fail(res, { code: 400, error: 'معرّف الجهاز مطلوب' });
  return ok(res, { deviceId: out.deviceId, presence: privacy.presenceOf(db, me) });
});

router.post('/presence', (req, res) => {
  const me = req.sawa.accountId;
  const db = withDb((d) => touch(d, me));
  return ok(res, privacy.presenceOf(db, me));
});

// ── الأثر ──────────────────────────────────────────────────────────────────
// الفهرس التقريبي: مربّعات بعدّادات فقط — بلا نصّ، بلا اسم، بلا معرّف (٤.٣)
router.get('/athar/grid', (req, res) => {
  const me = req.sawa.accountId;
  const since = req.query.since;
  const db = withDb(() => {});
  return ok(res, privacy.pad({
    ...privacy.gridOf(db, me),
    purges: privacy.purgesSince(db, since),
    syncedAt: new Date().toISOString(),
  }));
});

// دخل المربّع ⇒ يُطلب السجل الكامل من الخادم، ويُرشَّح بهوية الطالب
router.post('/athar/cell', (req, res) => {
  const me = req.sawa.accountId;
  const raw = req.body || {};
  const db = withDb(() => {});
  return ok(res, privacy.pad({ items: privacy.cellRecords(db, me, raw.gx, raw.gy) }));
});

router.get('/athar/sync', (req, res) => {
  const me = req.sawa.accountId;
  const since = req.query.since;
  const db = withDb(() => {});
  return ok(res, privacy.pad({
    items: privacy.syncSince(db, me, since),
    purges: privacy.purgesSince(db, since),
  }));
});

router.post('/athar', (req, res) => {
  const me = req.sawa.accountId;
  let out = null;
  const db = withDb((d) => { out = privacy.createMemory(d, me, req.body); });
  if (!out.ok) return fail(res, out);
  return ok(res, { memory: privacy.memoryView(db, out.memory, me) });
});

// توابع الحذف: معرّفات فقط، ليُطهّر كل جهاز نسخته (٤.٥)
router.get('/athar/purges', (req, res) => {
  const since = req.query.since;
  const db = withDb(() => {});
  return ok(res, privacy.pad({ purges: privacy.purgesSince(db, since) }));
});

// فتح واحد بمعرّفه: غير المسموح له يرى 404 نفسها التي يراها غير الموجود
router.get('/athar/:id', (req, res) => {
  const me = req.sawa.accountId;
  const db = withDb(() => {});
  const mem = (db.memories || []).find((m) => m.id === req.params.id);
  if (!mem || !privacy.canRead(db, mem, me)) return res.status(404).json({ error: 'الأثر غير موجود' });
  return ok(res, { memory: privacy.memoryView(db, mem, me) });
});

router.post('/athar/:id/visit', (req, res) => {
  const me = req.sawa.accountId;
  let out = { ok: false };
  withDb((d) => {
    const mem = (d.memories || []).find((m) => m.id === req.params.id);
    if (!mem || !privacy.canRead(d, mem, me)) return;
    out = { ok: true, visits: privacy.visitAggregate(d, mem.id) };
  });
  // زيارة الفتح ليست حدثًا يُسجَّل: عدّاد مجمّع فقط، بلا زائر وبلا وقت (٤.٦ و ٧.٢)
  if (!out.ok) return res.status(404).json({ error: 'الأثر غير موجود' });
  return ok(res, { visits: out.visits });
});

router.post('/athar/:id/delete', (req, res) => {
  const me = req.sawa.accountId;
  let out = null;
  withDb((d) => { out = privacy.deleteMemory(d, req.params.id, me); });
  if (!out.ok) return fail(res, out);
  // الحذف يخفي الأثر عن غيره أيضًا: الفلترة لحظة القراءة، والصفّ نفسه صار معدومًا
  return ok(res, { id: out.id, limit: 'سُحب الأثر من الخادم. نسخة ظهرت سابقًا على جهاز غير متصل لا يمكن سحبها.' });
});

// ── اكتشاف جهات الاتصال (٢.٢ – ٢.٥) ────────────────────────────────────────
// مفتاح البصمات يُسلَّم للحساب المسجَّل وحده، بمعدّل محدود، ولا يُسجَّل في أي ملف.
// بهذا لا يقوم هجوم قاموس عكسي على الخادم لمجرّد تسريب ملف المخزن.
router.get('/contacts/key', (req, res) => {
  if (limited('k:' + req.sawa.accountId, 6, 3600000)) {
    return res.status(429).json({ error: 'طلبات كثيرة — أعد المحاولة بعد قليل', code: 'rate' });
  }
  const k = privacy.keys();
  return ok(res, {
    key: k.cur,
    keyId: privacy.keyId(k.cur),
    maxFingerprints: privacy.MAX_FINGERPRINTS,
    // بند ٢.٦: ما يمنحه هذا الإذن وما لا يمنحه — النصّ يخدم الواجهة كما هو
    scope: 'بصمات للبحث وحده: لا تفتح أثرًا ولا حالة، ولا تُخزَّن.',
  });
});

router.post('/contacts/match', (req, res) => {
  const me = req.sawa.accountId;
  if (limited('m:' + me, 30, 3600000)) {
    return res.status(429).json({ error: 'طلبات كثيرة — أعد المحاولة بعد قليل', code: 'rate' });
  }
  let out = null;
  const db = withDb((d) => { out = privacy.matchFingerprints(d, me, (req.body || {}).fingerprints); });
  // لا أسماء لمن لم يكتمل الإفصاح المتبادل: العدد فقط (بند ٢.٤)
  return ok(res, privacy.pad({ mutual: privacy.matchesFor(db, me), waiting: out.waiting }));
});

router.get('/contacts/matches', (req, res) => {
  const me = req.sawa.accountId;
  const db = withDb(() => {});
  return ok(res, privacy.pad({ mutual: privacy.matchesFor(db, me) }));
});

// ── الهمسة: التوصيل، والصفّ المؤقت، وفشل التسليم (٥.٢، ٥.٣) ───────────────
router.post('/whisper/send', (req, res) => {
  const me = req.sawa.accountId;
  const raw = req.body || {};
  let out = null;
  withDb((d) => {
    const to = (d.accounts || []).find((a) => a.id === raw.to || a.username === raw.to);
    out = privacy.enqueue(d, me, to ? to.id : raw.to, raw);
  });
  if (!out.ok) return fail(res, out);
  return ok(res, { id: out.id, expiresAt: out.expiresAt });
});

router.get('/whisper/inbox', (req, res) => {
  const me = req.sawa.accountId;
  let items = [];
  let status = [];
  const db = withDb((d) => {
    touch(d, me);
    items = privacy.deliver(d, me);
    status = privacy.outboxStatus(d, me);
  });
  if (!db) return res.status(500).json({ error: 'تعذّر قراءة الصفّ' });
  return ok(res, privacy.pad({ items, status }));
});

router.get('/whisper/status', (req, res) => {
  const me = req.sawa.accountId;
  let status = [];
  withDb((d) => { status = privacy.outboxStatus(d, me); });
  return ok(res, privacy.pad({ status }));
});

router.post('/whisper/ack', (req, res) => {
  const me = req.sawa.accountId;
  let acked = 0;
  withDb((d) => { acked = privacy.ackOutbox(d, me, (req.body || {}).ids); });
  return ok(res, { acked });
});

module.exports = { router };

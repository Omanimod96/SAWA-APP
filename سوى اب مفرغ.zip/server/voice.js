// ─────────────────────────────────────────────────────────────────────────────
// voice.js — التسجيلات الصوتية كملفات على القرص، بروابط موقّعة ومحصورة.
//
// القواعد التي تحكم هذا الملف:
//  ١) لا صوت داخل قاعدة البيانات: الملف على القرص، والمخزن يحمل فهرسًا فقط
//     (الاسم، المالك، المدة، النوع) — بلا مسار مطلق وبلا أي محتوى.
//  ٢) لا وصول مباشر إلى تسجيل غيره: الرابط يحمل توقيعًا (HMAC) بصلاحية محدودة،
//     ولا يُسلَّم التوقيع إلا لمن يملك جلسة صالحة **وهو طرف في المحادثة**.
//  ٣) التشغيل من المتصفح يحتاج نطاقات (Range) — على iOS لا صوت بلا دعمها.
// ─────────────────────────────────────────────────────────────────────────────
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const privacy = require('./privacy');

// الأنواع المقبولة للتسجيل — مرتّبة بحسب أولوية المتصفح (Safari ينتج mp4)
const VOICE_MIME = {
  'audio/webm': 'webm',
  'audio/ogg': 'ogg',
  'audio/mp4': 'm4a',
  'audio/mpeg': 'mp3',
  'audio/wav': 'wav',
  'audio/x-wav': 'wav',
};
const MAX_MB = Number(process.env.SAWA_VOICE_MAX_MB || 8);
const MAX_SECONDS = Number(process.env.SAWA_VOICE_MAX_SEC || 300);
const LINK_TTL_MS = 12 * 3600 * 1000; // صلاحية الرابط الموقّع

const secret = () => {
  try {
    const k = privacy.keys();
    if (k && k.cur) return k.cur;
  } catch (e) { /* اعتُمد على احتياطي العملية */ }
  return 'sawa-voice-fallback';
};

const sign = (file, exp) => crypto.createHmac('sha256', secret()).update(`${file}|${exp}`).digest('base64url').slice(0, 32);

function signedUrl(file, nowMs) {
  const exp = (nowMs || Date.now()) + LINK_TTL_MS;
  return `api/voice/${file}?k=${sign(file, exp)}&e=${exp}`;
}

function checkLink(file, key, exp) {
  const e = Number(exp);
  if (!file || !key || !Number.isFinite(e)) return { ok: false, code: 403 };
  if (e < Date.now()) return { ok: false, code: 410 };
  const want = sign(file, e);
  const a = Buffer.from(String(key));
  const b = Buffer.from(want);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return { ok: false, code: 403 };
  return { ok: true };
}

// الفهرس في المخزن: {file, ownerId, durationMs, mime, size, at}
function indexOf(db) {
  if (!Array.isArray(db.voiceIndex)) db.voiceIndex = [];
  return db.voiceIndex;
}

function ownerOf(db, file) {
  const row = indexOf(db).find((r) => r.file === file);
  return row || null;
}

// تسجيل ملف جديد: يتحقّق من النوع والحجم وينظّف الاسم تمامًا (لا مسار من العميل)
function save(db, accountId, payload) {
  const raw = String((payload && payload.dataUrl) || '');
  const m = /^data:([^;,]+);base64,([\s\S]+)$/.exec(raw);
  if (!m) return { ok: false, code: 400, error: 'ملف التسجيل غير صالح' };
  const mime = m[1].toLowerCase().trim();
  const ext = VOICE_MIME[mime];
  if (!ext) return { ok: false, code: 415, error: 'صيغة تسجيل غير مدعومة' };
  const buf = Buffer.from(m[2], 'base64');
  if (!buf.length) return { ok: false, code: 400, error: 'التسجيل فارغ' };
  if (buf.length > MAX_MB * 1024 * 1024) return { ok: false, code: 413, error: `التسجيل أطول من ${MAX_MB} ميجابايت` };
  let seconds = Number((payload && payload.seconds) || 0);
  if (!Number.isFinite(seconds) || seconds < 0) seconds = 0;
  if (seconds > MAX_SECONDS) return { ok: false, code: 413, error: `مدة التسجيل أكبر من ${MAX_SECONDS} ثانية` };
  const file = `v${crypto.randomBytes(9).toString('hex')}.${ext}`;
  const dir = payload && payload.dir;
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, file), buf);
  indexOf(db).push({
    file,
    ownerId: accountId,
    mime,
    size: buf.length,
    durationMs: Math.round(seconds * 1000),
    at: new Date().toISOString(),
  });
  // لا نُبقي الفهرس ينمو بلا حدّ: آخر ٥٠٠ تسجيل يكفي، والأقدم تبقى ملفاته
  if (db.voiceIndex.length > 500) db.voiceIndex.splice(0, db.voiceIndex.length - 500);
  return { ok: true, file, mime, size: buf.length, durationMs: Math.round(seconds * 1000), url: signedUrl(file) };
}

// حذف ملف (يُستدعى عند إلغاء التسجيل قبل الإرسال، أو عند حذف الرسالة)
function remove(db, accountId, file) {
  const row = ownerOf(db, file);
  if (!row || row.ownerId !== accountId) return { ok: false, code: 403 };
  db.voiceIndex = indexOf(db).filter((r) => r.file !== file);
  return { ok: true, file };
}

const prune = (db) => { if (Array.isArray(db.voiceIndex)) db.voiceIndex = db.voiceIndex.slice(-500); };

// تهيئة أولية على المخزن (تُستدعى مع ترحيل v31)
function ensure(db) { indexOf(db); }

module.exports = { VOICE_MIME, MAX_MB, MAX_SECONDS, LINK_TTL_MS, signedUrl, sign, checkLink, save, remove, ensure, ownerOf, indexOf, prune };

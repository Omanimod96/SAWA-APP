const fs = require('fs');
const path = require('path');
const geo = require('./geo');

// جذر البيانات: قابل للتجاوز بمتغيّر البيئة ليعمل الفحص على نسخة معزولة بلا مساس ببيانات المستخدم
const DATA_DIR = process.env.SAWA_DATA_DIR
  ? path.resolve(process.env.SAWA_DATA_DIR)
  : path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

const clone = (v) => JSON.parse(JSON.stringify(v));

// ملف شخصي فارغ: التطبيق يبدأ بلا هوية جاهزة. الاسم والمدينة والرقم تُملأ من
// الحساب لحظة التسجيل بالهاتف (auth.applyToMe) — لا شخصية تجريبية محفوظة مسبقًا.
function blankMe() {
  return {
    id: 'u-me',
    name: '',
    handle: '@',
    city: '',
    avatarColor: '#1D4ED8',
    trust: 'دائرة قريبة',
    privacy: { states: 'circle', location: 'hourly', whispers: 'circle' },
    prefs: { theme: 'light', notifyQuiet: false },
    circles: ['دائرة قريبة', 'العائلة', 'الزملاء', 'الجيران'],
    phone: '',
    phoneMasked: '',
    username: '',
    avatar: '',
  };
}

function ensure() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  // ملف موجود لكنه فارغ أو غير قابل للتفسير (كتابة قُطعت / قرص ممتلئ):
  // نُبقيه نسخة احتياطية ثم نُعيد التهيئة بدل أن يظل الخادم بلا مخزن صالح
  if (fs.existsSync(DB_FILE)) {
    let bad = false;
    try {
      const parsed = JSON.parse(fs.readFileSync(DB_FILE, 'utf8').trim() || 'null');
      bad = !parsed || typeof parsed !== 'object';
    } catch (e) { bad = true; }
    if (!bad) return;
    const stamp = DB_FILE.replace(/\.json$/, '') + '.broken-' + Date.now() + '.json';
    try { fs.renameSync(DB_FILE, stamp); } catch (e) {
      try { fs.unlinkSync(DB_FILE); } catch (e2) { /* تجاهل */ }
    }
    console.error('[smart-social] db.json غير قابل للاستخدام — نُسخ إلى ' + stamp);
  }
  // مخزن جديد = عالم فارغ: لا أشخاص، ولا حالات، ولا آثار، ولا محادثات.
  // كل ما يظهر بعد ذلك ينشئه المستخدم الحقيقي (أو من يضيفه من دائرته).
  const db = {
    me: blankMe(),
    people: [],
    states: [],
    rooms: [],
    meetings: [],
    chats: [],
    whispers: [],
    notifications: [],
    athar: [],
    accounts: [],
    sessions: [],
    sessionGraves: [],
    auth: { createdAt: new Date().toISOString() },
    createdAt: new Date().toISOString(),
  };
  // كتابة ذرّية: ملف مؤقت ثم إعادة تسمية — لا يبقى db.json نصف مكتوب إن توقف الخادم
  const tmp = DB_FILE + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(tmp, DB_FILE);
  cache = null;
  cacheStamp = 0;
  return db;
}

// ترحيل المخزن: يضيف المجموعات الجديدة دون المساس ببيانات المستخدم
function migrate(db) {
  let changed = false;
  // مجموعات أساسية موجودة دائمًا (فارغة إن لم يستخدمها أحد) — لا بذرة تُحقن هنا أبدًا.
  ['people', 'states', 'rooms', 'meetings', 'chats', 'whispers', 'notifications', 'athar']
    .forEach((key) => {
      if (!Array.isArray(db[key])) { db[key] = []; changed = true; }
    });
  if (!db.me) { db.me = blankMe(); changed = true; }
  // تنظيف مخلفات البذر: مفاتيح تتبّع كانت تمنع عودة أثر حذفه المستخدم، وحقول
  // «أُضيف مرة واحدة». لم يبق لها معنى بعد أن صار المخزن يبدأ فارغًا.
  ['seedAtharIds', 'seedMediaAdded', 'seedPrivateAdded', 'seedRoomsAdded'].forEach((k) => {
    if (db[k] !== undefined) { delete db[k]; changed = true; }
  });
  // حسابات الدخول بالهاتف وجلساتها — تُضاف دون المساس بأي بيانات قائمة
  if (!Array.isArray(db.accounts)) { db.accounts = []; changed = true; }
  if (!Array.isArray(db.sessions)) { db.sessions = []; changed = true; }
  // أثر الجلسات المُبطَلة (بسبب جلسة واحدة نشطة): يُحفظ أسبوعًا لنُبلّغ الجهاز القديم
  // بالسبب، ثم يُنظَّف — وبهذا لا ينمو المخزن بلا حدّ.
  if (!Array.isArray(db.sessionGraves)) { db.sessionGraves = []; changed = true; }
  {
    const now = Date.now();
    const kept = db.sessionGraves.filter((g) => g && g.token && now - Date.parse(g.at || 0) < 7 * 24 * 3600 * 1000);
    if (kept.length !== db.sessionGraves.length) { db.sessionGraves = kept.slice(-200); changed = true; }
  }
  if (!db.auth || typeof db.auth !== 'object') { db.auth = { createdAt: new Date().toISOString() }; changed = true; }
  // الهمسات: ضمان الحقول المطلوبة لكل محادثة همسة قائمة (لا نمسّ أي رسالة)
  if (Array.isArray(db.whispers)) {
    db.whispers.forEach((w) => {
      if (!w || typeof w !== 'object') return;
      if (!w.direction) { w.direction = 'in'; changed = true; }
      if (!Array.isArray(w.messages)) { w.messages = []; changed = true; }
      if (w.revealed === undefined) { w.revealed = false; changed = true; }
      if (w.revealAsked === undefined) { w.revealAsked = false; changed = true; }
      if (!w.revealState) { w.revealState = 'idle'; changed = true; }
      if (w.revealOnAsk === undefined) { w.revealOnAsk = true; changed = true; }
      if (w.peerAsked === undefined) { w.peerAsked = false; changed = true; }
      if (w.reaction === undefined) { w.reaction = null; changed = true; }
      if (w.unread === undefined) { w.unread = 0; changed = true; }
      if (!w.createdAt) { w.createdAt = new Date().toISOString(); changed = true; }
    });
  }
  // حالة صفّ الحساب: نُنقّي الجلسات المنتهية عند كل ترحيل بدل أن تتراكم
  {
    const now = Date.now();
    const alive = db.sessions.filter((s) => s && s.token && !(s.expiresAt && Date.parse(s.expiresAt) < now));
    if (alive.length !== db.sessions.length) { db.sessions = alive; changed = true; }
    // جلسة واحدة لكل حساب: أي تكرار قديم في المخزن يُقلَّص إلى الأحدث (ترحيل لمرة واحدة)
    const newest = new Map();
    db.sessions.forEach((s) => {
      const prev = newest.get(s.accountId);
      if (!prev || Date.parse(s.createdAt || 0) > Date.parse(prev.createdAt || 0)) newest.set(s.accountId, s);
    });
    if (newest.size !== db.sessions.length) { db.sessions = [...newest.values()]; changed = true; }
  }
  // رقم هاتف مسجَّل في الملف الشخصي للعرض في «ملفي»
  if (db.me && db.me.phone === undefined) { db.me.phone = ''; changed = true; }
  // اسم المستخدم وصورة العرض في «ملفي» (يُملأان عند إنشاء الحساب، وقد يبقى القديم بلا اسم)
  if (db.me && db.me.username === undefined) { db.me.username = ''; changed = true; }
  if (db.me && db.me.avatar === undefined) { db.me.avatar = ''; changed = true; }
  if (db.me && db.me.username && db.me.handle !== '@' + db.me.username) {
    db.me.handle = '@' + db.me.username; changed = true;
  }
  // حسابات سابقة بلا اسم مستخدم (أنشئت قبل إضافة الخيار): نمنح كل حساب اسمًا فريدًا
  // مشتقًّا من اسمه أو رقمه، حتى يبقى الجميع قابلاً للمراسلة بالاسم المستخدم.
  if (Array.isArray(db.accounts)) {
    const used = new Set(db.accounts.map((a) => a && a.username).filter(Boolean));
    db.accounts.forEach((a) => {
      if (!a || a.username) return;
      const base = String(a.handle || '').replace(/^@/, '').replace(/[^a-z0-9_]/gi, '').toLowerCase();
      let cand = /^[a-z][a-z0-9_]{2,19}$/.test(base) ? base : `sawa${String(a.phone || '').slice(-4)}`;
      if (!/^[a-z][a-z0-9_]{2,19}$/.test(cand)) cand = `sawa${String(a.phone || '').slice(-4)}`;
      let n = 1;
      while (used.has(cand)) cand = `${cand.slice(0, 17)}${n++}`;
      a.username = cand;
      a.handle = '@' + cand;
      used.add(cand);
      changed = true;
    });
  }
  // اسم مستخدم «أنا»: يتبع حسابي إن وُجد، وإلا نأخذه من handle القديم حتى لا يبقى
  // ملفي بلا عنوان يمكن للناس أن يجدوني به.
  if (db.me) {
    const mine = (db.accounts || []).find((a) => a && a.phone && a.phone === db.me.phone) || null;
    const base = String(db.me.handle || '').replace(/^@/, '').toLowerCase();
    if (mine && mine.username && db.me.username !== mine.username) {
      db.me.username = mine.username;
      db.me.handle = '@' + mine.username;
      changed = true;
    } else if (!db.me.username && /^[a-z][a-z0-9_]{2,19}$/.test(base) &&
               !(db.accounts || []).some((a) => a && a.username === base)) {
      db.me.username = base;
      db.me.handle = '@' + base;
      changed = true;
    }
  }
  // صورة عرض الأشخاص: الحقل موجود دائمًا (فارغ = الأحرف الأولى بلون الشخص)
  if (Array.isArray(db.people)) {
    db.people.forEach((p) => {
      if (p && p.avatar === undefined) { p.avatar = ''; changed = true; }
      if (p && p.username === undefined) { p.username = ''; changed = true; }
    });
  }
  db.chats.forEach((c) => {
    if (!Array.isArray(c.messages)) { c.messages = []; changed = true; }
    if (typeof c.unread !== 'number') { c.unread = 0; changed = true; }
  });
  (db.states || []).forEach((s) => {
    if (typeof s.seen !== 'boolean') { s.seen = false; changed = true; }
    if (s.media === undefined) { s.media = null; changed = true; }
    if (!s.seconds) { s.seconds = s.media ? (s.media.type === 'image' ? 7 : 15) : 6; changed = true; }
    // كل حالة لها جمهور — الافتراضي: كل الدائرة
    if (!s.audience || !AUD_SCOPES.includes(s.audience.scope)) {
      s.audience = { scope: 'circle', groups: [], people: [] };
      changed = true;
    }
  });
  // الاجتماعات: نوع الموعد (تصويت / موعد بتذكير) + جدول التذكير
  (db.meetings || []).forEach((m) => {
    if (!m.kind) { m.kind = 'vote'; changed = true; }
    if (!Array.isArray(m.reminders) || !m.reminders.length) { m.reminders = REMIND_DEFAULT.slice(); changed = true; }
    if (!Array.isArray(m.sentReminders)) { m.sentReminders = []; changed = true; }
    if (!Array.isArray(m.skippedReminders)) {
      // تذكير «مضى وقته» = مسجّل كأنه أُرسل ولم يصله إشعار فعلًا
      const t0 = meetingAt(m);
      const list = remindersOf(m);
      const last = list[list.length - 1];
      const mins = t0 === null ? null : (t0 - Date.now()) / 60000;
      const notified = new Set(
        (db.notifications || [])
          .filter((n) => n.kind === 'reminder' && n.meta && n.meta.meetingId === m.id)
          .map((n) => n.meta.minutes),
      );
      m.skippedReminders = mins === null ? []
        : m.sentReminders.filter((b) => mins <= b && b !== last && !notified.has(b));
      m.sentReminders = m.sentReminders.filter((b) => !m.skippedReminders.includes(b));
      changed = true;
    }
    if (!m.at && m.confirmed && m.confirmed.at) { m.at = m.confirmed.at; changed = true; }
    if (!m.place) { m.place = meetingPlace(m); changed = true; }
    if (!Array.isArray(m.slots)) { m.slots = []; changed = true; }
    const label = remindersOf(m).map(remindLabel).join(' و ');
    if (m.reminder !== label) { m.reminder = label; changed = true; }
  });
  // الغرف: مالك الغرفة + الدردشة الجماعية داخلها
  (db.rooms || []).forEach((r) => {
    if (!r.owner) {
      const st = (db.states || []).find((s) => s.id === r.stateId);
      r.owner = (st && st.author) || (r.members && r.members[0]) || 'u-me';
      changed = true;
    }
    if (!Array.isArray(r.messages)) { r.messages = []; changed = true; }
    if (typeof r.unread !== 'number') { r.unread = 0; changed = true; }
  });
  // ── أثر: ذكريات مثبّتة على المكان ──
  // كل أثر يحمل إحداثيات صحيحة وجمهورًا واضحًا؛ أي أثر بلا موقع سليم يُستبعد من الخريطة.
  (db.athar || []).forEach((a) => {
    if (!a.place || typeof a.place !== 'object') { a.place = { name: 'مكان بلا اسم', lat: null, lng: null }; changed = true; }
    const point = geo.validPoint(a.place.lat, a.place.lng);
    if (!point) { a.broken = true; changed = true; }
    else if (a.broken) { delete a.broken; changed = true; }
    if (!a.audience || !AUD_SCOPES.includes(a.audience.scope)) {
      a.audience = { scope: 'circle', groups: [], people: [] };
      changed = true;
    }
    if (typeof a.visits !== 'number') { a.visits = 0; changed = true; }
    if (a.media === undefined) { a.media = null; changed = true; }
    if (!a.createdAt) { a.createdAt = new Date().toISOString(); changed = true; }
  });
  if (changed) write(db);
  return db;
}

// نوم متزامن قصير (لا يحتاج async)
function sleepSync(ms) {
  try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); } catch (e) { /* ignore */ }
}

// ذاكرة مؤقتة داخل العملية: تُقلّل قراءة الملف وتُغلق نافذة التنازع
let cache = null;
let cacheStamp = 0;

function read() {
  ensure();
  let stamp = 0;
  try { stamp = fs.statSync(DB_FILE).mtimeMs; } catch (e) { stamp = 0; }
  if (cache && stamp && stamp === cacheStamp) return migrate(cache);

  // ثلاث محاولات: قد يقرأ الطلب الملف في لحظة كتابة (ملف جزئي مؤقتًا)
  let lastErr = null;
  for (let i = 0; i < 3; i += 1) {
    try {
      const parsed = migrate(JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
      cache = parsed;
      try { cacheStamp = fs.statSync(DB_FILE).mtimeMs; } catch (e) { cacheStamp = 0; }
      return parsed;
    } catch (e) {
      lastErr = e;
      sleepSync(60);
    }
  }

  // فشل حقيقي: نُبقي نسخة من الملف التالف بدل حذفه، ثم نُعيد التهيئة
  try {
    const broken = DB_FILE.replace(/\.json$/, '') + '.broken-' + Date.now() + '.json';
    fs.copyFileSync(DB_FILE, broken);
    console.error('[smart-social] db.json غير قابل للقراءة — نُسخ إلى ' + broken + ':', lastErr && lastErr.message);
  } catch (e) { /* ignore */ }
  try { fs.unlinkSync(DB_FILE); } catch (e) { /* ignore */ }
  ensure();
  cache = null; cacheStamp = 0;
  const fresh = migrate(JSON.parse(fs.readFileSync(DB_FILE, 'utf8')));
  cache = fresh;
  try { cacheStamp = fs.statSync(DB_FILE).mtimeMs; } catch (e) { cacheStamp = 0; }
  return fresh;
}

function write(db) {
  // كتابة ذرّية: ملف مؤقت ثم إعادة تسمية — لا يُقرأ الملف نصف مكتوب أبدًا
  const tmp = DB_FILE + '.tmp-' + process.pid;
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
  fs.renameSync(tmp, DB_FILE);
  cache = db;
  try { cacheStamp = fs.statSync(DB_FILE).mtimeMs; } catch (e) { cacheStamp = 0; }
  return db;
}

function mutate(fn) {
  const db = read();
  const out = fn(db) || db;
  return write(out);
}

const id = (p) => p + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);

// ── خصوصية الحالة: من يراها؟ ──
// scope: circle = كل دائرتي | groups = دوائر محددة | people = أشخاص محدّدون
const AUD_SCOPES = ['circle', 'groups', 'people'];

// جمهور أي عنصر جديد: دائرتي كاملة إن لم يحدّد المستخدم غيرها.

function normalizeAudience(me, people, raw) {
  const scope = raw && AUD_SCOPES.includes(raw.scope) ? raw.scope : 'circle';
  const known = new Set((me && me.circles) || []);
  const ids = new Set((people || []).map((p) => p.id));
  const groups = ((raw && raw.groups) || []).filter((g) => known.has(g));
  const picks = ((raw && raw.people) || []).filter((pid) => ids.has(pid));
  if (scope === 'groups') return groups.length ? { scope, groups, people: [] } : { scope: 'circle', groups: [], people: [] };
  if (scope === 'people') return picks.length ? { scope, groups: [], people: picks } : { scope: 'circle', groups: [], people: [] };
  return { scope: 'circle', groups: [], people: [] };
}

function audienceView(raw, me, people) {
  const a = normalizeAudience(me, people, raw);
  if (a.scope === 'groups') {
    return { ...a, label: a.groups.join(' و '), count: (people || []).filter((p) => a.groups.includes(p.relation)).length };
  }
  if (a.scope === 'people') {
    const names = a.people
      .map((pid) => (((people || []).find((p) => p.id === pid) || {}).name || '').split(' ')[0])
      .filter(Boolean);
    return { ...a, label: names.length > 2 ? `${names[0]}، ${names[1]} وآخرون` : names.join('، '), count: a.people.length };
  }
  return { ...a, label: 'كل دائرتك', count: (people || []).length };
}

// هل تظهر هذه الحالة لي؟ حالاتي كلها ظاهرة، وحالات غيري تُفلتر حسب جمهورها
function canSee(state, me, people) {
  if (!state || state.author === 'u-me') return true;
  const a = normalizeAudience(me, people, state.audience);
  if (a.scope === 'circle') return true;
  if (a.scope === 'people') return a.people.includes('u-me');
  const author = (people || []).find((p) => p.id === state.author);
  return Boolean(author && a.groups.includes(author.relation));
}

// ── «من كان معك»: رفاق الذكرى — أثر يربط المكان بالشخص لا بالناشر وحده ──
const COMPANIONS_MAX = 8;
function cleanCompanions(people, raw) {
  const ids = new Set((people || []).map((p) => p.id));
  const list = Array.isArray(raw) ? raw : [];
  const out = [];
  for (const x of list) {
    const id = String(x);
    if (ids.has(id) && !out.includes(id)) out.push(id);
    if (out.length >= COMPANIONS_MAX) break;
  }
  return out;
}

// ── «متى كانت الذكرى»: تاريخ في الماضي أو اليوم. المستقبل مرفوض — الأثر توثيق لا موعد ──
function memoryWhen(raw) {
  if (raw === undefined || raw === null || String(raw).trim() === '') return { ok: true, iso: null };
  const s = String(raw).trim();
  if (!/^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?)?$/.test(s)) {
    return { ok: false, reason: 'صيغة تاريخ الذكرى غير مفهومة' };
  }
  const t = Date.parse(s);
  if (Number.isNaN(t)) return { ok: false, reason: 'صيغة تاريخ الذكرى غير مفهومة' };
  if (t > Date.now() + 24 * 3600 * 1000) return { ok: false, reason: 'لا يمكن توثيق ذكرى في المستقبل' };
  return { ok: true, iso: new Date(t).toISOString() };
}

// تسمية تاريخ الذكرى: اليوم/أمس كما نقولها، وما قبلهما تاريخ صريح.
// «قبل ٣ سنوات» تصف العمر ولا تُخبر متى كانت الذكرى — والذكرى تُعرف بيومها.
// والأرقام لاتينية كما في بقية التسميات (ageLabel)، فلا تختلف الأرقام بين الشاشات.
function memoryWhenLabel(iso, now) {
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return '';
  const day = (x) => new Date(x).toISOString().slice(0, 10);
  const ref = now || Date.now();
  if (day(t) === day(ref)) return 'اليوم';
  if (day(t) === day(ref - 86400000)) return 'أمس';
  return new Intl.DateTimeFormat('ar', {
    day: 'numeric', month: 'long', year: 'numeric', numberingSystem: 'latn', timeZone: 'UTC',
  }).format(new Date(t));
}

// ── دائرة الأثر: من يرى أثر من؟ (نفس منطق الحالات) ──
// أثر بلا موقع سليم لا يظهر على الخريطة أبدًا.
function canSeeAthar(item, me, people) {
  if (!item || item.broken) return false;
  if (!geo.validPoint(item.place && item.place.lat, item.place && item.place.lng)) return false;
  return canSee({ author: item.author, audience: item.audience }, me, people);
}

// أثر جاهز للعرض: اسم صاحب الأثر ولونه + وصف الزمن والمسافة
function atharView(item, db, now) {
  const t = now || Date.now();
  const author = item.author === 'u-me'
    ? { id: 'u-me', name: (db.me && db.me.name) || 'أنت', color: (db.me && db.me.avatarColor) || '#1D4ED8', avatar: (db.me && db.me.avatar) || '', relation: 'أنت' }
    : ((db.people || []).find((p) => p.id === item.author) || { id: item.author, name: 'من دائرتك', color: '#64748B', relation: '' });
  return {
    ...item,
    mine: item.author === 'u-me',
    authorName: author.name,
    authorColor: author.color,
    authorAvatar: author.avatar || '',
    authorRelation: author.relation,
    ageLabel: geo.ageLabel(item.createdAt, t),
    // الرفاق: من كان معك في الذكرى — بالاسم واللون كما في الدائرة
    companionView: (item.companions || []).map((pid) => {
      const p = (db.people || []).find((x) => x.id === pid);
      return p ? { id: p.id, name: p.name, color: p.color, avatar: p.avatar || '' } : null;
    }).filter(Boolean),
    companionNames: (item.companions || [])
      .map((pid) => (((db.people || []).find((x) => x.id === pid) || {}).name || '').split(' ')[0])
      .filter(Boolean),
    whenAt: item.when || null,
    whenLabel: item.when ? memoryWhenLabel(item.when, t) : null,
    audienceView: audienceView(item.audience, db.me, db.people),
  };
}

function visibleAthar(db, now) {
  const t = now || Date.now();
  return (db.athar || [])
    .filter((a) => canSeeAthar(a, db.me, db.people))
    .map((a) => atharView(a, db, t));
}

function notify(db, text, kind, meta) {
  db.notifications.unshift({
    id: id('n'), text, at: new Date().toISOString(), read: false,
    kind: kind || 'info', meta: meta || null,
  });
  db.notifications = db.notifications.slice(0, 40);
}

// ── تذكيرات المواعيد: قبل يوم وقبل ساعة (قابل للتوسيع) ──
const REMIND_DEFAULT = [1440, 60];
const REMIND_LABEL = {
  2880: 'قبل يومين', 1440: 'قبل يوم', 720: 'قبل 12 ساعة', 120: 'قبل ساعتين',
  60: 'قبل ساعة', 30: 'قبل نصف ساعة', 15: 'قبل ربع ساعة',
};
const remindLabel = (m) => REMIND_LABEL[m] || `قبل ${m} دقيقة`;

function remindersOf(m) {
  const raw = m && Array.isArray(m.reminders) && m.reminders.length ? m.reminders : REMIND_DEFAULT;
  return [...new Set(raw.map(Number).filter((n) => n > 0))].sort((a, b) => b - a);
}

// موعد الاجتماع: إمّا موعد مثبّت مباشرة أو الموعد المحسوم بالتصويت
function meetingAt(m) {
  const raw = (m && m.at) || (m && m.confirmed && m.confirmed.at) || null;
  const t = raw ? Date.parse(raw) : NaN;
  return Number.isNaN(t) ? null : t;
}
function meetingPlace(m) {
  return (m && (m.place || (m.confirmed && m.confirmed.place))) || (m && m.places && m.places[0]) || null;
}
// نطاقات التذكير: كل تذكير يغطي الفترة بينه وبين التذكير الذي يليه
function reminderBands(m) {
  const list = remindersOf(m);
  return list.map((minutes, i) => ({
    minutes, label: remindLabel(minutes),
    lower: i + 1 < list.length ? list[i + 1] : 0,
  }));
}
// عند الجدولة: التذكيرات التي مضى وقتها (الموعد أقرب من أن يبقى لها وقت) تُسجّل «مضى وقته»،
// ويبقى التذكير الأقرب فقط ليُرسل في حينه. التذكيرات المُرسلة فعلًا لا تُمسّ.
function primeReminders(m, now) {
  const t0 = meetingAt(m);
  const t = now || Date.now();
  const list = remindersOf(m);
  const last = list[list.length - 1];
  const sent = Array.isArray(m.sentReminders) ? m.sentReminders : [];
  if (!t0) { m.sentReminders = sent; m.skippedReminders = []; return m.skippedReminders; }
  const mins = (t0 - t) / 60000;
  m.skippedReminders = list.filter((b) => mins <= b && b !== last && !sent.includes(b));
  m.sentReminders = sent;
  return m.skippedReminders;
}

// المغلق تلقائيًا: تُقفل الغرفة بعد انتهاء وقتها وتُحوّل إلى «أثر»
function tick(db) {
  let changed = false;
  const t = Date.now();

  // تذكيرات المواعيد: قبل يوم وقبل ساعة (يُرسل كل تذكير مرة واحدة)
  (db.meetings || []).forEach((m) => {
    if (m.status === 'voting') return;
    const t0 = meetingAt(m);
    if (!t0) return;
    const mins = (t0 - t) / 60000;
    if (mins < 0) return; // فات الموعد
    if (!Array.isArray(m.sentReminders)) { m.sentReminders = []; changed = true; }
    if (!Array.isArray(m.skippedReminders)) { m.skippedReminders = []; changed = true; }
    reminderBands(m).forEach((b) => {
      const skipped = m.skippedReminders.includes(b.minutes);
      if (!skipped && mins <= b.minutes && mins > b.lower && !m.sentReminders.includes(b.minutes)) {
        m.sentReminders.push(b.minutes);
        notify(db, `تذكير ${b.label}: «${m.title}»`, 'reminder', {
          meetingId: m.id, at: new Date(t0).toISOString(), place: meetingPlace(m),
          minutes: b.minutes, label: b.label,
        });
        changed = true;
      }
    });
  });
  // ── الهمسات: محادثة حيّة — صاحبها يردّ، ويجيب على «من صاحب الهمسة؟» ──
  (db.whispers || []).forEach((w) => {
    if (!w || w.closed || !Array.isArray(w.messages) || !w.messages.length) return;
    const last = w.messages[w.messages.length - 1];
    const age = t - Date.parse(last.at || 0);
    if (!Number.isFinite(age) || age < WHISPER_WAIT_MS) return;
    const peer = (db.people || []).find((p) => p.id === w.peerId) || null;
    const name = peer ? peer.name : 'أحد أفراد دائرتك';
    const push = (text, kind) => {
      w.messages.push({
        id: id('wm'), from: 'peer', text, kind: kind || 'text', at: new Date().toISOString(),
      });
      w.unread = (w.unread || 0) + 1;
      changed = true;
    };
    // سألت «من صاحب الهمسة؟» — الآن يأتي الجواب: تعريف بالنفس، أو اعتذار مهذّب
    if (w.direction === 'in' && w.revealState === 'asked') {
      if (w.revealOnAsk !== false) {
        w.revealed = true;
        w.revealState = 'granted';
        push(`أنا ${name}. سامحني على الهمسة — ما عرفت أقولها لك وجهًا لوجه.`, 'reveal');
        notify(db, `${name} عرّف بنفسه — كان صاحب الهمسة المجهولة.`, 'whisper', { whisperId: w.id });
      } else {
        w.revealState = 'declined';
        push('أفضّل أن أبقى مجهولًا — اعذرني. المهم أن الكلام وصل.', 'reveal');
        notify(db, 'صاحب الهمسة فضّل أن يبقى مجهولًا.', 'whisper', { whisperId: w.id });
      }
      return;
    }
    // همسة أنت بدأتها: صاحبها يطلب منك أن تعرّف بنفسك (باب الكشف في الاتجاهين)
    if (w.direction === 'out' && !w.peerAsked && !w.revealed
        && w.messages.filter((m) => m.from === 'u-me').length >= 2) {
      w.peerAsked = true;
      push('من أنت؟ ما أحب أتكلم مع واحد ما أعرفه.', 'ask');
      notify(db, 'صاحب الهمسة يسأل: «من أنت؟» — عرّف بنفسك أو ابقَ مجهولًا.', 'whisper', { whisperId: w.id });
      return;
    }
    // ردّ عادي على آخر رسالة كتبتها (والردّ نفسه لا يُنشئ إشعارًا — يكفي عدّاد الغير مقروء)
    if (last.from === 'u-me' && (last.kind || 'text') === 'text') {
      const lines = WHISPER_LINES[String(w.peerId)] || WHISPER_LINES_FALLBACK;
      const mineCount = w.messages.filter((m) => m.from === 'u-me').length;
      push(lines[(mineCount - 1) % lines.length] || WHISPER_LINES_FALLBACK[0], 'text');
    }
  });

  db.rooms.forEach((r) => {
    if (r.status === 'open' && new Date(r.closesAt).getTime() < t) {      r.status = 'closed';
      r.memories.push({
        text: `أُقفلت الغرفة تلقائيًا بعد انتهاء مدتها — حضر ${r.members.length} من ${r.capacity}.`,
        at: new Date().toISOString(),
      });
      if (!Array.isArray(r.messages)) r.messages = [];
      r.messages.push({
        id: id('rm'),
        from: 'sys',
        text: 'انتهت مدة الغرفة وأُقفلت — الدردشة صارت للقراءة فقط.',
        at: new Date().toISOString(),
      });
      notify(db, `انتهت «${r.title}» وأُرشفت في أثر.`, 'memory');
      changed = true;
    }
  });
  // ── الحالات: لا تبقى أكثر من ٢٤ ساعة، وبعدها تُحذف نهائيًا من المخزن ──
  // من أراد أن تبقى ذكراه يختار «أثر» أو «أثر وحالة» فيُنشأ سجل أثر دائم مستقل.
  const HOUR = 3600 * 1000;
  const openStateIds = new Set((db.rooms || [])
    .filter((r) => r.status === 'open' && r.stateId)
    .map((r) => r.stateId));
  db.states = (db.states || []).filter((s) => {
    const exp = Date.parse(s.expiresIn);
    if (!Number.isFinite(exp)) return true;
    let born = Date.parse(s.createdAt);
    if (!Number.isFinite(born)) { born = t; s.createdAt = new Date(t).toISOString(); changed = true; }
    const cap = Math.min(exp, born + 24 * HOUR); // سقف صارم: ٢٤ ساعة مهما طلبت الواجهة
    if (cap !== exp) { s.expiresIn = new Date(cap).toISOString(); changed = true; }
    if (cap > t) return true;
    if (openStateIds.has(s.id)) return true; // غرفة مفتوحة ما زالت تشير إليها — تُحذف بعد إقفالها
    // حالتها انتهت: منشوراتها وردودها وهمساتها تُرفع معها، والوسائط المرفوعة تبقى على القرص
    changed = true;
    return false;
  });
  return changed;
}

// ردود صاحب الهمسة: قصيرة، حذرة، ولا تكشف شيئًا — الكشف له باب واحد فقط.
// الدور يتبدّل بحسب عدد رسائله حتى لا يتكرر الردّ نفسه في كل مرة.
const WHISPER_LINES = {
  u1: ['خلني أفكر… بس أقول لك: أنت تعرفني فعلًا.', 'ما راح أطوّل — أوعدك.'],
  u4: ['ضحكت. وأقول لك شي ثاني: أنا قريب منك بالضبط.', 'لا تسأل أحد — الجواب عندك.'],
  u6: ['الجدة تقول إن الحدس ما يخطئ.', 'بكرة أقول لك أكثر.'],
  u7: ['بيني وبينك… خلها سرّ.', 'تراني قريب، بس لا تلفّ وتدور.'],
  u8: ['حسنًا… بس خلها سرّنا.', 'أنا هنا، تابع.'],
};
const WHISPER_LINES_FALLBACK = ['وصلتني — أكمل.', 'أنا معك، تابع.'];

// مهلة بشرية قصيرة قبل الردّ — تكفي ليشعر أن هناك شخصًا يقرأ لا روبوتًا يجيب فورًا
const WHISPER_WAIT_MS = 20 * 1000;

// ── الهمسة كمحادثة ──
// تلميح مبهم يساعد على التخمين بلا كشف: القرب من الدائرة لا الاسم.
const REL_HINT = {
  'العائلة': 'من العائلة',
  'الزملاء': 'من الزملاء',
  'الجيران': 'من الجيران',
  'دائرة قريبة': 'من دائرتك المقربة',
};
const whisperHint = (p) => (p && REL_HINT[p.relation]) || 'من دائرتك';

// حجب صاحب الهمسة مسؤولية الخادم: لا يُرسل أي معرّف أو اسم قبل أن يكشف نفسه.
// حتى `revealOnAsk` (نيّة صاحبها) لا تُرسل قبل أن تسأل.
function whisperView(w, db) {
  const peer = (db.people || []).find((p) => p.id === w.peerId) || null;
  const mine = w.direction === 'out';           // أنا من بدأها → أعرف مع من أتكلم
  const open = mine || w.revealed === true;
  const messages = (Array.isArray(w.messages) ? w.messages : []).map((m) => ({
    id: m.id,
    at: m.at,
    text: m.text || '',
    kind: m.kind || 'text',
    mine: m.from === 'u-me',
  }));
  const last = messages.length ? messages[messages.length - 1] : null;
  return {
    id: w.id,
    direction: mine ? 'out' : 'in',
    alias: open && peer ? peer.name : 'همسة',
    hint: open && peer ? peer.relation : whisperHint(peer),
    peer: open && peer
      ? {
        id: peer.id, name: peer.name, color: peer.color,
        avatar: peer.avatar || '', username: peer.username || '', relation: peer.relation,
      }
      : null,
    revealed: Boolean(w.revealed),
    revealAsked: Boolean(w.revealAsked),
    revealState: w.revealState || 'idle',
    peerAsked: Boolean(w.peerAsked),
    reaction: w.reaction || null,
    stateId: w.stateId || null,
    fromState: w.fromState || '',
    unread: w.unread || 0,
    messages,
    last,
    count: messages.length,
    updatedAt: last ? last.at : (w.createdAt || new Date(db.createdAt || Date.now()).toISOString()),
  };
}

function withMeta(db) {
  const t = Date.now();
  // «أثر» لا يُرسل كاملًا في كل تحديث — للخريطة مسارها المستقل بنطاق محسوب على الخادم.
  const { athar: atharRaw, ...rest } = db;
  const visible = visibleAthar(db, t);
  const mine = visible.filter((a) => a.mine);
  const chats = (db.chats || []).map((c) => {
    const person = (db.people || []).find((p) => p.id === c.personId) || null;
    const last = c.messages && c.messages.length ? c.messages[c.messages.length - 1] : null;
    return {
      ...c,
      person,
      last,
      updatedAt: last ? last.at : new Date(db.createdAt || t).toISOString(),
    };
  }).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());

  // محادثات الهمس: تصل كاملة بلا هوية صاحبها (انظر whisperView)
  const whispers = (db.whispers || [])
    .map((w) => whisperView(w, db))
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  const whisperOfState = (sid) => {
    const list = whispers.filter((w) => w.stateId === sid);
    // الهمسة الواردة أولًا: همستي أنا لا تحجب المجهولة التي وصلتني على الحالة
    return list.find((w) => w.direction === 'in') || list[0] || null;
  };

  const roster = [db.me, ...(db.people || [])].filter(Boolean);
  const rooms = (db.rooms || []).map((r) => {
    const messages = Array.isArray(r.messages) ? r.messages : [];
    return {
      ...r,
      messages,
      last: messages.length ? messages[messages.length - 1] : null,
      messageCount: messages.length,
      msLeft: Math.max(0, new Date(r.closesAt).getTime() - t),
      fill: Math.round((r.members.length / r.capacity) * 100),
      mine: r.owner === 'u-me',
      joined: (r.members || []).includes('u-me'),
      unread: r.unread || 0,
      roster: (r.members || []).map((id) => roster.find((p) => p.id === id)).filter(Boolean),
    };
  });

  const meetings = (db.meetings || []).map((m) => {
    const t0 = meetingAt(m);
    const bands = reminderBands(m);
    const sent = Array.isArray(m.sentReminders) ? m.sentReminders : [];
    const skipped = Array.isArray(m.skippedReminders) ? m.skippedReminders : [];
    const minsLeft = t0 === null ? null : (t0 - t) / 60000;
    // حالة كل تذكير: أُرسل / يُرسل الآن / قادم / مضى وقته (الموعد أقرب من أن يبقى له وقت)
    const bandStatus = (b) => {
      if (sent.includes(b.minutes)) return 'sent';
      if (skipped.includes(b.minutes)) return 'skipped';
      if (minsLeft === null) return 'upcoming';
      if (minsLeft <= b.minutes && minsLeft > b.lower) return 'due';
      if (minsLeft <= b.minutes) return 'skipped';
      return 'upcoming';
    };
    return {
      ...m,
      kind: m.kind || 'vote',
      reminders: remindersOf(m),
      skippedReminders: skipped,
      bands,
      place: meetingPlace(m),
      reminder: remindersOf(m).map(remindLabel).join(' و '),
      reminderView: bands.map((b) => ({ ...b, sent: sent.includes(b.minutes), status: bandStatus(b) })),
      atIso: t0 ? new Date(t0).toISOString() : null,
      msTo: t0 ? Math.max(0, t0 - t) : null,
      overdue: Boolean(t0 && t0 < t),
      scheduled: m.status === 'scheduled' || (m.status === 'confirmed' && Boolean(t0)),
    };
  });

  return {
    ...rest,
    meetings,
    meetingsNext: meetings
      .filter((m) => m.atIso && !m.overdue)
      .sort((a, b) => new Date(a.atIso).getTime() - new Date(b.atIso).getTime())[0] || null,
    chats,
    chatsUnread: chats.reduce((sum, c) => sum + (c.unread || 0), 0),
    whispers,
    whispersUnread: whispers.reduce((sum, w) => sum + (w.unread || 0), 0),
    rooms,
    roomsUnread: rooms.reduce((sum, r) => sum + (r.unread || 0), 0),
    // ملخّص أثر: يكفي الواجهة لتعرف حجم أرشيفها دون تحميل الخريطة كلها
    atharSummary: {
      total: visible.length,
      mine: mine.length,
      places: [...new Set(visible.map((a) => a.place && a.place.name).filter(Boolean))].length,
      visits: mine.reduce((sum, a) => sum + (a.visits || 0), 0),
      latest: visible.slice().sort((a, b) => Date.parse(b.createdAt) - Date.parse(a.createdAt))[0] || null,
    },
    // لا نُرجع الحالات المنتهية أصلًا إلى الواجهة؛ msLeft وحده لا يكفي لأن الحالة
    // كانت تبقى في القائمة مع قيمة 0 حتى أول تحديث. «أثر» يُنشأ لاحقًا من مسار
    // مستقل، لذلك لا نخلط الأرشيف مع الحالات النشطة هنا.
    states: (db.states || [])
      .filter((s) => {
        const expiresAt = Date.parse(s.expiresIn);
        return Number.isFinite(expiresAt) && expiresAt > t && canSee(s, db.me, db.people);
      })
      .map((s) => {
        const wh = whisperOfState(s.id);
        return {
          ...s,
          audience: normalizeAudience(db.me, db.people, s.audience),
          audienceView: audienceView(s.audience, db.me, db.people),
          msLeft: Math.max(0, new Date(s.expiresIn).getTime() - t),
          progress: s.threshold ? Math.min(100, Math.round(((s.tally.yes || 0) / s.threshold) * 100)) : null,
          // همسة هذه الحالة (إن وُجدت): تفتحها بطاقة الحالة من دون أن تكشف صاحبها
          whisperId: wh ? wh.id : null,
          whisperUnread: wh ? wh.unread : 0,
          whisperAnonymous: wh ? (wh.direction === 'in' && !wh.revealed) : false,
        };
      }),
  };
}

module.exports = {
  read, write, mutate, id, notify, tick, withMeta, normalizeAudience, audienceView, canSee, DB_FILE,
  init: ensure, DATA_DIR,
  canSeeAthar, atharView, visibleAthar, cleanCompanions, memoryWhen, memoryWhenLabel, COMPANIONS_MAX,
  remindersOf, remindLabel, reminderBands, primeReminders, meetingAt, meetingPlace,
  REMIND_DEFAULT, REMIND_LABEL,
};

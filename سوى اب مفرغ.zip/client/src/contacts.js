// جهات الاتصال: نقرأ الأسماء فقط — بلا أرقام هواتف، وبلا تخزين في سوى.
//
// الزر يعمل في كل بيئة عبر ثلاث طبقات، والكود نفسه يخدمها بلا تعديل:
//   ١) تطبيق أصلي (آيفون/أندرويد عبر Capacitor): إضافة Contacts تفتح دفتر النظام،
//      والإذن هنا إذن نظام (Info.plist في آيفون · READ_CONTACTS في أندرويد).
//   ٢) متصفح أندرويد (كروم): Contact Picker API — نافذة يختار منها المستخدم بنفسه.
//   ٣) لا منتقي (سفاري/آيفون، أو متصفح مكتبي): الزر لا يعطب — يُفتح البديل مباشرةً:
//      البحث باسم المستخدم، والدعوة برابط، وجملة واحدة تشرح السبب بصدق.

// — الطبقة الأولى: إضافة الجهاز إن وُجدت —
export function nativePlugin() {
  const cap = typeof window !== 'undefined' ? window.Capacitor : null;
  const p = cap && cap.Plugins ? cap.Plugins.Contacts : null;
  if (!p) return null;
  return typeof p.pickContact === 'function' || typeof p.getContacts === 'function' ? p : null;
}

// — الطبقة الثانية: منتقي المتصفح (كروم أندرويد) —
export function pickerSupported() {
  return typeof navigator !== 'undefined' && Boolean(navigator.contacts && navigator.contacts.select);
}

// 'native' | 'picker' | 'fallback' — مصدر واحد للحقيقة في الواجهة كلها
export function contactsMode() {
  if (nativePlugin()) return 'native';
  if (pickerSupported()) return 'picker';
  return 'fallback';
}

export const contactsSupported = () => contactsMode() !== 'fallback';

// جملة واحدة صادقة لكل حالة — بلا مصطلحات تقنية
export function contactsNote() {
  const m = contactsMode();
  if (m === 'native') return 'افتح دفتر هاتفك واختر من تريد — الأسماء فقط، وبلا أرقام.';
  if (m === 'picker') return 'سيفتح المتصفح قائمة من جهازك تختار منها من تريد.';
  return 'هذا المتصفح — وآيفون خاصةً — لا يسمح للمواقع بفتح دفتر الهاتف. اكتب اسم المستخدم، أو ادعُ صديقك برابط؛ وسيعمل الزر مباشرة داخل التطبيق.';
}

// ── اسم من دفتر النظام: الاسم الظاهر فقط، ولا نلمس الأرقام أو البريد ──
function nameOfNative(c) {
  const n = c && (c.name || c.displayName);
  if (!n) return '';
  if (typeof n === 'string') return n.trim();
  const full = n.display || [n.given, n.middle, n.family].filter(Boolean).join(' ');
  return String(full || '').trim();
}

const fromNative = (list) =>
  (list || []).map((c) => ({ name: nameOfNative(c) })).filter((c) => c.name);

// إذن النظام — يُسأل مرّة واحدة، ثم يُتذكَّر من الجهاز نفسه
export async function requestNativePermission() {
  const p = nativePlugin();
  if (!p) return 'granted';
  try {
    let st = typeof p.checkPermissions === 'function' ? await p.checkPermissions() : null;
    if (st && st.contacts === 'granted') return 'granted';
    if (typeof p.requestPermissions === 'function') st = await p.requestPermissions();
    return (st && st.contacts) || 'prompt';
  } catch (e) { return 'prompt'; }
}

const deniedError = () => Object.assign(new Error('contacts-denied'), { code: 'denied' });

async function pickNative({ multiple = true } = {}) {
  const p = nativePlugin();
  const st = await requestNativePermission();
  if (st === 'denied') throw deniedError();
  // إن دعمت الإضافة المنتقي الأصلي: نُظهر دفتر النظام ونأخذ ما اختاره وحده.
  if (!multiple && typeof p.pickContact === 'function') {
    const one = await p.pickContact();
    const c = one && (one.contact || one);
    return fromNative(c ? [c] : []);
  }
  // وإلا: قراءة الأسماء وحدها — الاسم فقط في الطلب، فلا يمرّ رقم ولا بريد.
  const res = await p.getContacts({ projection: { name: true } });
  return fromNative((res && res.contacts) || []);
}

async function pickWeb({ multiple = true } = {}) {
  // نطلب الاسم وحده: لا هاتف ولا بريد ولا أي حقل آخر
  const list = await navigator.contacts.select(['name'], { multiple });
  return (list || [])
    .map((c) => ({ name: String(((c && c.name) || [])[0] || '').trim() }))
    .filter((c) => c.name);
}

// الطلب الموحّد: يختار الطبقة المتاحة تلقائيًا — وتصبح الطبقة الأولى (الجهاز)
// فعّالة بمجرد نقل الموقع إلى تطبيق، بلا تغيير سطر واحد هنا.
export async function pickContacts(opts = {}) {
  const mode = contactsMode();
  if (mode === 'fallback') {
    const e = new Error('unsupported');
    e.code = 'unsupported';
    throw e;
  }
  try {
    return mode === 'native' ? await pickNative(opts) : await pickWeb(opts);
  } catch (e) {
    // أغلق المستخدم القائمة بنفسه — ليس خطأً
    if (e && (e.name === 'AbortError' || e.name === 'NotAllowedError')) return [];
    if (e && e.code === 'denied') throw e;
    throw e;
  }
}

// تطبيع الاسم العربي: نُزيل التشكيل ونوحّد الألف والهاء والتاء المربوطة ونُسقط الفراغات
export function normName(v) {
  return String(v || '')
    .replace(/[\u064B-\u0652\u0640]/g, '')
    .replace(/[أإآا]/g, 'ا')
    .replace(/[ىي]/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/[^\p{L}\p{N}]/gu, '')
    .toLowerCase();
}

// مطابقة محلية بحتة: الاسم الأول يكفي — كل شيء يحدث في هذا الجهاز.
export function matchPeople(items, people) {
  const pool = people || [];
  return (items || []).map((c) => {
    const n = normName(c.name);
    const first = n.split(/\s+/)[0] || n;
    const found = pool.find((p) => {
      if (!n) return false;
      const pn = normName(p.name);
      const un = normName(p.username);
      return (pn && (pn === n || pn.includes(n) || n.includes(pn) || pn.startsWith(first))) || (un && un === n.replace(/\s+/g, ''));
    });
    return { name: c.name, person: found || null };
  });
}

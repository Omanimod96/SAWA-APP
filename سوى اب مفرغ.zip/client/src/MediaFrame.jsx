import React, { useEffect, useRef, useState } from 'react';
import { filterCss, normView } from './mediaView.js';

// إطار الوسائط: صورة أو مقطع مع التدوير والقلب والفلتر والقصّ.
// يُستخدم في المحرّر والمعاينة والعارض — فتظهر الحالة كما صُنعت بالضبط.
const useFit = (ref, ratio) => {
  const [size, setSize] = useState(null);
  useEffect(() => {
    const el = ref.current;
    if (!el || !ratio) { setSize(null); return undefined; }
    const calc = () => {
      const b = el.getBoundingClientRect();
      if (!b.width) return;
      const hFromW = b.width / ratio;
      if (!b.height || hFromW <= b.height + 1) setSize({ mode: 'w' });
      else setSize({ mode: 'h', width: Math.round(b.height * ratio), height: Math.round(b.height) });
    };
    calc();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(calc);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ratio, ref]);
  return size;
};

export default function MediaFrame({
  src, overlaySrc, type = 'image', dims, view,
  className = '', children, mediaRef, videoProps,
}) {
  const v = normView(view);
  const swap = v.rot % 180 !== 0;
  const c = v.crop;
  const known = !!(dims && dims.w && dims.h);
  const vw = known ? (swap ? dims.h : dims.w) : 0;
  const vh = known ? (swap ? dims.w : dims.h) : 0;
  const ratio = known ? ((c ? c.w : 1) * vw) / ((c ? c.h : 1) * vh) : null;

  const fitRef = useRef(null);
  const size = useFit(fitRef, ratio);
  const frameStyle = size && size.mode === 'h'
    ? { width: `${size.width}px`, height: `${size.height}px` }
    : ratio ? { width: '100%', aspectRatio: String(ratio) } : { width: '100%', height: '100%' };
  const viewStyle = c
    ? { width: `${100 / c.w}%`, height: `${100 / c.h}%`, left: `${(-c.x / c.w) * 100}%`, top: `${(-c.y / c.h) * 100}%` }
    : { inset: 0 };
  const rotStyle = {
    width: known ? `${((swap ? vh : vw) / vw) * 100}%` : '100%',
    height: known ? `${((swap ? vw : vh) / vh) * 100}%` : '100%',
    transform: `translate(-50%, -50%) rotate(${v.rot}deg) scaleX(${v.flipH ? -1 : 1}) scaleY(${v.flipV ? -1 : 1})`,
  };
  const fit = known ? 'fill' : 'contain';

  return (
    <div ref={fitRef} className={`mfit ${className}`.trim()}>
      <div className="mframe" style={{ ...frameStyle, filter: filterCss(v.filter) }}>
        <div className="mframe-view" style={viewStyle}>
          {type === 'video' ? (
            <>
              <div className="mframe-rot" style={rotStyle}>
                <video ref={mediaRef} className="mframe-media" style={{ objectFit: fit }} src={src} {...(videoProps || {})} />
              </div>
              {overlaySrc ? <img className="mframe-media mframe-ovl" src={overlaySrc} alt="" aria-hidden="true" /> : null}
            </>
          ) : (
            <div className="mframe-rot" style={rotStyle}>
              <img className="mframe-media" style={{ objectFit: fit }} src={src} alt="وسائط الحالة" />
            </div>
          )}
        </div>
      </div>
      {children}
    </div>
  );
}

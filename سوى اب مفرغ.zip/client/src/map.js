// ── محرّك خريطة خفيف: إسقاط ميركاتور + شبكة بلاطات (بلا مكتبات خارجية) ──
// السبب: التطبيق يُبنى مرة واحدة ويعمل على الهاتف بسرعة؛ لا نريد ميجابايتات JS.
const TILE = 256;
export const MIN_Z = 5;
export const MAX_Z = 16;

const clampLat = (lat) => Math.max(-85.0511, Math.min(85.0511, lat));

// بلاطات خريطة فاتحة/داكنة (CARTO) مع نسبة المصدر المطلوبة
export function tileUrl(z, x, y, dark) {
  const style = dark ? 'dark_all' : 'light_all';
  const sub = 'abcd'[(x + y) % 4];
  return `https://${sub}.basemaps.cartocdn.com/${style}/${z}/${x}/${y}.png`;
}

// إحداثيات العالم (بكسل) عند مستوى تكبير معيّن
export function project(lat, lng, z) {
  const size = TILE * Math.pow(2, z);
  const s = Math.sin((clampLat(lat) * Math.PI) / 180);
  return {
    x: ((lng + 180) / 360) * size,
    y: (0.5 - Math.log((1 + s) / (1 - s)) / (4 * Math.PI)) * size,
  };
}

export function unproject(x, y, z) {
  const size = TILE * Math.pow(2, z);
  const n = Math.PI - (2 * Math.PI * y) / size;
  return {
    lat: (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))),
    lng: (x / size) * 360 - 180,
  };
}

// كم متر لكل بكسل — نستخدمها لتحويل النطاق إلى نصف قطر مرئي
export function metersPerPixel(lat, z) {
  return (156543.03392 * Math.cos((clampLat(lat) * Math.PI) / 180)) / Math.pow(2, z);
}

// موضع نقطة على الشاشة نسبةً إلى مركز العرض (بالبكسل، +x يمين الشاشة)
export function toScreen(point, center, z) {
  const p = project(point.lat, point.lng, z);
  const c = project(center.lat, center.lng, z);
  return { x: p.x - c.x, y: p.y - c.y };
}

// إزاحة مركز الخريطة بمقدار (dx, dy) بكسل — تُستخدم عند السحب
export function panCenter(center, dx, dy, z) {
  const c = project(center.lat, center.lng, z);
  return unproject(c.x - dx, c.y - dy, z);
}

// البلاطات التي تغطّي مساحة العرض
export function tilesFor(center, z, width, height) {
  const c = project(center.lat, center.lng, z);
  const halfW = width / 2;
  const halfH = height / 2;
  const n = Math.pow(2, z);
  const x0 = Math.floor((c.x - halfW) / TILE);
  const x1 = Math.floor((c.x + halfW) / TILE);
  const y0 = Math.max(0, Math.floor((c.y - halfH) / TILE));
  const y1 = Math.min(n - 1, Math.floor((c.y + halfH) / TILE));
  const out = [];
  for (let x = x0; x <= x1; x += 1) {
    for (let y = y0; y <= y1; y += 1) {
      out.push({
        key: `${z}/${x}/${y}`,
        z,
        x: ((x % n) + n) % n,
        y,
        left: x * TILE - (c.x - halfW),
        top: y * TILE - (c.y - halfH),
      });
    }
  }
  return out;
}

// مستوى تكبير يضع النطاق المرغوب داخل الارتفاع المتاح
export function zoomForRadius(lat, radiusKm, height) {
  const target = Math.max(48, height * 0.42); // نصف قطر مرئي مريح
  const meters = radiusKm * 1000;
  let best = MIN_Z;
  for (let z = MAX_Z; z >= MIN_Z; z -= 1) {
    if (meters / metersPerPixel(lat, z) <= target) { best = z; break; }
  }
  return Math.max(MIN_Z, Math.min(MAX_Z, best));
}

// الأذونات — سؤال واحد، في سياق الحاجة، وبلا أي تخزين على المنصة.
//
// قاعدتان لا تتغيّران:
//  ١) القرار يُحفظ في هذا الجهاز وحده (localStorage). لا يُرسل قرار إلى الخادم،
//     ولا تُخزَّن في سوى أي صورة أو صوت أو موقع أو اسم من جهات الاتصال.
//  ٢) لا نُعيد السؤال: من وافق مرة لا يُسأل ثانية، ومن رفض لا نُلحّ عليه —
//     تبقى بطاقة «أذونات الجهاز» في تبويب «أنا» ليغيّر رأيه متى شاء.

import { contactsSupported, contactsMode, nativePlugin, requestNativePermission } from './contacts.js';

export const PERMS = [
  {
    id: 'camera',
    title: 'الكاميرا',
    ask: 'هل تسمح لسوى باستعمال الكاميرا؟',
    why: 'لتصوير صورة أو مقطع لحالتك أو أثرك.',
    keep: 'الكاميرا لا تعمل إلا في اللحظة التي تضغط فيها على التصوير.',
    native: true,
  },
  {
    id: 'microphone',
    title: 'الميكروفون',
    ask: 'هل تسمح لسوى باستعمال الميكروفون؟',
    why: 'لتسجيل حالة صوتية بضغطة واحدة.',
    keep: 'لا يُسجَّل شيء قبل أن تضغط «سجّل الآن»، والتسجيل يبقى عندك حتى تنشره.',
    native: true,
  },
  {
    id: 'location',
    title: 'الموقع',
    ask: 'هل تسمح لسوى بمعرفة موقعك؟',
    why: 'لتثبيت «أثر» على المكان الذي أنت فيه فعلًا.',
    keep: 'يمكنك دائمًا سحب الخريطة وتثبيت المكان يدويًا بلا موقع.',
    native: true,
  },
  {
    id: 'media',
    title: 'الاستوديو والملفات',
    ask: 'هل تسمح لسوى بفتح صورك ومقاطعك ومستنداتك؟',
    why: 'لاختيار صورة أو مقطع أو مستند تشاركه في حالة أو أثر أو محادثة.',
    keep: 'لا نفتح شيئًا من جهازك إلا ما تختاره أنت — ولا نطّلع على بقية الاستوديو.',
    native: false,
  },
  {
    id: 'contacts',
    title: 'جهات الاتصال',
    ask: 'هل تسمح لسوى بقراءة جهات اتصالك؟',
    why: 'لتعرف من منهم موجود في سوى فتبدأ معه محادثة بضغطة.',
    keep: 'أسماء من تختارهم فقط — بلا أرقام، ولا تُرفع ولا تُخزَّن في سوى. وفي المتصفح (وآيفون خاصةً) يُفتح الدفتر داخل التطبيق، والبديل جاهز: اسم المستخدم أو رابط الدعوة.',
    native: false,
  },
];

export const permById = (id) => PERMS.find((p) => p.id === id) || null;

// ── القرار المحلي: هذا الجهاز فقط، لا خادم ولا حساب ──
const KEY = 'sawa.perm.v1';
const INTRO_KEY = 'sawa.perm.intro';

// قراءة حالة المتصفح تُكاش ٢٠ ثانية: permissions.query تُستدعى كثيرًا بلا داعٍ
const stateCache = new Map();

function readAll() {
  try {
    const v = JSON.parse(localStorage.getItem(KEY) || '{}');
    return v && typeof v === 'object' ? v : {};
  } catch (e) { return {}; }
}

function writeAll(v) {
  try { localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { /* مساحة ممتلئة — نتجاهل */ }
  notify();
}

// state: granted (سُمح) · denied (ممنوع من المتصفح) · later (ليس الآن) · unasked
export function decisionOf(id) {
  const d = readAll()[id];
  return d && d.state ? d : { state: 'unasked', at: '' };
}

export function setDecision(id, state) {
  const all = readAll();
  all[id] = { state, at: new Date().toISOString() };
  stateCache.delete(id); // قرار جديد يعني قراءة جديدة من المتصفح
  writeAll(all);
  return { state, at: all[id].at };
}

export function forgetDecision(id) {
  const all = readAll();
  delete all[id];
  writeAll(all);
}

export function allDecisions() {
  const all = readAll();
  const out = {};
  PERMS.forEach((p) => { out[p.id] = all[p.id] ? all[p.id].state : 'unasked'; });
  return out;
}

export function introSeen() {
  try { return localStorage.getItem(INTRO_KEY) === '1'; } catch (e) { return true; }
}

export function markIntroSeen() {
  try { localStorage.setItem(INTRO_KEY, '1'); } catch (e) { /* تجاهل */ }
}

// ── إشعار الواجهة: لوحة الطلب الواحد تُفتح من أي مكان في التطبيق ──
const listeners = new Set();
let pending = null;

export function subscribe(fn) {
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

export function currentPending() { return pending; }

// صلاحية صار قرارها «مُسموح» لا معنى لبقاء طلبها معلّقًا: نُحسمه فورًا كي لا تُسأل
// عن الشيء نفسه مرّتين (يحدث فعلًا بعد «اسمح للكل» في اللوحة الأولى).
function settleDecided(id) {
  if (!pending || !pending.perm || pending.perm.id !== id) return;
  if (decisionOf(id).state === 'granted') pending.settle(true);
}

function notify() {
  listeners.forEach((fn) => { try { fn(); } catch (e) { /* مستمع معطوب لا يُسقط الواجهة */ } });
}

let askSeq = 0;

function openAsk(perm, opts) {
  return new Promise((resolve) => {
    const token = ++askSeq;
    if (pending) pending.settle(false); // طلب سابق بلا جواب — نُغلقه بدل أن نتركه معلّقًا
    let settled = false;
    const settle = (allowed) => {
      if (settled) return; // الحسم مرّة واحدة: لا وعد يُحلّ مرّتين
      settled = true;
      if (token === askSeq) { pending = null; notify(); }
      resolve(allowed);
    };
    const signal = opts && opts.signal;
    if (signal) {
      // إغلاق الشاشة التي طلبت الإذن = إلغاء الطلب: لا ورقة تبقى معلّقة تحجب
      // التطبيق (عطل شوهد فعلًا: زر «+» يبدو معطّلًا بعد الخروج من الكاميرا)،
      // ولا قرار «ليس الآن» يُسجَّل بغير إرادة المستخدم.
      if (signal.aborted) { resolve('canceled'); return; }
      signal.addEventListener('abort', () => settle('canceled'), { once: true });
    }
    pending = {
      token,
      perm,
      reason: (opts && opts.reason) || '',
      settle,
    };
    notify();
  });
}

// ── ما يدعمه هذا المتصفح فعلًا ──
export function isSupported(id) {
  if (typeof navigator === 'undefined') return false;
  if (id === 'camera' || id === 'microphone') {
    return Boolean(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  }
  if (id === 'location') return Boolean(navigator.geolocation);
  if (id === 'media') return true;
  if (id === 'contacts') return contactsSupported();
  return false;
}

// داخل إطار (معاينة المنصة) تمنع سياسة الأذونات الكاميرا والميكروفون والموقع —
// نكتشف ذلك مبكرًا ونقولها بصراحة بدل فشل صامت.
export function inFrame() {
  try { return window.self !== window.top; } catch (e) { return true; }
}

async function browserState(id) {
  const keep = stateCache.get(id);
  if (keep && Date.now() - keep.at < 20000) return keep.state; // قراءة واحدة تكفي لكل ثوانٍ
  if (typeof navigator === 'undefined' || !navigator.permissions || !navigator.permissions.query) return null;
  const name = id === 'location' ? 'geolocation' : id;
  try {
    const st = await navigator.permissions.query({ name });
    const state = st && st.state ? st.state : null; // granted | denied | prompt
    stateCache.set(id, { state, at: Date.now() });
    return state;
  } catch (e) { return null; } // متصفح لا يعرف هذا الاسم — نعتمد على قرارنا المحلي
}

// — الطلب الحقيقي من الجهاز: يُظهر نافذة المتصفح نفسه —
export async function probe(id) {
  if (id === 'camera' || id === 'microphone') {
    const stream = await navigator.mediaDevices.getUserMedia(id === 'camera' ? { video: true } : { audio: true });
    stream.getTracks().forEach((t) => t.stop()); // نُغلق الكاميرا/الميكروفون فورًا بعد أخذ الموافقة
    return true;
  }
  if (id === 'location') {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
        (err) => reject(Object.assign(new Error('geo'), { name: err && err.code === 1 ? 'NotAllowedError' : 'PositionUnavailableError' })),
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 300000 },
      );
    });
  }
  if (id === 'contacts') {
    // في التطبيق الأصلي: إذن نظام حقيقي يُطلب الآن. وفي المتصفح لا يوجد إذن مسبق —
    // النافذة تظهر وقت الاستخدام نفسه، فلا نسأل مقدّمًا بلا داعٍ.
    if (nativePlugin()) {
      const st = await requestNativePermission();
      if (st === 'denied') throw Object.assign(new Error('contacts'), { name: 'NotAllowedError' });
    }
    return true;
  }
  return true; // الاستوديو: نافذة الجهاز تظهر وقت الاستخدام، فلا نطلبه مقدّمًا
}

// منح الإذن بعد موافقة المستخدم: يطلب من الجهاز فعلًا ثم يسجّل النتيجة محليًا.
export async function grant(id, opts = {}) {
  const perm = permById(id);
  if (!perm) return { ok: true, perm: null };
  if (!isSupported(id)) { setDecision(id, 'unsupported'); return { ok: false, reason: 'unsupported', perm }; }
  if (opts.defer) { setDecision(id, 'granted'); settleDecided(id); return { ok: true, perm, deferred: true }; }
  try {
    const value = await probe(id, opts);
    setDecision(id, 'granted');
    settleDecided(id);
    return { ok: true, perm, value };
  } catch (e) {
    const denied = e && (e.name === 'NotAllowedError' || e.name === 'SecurityError');
    setDecision(id, denied ? 'denied' : 'later');
    return { ok: false, reason: denied ? 'denied' : 'failed', error: e, perm };
  }
}

// الطلب الموحّد: يُستدعى من زر الميزة نفسها (تصوير، تسجيل، ملفات، موقع، جهات اتصال).
export async function ensure(id, opts = {}) {
  const perm = permById(id);
  if (!perm) return { ok: true, perm: null };
  if (!isSupported(id)) return { ok: false, reason: 'unsupported', perm };
  if (inFrame() && perm.native) return { ok: false, reason: 'framed', perm };

  const d = decisionOf(id);
  if (d.state === 'granted') return { ok: true, perm, cached: true };

  const bs = await browserState(id);
  if (bs === 'granted') { setDecision(id, 'granted'); return { ok: true, perm }; }
  if (bs === 'denied' && perm.native) { setDecision(id, 'denied'); return { ok: false, reason: 'denied', perm }; }
  if (d.state === 'denied' && perm.native) return { ok: false, reason: 'denied', perm };

  // وعدنا في الورقة: «ليس الآن» لا تُتبَع بسؤال تلقائي.
  // السؤال يعود فقط حين يضغط المستخدم الزر بنفسه (force) أو يطلبه من «أنا».
  if (d.state === 'later' && !opts.force) return { ok: false, reason: 'later', perm };

  const allowed = await openAsk(perm, opts);
  if (allowed === 'canceled') return { ok: false, reason: 'canceled', perm };
  if (!allowed) {
    if (decisionOf(id).state !== 'granted') setDecision(id, 'later');
    return { ok: false, reason: 'later', perm };
  }
  return grant(id, opts);
}

// رسالة واحدة واضحة لكل سبب — بلا مصطلحات تقنية.
export function hintFor(res) {
  if (!res || !res.perm) return '';
  const name = res.perm.title;
  if (res.reason === 'unsupported') return `${name} غير مدعوم على هذا المتصفح — يمكنك المتابعة بالطريقة البديلة.`;
  if (res.reason === 'canceled') return ''; // أُغلق الطلب بإغلاق الشاشة — لا رسالة ولا تعليق
  if (res.reason === 'framed') return `افتح سوى في نافذة مستقلة ليطلب المتصفح إذن ${name}.`;
  if (res.reason === 'denied') return `إذن ${name} ممنوع من المتصفح — افتح «أذونات الجهاز» في تبويب أنا لإعادة الطلب.`;
  if (res.reason === 'failed') return `لم نتمكن من الوصول إلى ${name} الآن — جرّب مرة أخرى.`;
  return `لم تسمح بـ${name} بعد — تقدر تسمح لاحقًا من تبويب أنا.`;
}

// ── لوحة الأذونات الكاملة: تُفتح مرّة واحدة بعد أول دخول، ويمكن مراجعتها من «أنا» ──
let introOpen = false;
const introListeners = new Set();

export function subscribeIntro(fn) {
  introListeners.add(fn);
  return () => { introListeners.delete(fn); };
}

export function introOpenNow() { return introOpen; }

export function openIntro() {
  introOpen = true;
  markIntroSeen();
  introListeners.forEach((fn) => { try { fn(); } catch (e) { /* مستمع معطوب */ } });
}

export function closeIntro() {
  introOpen = false;
  markIntroSeen();
  introListeners.forEach((fn) => { try { fn(); } catch (e) { /* مستمع معطوب */ } });
}

// ملاحظة: آخر مكان معروف يُخزَّنه كل مكوّن في مفتاحه المحلي (sawa.athar.point) —
// لا نُكرّر مصدر الحقيقة هنا.

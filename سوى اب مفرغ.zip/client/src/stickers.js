// حزم الملصقات: يجلبها من الخادم مرة ويحفظها على الجهاز — فالحزمة الجديدة تُضاف
// على الخادم وحده وتظهر في التطبيق بلا تحديث من جهة العميل (بند ٥).
import { api } from './api.js';

const KEY = 'sawa.stickers.v1';
let cache = null;

export function stickerCache() {
  if (cache) return cache;
  try {
    const raw = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (raw && Array.isArray(raw.packs) && raw.packs.length) { cache = raw; return cache; }
  } catch (e) { /* ذاكرة معطوبة — نُصفّرها */ }
  return { version: 0, packs: [] };
}

function save(data) {
  cache = data;
  try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (e) { /* مساحة ممتلئة */ }
  return data;
}

// يقرأ النسخة المخزّنة فورًا (بلا انتظار)، ثم يسأل الخادم عن إصدار أحدث
export async function loadStickers({ onUpdate } = {}) {
  const local = stickerCache();
  if (local.packs.length && onUpdate) onUpdate(local);
  try {
    const fresh = await api.stickers();
    if (fresh && Array.isArray(fresh.packs) && fresh.version !== local.version) {
      save(fresh);
      if (onUpdate) onUpdate(fresh);
      return fresh;
    }
    if (fresh && Array.isArray(fresh.packs) && !local.packs.length) {
      save(fresh);
      if (onUpdate) onUpdate(fresh);
      return fresh;
    }
  } catch (e) { /* بلا شبكة: نكتفي بالمخزّن */ }
  return local;
}

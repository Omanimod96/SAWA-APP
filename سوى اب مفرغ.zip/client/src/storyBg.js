// ألوان «الحالة النصية»: لون سادة واحد، من قائمة مغلقة يتحقق منها الخادم أيضًا
// (نفس القيم في server/index.js → STORY_BG). لا نصّ حر: القيمة الملوّنة تُخزَّن
// كرمز hex فقط، فإن جاءت قيمة غير معروفة عرضنا الشكل القديم بدل لون مكسور.
export const STORY_BG = [
  { id: 'layl', hex: '#0B1F3F', label: 'ليل' },
  { id: 'bahr', hex: '#0F766E', label: 'بحر' },
  { id: 'ghuroub', hex: '#5B2A6E', label: 'غروب' },
  { id: 'turab', hex: '#9A3412', label: 'تراب' },
  { id: 'waha', hex: '#14532D', label: 'واحة' },
  { id: 'hajar', hex: '#334155', label: 'حجر' },
  { id: 'ward', hex: '#9F1239', label: 'ورد' },
  { id: 'asal', hex: '#B45309', label: 'عسل' },
];

export const DEFAULT_BG = STORY_BG[0].hex;

export function bgOf(hex) {
  const v = String(hex || '').trim().toUpperCase();
  return STORY_BG.find((c) => c.hex === v) || null;
}

export function bgLabel(hex) {
  const c = bgOf(hex);
  return c ? c.label : null;
}

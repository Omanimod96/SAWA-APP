// ─────────────────────────────────────────────────────────────────────────────
// rtc.js (عميل) — الاتصال الصوتي والمرئي.
//
// قناتان لا ثالثة لهما:
//   • الصعود (كل إشارة): POST /api/rtc/signal — يحمل رمز الجلسة في ترويسة.
//   • النزول: WebSocket على /ws/rtc، وإن حُجبت الترقية → SSE على /api/rtc/stream
//     (يُقرأ بـ fetch streaming لأن EventSource لا يرسل الترويسات).
//   لا polling مطلقًا: لا نطلب حالة المكالمة إلا عند فتح التطبيق أو بعد عودة الشبكة.
//
// الوسائط لا تمرّ من الخادم: WebRTC نقطة لنقطة، والخادم ينسّق الإشارات فقط.
// ─────────────────────────────────────────────────────────────────────────────
import { api, apiUrl } from './api.js';
import { getToken } from './auth.js';
import { ensure, hintFor } from './permissions.js';

const FALLBACK_ICE = [{ urls: ['stun:stun.l.google.com:19302'] }];
const CHANNEL_TIMEOUT = 5000;
const ICE_RESTART_WAIT = 4000;
const MAX_BACKOFF = 8000;
const MAX_ICE_QUEUE = 60;

const audioConstraints = {
  audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
};
const videoConstraints = (facing) => ({
  video: { facingMode: facing === 'environment' ? { ideal: 'environment' } : 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
});

export function createCallClient({ onEvent }) {
  const emit = (type, payload) => { try { onEvent(type, payload); } catch (e) { /* مستمع معطوب */ } };

  const S = {
    phase: 'idle',        // idle | outgoing | incoming | connecting | active | ended
    call: null,           // وصف المكالمة من الخادم
    muted: false,
    camOff: false,
    facing: 'user',
    notice: '',
    error: '',
    durationSec: 0,
    localReady: false,
    remoteReady: false,
    channel: '',          // ws | sse
    online: [],          // قائمة أسماء المتصلين الآن (تُملأ من إشارة presence)
    netOnline: true,     // هل القناة النازلة حيّة؟ (حالة شبكة، لا علاقة لها بالحضور)
    resolvedByMe: '',    // معرّف مكالمة أنهاها صاحب الجهاز بنفسه (رفض/إنهاء)
    resumable: false,
  };

  let pc = null;
  let local = null;
  let remote = null;
  let ws = null;
  let abort = null;
  let retryTimer = null;
  let waitTimer = null;
  let deadToken = null;   // رمز رفضه الخادم — لا نعيد المحاولة به أبدًا
  let backoff = 800;
  let handshakeTimer = null;
  let stopped = false;
  let preferSse = false;
  let pendingOffer = null;
  let iceQueue = [];
  let restartTimer = null;
  let tick = null;
  let peerGone = false;
  let iceServers = FALLBACK_ICE;
  let connectSeq = 0;

  const snapshot = () => ({ ...S, hasLocal: Boolean(local), hasRemote: Boolean(remote) });
  const announce = () => emit('change', snapshot());

  // ── القناة النازلة ────────────────────────────────────────────────────────
  function scheduleReconnect() {
    if (stopped) return;
    clearTimeout(retryTimer);
    retryTimer = setTimeout(connect, backoff);
    backoff = Math.min(MAX_BACKOFF, Math.round(backoff * 1.6));
  }

  // بلا رمز لا نفتح قناة أصلًا: الترقية بلا هوية تردّ 401 فيطبعها المتصفح خطأً
  // في الطرفية («فشل التحقق») ويُقرأ كعطل JS بلا سبب حقيقي. ننتظر بهدوء حتى يعود
  // الرمز (بعد دخول جديد) ثم نوصل — بلا أي طلب شبكة في هذه الأثناء.
  function waitForToken() {
    clearTimeout(waitTimer);
    if (stopped) return;
    waitTimer = setTimeout(() => {
      if (stopped) return;
      if (getToken()) connect(); else waitForToken();
    }, 1200);
  }

  function connect() {
    if (stopped) return;
    const token = getToken();
    // بلا رمز، أو برمز رفضه الخادم: لا نفتح قناة — ننتظر تغيّر الرمز بهدوء.
    if (!token || token === deadToken) { S.channel = ''; waitForToken(); return; }
    const seq = ++connectSeq;
    if (preferSse) { connectSse(seq); return; }
    let opened = false;
    let socket = null;
    try {
      const u = new URL(apiUrl('ws/rtc'));
      u.protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      u.searchParams.set('token', token);
      socket = new WebSocket(u.toString());
    } catch (e) { preferSse = true; connect(); return; }
    ws = socket;
    handshakeTimer = setTimeout(() => {
      // الترقية محجوبة عند الوكيل: ننتقل إلى SSE بدل إعادة المحاولة بلا نهاية
      if (!opened && seq === connectSeq) {
        preferSse = true;
        try { socket.close(); } catch (e) { /* تجاهل */ }
        connectSse(seq + 1);
      }
    }, CHANNEL_TIMEOUT);
    socket.onopen = () => {
      opened = true;
      clearTimeout(handshakeTimer);
      S.channel = 'ws';
      backoff = 800;
      announce();
    };
    socket.onmessage = (e) => { try { handle(JSON.parse(e.data)); } catch (err) { /* تجاهل */ } };
    socket.onerror = () => { try { socket.close(); } catch (e) { /* تجاهل */ } };
    socket.onclose = (e) => {
      clearTimeout(handshakeTimer);
      if (stopped || seq !== connectSeq) return;
      S.channel = '';
      announce();
      // 4401 = أُغلقت القناة لأن الجلسة أُبطلت (دخول من مكان آخر) — لا إعادة محاولة
      if (e && e.code === 4401) { deadToken = getToken() || deadToken; waitForToken(); return; }
      scheduleReconnect();
    };
  }

  async function connectSse(seq) {
    if (stopped) return;
    try {
      abort = new AbortController();
      const res = await fetch(apiUrl('api/rtc/stream'), {
        headers: { 'x-sawa-token': getToken() || '', Accept: 'text/event-stream' },
        signal: abort.signal,
      });
      // 401 على القناة النازلة = الجلسة أُبطلت: لا معنى لإعادة المحاولة بالرمز نفسه
      if (res.status === 401) { deadToken = getToken() || deadToken; S.channel = ''; announce(); waitForToken(); return; }
      if (!res.ok || !res.body) throw new Error('sse');
      if (seq !== connectSeq && seq !== connectSeq + 1) { /* تشغيل قديم — نتجاهل */ }
      S.channel = 'sse';
      backoff = 800;
      announce();
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i = buf.indexOf('\n\n');
        while (i >= 0) {
          const chunk = buf.slice(0, i);
          buf = buf.slice(i + 2);
          const line = chunk.split('\n').find((l) => l.startsWith('data: '));
          if (line) { try { handle(JSON.parse(line.slice(6))); } catch (e) { /* تجاهل */ } }
          i = buf.indexOf('\n\n');
        }
      }
      throw new Error('sse-end');
    } catch (e) {
      if (stopped) return;
      S.channel = '';
      announce();
      scheduleReconnect();
    }
  }


  // ── استقبال إشارات الخادم ─────────────────────────────────────────────────
  async function handle(msg) {
    if (!msg || !msg.ev) return;
    if (msg.ev === 'session') {
      // الخادم أنهى القناة لأن الجلسة لم تعد صالحة. نُسجّل الرمز المرفوض حتى لا
      // نعيد المحاولة به (المحاولة نفسها تُنتج ردّ 401 وخطأً في طرفية المتصفح).
      deadToken = getToken() || deadToken;
      S.channel = '';
      announce();
      return;
    }
    if (msg.ev === 'ready') {
      if (Array.isArray(msg.ice && msg.ice.iceServers) && msg.ice.iceServers.length) iceServers = msg.ice.iceServers;
      if (Array.isArray(msg.online)) emit('presence', { list: msg.online });
      if (msg.call) { S.call = msg.call; S.resumable = true; }
      emit('channel', { channel: S.channel });
      // بعد أي انقطاع: نسأل الخادم مرة واحدة عن المكالمة القائمة (لا polling)
      if (S.phase !== 'idle' && S.call) resumeCall();
      return;
    }
    if (msg.ev === 'presence') { emit('presence', { username: msg.username, online: msg.online }); return; }
    if (msg.ev === 'chat:changed') { emit('chat', { personId: msg.personId }); return; }

    if (msg.ev === 'call:incoming') {
      if (S.phase !== 'idle') { return; } // مشغول: الخادم لن يرسل أصلًا، وهذا حزام أمان
      S.phase = 'incoming';
      S.call = msg.call;
      S.error = '';
      S.notice = '';
      emit('incoming', msg.call);
      announce();
      return;
    }

    if (msg.callId && S.call && msg.callId !== S.call.id && msg.ev !== 'call:incoming') return;

    if (msg.ev === 'call:accepted') {
      S.call = msg.call;
      S.phase = 'active';
      S.durationSec = msg.call.durationSec || 0;
      startTicker();
      emit('accepted', msg.call);
      announce();
      return;
    }
    if (msg.ev === 'call:sdp') {
      if (pendingOfferPhase()) { pendingOffer = msg.description; return; } // يُخزَّن حتى القبول
      await applyRemote(msg.description);
      return;
    }
    if (msg.ev === 'call:ice') { await addIce(msg.candidate); return; }
    if (msg.ev === 'call:media') {
      S.peerMuted = msg.media && msg.media.audio === false;
      S.peerCamOff = msg.media && msg.media.video === false;
      emit('media', { peerMuted: S.peerMuted, peerCamOff: S.peerCamOff });
      announce();
      return;
    }
    if (msg.ev === 'call:peer-connecting') {
      peerGone = true;
      S.notice = 'يبدو أن شبكة الطرف الآخر انقطعت — نحاول المتابعة';
      announce();
      return;
    }
    if (msg.ev === 'call:peer-back') {
      peerGone = false;
      S.notice = '';
      try { if (pc && pc.connectionState !== 'connected') await restartIce(); } catch (e) { /* تجاهل */ }
      announce();
      return;
    }
    if (msg.ev === 'call:ended') {
      // من أنهى المكالمة بيده سبق قرارُه الإشعار: لا تُعاد عليه شاشة «انتهت» بعد رفض
      // (وإلا رأى «رُفضت المكالمة» لمن رفضها هو)، ولا رسالة توبيخ على فعلٍ فعله.
      const mine = Boolean(msg.call && msg.call.id && msg.call.id === S.resolvedByMe);
      if (mine) {
        S.resolvedByMe = '';
        stopTicker();
        teardown({ keepCall: true });
        if (S.phase !== 'ended') { S.phase = 'idle'; S.call = null; }
        else setTimeout(() => { if (S.phase === 'ended') { S.phase = 'idle'; S.call = null; announce(); } }, 6000);
        emit('ended', { call: msg.call, reason: msg.call && msg.call.status, local: true });
        announce();
        return;
      }
      S.call = msg.call;
      S.phase = 'ended';
      S.notice = '';
      stopTicker();
      const reason = msg.call && msg.call.status;
      teardown({ keepCall: true });
      emit('ended', { call: msg.call, reason });
      announce();
      setTimeout(() => { if (S.phase === 'ended') { S.phase = 'idle'; S.call = null; announce(); } }, 6000);
    }
  }

  const pendingOfferPhase = () => S.phase === 'incoming' || (S.phase === 'connecting' && !pc);

  // ── الوسائط ───────────────────────────────────────────────────────────────
  // الأذونات تمرّ من طبقة التطبيق نفسها: سؤال واحد في سياق الحاجة، والموافقة
  // تُحفظ في هذا الجهاز وحده. الضغط على زرّ المكالمة صار «طلبًا صريحًا» (force)
  // فلا يتكرّر السؤال مرّتين بعد أول موافقة.
  async function askFor(kind) {
    const mic = await ensure('microphone', {
      force: true,
      reason: kind === 'video' ? 'لتسمعك في المكالمة المرئية' : 'لتسمعك في المكالمة الصوتية',
    });
    if (!mic.ok) throw new Error(hintFor(mic) || 'لم يُسمح بالميكروفون');
    if (kind !== 'video') return;
    const cam = await ensure('camera', { force: true, reason: 'ليشاهدك الطرف الآخر في المكالمة المرئية' });
    if (!cam.ok) throw new Error(hintFor(cam) || 'لم يُسمح بالكاميرا');
  }

  async function acquire(kind) {
    await askFor(kind);
    const constraints = kind === 'video'
      ? { ...audioConstraints, ...videoConstraints(S.facing) }
      : { ...audioConstraints };
    local = await navigator.mediaDevices.getUserMedia(constraints);
    S.localReady = true;
    S.muted = false;
    S.camOff = kind !== 'video';
    emit('local', local);   // الواجهة ترسم المعاينة المحلية من هنا
    return local;
  }

  function buildPeer() {
    pc = new RTCPeerConnection({ iceServers, bundlePolicy: 'max-bundle', iceCandidatePoolSize: 2 });
    if (local) local.getTracks().forEach((t) => pc.addTrack(t, local));
    remote = new MediaStream();
    pc.ontrack = (e) => {
      e.streams[0].getTracks().forEach((t) => { if (!remote.getTracks().includes(t)) remote.addTrack(t); });
      S.remoteReady = true;
      emit('remote', remote);
      announce();
    };
    pc.onicecandidate = (e) => {
      if (!e.candidate || !S.call) return;
      api.rtcSignal({ ev: 'ice', callId: S.call.id, candidate: e.candidate.toJSON() }).catch(() => {
        iceQueue.push(e.candidate.toJSON()); // نُعيدها عبر المسار المخزَّن إن فشل الإرسال
      });
    };
    pc.onconnectionstatechange = () => {
      const st = pc.connectionState;
      if (st === 'connected') {
        peerGone = false;
        S.notice = '';
        if (S.phase !== 'active') { S.phase = 'active'; startTicker(); }
        emit('connected', {});
        announce();
        return;
      }
      if (st === 'disconnected') {
        clearTimeout(restartTimer);
        restartTimer = setTimeout(async () => {
          if (!pc || pc.connectionState === 'connected' || stopped) return;
          S.notice = 'الشبكة ضعفت — نحاول استعادة الصوت والصورة';
          announce();
          await restartIce();
        }, ICE_RESTART_WAIT);
        return;
      }
      if (st === 'failed') {
        S.notice = 'تعذّر استمرار الاتصال — نحاول مرة أخيرة';
        announce();
        restartIce().catch(() => hangup('network'));
      }
    };
    return pc;
  }

  async function restartIce() {
    if (!pc || typeof pc.restartIce !== 'function') return;
    try {
      pc.restartIce();
      const offer = await pc.createOffer({ iceRestart: true });
      await pc.setLocalDescription(offer);
      if (S.call) await api.rtcSignal({ ev: 'sdp', callId: S.call.id, description: { type: offer.type, sdp: offer.sdp } });
    } catch (e) { /* نحاول مرة أخرى مع الحدث القادم */ }
  }

  async function applyRemote(description) {
    if (!pc) buildPeer();
    if (!description || !description.sdp) return;
    try {
      await pc.setRemoteDescription(new RTCSessionDescription(description));
      flushIce();
      if (description.type === 'offer') {
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        if (S.call) await api.rtcSignal({ ev: 'sdp', callId: S.call.id, description: { type: answer.type, sdp: answer.sdp } });
      }
    } catch (e) {
      S.error = 'تعذّر تجهيز الاتصال — جرّب مرة أخرى';
      announce();
    }
  }

  function flushIce() {
    const queue = iceQueue.splice(0, iceQueue.length).slice(0, MAX_ICE_QUEUE);
    queue.forEach((c) => { addIce(c); });
  }

  async function addIce(candidate) {
    if (!pc || !pc.remoteDescription) { if (candidate) iceQueue.push(candidate); return; }
    try { await pc.addIceCandidate(candidate); } catch (e) { /* مرشّح متأخر — نتجاهله */ }
  }

  // ── المؤقّت: مدة المكالمة الظاهرة (عدّ محلي، بلا سؤال للخادم كل ثانية) ────
  function startTicker() {
    stopTicker();
    const base = Date.now();
    tick = setInterval(() => {
      S.durationSec = Math.max(S.durationSec, Math.round((Date.now() - base) / 1000));
      announce();
    }, 1000);
  }

  function stopTicker() {
    if (tick) clearInterval(tick);
    tick = null;
  }

  // ── الإنهاء المحلي: نوقف الوسائط والقناة، ونُبقي السجلّ ليُعرض للمستخدم ──
  function teardown({ keepCall = false } = {}) {
    stopTicker();
    clearTimeout(restartTimer);
    if (pc) { try { pc.close(); } catch (e) { /* تجاهل */ } }
    pc = null;
    if (local) { local.getTracks().forEach((t) => { try { t.stop(); } catch (e) { /* تجاهل */ } }); }
    local = null;
    remote = null;
    iceQueue = [];
    pendingOffer = null;
    S.localReady = false;
    S.remoteReady = false;
    if (!keepCall) { S.call = null; }
  }

  // ── الصعود: كل إشارة تمرّ من هنا وتُخطئ بهدوء بلا إسقاط الواجهة ──────────
  async function signal(payload) {
    try { return await api.rtcSignal(payload); }
    catch (e) { S.error = (e && e.message) || 'تعذّر إرسال الإشارة'; announce(); return null; }
  }

  // عودة الشبكة: نسأل الحالة مرة واحدة، فإن كانت مكالمتي قائمة نُكملها
  async function resumeCall() {
    try {
      const st = await api.rtcState();
      if (Array.isArray(st.online)) emit('presence', { list: st.online });
      if (!st.call) { teardown(); S.phase = 'idle'; announce(); return; }
      S.call = st.call;
      if (st.call.state === 'active') { S.phase = 'active'; startTicker(); }
      else if (st.call.role === 'callee') S.phase = 'incoming';
      else S.phase = 'outgoing';
      if (!pc) { await acquire(st.call.kind); buildPeer(); }
      announce();
    } catch (e) { /* لا شيء — نُعيد المحاولة عند الحدث القادم */ }
  }

  // ── الأزرار: بدء · قبول · رفض · إنهاء · كتم · كاميرا · تبديل العدسة ──────
  // البدء: نطلب الأذن ونفتح الوسائط أولًا، ثم ندعو عبر الخادم، ثم نرسل العرض
  // (offer). لا نضع مرشّحات ICE إلا بعد أن يصير للسؤال وصف محلي.
  async function start(personId, kind) {
    if (S.phase !== 'idle' && S.phase !== 'ended') return { ok: false, error: 'هناك مكالمة قائمة' };
    S.error = '';
    S.notice = '';
    S.phase = 'outgoing';
    S.call = { id: '', kind, state: 'ringing', role: 'caller', peer: {}, durationSec: 0 };
    announce();
    try {
      await acquire(kind);
    } catch (e) {
      S.phase = 'idle';
      S.call = null;
      S.error = (e && e.message) || 'لم نتمكّن من الوصول إلى الميكروفون أو الكاميرا';
      announce();
      return { ok: false, error: S.error };
    }
    const res = await signal({ ev: 'invite', personId, kind });
    if (!res || !res.ok || !res.call) {
      const msg = (res && res.error) || S.error || 'تعذّر بدء المكالمة';
      teardown();
      S.phase = 'idle';
      S.call = null;
      S.error = msg;
      announce();
      return { ok: false, error: msg };
    }
    S.call = res.call;
    if (res.call.state === 'ended' || res.call.status) {
      // انتهت فورًا: مشغول أو غير متاح — نُظهر السبب بجملة واحدة
      teardown({ keepCall: true });
      S.phase = 'ended';
      announce();
      emit('ended', { call: res.call, reason: res.call.status });
      return { ok: true, call: res.call };
    }
    buildPeer();
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    await signal({ ev: 'sdp', callId: S.call.id, description: { type: offer.type, sdp: offer.sdp } });
    announce();
    return { ok: true, call: S.call };
  }

  async function accept() {
    if (S.phase !== 'incoming' || !S.call) return { ok: false };
    try {
      await acquire(S.call.kind);
    } catch (e) {
      S.error = (e && e.message) || 'لم نتمكّن من الوصول إلى الميكروفون أو الكاميرا';
      announce();
      await reject('no-media');
      return { ok: false, error: S.error };
    }
    const res = await signal({ ev: 'accept', callId: S.call.id });
    if (!res || !res.ok) { teardown(); S.phase = 'idle'; S.call = null; announce(); return { ok: false }; }
    S.phase = 'connecting';
    buildPeer();
    if (pendingOffer) { const d = pendingOffer; pendingOffer = null; await applyRemote(d); }
    announce();
    return { ok: true };
  }

  async function reject(reason) {
    const id = S.call && S.call.id;
    if (id) S.resolvedByMe = id;   // لا شاشة «انتهت» ولا رسالة بعد قراره
    S.phase = 'idle';
    teardown();
    announce();
    if (id) await signal({ ev: 'reject', callId: id, reason: reason || 'declined' });
    return { ok: true };
  }

  async function hangup(reason) {
    const id = S.call && S.call.id;
    const wasActive = S.phase === 'active';
    if (id) S.resolvedByMe = id;
    teardown({ keepCall: Boolean(id) });
    S.phase = id ? 'ended' : 'idle';
    announce();
    if (id) await signal({ ev: 'end', callId: id, reason: reason || (wasActive ? 'hangup' : 'canceled') });
    return { ok: true };
  }

  function toggleMute() {
    S.muted = !S.muted;
    if (local) local.getAudioTracks().forEach((t) => { t.enabled = !S.muted; });
    if (S.call && S.call.id) signal({ ev: 'media', callId: S.call.id, audio: !S.muted, video: !S.camOff });
    announce();
    return S.muted;
  }

  function toggleCam() {
    S.camOff = !S.camOff;
    if (local) local.getVideoTracks().forEach((t) => { t.enabled = !S.camOff; });
    if (S.call && S.call.id) signal({ ev: 'media', callId: S.call.id, audio: !S.muted, video: !S.camOff });
    announce();
    return S.camOff;
  }

  async function flipCamera() {
    if (!local || !S.call || S.call.kind !== 'video') return;
    S.facing = S.facing === 'user' ? 'environment' : 'user';
    announce();
    try {
      const fresh = await navigator.mediaDevices.getUserMedia(videoConstraints(S.facing));
      const newTrack = fresh.getVideoTracks()[0];
      const sender = pc && pc.getSenders().find((s) => s.track && s.track.kind === 'video');
      if (sender && newTrack) await sender.replaceTrack(newTrack);
      local.getVideoTracks().forEach((t) => t.stop());
      local.getVideoTracks().forEach((t) => local.removeTrack(t));
      local.addTrack(newTrack);
      newTrack.enabled = !S.camOff;
      emit('local', local);
    } catch (e) { /* نُبقي العدسة الحالية */ }
    announce();
  }

  // ── الإغلاق الكامل: عند خروج التطبيق أو تبديل الحساب ────────────────────
  function stop() {
    stopped = true;
    clearTimeout(retryTimer);
    clearTimeout(waitTimer);
    clearTimeout(handshakeTimer);
    if (abort) { try { abort.abort(); } catch (e) { /* تجاهل */ } }
    if (ws) { try { ws.close(); } catch (e) { /* تجاهل */ } }
    ws = null;
    teardown();
    S.phase = 'idle';
  }

  // إغلاق شاشة «انتهت» بيد المستخدم قبل مؤقّت الإخفاء التلقائي
  function dismiss() {
    if (S.phase !== 'ended') return { ok: false };
    S.phase = 'idle';
    S.call = null;
    announce();
    return { ok: true };
  }

  // نفتح القناة مع أول تركيب — القناة نفسها لا تعني مكالمة قائمة
  connect();

  return {
    // للقراءة فقط: الواجهة ترسم من هنا
    state: snapshot,
    start,
    accept,
    reject,
    hangup,
    toggleMute,
    toggleCam,
    flipCamera,
    dismiss,
    stop,
    connect: () => { stopped = false; backoff = 800; connect(); },
    isOnline: () => S.netOnline,
  };
}

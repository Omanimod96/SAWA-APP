// تنسيق المواعيد بالتوقيت المحلي للمستخدم (العرض فقط — الخادم يحفظ ISO)
const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const pad = (n) => String(n).padStart(2, '0');

function partOfDay(h) {
  if (h < 12) return 'صباحًا';
  if (h < 16) return 'ظهرًا';
  if (h < 20) return 'مساءً';
  return 'ليلًا';
}

export function clockText(input) {
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return '';
  const h = d.getHours();
  return `${h % 12 || 12}:${pad(d.getMinutes())} ${partOfDay(h)}`;
}

export function dayText(input) {
  const d = new Date(input);
  if (Number.isNaN(d.getTime())) return '';
  const midnight = (x) => { const y = new Date(x); y.setHours(0, 0, 0, 0); return y.getTime(); };
  const diff = Math.round((midnight(d) - midnight(new Date())) / 86400000);
  if (diff === 0) return 'اليوم';
  if (diff === 1) return 'غدًا';
  if (diff === 2) return 'بعد غد';
  if (diff === -1) return 'أمس';
  return `${DAYS[d.getDay()]} ${d.getDate()} ${MONTHS[d.getMonth()]}`;
}

export function fmtWhen(input) {
  if (!input) return '';
  return `${dayText(input)} ${clockText(input)}`.trim();
}

export function fmtDate(input) {
  if (!input) return '';
  return dayText(input);
}

// «بعد ٤٥ دقيقة» / «بعد ٣ س ٢٠ د» / «بعد يوم و٥ س»
export function countdown(ms) {
  if (ms === null || ms === undefined) return '';
  if (ms <= 0) return 'فات الموعد';
  const min = Math.floor(ms / 60000);
  if (min < 1) return 'بعد لحظات';
  if (min < 60) return `بعد ${min} دقيقة`;
  const hours = Math.floor(min / 60);
  const rest = min % 60;
  if (hours < 24) return rest ? `بعد ${hours} س ${rest} د` : `بعد ${hours} ساعة`;
  const days = Math.floor(hours / 24);
  const hLeft = hours % 24;
  return hLeft ? `بعد ${days} يوم و${hLeft} س` : `بعد ${days} يوم`;
}

// قيمة جاهزة لحقل datetime-local (بالتوقيت المحلي)
export function toInputValue(input) {
  const d = input ? new Date(input) : new Date();
  if (Number.isNaN(d.getTime())) return '';
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// الموعد الافتراضي: غدًا في الساعة الثامنة مساءً
export function defaultSlot(hour = 20, daysAhead = 1) {
  const d = new Date();
  d.setDate(d.getDate() + daysAhead);
  d.setHours(hour, 0, 0, 0);
  return toInputValue(d);
}

// تحويل قيمة الحقل إلى ISO بتوقيت UTC كما يفهمه الخادم
export function fromInputValue(value) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d.toISOString();
}

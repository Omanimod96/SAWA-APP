import { Camera, Mic, MapPin, Images, ContactRound, ShieldCheck } from 'lucide-react';

// أيقونة واحدة لكل إذن — مصدر واحد تستخدمه ورقة الطلب وبطاقة الإعدادات
export const PERM_ICONS = {
  camera: Camera,
  microphone: Mic,
  location: MapPin,
  media: Images,
  contacts: ContactRound,
};

export const permIcon = (id) => PERM_ICONS[id] || ShieldCheck;

// ذاكرة محلية سريعة (stale-while-revalidate) — تجعل الواجهة تظهر فورًا
// ثم تُحدَّث بهدوء من الشبكة. كل المفاتيح تحت بادئة واحدة لسهولة التنظيف.
const PREFIX = 'sawa.cache.';

export function saveCache(key, value) {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify({ at: Date.now(), value }));
  } catch (e) { /* الذاكرة ممتلئة — نتجاهل */ }
}

export function readCache(key, maxAgeMs = 24 * 3600 * 1000) {
  try {
    const raw = JSON.parse(localStorage.getItem(PREFIX + key) || 'null');
    if (!raw || !raw.value) return null;
    if (Date.now() - Number(raw.at || 0) > maxAgeMs) return null;
    return raw.value;
  } catch (e) { return null; }
}

export function clearCache() {
  try {
    Object.keys(localStorage)
      .filter((k) => k.startsWith(PREFIX))
      .forEach((k) => localStorage.removeItem(k));
  } catch (e) { /* تجاهل */ }
}

// صورة مختصرة من بيانات الإقلاع تكفي للرسم الأول (نتجاهل الحقول الضخمة)
export function slimBootstrap(d) {
  if (!d || !Array.isArray(d.states)) return null;
  return d;
}

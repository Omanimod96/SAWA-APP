/**
 * أرقام عربية/فارسية → أرقام لاتينية.
 *
 * السبب: لوحة المفاتيح العربية تكتب «١٢٣٤٥٦» لا «123456»، و`\d` في جافاسكربت
 * لا يراها أرقامًا فتُحذف كلها — فيبقى حقل الرمز فارغًا والزرّ معطّلًا، ويرى
 * المستخدم أن «الرمز لا يعمل» بلا سبب ظاهر. نُطبّع عند الإدخال بدل أن نُطالب
 * المستخدم بتغيير لوحة مفاتيحه. نفس الشيء لرقم الهاتف.
 */
const ARABIC = '٠١٢٣٤٥٦٧٨٩';
const PERSIAN = '۰۱۲۳۴۵۶۷۸۹';

export function toLatinDigits(raw) {
  return String(raw == null ? '' : raw).replace(/[\u0660-\u0669\u06F0-\u06F9]/g, (ch) => {
    const a = ARABIC.indexOf(ch);
    if (a > -1) return String(a);
    const p = PERSIAN.indexOf(ch);
    return p > -1 ? String(p) : ch;
  });
}

// أرقام لاتينية فقط، بحدّ أقصى اختياري
export function digitsOnly(raw, max) {
  const s = toLatinDigits(raw).replace(/\D/g, '');
  return max ? s.slice(0, max) : s;
}

// الموقع الجغرافي بهدوء: داخل إطار المعاينة تمنع سياسة الأذونات الموقع،
// فنكتفي بمركز المدينة بدل إظهار أخطاء أو انتظار طويل.
export function geoUnavailable() {
  try {
    if (window.self !== window.top) return true; // داخل إطار (معاينة المنصة)
  } catch (e) { return true; }
  return !navigator.geolocation;
}

export function currentPoint({ timeout = 2500, highAccuracy = false } = {}) {
  return new Promise((resolve) => {
    if (geoUnavailable()) { resolve(null); return; }
    let settled = false;
    const finish = (v) => { if (!settled) { settled = true; resolve(v); } };
    const guard = setTimeout(() => finish(null), timeout + 600);
    try {
      navigator.geolocation.getCurrentPosition(
        (pos) => { clearTimeout(guard); finish({ lat: pos.coords.latitude, lng: pos.coords.longitude }); },
        () => { clearTimeout(guard); finish(null); },
        { enableHighAccuracy: highAccuracy, timeout, maximumAge: 600000 },
      );
    } catch (e) { clearTimeout(guard); finish(null); }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// useCall.js — خطّاف واحد يجمع المكالمة في التطبيق كلّه.
//
// لماذا خطّاف واحد في الأعلى (App) لا نسخة في كل شاشة: قناة الإشارات واحدة لكل
// حساب، ومكالمة واحدة في الوقت نفسه. النسخ المتعدّدة تعني رنينًا يُقرأ مرّتين
// ومكالمة تُنهى من نسخة لا تعلم بالأخرى.
// ─────────────────────────────────────────────────────────────────────────────
import { useEffect, useRef, useState } from 'react';
import { createCallClient } from './rtc.js';

const EMPTY = {
  phase: 'idle',
  call: null,
  channel: '',
  durationSec: 0,
  muted: false,
  camOff: false,
  facing: 'user',
  localReady: false,
  remoteReady: false,
  notice: '',
  error: '',
  online: [],
  peerMuted: false,
  peerCamOff: false,
};

export function useCall({ onChatChanged, onCallEnded, onNotice } = {}) {
  const [state, setState] = useState(EMPTY);
  const [local, setLocal] = useState(null);
  const [remote, setRemote] = useState(null);
  const clientRef = useRef(null);
  const cbs = useRef({});
  cbs.current = { onChatChanged, onCallEnded, onNotice };

  useEffect(() => {
    const client = createCallClient({
      onEvent: (type, payload) => {
        if (type === 'change') setState((prev) => ({ ...prev, ...payload }));
        else if (type === 'local') setLocal(payload);
        else if (type === 'remote') setRemote(payload);
        else if (type === 'chat') { if (cbs.current.onChatChanged) cbs.current.onChatChanged(payload.personId); }
        else if (type === 'ended') { setLocal(null); setRemote(null); if (cbs.current.onCallEnded) cbs.current.onCallEnded(payload); }
        else if (type === 'presence') {
          if (Array.isArray(payload.list)) setState((p) => ({ ...p, online: payload.list.slice() }));
          else setState((p) => {
            // الحضور قائمة أسماء دائمًا: أي قيمة غير مصفوفة (حالة قديمة أو حمولة ناقصة)
            // تُعامَل كقائمة فارغة — لا نُسقط التطبيق بسبب حقل حضور مشوّه.
            const set = new Set(Array.isArray(p.online) ? p.online : []);
            if (payload.online) set.add(payload.username); else set.delete(payload.username);
            return { ...p, online: [...set] };
          });
        }
      },
    });
    clientRef.current = client;
    return () => { try { client.stop(); } catch (e) { /* تجاهل */ } };
  }, []);

  const at = (fn) => async (...args) => {
    const client = clientRef.current;
    if (!client) return { ok: false };
    return client[fn](...args);
  };

  return {
    state,
    local,
    remote,
    online: state.online,
    actions: {
      start: async (personId, kind) => {
        const client = clientRef.current;
        if (!client) return { ok: false };
        const out = await client.start(personId, kind);
        if (out && out.ok === false && cbs.current.onNotice) cbs.current.onNotice(out.error, 'error');
        return out;
      },
      accept: at('accept'),
      reject: at('reject'),
      hangup: at('hangup'),
      toggleMute: () => clientRef.current && clientRef.current.toggleMute(),
      toggleCam: () => clientRef.current && clientRef.current.toggleCam(),
      flipCamera: at('flipCamera'),
      dismiss: () => clientRef.current && clientRef.current.dismiss(),
    },
  };
}

// ── خزنة الجهاز: ملف واحد على جهاز المستخدم ──────────────────────────────
// الفكرة: المحادثات والبيانات التي يحتاجها التطبيق تُكتب أيضًا في ملف يختاره
// المستخدم بنفسه على جهازه (سوى-بياناتي.json)، وتُحدَّث تلقائيًا بعد كل تغيير.
// ملف واحد يحمل نسخة كاملة — يُستعاد منه على أي جهاز آخر بلا خادم ولا حساب.
//
// تقنياً: File System Access API (`showSaveFilePicker`) حيث توجد (كروم على
// أندرويد والحاسوب)، والمقبض يُحفظ في IndexedDB فيبقى بعد إغلاق التطبيق.
// وحيث لا توجد (سفاري على آيفون) نُبقي الطريق نفسه: تنزيل نسخة + استعادة من
// ملف — فلا يبقى مستخدم بلا وسيلة.
const HANDLE_KEY = 'vault';
const META_KEY = 'sawa.vault.meta';
export const VAULT_NAME = 'سوى-بياناتي.json';
const VAULT_KIND = 'sawa-vault';
const VAULT_VERSION = 1;

// الحقول التي تخصّ المستخدم في بيانات الإقلاع — هي ما يُحفظ في الملف.
const KEEP = [
  'me', 'people', 'chats', 'whispers', 'states', 'rooms', 'meetings',
  'notifications', 'circles', 'memberships',
];

export function vaultSupported() {
  return typeof window !== 'undefined' && typeof window.showSaveFilePicker === 'function';
}

export function readMeta() {
  try {
    const m = JSON.parse(localStorage.getItem(META_KEY) || 'null');
    return m && typeof m === 'object' ? m : null;
  } catch (e) { return null; }
}

function writeMeta(meta) {
  try { localStorage.setItem(META_KEY, JSON.stringify(meta)); } catch (e) { /* تجاهل */ }
}

// ── مقبض الملف في IndexedDB (يبقى بعد إغلاق التطبيق) ──
function idb() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('sawa.vault', 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('handles')) db.createObjectStore('handles');
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbPut(value) {
  try {
    const db = await idb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction('handles', 'readwrite');
      tx.objectStore('handles').put(value, HANDLE_KEY);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch (e) { /* بلا مقبض محفوظ: نُكمل بالتنزيل */ }
}

async function idbGet() {
  try {
    const db = await idb();
    const value = await new Promise((resolve, reject) => {
      const tx = db.transaction('handles', 'readonly');
      const r = tx.objectStore('handles').get(HANDLE_KEY);
      r.onsuccess = () => resolve(r.result || null);
      r.onerror = () => reject(r.error);
    });
    db.close();
    return value;
  } catch (e) { return null; }
}

export async function idbDelete() {
  try {
    const db = await idb();
    await new Promise((resolve) => {
      const tx = db.transaction('handles', 'readwrite');
      tx.objectStore('handles').delete(HANDLE_KEY);
      tx.oncomplete = resolve;
      tx.onerror = resolve;
    });
    db.close();
  } catch (e) { /* تجاهل */ }
  try { localStorage.removeItem(META_KEY); } catch (e) { /* تجاهل */ }
}

// الصلاحية تُفقد مع إغلاق المتصفح: تُسأل مرة أخرى من داخل ضغطة زر (لا تلقائيًا).
async function permission(handle, request) {
  if (!handle || !handle.queryPermission) return 'granted';
  const opts = { mode: 'readwrite' };
  let state = await handle.queryPermission(opts);
  if (state === 'prompt' && request) state = await handle.requestPermission(opts);
  return state;
}

// ── بناء النسخة ──
export function buildSnapshot(data, account) {
  const out = { kind: VAULT_KIND, version: VAULT_VERSION, savedAt: new Date().toISOString() };
  KEEP.forEach((k) => { if (data && data[k] !== undefined) out[k] = data[k]; });
  out.athar = (data && Array.isArray(data.atharMine) ? data.atharMine : (data && data.athar)) || [];
  out.account = account
    ? { name: account.name, username: account.username, phoneMasked: account.phoneMasked, city: account.city }
    : null;
  return out;
}

// ── اختيار ملف على الجهاز (فتحه/إنشاؤه) ثم كتابة أول نسخة ──
export async function pickVault(data, account) {
  const handle = await window.showSaveFilePicker({
    suggestedName: VAULT_NAME,
    types: [{ description: 'نسخة سوى', accept: { 'application/json': ['.json'] } }],
  });
  await idbPut(handle);
  const res = await writeToHandle(handle, buildSnapshot(data, account));
  writeMeta({ name: handle.name, lastAt: res.at, bytes: res.bytes, ok: true });
  return { name: handle.name, ...res };
}

async function writeToHandle(handle, snapshot) {
  const w = await handle.createWritable();
  const text = JSON.stringify(snapshot, null, 2);
  await w.write(text);
  await w.close();
  return { at: snapshot.savedAt, bytes: new Blob([text]).size };
}

// ── الحفظ التلقائي: صامت تمامًا، وبلا سؤال صلاحية في وجه المستخدم ──
// إن لم يكن هناك مقبض أو انتهت صلاحيته، نكتفي بتسجيل أن هناك نسخة معلّقة،
// ونُظهر ذلك في اللوحة — لا نُقاطع المستخدم بنافذة اختيار ملف.
export async function autoSave(data, account) {
  const handle = await idbGet();
  if (!handle) return { skipped: 'no-handle' };
  const state = await permission(handle, false);
  if (state !== 'granted') {
    const meta = readMeta() || {};
    writeMeta({ ...meta, pending: true, name: handle.name });
    return { skipped: 'permission' };
  }
  try {
    const res = await writeToHandle(handle, buildSnapshot(data, account));
    writeMeta({ name: handle.name, lastAt: res.at, bytes: res.bytes, ok: true, pending: false });
    return { name: handle.name, ...res };
  } catch (e) {
    return { error: e && e.message ? e.message : 'تعذّر الحفظ' };
  }
}

// كتابة فورية بضغطة زر (تطلب الصلاحية إن لزمت — وهي داخل تفاعل المستخدم)
export async function saveNow(data, account) {
  const handle = await idbGet();
  if (!handle) return { error: 'لم يُختر ملف بعد' };
  const state = await permission(handle, true);
  if (state !== 'granted') return { error: 'لم يُسمح بالكتابة في الملف' };
  try {
    const res = await writeToHandle(handle, buildSnapshot(data, account));
    writeMeta({ name: handle.name, lastAt: res.at, bytes: res.bytes, ok: true, pending: false });
    return { name: handle.name, ...res };
  } catch (e) {
    return { error: e && e.message ? e.message : 'تعذّر الحفظ' };
  }
}

export async function readVault() {
  const handle = await idbGet();
  if (!handle) return { error: 'لم يُختر ملف بعد' };
  const state = await permission(handle, true);
  if (state !== 'granted') return { error: 'لم يُسمح بقراءة الملف' };
  const file = await handle.getFile();
  const text = await file.text();
  return parseVault(text, file.name);
}

export async function readFileObject(file) {
  const text = await file.text();
  return parseVault(text, file.name);
}

export function parseVault(text, name) {
  let doc = null;
  try { doc = JSON.parse(text); } catch (e) {
    return { error: 'الملف ليس نسخة سوى صالحة (JSON غير مقروء)' };
  }
  if (!doc || doc.kind !== VAULT_KIND) {
    return { error: 'هذا الملف ليس نسخة «سوى» — اختر ملفًا أنشأه التطبيق' };
  }
  return { ok: true, name: name || '', doc };
}

// استعادة على الجهاز الحالي: نُطبّق ما في الملف على العرض فورًا.
export function applySnapshot(prev, doc) {
  const next = { ...(prev || {}) };
  KEEP.forEach((k) => { if (doc[k] !== undefined) next[k] = doc[k]; });
  next.athar = doc.athar || [];
  return next;
}

export function downloadSnapshot(data, account) {
  const snapshot = buildSnapshot(data, account);
  const text = JSON.stringify(snapshot, null, 2);
  const url = URL.createObjectURL(new Blob([text], { type: 'application/json' }));
  const a = document.createElement('a');
  a.href = url;
  a.download = VAULT_NAME;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
  writeMeta({ name: VAULT_NAME, lastAt: snapshot.savedAt, bytes: new Blob([text]).size, ok: true });
  return { at: snapshot.savedAt, bytes: new Blob([text]).size };
}

export function countOf(doc) {
  const n = (v) => (Array.isArray(v) ? v.length : 0);
  const messages = n(doc.chats) ? doc.chats.reduce((s, c) => s + n(c && c.messages), 0) : 0;
  return {
    people: n(doc.people), chats: n(doc.chats), messages,
    whispers: n(doc.whispers), athar: n(doc.athar), states: n(doc.states),
  };
}

export function sizeLabel(bytes) {
  const b = Number(bytes || 0);
  if (!b) return '—';
  if (b < 1024) return `${b} بايت`;
  if (b < 1024 * 1024) return `${Math.round(b / 102.4) / 10} ك.ب`;
  return `${Math.round(b / 104857.6) / 10} م.ب`;
}

export function timeLabel(iso) {
  if (!iso) return 'لم يُحفظ بعد';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return 'لم يُحفظ بعد';
  const mins = Math.floor((Date.now() - d.getTime()) / 60000);
  if (mins < 1) return 'الآن';
  if (mins < 60) return `قبل ${mins} دقيقة`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `قبل ${hrs} ساعة`;
  return d.toLocaleDateString('ar-OM');
}

import { getToken } from './auth.js';

// عنوان الـ API نسبي إلى أصل الصفحة — يعمل على مسار النشر وعلى المضيف الفرعي
export function apiUrl(path) {
  const clean = String(path).replace(/^\/+/, '');
  try {
    return new URL(clean, document.baseURI).toString();
  } catch (e) {
    return clean;
  }
}

async function request(path, options) {
  const token = getToken();
  const res = await fetch(apiUrl(path), {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'x-sawa-token': token } : {}),
    },
    ...options,
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    // نحمل حالة الرد وجسمه على الخطأ: الواجهة تحتاج 401 (جلسة منتهية) و429 (محاولات)
    const err = new Error((data && data.error) || `HTTP ${res.status}`);
    err.status = res.status;
    err.body = data;
    err.code = (data && data.code) || ''; // session_replaced = أُغلقت الجلسة بدخول من مكان آخر
    throw err;
  }
  return data;
}

const qs = (obj) => {
  const sp = new URLSearchParams();
  Object.entries(obj || {}).forEach(([k, v]) => { if (v !== undefined && v !== null) sp.set(k, String(v)); });
  const out = sp.toString();
  return out ? `?${out}` : '';
};

export const api = {
  // ── الدخول بالهاتف ──
  authDemo: () => request('api/auth/demo'),
  authOtp: (phone) => request('api/auth/otp', { method: 'POST', body: JSON.stringify({ phone }) }),
  authVerify: (payload) => request('api/auth/verify', { method: 'POST', body: JSON.stringify(payload) }),
  authSession: () => request('api/auth/session'),
  authLogout: () => request('api/auth/logout', { method: 'POST', body: '{}' }),
  // فحص توفّر اسم المستخدم أثناء الكتابة (بلا بيانات حساب)
  usernameCheck: (u) => request(`api/auth/username${qs({ u })}`),
  // التواصل باسم المستخدم: بحث بلا رقم هاتف، ثم إضافة تفتح محادثة
  lookupUsername: (username) => request(`api/people/lookup${qs({ username })}`),
  addByUsername: (username) =>
    request('api/circle/from-username', { method: 'POST', body: JSON.stringify({ username }) }),
  bootstrap: () => request('api/bootstrap'),
  athar: (p) => request(`api/athar${qs(p)}`),
  createAthar: (payload) => request('api/athar', { method: 'POST', body: JSON.stringify(payload) }),
  visitAthar: (id) => request(`api/athar/${id}/visit`, { method: 'POST', body: '{}' }),
  createState: (payload) => request('api/states', { method: 'POST', body: JSON.stringify(payload) }),
  uploadMedia: (payload) => request('api/media', { method: 'POST', body: JSON.stringify(payload) }),
  seenState: (id) => request(`api/states/${id}/seen`, { method: 'POST', body: '{}' }),
  deleteState: (id) => request(`api/states/${id}/delete`, { method: 'POST', body: '{}' }),
  respond: (id, choice) =>
    request(`api/states/${id}/respond`, { method: 'POST', body: JSON.stringify({ choice }) }),
  whisper: (id, to, text) =>
    request(`api/states/${id}/whisper`, { method: 'POST', body: JSON.stringify({ to, text }) }),
  // الهمسة صارت محادثة: بدء، ردّ، تقييم، سؤال عن صاحبها، وتعريف بالنفس
  whisperStart: (to, text, stateId) =>
    request('api/whispers', { method: 'POST', body: JSON.stringify({ to, text, stateId: stateId || null }) }),
  whisperSend: (id, text) =>
    request(`api/whispers/${id}/send`, { method: 'POST', body: JSON.stringify({ text }) }),
  whisperReact: (id, kind) =>
    request(`api/whispers/${id}/react`, { method: 'POST', body: JSON.stringify({ kind }) }),
  whisperAsk: (id) => request(`api/whispers/${id}/ask`, { method: 'POST', body: '{}' }),
  whisperReveal: (id, yes) =>
    request(`api/whispers/${id}/reveal`, { method: 'POST', body: JSON.stringify({ yes: yes !== false }) }),
  whisperRead: (id) => request(`api/whispers/${id}/read`, { method: 'POST', body: '{}' }),
  whisperDelete: (id) => request(`api/whispers/${id}/delete`, { method: 'POST', body: '{}' }),
  createRoom: (payload) => request('api/rooms', { method: 'POST', body: JSON.stringify(payload) }),
  joinRoom: (id) => request(`api/rooms/${id}/join`, { method: 'POST', body: '{}' }),
  readRoom: (id) => request(`api/rooms/${id}/read`, { method: 'POST', body: '{}' }),
  sendRoomMessage: (id, text) =>
    request(`api/rooms/${id}/messages`, { method: 'POST', body: JSON.stringify({ text }) }),
  closeRoom: (id) => request(`api/rooms/${id}/close`, { method: 'POST', body: '{}' }),
  addMemory: (id, text) =>
    request(`api/rooms/${id}/memory`, { method: 'POST', body: JSON.stringify({ text }) }),
  createMeeting: (payload) => request('api/meetings', { method: 'POST', body: JSON.stringify(payload) }),
  vote: (id, slotId) =>
    request(`api/meetings/${id}/vote`, { method: 'POST', body: JSON.stringify({ slotId }) }),
  confirmMeeting: (id, payload) =>
    request(`api/meetings/${id}/confirm`, { method: 'POST', body: JSON.stringify(payload || {}) }),
  sendMessage: (personId, text, media) =>
    request(`api/chats/${personId}/send`, {
      method: 'POST',
      body: JSON.stringify(media ? { text: text || '', media } : { text }),
    }),
  readChat: (personId) => request(`api/chats/${personId}/read`, { method: 'POST', body: '{}' }),
  // ── طبقة الخصوصية الخادمية (v31) ──
  // كل مسار هنا يحتاج جلسة صالحة، ويُرجع ما يحقّ للحساب رؤيته فقط (١.٤ و ١.٥).
  v31State: () => request('api/v31/state'),
  v31WhoSees: () => request('api/v31/who-sees'),
  v31Circles: () => request('api/v31/circles'),
  v31CreateCircle: (payload) => request('api/v31/circles', { method: 'POST', body: JSON.stringify(payload || {}) }),
  v31AddMembers: (id, memberIds) =>
    request(`api/v31/circles/${id}/members`, { method: 'POST', body: JSON.stringify({ memberIds }) }),
  v31RemoveMember: (id, accountId) =>
    request(`api/v31/circles/${id}/remove`, { method: 'POST', body: JSON.stringify({ accountId }) }),
  v31DeleteCircle: (id) => request(`api/v31/circles/${id}/delete`, { method: 'POST', body: '{}' }),
  v31Block: (accountId, block) =>
    request('api/v31/blocks', { method: 'POST', body: JSON.stringify({ accountId, block }) }),
  v31Grid: (since) => request(`api/v31/athar/grid${qs({ since })}`),
  v31Cell: (gx, gy) => request('api/v31/athar/cell', { method: 'POST', body: JSON.stringify({ gx, gy }) }),
  v31Sync: (since) => request(`api/v31/athar/sync${qs({ since })}`),
  v31AtharOne: (id) => request(`api/v31/athar/${id}`),
  v31CreateAthar: (payload) => request('api/v31/athar', { method: 'POST', body: JSON.stringify(payload) }),
  v31VisitAthar: (id) => request(`api/v31/athar/${id}/visit`, { method: 'POST', body: '{}' }),
  v31DeleteAthar: (id) => request(`api/v31/athar/${id}/delete`, { method: 'POST', body: '{}' }),
  v31Device: (payload) => request('api/v31/devices', { method: 'POST', body: JSON.stringify(payload || {}) }),
  v31Presence: () => request('api/v31/presence', { method: 'POST', body: '{}' }),
  v31ContactsKey: () => request('api/v31/contacts/key'),
  v31ContactsMatch: (fingerprints) =>
    request('api/v31/contacts/match', { method: 'POST', body: JSON.stringify({ fingerprints }) }),
  v31WhisperSend: (to, text, stateId) =>
    request('api/v31/whisper/send', { method: 'POST', body: JSON.stringify({ to, text, stateId: stateId || null }) }),
  v31WhisperInbox: () => request('api/v31/whisper/inbox'),
  v31WhisperStatus: () => request('api/v31/whisper/status'),
  v31WhisperAck: (ids) => request('api/v31/whisper/ack', { method: 'POST', body: JSON.stringify({ ids }) }),
  // ── الاتصال الصوتي والمرئي (v32) ──
  // الصعود من هنا (وكل إشارة تحمل رمز الجلسة في الترويسة)، والنزول على القناة
  // الحيّة في rtc.js — لا سؤال دوري عن الحالة أثناء المكالمة.
  rtcState: () => request('api/rtc/state'),
  rtcIce: () => request('api/rtc/ice'),
  rtcHistory: (personId) => request(`api/rtc/history${qs({ personId })}`),
  rtcSignal: (payload) => request('api/rtc/signal', { method: 'POST', body: JSON.stringify(payload || {}) }),
  saveMe: (payload) => request('api/me', { method: 'POST', body: JSON.stringify(payload) }),
  readAll: () => request('api/notifications/read', { method: 'POST', body: '{}' }),
  invite: (payload) => request('api/circle/invite', { method: 'POST', body: JSON.stringify(payload) }),
  reset: () => request('api/reset', { method: 'POST', body: JSON.stringify({ confirm: 'reset' }) }),
};

import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './styles.css';

// عامل الخدمة يُسجَّل فورًا لا بعد load — الزيارة التالية تُفتح من الذاكرة بلا شبكة.
// (كان يُسجَّل بعد load، فتفقد أول زيارة فرصة التحضير المسبق.)
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => null);
}

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

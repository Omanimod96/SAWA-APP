import React, { useEffect, useMemo, useState } from 'react';
import { Plus, Sparkles, DoorOpen, Loader2, ChevronLeft } from 'lucide-react';
import StoriesStrip from './StoriesStrip.jsx';
import StoryViewer from './StoryViewer.jsx';
import StoryComposer from './StoryComposer.jsx';
import CameraCapture from './CameraCapture.jsx';
import StateCard from './StateCard.jsx';
import RoomsSheet from './RoomsSheet.jsx';

const MEDIA_TYPES = ['image', 'video', 'audio'];
const isMediaState = (s) => Boolean(s.media && MEDIA_TYPES.includes(s.media.type));

export default function StatesView({ data, actions, busy, goTab, onError, onOpenWhisper }) {
  const [composer, setComposer] = useState(false);
  // «إنشاء حالة» يبدأ من الكاميرا: صورة بضغطة، أو استوديو، أو X للرجوع.
  const [camera, setCamera] = useState(false);
  const [readyFile, setReadyFile] = useState(null); // ما التُقط/اختير، ليُعرض جاهزًا في النموذج
  const [viewing, setViewing] = useState(null);
  // الغرف صارت داخل نافذة الحالات: ورقة واحدة، وبطاقة الغرفة تفتح غرفتها مباشرة
  const [rooms, setRooms] = useState(false);
  const [roomFocus, setRoomFocus] = useState(null); // { id, at } — كل طلب يحمل بصمته
  const me = data.me;
  const [now, setNow] = useState(() => Date.now());

  // تحديث محلي كل ثانية حتى تختفي الحالة في لحظة انتهاء مدتها، دون انتظار
  // دورة التحديث الشبكي في App (45 ثانية).
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const activeStates = useMemo(
    () => data.states.filter((s) => {
      const expiresAt = Date.parse(s.expiresIn);
      return Number.isFinite(expiresAt) && expiresAt > now;
    }),
    [data.states, now]
  );

  const mediaStates = useMemo(() => activeStates.filter(isMediaState), [activeStates]);
  const textStates = useMemo(() => activeStates.filter((s) => !isMediaState(s)), [activeStates]);

  // الشريط الأفقي = حالات الوسائط فقط (صورة / فيديو / صوت)، مجمّعة حسب الشخص
  const groups = useMemo(() => {
    const out = [];
    mediaStates.forEach((s) => {
      const person = s.author === 'u-me'
        ? { id: 'u-me', name: me.name || 'أنت', color: me.avatarColor || '#1D4ED8', relation: 'أنت', mine: true }
        : (data.people.find((p) => p.id === s.author) || { id: s.author, name: 'أحد الدائرة', color: '#64748B', relation: 'دائرة' });
      let g = out.find((x) => x.person.id === person.id);
      if (!g) { g = { person, states: [], unseen: false, mine: Boolean(person.mine) }; out.push(g); }
      g.states.push(s);
      if (!s.seen && !person.mine && s.msLeft) g.unseen = true;
    });
    // حالتك أولًا، ثم من لديه جديد، ثم البقية
    return out.sort((a, b) => (a.mine === b.mine ? Number(b.unseen) - Number(a.unseen) : a.mine ? -1 : 1));
  }, [mediaStates, data.people, me]);

  const openRooms = data.rooms.filter((r) => r.status === 'open');
  const freshRooms = openRooms.filter((r) => !r.joined).length;
  const insideRooms = openRooms.filter((r) => r.joined).length;
  const atharRooms = data.rooms.filter((r) => r.status !== 'open' && r.joined).length;
  const roomUnread = data.roomsUnread
    || data.rooms.reduce((sum, r) => sum + (r.unread || 0), 0);
  const myGroup = groups.find((g) => g.mine) || null;

  return (
    <div className="view docked">
      <div className="pinned rooms-entry-wrap">
        <button
          className={`rooms-entry${openRooms.length ? ' live' : ''}`}
          onClick={() => { setRoomFocus(null); setRooms(true); }}
          aria-label="افتح نافذة الغرف"
        >
          <span className="re-icon"><DoorOpen size={17} strokeWidth={1.9} /></span>
          <span className="re-txt">
            <b>الغرف</b>
            <small>
              {openRooms.length === 0
                ? 'لا غرفة مفتوحة الآن'
                : `${openRooms.length} مفتوحة — ${freshRooms} جديدة · ${insideRooms} داخلها`}
              {atharRooms > 0 ? ` · ${atharRooms} صارت أثرًا` : ''}
            </small>
          </span>
          {roomUnread > 0 && <span className="re-unread">{roomUnread}</span>}
          <ChevronLeft className="re-go" size={17} strokeWidth={1.9} />
        </button>
      </div>

      <StoriesStrip
        groups={groups}
        me={me}
        myGroup={myGroup}
        myIndex={Math.max(0, groups.findIndex((g) => g.mine))}
        busy={busy}
        onOpen={(i) => setViewing(i)}
        onAdd={() => setCamera(true)}
      />

      <div className="cta-dock">
        <button
          className="fab-add"
          onClick={() => setCamera(true)}
          disabled={busy}
          aria-label="أنشئ حالة — الكاميرا"
          title="أنشئ حالة"
        >
          <Plus size={26} strokeWidth={2} />
        </button>
      </div>

      {busy && (
        <div className="inline-busy">
          <Loader2 className="spin" size={14} strokeWidth={2} /> يجهّز حالتك…
        </div>
      )}

      {textStates.length === 0 ? (
        <div className="empty small">
          <div className="circle"><Sparkles size={20} strokeWidth={1.8} /></div>
          <strong>لا حالات نصية حاليًا</strong>
        </div>
      ) : (
        textStates.map((s, i) => (
          <div key={s.id} className={`fade-up d${(i % 3) + 1}`}>
            <StateCard
              state={s}
              people={data.people}
              me={me}
              index={i}
              onRespond={(id, key) => actions.respond(id, key)}
              onWhisper={(id, to, text) => actions.whisper(id, to, text)}
              onOpenWhisper={onOpenWhisper}
              onOpenRoom={(roomId) => { setRoomFocus({ id: roomId || null, at: Date.now() }); setRooms(true); }}
            />
          </div>
        ))
      )}

      {viewing !== null && groups.length > 0 && (
        <StoryViewer
          groups={groups}
          start={Math.min(viewing, groups.length - 1)}
          actions={actions}
          busy={busy}
          onSeen={actions.markSeen}
          goRooms={() => { setViewing(null); setRoomFocus(null); setRooms(true); }}
          onClose={() => setViewing(null)}
        />
      )}

      <StoryComposer
        open={composer}
        busy={busy}
        actions={actions}
        onError={onError}
        me={me}
        people={data.people}
        initialFile={readyFile}
        onOpenRooms={() => { setRoomFocus(null); setRooms(true); }}
        onClose={() => { setComposer(false); setReadyFile(null); }}
      />

      <RoomsSheet
        open={rooms}
        data={data}
        actions={actions}
        busy={busy}
        focus={roomFocus}
        onClose={() => setRooms(false)}
        onGoAthar={() => goTab('athar')}
      />

      <CameraCapture
        open={camera}
        kind="image"
        onClose={() => setCamera(false)}
        onMedia={(file) => { setReadyFile(file); setCamera(false); setComposer(true); }}
        onText={() => { setCamera(false); setComposer(true); }}
      />
    </div>
  );
}

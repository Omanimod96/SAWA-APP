import React from 'react';
import { MapPin, Clock, Footprints, Plus, Route, Sparkles, Lock, CalendarDays, UserPlus } from 'lucide-react';
import Avatar from './Avatar.jsx';
import Sheet from './Sheet.jsx';
import { apiUrl } from '../api.js';

const toneChipStyle = (hex) => ({ background: `${hex}22`, color: hex, borderColor: `${hex}55` });

function ToneTag({ hex, label }) {
  return <span className="tag tone" style={toneChipStyle(hex)}>{label}</span>;
}

// ورقة تفاصيل الومضة: من شارك في هذا المكان وماذا كتب
export default function PulseSheet({ pulse, items, onClose, onVisit, onCompose, busy, canVisit }) {
  const list = (items || []).filter((i) => pulse.items.includes(i.id));
  const people = [...new Map(list.map((i) => [i.author, i])).values()];
  return (
    <Sheet title="ومضة المكان" onClose={onClose}>
      <div className="pulse-head">
        <span className="pulse-orb" style={{ '--tone': pulse.tone }} aria-hidden="true"><i /></span>
        <div className="grow">
          <h4>{pulse.placeName}</h4>
          <div className="meta">
            <MapPin size={12} strokeWidth={1.8} /> {pulse.distanceLabel} منك
            <span className="sep">·</span><Clock size={12} strokeWidth={1.8} /> {pulse.ageLabel}
          </div>
        </div>
        <ToneTag hex={pulse.tone} label={pulse.tierLabel} />
      </div>

      <div className="stat-row">
        <div><b>{pulse.count}</b><span>آثار هنا</span></div>
        <div><b>{people.length}</b><span>من دائرتك</span></div>
        <div><b>{pulse.visits}</b><span>زيارة موثّقة</span></div>
      </div>

      <div className="actions">
        <button
          className={`btn sm ${canVisit ? 'btn-primary' : 'btn-ghost'}`}
          onClick={() => onVisit(pulse)}
          disabled={busy || !canVisit}
          title={canVisit ? 'أضف زيارة لهذا المكان' : 'الزيارة تُحسب عندما تزور أثرًا لغيرك'}
        >
          <Footprints size={15} strokeWidth={1.8} /> زرت هذا المكان
        </button>
        <button className="btn btn-ghost sm" onClick={() => onCompose(pulse)}>
          <Plus size={15} strokeWidth={1.8} /> أوثّق أثرًا هنا
        </button>
      </div>

      <ul className="memory-list">
        {list.map((it) => (
          <li key={it.id}>
            <Avatar name={it.authorName} color={it.authorColor} photo={it.authorAvatar} size="sm" />
            <div className="grow">
              <div className="who-line">
                <strong>{it.mine ? 'أنت' : it.authorName}</strong>
                <span className="muted">{it.ageLabel}</span>
                {it.mine && (
                  <span className="tag tiny">
                    <Lock size={10} strokeWidth={2} /> {it.audienceLabel}
                  </span>
                )}
              </div>
              <p className={it.bg ? 'memory-text' : undefined} style={it.bg ? { background: it.bg } : undefined}>{it.text}</p>
              {(it.whenLabel || (it.companionView || []).length > 0) && (
                <div className="memory-link">
                  {it.whenLabel && (
                    <span className="tag tiny" data-when={it.whenLabel}>
                      <CalendarDays size={10} strokeWidth={2} /> {it.whenLabel}
                    </span>
                  )}
                  {(it.companionView || []).length > 0 && (
                    <span className="tag tiny with" data-companions={(it.companionView || []).length}>
                      <UserPlus size={10} strokeWidth={2} /> مع {(it.companionNames || []).length > 2
                        ? `${(it.companionNames || [])[0]} و${(it.companionNames || []).length - 1} آخرين`
                        : (it.companionNames || []).join(' و ')}
                    </span>
                  )}
                </div>
              )}
              {it.media && it.media.type === 'image' && (
                <img className="memory-img" src={apiUrl(it.media.url)} alt="" loading="lazy" />
              )}
            </div>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

// قائمة الأماكن: بديل نصّي للخريطة — الأقرب أولًا
export function PlaceList({ pulses, radiusKm, onOpen, onFocus, onClose }) {
  if (!pulses.length) return null;
  return (
    <Sheet title={`الأماكن داخل ${radiusKm} كم`} onClose={onClose}>
      <ul className="place-list">
        {pulses.map((p) => (
          <li key={p.id} className="place-row">
            <button type="button" className="place-open" onClick={() => onOpen(p)}>
              <span className="place-orb" style={{ '--tone': p.tone, '--size': `${16 + p.intensity * 18}px` }}><i /></span>
              <span className="grow">
                <strong>{p.placeName}</strong>
                <span className="meta">
                  {p.count} {p.count === 1 ? 'أثر' : 'آثار'} · {p.distanceLabel} · {p.ageLabel}
                </span>
              </span>
            </button>
            <button
              type="button"
              className="iconbtn sm"
              aria-label={`أظهر ${p.placeName} على الخريطة`}
              onClick={() => onFocus(p)}
            >
              <Route size={15} strokeWidth={1.8} />
            </button>
          </li>
        ))}
      </ul>
    </Sheet>
  );
}

export function Legend({ legend }) {
  return (
    <div className="legend" aria-label="دلالة ألوان الومضات">
      <Sparkles size={13} strokeWidth={1.8} />
      {legend.map((t, i) => (
        <span key={t.hex} className="legend-item">
          <i style={{ background: t.hex }} />
          {t.label}
          {i < legend.length - 1 ? <em className="sep">·</em> : null}
        </span>
      ))}
    </div>
  );
}

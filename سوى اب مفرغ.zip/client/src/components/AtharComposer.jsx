import React, { useMemo, useRef, useState } from 'react';
import { MapPin, Crosshair, ImagePlus, X, Loader2, Send, Users, UserPlus, CalendarDays } from 'lucide-react';
import Sheet from './Sheet.jsx';
import AtharMap from './AtharMap.jsx';
import { zoomForRadius } from '../map.js';
import { TYPE_OF, shrinkImage, fmtSize } from '../media.js';
import { ensure, hintFor } from '../permissions.js';

// «متى كانت الذكرى»: بصيغة YYYY-MM-DD كما يفهمها حقل التاريخ في الجوّال
const todayIso = () => new Date().toISOString().slice(0, 10);
const isoDaysAgo = (n) => new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);

// ورقة توثيق أثر: خريطة صغيرة داخل الورقة نفسها لاختيار المكان بلا مغادرة النموذج
export default function AtharComposer({
  seed, me, people, origin, located, placeNames, pulses, onLocate, onClose, onPublish, busy, dark,
}) {
  const start = seed && Number.isFinite(seed.lat) ? { lat: seed.lat, lng: seed.lng } : origin;
  const [view, setView] = useState(start);
  const [zoom, setZoom] = useState(() => Math.max(10, zoomForRadius(start.lat, 12, 210)));
  const [name, setName] = useState((seed && seed.name) || '');
  const [text, setText] = useState('');
  const [audience, setAudience] = useState({ scope: 'circle', groups: [], people: [] });
  const [media, setMedia] = useState(null);
  const [companions, setCompanions] = useState([]);
  const [when, setWhen] = useState(() => todayIso());
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState('');
  const fileRef = useRef(null);

  const point = view;
  const circles = (me && me.circles) || [];
  const coords = `${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}`;

  // الصورة من جهازك: إذن واحد (لا يطلبه المتصفح أصلًا للاستوديو) ثم نفتح المنتقي
  const pickImage = async () => {
    const res = await ensure('media', { force: true, reason: 'لتختار صورة من جهازك وتوثّقها مع أثرك.' });
    if (!res.ok) { if (res.reason !== 'later') setErr(hintFor(res)); return; }
    if (fileRef.current) fileRef.current.click();
  };

  const onFile = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    if (TYPE_OF(file) !== 'image') { setErr('صورة واحدة تكفي — الفيديو مكانه الحالة'); return; }
    if (file.size > 6 * 1024 * 1024) { setErr('حجم الصورة أكبر من 6 ميجابايت'); return; }
    setErr('');
    setUploading(true);
    try {
      const small = await shrinkImage(file, 1400, 0.84);
      setMedia({ dataUrl: small.dataUrl, size: small.size, name: file.name });
    } catch (ex) {
      setErr(ex.message || 'تعذّر معالجة الصورة');
    } finally {
      setUploading(false);
    }
  };

  // رفاق الذكرى: حتى ثمانية، والضغط مرة أخرى يزيل الاسم
  const toggleCompanion = (pid) => setCompanions((list) => (
    list.includes(pid) ? list.filter((x) => x !== pid) : [...list, pid].slice(0, 8)
  ));

  const whenLabel = useMemo(() => {
    if (!when) return 'بلا تاريخ محدّد';
    if (when === todayIso()) return 'اليوم';
    if (when === isoDaysAgo(1)) return 'أمس';
    return new Date(`${when}T00:00:00`).toLocaleDateString('ar', { day: 'numeric', month: 'long', year: 'numeric' });
  }, [when]);

  const toggleGroup = (g) => setAudience((a) => {    const groups = a.groups.includes(g) ? a.groups.filter((x) => x !== g) : [...a.groups, g];
    return groups.length ? { scope: 'groups', groups, people: [] } : { scope: 'circle', groups: [], people: [] };
  });

  const canSubmit = useMemo(
    () => Boolean(text.trim()) && Boolean(name.trim()) && Boolean(point) && !uploading,
    [text, name, point, uploading]
  );

  const submit = () => {
    if (!text.trim()) { setErr('اكتب ما تريد أن يبقى في هذا المكان'); return; }
    if (!name.trim()) { setErr('اكتب اسم المكان'); return; }
    onPublish({
      place: { name: name.trim(), lat: point.lat, lng: point.lng },
      text: text.trim(),
      media: media ? { dataUrl: media.dataUrl } : null,
      companions,
      when: when || null,
      audience,
    });
  };

  return (
    <Sheet title="أثر جديد" onClose={onClose}>
      <div className="field">
        <label>المكان على الخريطة</label>
        <div className="picker-box">
          <AtharMap
            view={view}
            onView={setView}
            zoom={zoom}
            onZoom={setZoom}
            origin={null}
            pulses={pulses}
            ring={null}
            selectedId={null}
            onSelect={() => {}}
            picking
            dark={dark}
          />
        </div>
        <div className="loc-row">
          <span className="loc-chip"><MapPin size={13} strokeWidth={1.8} /> {coords}</span>
          <button
            type="button"
            className="btn btn-soft sm"
            onClick={async () => {
              const p = await onLocate();
              if (p) setView({ lat: p.lat, lng: p.lng });
              else setErr('تعذّر الوصول إلى موقعك — حرّك الخريطة يدويًا');
            }}
          >
            <Crosshair size={14} strokeWidth={1.8} /> موقعي
          </button>
        </div>
      </div>

      <div className="field">
        <label htmlFor="ath-name">اسم المكان</label>
        <input
          id="ath-name"
          list="ath-places"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="مثال: كورنيش القرم"
          autoComplete="off"
        />
        <datalist id="ath-places">
          {(placeNames || []).map((p) => <option key={p} value={p} />)}
        </datalist>
        {!located && <p className="muted-note small">نبدأ من مركز المدينة.</p>}
      </div>

      <div className="field">
        <label htmlFor="ath-text">ماذا تريد أن يبقى هنا؟</label>
        <textarea
          id="ath-text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="جملة واحدة تكفي — من كان معك، وماذا حدث، وكيف كان المكان."
          maxLength={600}
        />
      </div>

      <div className="field">
        <label htmlFor="ath-when"><CalendarDays size={13} strokeWidth={1.8} /> متى كانت الذكرى؟</label>
        <input
          id="ath-when"
          type="date"
          value={when}
          max={todayIso()}
          onChange={(e) => setWhen(e.target.value)}
        />
        <div className="chips filter">
          <button type="button" className={`chip${when === todayIso() ? ' on' : ''}`} onClick={() => setWhen(todayIso())}>اليوم</button>
          <button type="button" className={`chip${when === isoDaysAgo(1) ? ' on' : ''}`} onClick={() => setWhen(isoDaysAgo(1))}>أمس</button>
          <button type="button" className={`chip${when === isoDaysAgo(365) ? ' on' : ''}`} onClick={() => setWhen(isoDaysAgo(365))}>قبل سنة</button>
        </div>
        <p className="muted-note small" data-when-label={whenLabel}>الذكرى {whenLabel}</p>
      </div>

      <div className="field">
        <label><UserPlus size={13} strokeWidth={1.8} /> من كان معك؟</label>
        <div className="chips filter">
          {(people || []).map((p) => (
            <button
              key={p.id}
              type="button"
              className={`chip${companions.includes(p.id) ? ' on' : ''}`}
              onClick={() => toggleCompanion(p.id)}
            >
              {(p.name || '').split(' ')[0]}
            </button>
          ))}
          {!(people || []).length && <p className="muted-note small">لا أحد في دائرتك بعد — الدعوة تبدأ من تبويب الدائرة.</p>}
        </div>
        {companions.length > 0 && (
          <p className="muted-note small" data-companions={companions.length}>
            معك {companions.length === 1 ? 'شخص واحد' : `${companions.length} أشخاص`} في هذه الذكرى
          </p>
        )}
      </div>

      <div className="field">
        <label>صورة من المكان (اختياري)</label>
        {media ? (
          <div className="media-pick">
            <img src={media.dataUrl} alt="" />
            <div className="grow">
              <strong>{media.name}</strong>
              <span className="muted">{fmtSize(media.size)}</span>
            </div>
            <button type="button" className="iconbtn sm" onClick={() => setMedia(null)} aria-label="إزالة الصورة">
              <X size={15} strokeWidth={2} />
            </button>
          </div>
        ) : (
          <button
            type="button"
            className="btn btn-ghost btn-block"
            onClick={pickImage}
            disabled={uploading}
          >
            {uploading ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <ImagePlus size={16} strokeWidth={1.8} />}
            {uploading ? 'تُجهَّز الصورة…' : 'أضف صورة'}
          </button>
        )}
        <input ref={fileRef} type="file" accept="image/*" onChange={onFile} hidden />
      </div>

      <div className="field">
        <label><Users size={13} strokeWidth={1.8} /> من يرى هذا الأثر؟</label>
        <div className="chips filter">
          <button
            type="button"
            className={`chip${audience.scope === 'circle' ? ' on' : ''}`}
            onClick={() => setAudience({ scope: 'circle', groups: [], people: [] })}
          >
            كل دائرتي
          </button>
          {circles.map((g) => (
            <button key={g} type="button" className={`chip${audience.groups.includes(g) ? ' on' : ''}`} onClick={() => toggleGroup(g)}>
              {g}
            </button>
          ))}
        </div>
      </div>

      {err && <p className="field-err">{err}</p>}

      <div className="actions sticky-actions">
        <button type="button" className="btn btn-primary grow" onClick={submit} disabled={!canSubmit || busy}>
          {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <Send size={16} strokeWidth={1.8} />}
          انشر الأثر
        </button>
        <button type="button" className="btn btn-ghost sm" onClick={onClose}>إلغاء</button>
      </div>
    </Sheet>
  );
}

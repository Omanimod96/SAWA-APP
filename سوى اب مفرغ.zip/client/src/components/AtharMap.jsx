import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { tilesFor, toScreen, panCenter, tileUrl, metersPerPixel, MIN_Z, MAX_Z } from '../map.js';

// قياس مساحة العرض — الخريطة تملأ المساحة المتاحة لا أكثر
function useSize(ref) {
  const [size, setSize] = useState({ w: 0, h: 0 });
  useEffect(() => {
    if (!ref.current) return undefined;
    const el = ref.current;
    const measure = () => setSize({ w: el.clientWidth, h: el.clientHeight });
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ref]);
  return size;
}

export default function AtharMap({
  view, onView, zoom, onZoom, origin, pulses, ring, selectedId, onSelect, picking, dark, children,
}) {
  const wrapRef = useRef(null);
  const { w, h } = useSize(wrapRef);
  const [drag, setDrag] = useState({ x: 0, y: 0 });
  const pointers = useRef(new Map());
  const pinchRef = useRef(null);
  const dragRef = useRef({ x: 0, y: 0 });
  const shift = useCallback((dx, dy) => {
    dragRef.current = { x: dragRef.current.x + dx, y: dragRef.current.y + dy };
    setDrag(dragRef.current);
  }, []);

  // سحب الخريطة: نُزيح الرسم لحظيًا ثم نثبّت المركز عند رفع الإصبع
  const onPointerDown = useCallback((e) => {
    if (picking) return;
    // الأزرار والشرائح فوق الخريطة تُلمس كأزرار لا كسحب — لولا هذا لالتهم السحب نقراتها
    if (e.target && e.target.closest && e.target.closest('button, a, input, select, textarea, label, [role="button"]')) return;
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    e.currentTarget.setPointerCapture(e.pointerId);
  }, [picking]);

  const onPointerMove = useCallback((e) => {
    if (picking || !pointers.current.has(e.pointerId)) return;
    const prev = pointers.current.get(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });

    if (pointers.current.size >= 2) {
      const pts = [...pointers.current.values()];
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      if (pinchRef.current && pinchRef.current.base) {
        const ratio = dist / pinchRef.current.base;
        const next = Math.round(Math.max(MIN_Z, Math.min(MAX_Z, pinchRef.current.zoom + Math.log2(ratio))));
        if (next !== zoom) onZoom(next);
      } else {
        pinchRef.current = { base: dist, zoom };
      }
      return;
    }
    shift(e.clientX - prev.x, e.clientY - prev.y);
  }, [picking, onZoom, zoom, shift]);

  const settle = useCallback((e) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinchRef.current = null;
    const d = dragRef.current;
    if (d.x || d.y) onView(panCenter(view, d.x, d.y, zoom));
    dragRef.current = { x: 0, y: 0 };
    setDrag({ x: 0, y: 0 });
  }, [onView, view, zoom]);

  const step = useCallback((dir) => {
    onZoom(Math.max(MIN_Z, Math.min(MAX_Z, zoom + dir)));
  }, [onZoom, zoom]);

  const tiles = useMemo(() => (w && h ? tilesFor(view, zoom, w + 128, h + 128) : []), [view, zoom, w, h]);
  const cx = w / 2 + drag.x;
  const cy = h / 2 + drag.y;

  // موضع النقطة على الشاشة (نسبةً لمركز العرض ثم إلى منتصف المساحة)
  const screenOf = useCallback((pt) => {
    const s = toScreen(pt, view, zoom);
    return { left: cx + s.x, top: cy + s.y };
  }, [view, zoom, cx, cy]);

  const ringPoints = useMemo(
    () => (ring || []).map((p) => { const s = screenOf(p); return `${s.left.toFixed(1)},${s.top.toFixed(1)}`; }).join(' '),
    [ring, screenOf]
  );
  const scaleKm = metersPerPixel(view.lat, zoom);

  return (
    <div
      className="mapwrap"
      ref={wrapRef}
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={settle}
      onPointerCancel={settle}
      role="application"
      aria-label="خريطة الآثار"
    >
      <div className="tiles" style={{ transform: `translate3d(${drag.x}px, ${drag.y}px, 0)` }}>
        {tiles.map((t) => (
          <img
            key={t.key}
            className="tile"
            src={tileUrl(t.z, t.x, t.y, dark)}
            alt=""
            draggable="false"
            loading="lazy"
            style={{ left: t.left, top: t.top }}
          />
        ))}
      </div>

      <svg className="map-svg" width={w} height={h} aria-hidden="true">
        {ringPoints && (
          <polygon points={ringPoints} className="range-ring" />
        )}
      </svg>

      {origin && (
        <span className="me-dot" style={{ ...screenOf(origin), transform: 'translate(-50%, -50%)' }}>
          <i />
        </span>
      )}

      {pulses.map((p) => {
        const s = screenOf(p);
        const size = 18 + p.intensity * 26;
        const on = p.id === selectedId;
        return (
          <button
            key={p.id}
            type="button"
            className={`pulse${on ? ' on' : ''}${p.mine ? ' mine' : ''}${p.count >= 3 ? ' big' : ''}`}
            style={{
              left: s.left,
              top: s.top,
              '--tone': p.tone,
              '--size': `${Math.round(size)}px`,
              '--dur': `${p.period}ms`,
            }}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => { e.stopPropagation(); onSelect(on ? null : p.id); }}
            aria-label={`${p.placeName} — ${p.count} آثار، ${p.ageLabel}`}
            aria-pressed={on}
          >
            <span className="halo" />
            <span className="ring" />
            <span className="ring r2" />
            <span className="core">{p.count > 1 ? <b>{p.count}</b> : null}</span>
            {(on || p.count >= 3) && <span className="plabel">{p.placeName}</span>}
          </button>
        );
      })}

      {picking && (
        <span className="crosshair" style={{ left: cx, top: cy }} aria-hidden="true">
          <i /><i />
        </span>
      )}

      <div className="map-foot">
        <span className="scalebar" style={{ width: 72 }}>
          {scaleKm * 72 >= 1000 ? `${Math.round((scaleKm * 72) / 1000)} كم` : `${Math.round(scaleKm * 72)} م`}
        </span>
        <span className="attrib">© OpenStreetMap · CARTO</span>
      </div>

      <button type="button" className="zoom-btn zoom-in" onClick={() => step(1)} aria-label="تقريب">+</button>
      <button type="button" className="zoom-btn zoom-out" onClick={() => step(-1)} aria-label="تبعيد">−</button>

      {children}
    </div>
  );
}

import { useEffect, useState } from 'react';

// نبضة كل ثانية: مؤقّت الغرفة ينقص حيًّا بلا انتظار دورة تحديث الشبكة.
export function useTick(ms = 1000) {
  const [n, setN] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setN((v) => v + 1), ms);
    return () => clearInterval(t);
  }, [ms]);
  return n;
}

export const timeOf = (iso) => {
  try { return new Date(iso).toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' }); }
  catch (e) { return ''; }
};

export function dayLabel(iso) {
  const d = new Date(iso);
  const today = new Date();
  const yest = new Date(Date.now() - 864e5);
  const same = (a, b) => a.toDateString() === b.toDateString();
  if (same(d, today)) return 'اليوم';
  if (same(d, yest)) return 'أمس';
  try { return d.toLocaleDateString('ar-OM', { day: 'numeric', month: 'long' }); }
  catch (e) { return ''; }
}

// ختم السطر الأخير في القائمة: ساعة اليوم، وتاريخ ما قبله
export const listStamp = (iso) => (dayLabel(iso) === 'اليوم' ? timeOf(iso) : dayLabel(iso));

// اسم المرسل داخل الغرفة: أنت / اسم العضو
export function senderName(room, from) {
  if (from === 'u-me') return 'أنت';
  const p = (room.roster || []).find((x) => x.id === from);
  return p ? p.name.split(' ')[0] : 'عضو';
}

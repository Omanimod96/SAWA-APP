import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  X, ChevronRight, ChevronLeft, Pause, Play, Mic, Image as ImageIcon, Video,
  MessageSquareDashed, DoorOpen, Trash2, Send, Check, MapPin, Sparkles, Volume2, Lock, Users,
} from 'lucide-react';
import Avatar from './Avatar.jsx';
import { apiUrl } from '../api.js';
import MediaFrame from '../MediaFrame.jsx';

const mUrl = (u) => (u ? apiUrl(u) : '');

function ago(iso) {
  const ms = Date.now() - new Date(iso).getTime();
  const m = Math.max(0, Math.floor(ms / 60000));
  if (m < 1) return 'الآن';
  if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `قبل ${h} ساعة`;
  return `قبل ${Math.floor(h / 24)} يوم`;
}

function Bars({ count, index, progress }) {
  return (
    <div className="viewer-bars">
      {Array.from({ length: count }).map((_, i) => (
        <span key={i} className="vbar">
          <i style={{ width: i < index ? '100%' : i === index ? `${Math.round(progress * 100)}%` : '0%' }} />
        </span>
      ))}
    </div>
  );
}

export default function StoryViewer({ groups, start, actions, busy, onClose, onSeen, goRooms }) {
  const [now, setNow] = useState(() => Date.now());

  // لا نعتمد على إعادة تحميل App كل 45 ثانية لإخفاء الحالة المنتهية؛
  // العارض نفسه يراقب وقت الانتهاء حتى لا تبقى الحالة مفتوحة بعد انتهاء مدتها.
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const flat = useMemo(
    () => groups.flatMap((g) => g.states.map((s) => ({ person: g.person, state: s }))),
    [groups]
  );
  const [i, setI] = useState(() => {
    let n = 0;
    groups.slice(0, start).forEach((g) => { n += g.states.length; });
    return n;
  });
  const [progress, setProgress] = useState(0);
  const [paused, setPaused] = useState(false);
  const [dur, setDur] = useState(6000);
  const [whisperOpen, setWhisperOpen] = useState(false);
  const [whisperText, setWhisperText] = useState('');
  const [blocked, setBlocked] = useState(false);
  const nextRef = useRef(() => {});
  const mediaRef = useRef(null);

  const cur = flat[i];
  const state = cur ? cur.state : null;
  const person = cur ? cur.person : null;
  const mine = state ? (state.author === 'u-me' || !!state.authorIsMe) : false;

  useEffect(() => {
    if (!state || !Number.isFinite(Date.parse(state.expiresIn)) || Date.parse(state.expiresIn) <= now) onClose();
  }, [state, now, onClose]);

  const groupOf = useMemo(() => {
    if (!person) return { list: [], index: 0 };
    const g = groups.find((x) => x.person.id === person.id);
    if (!g) return { list: [], index: 0 };
    const index = g.states.findIndex((s) => s.id === (state && state.id));
    return { list: g.states, index: index < 0 ? 0 : index };
  }, [groups, person, state]);

  const go = useCallback((delta) => {
    setI((n) => {
      const t = n + delta;
      if (t < 0) { setProgress(0); return 0; }
      if (t >= flat.length) { onClose(); return n; }
      return t;
    });
  }, [flat.length, onClose]);

  nextRef.current = () => go(1);

  // مدة العرض: نص ٦ ثوان، صورة ٧، فيديو/صوت حسب طول المقطع
  useEffect(() => {
    if (!state) return;
    const base = state.media
      ? state.media.type === 'image'
        ? 7000
        : Math.max(4000, Math.min(30000, Number(state.media.durationMs) || (Number(state.seconds) || 15) * 1000))
      : (Number(state.seconds) || 6) * 1000;
    setDur(base);
    setProgress(0);
    setWhisperOpen(false);
  }, [i, state && state.id]);

  useEffect(() => {
    if (!state) return;
    if (!state.seen && !mine && onSeen) onSeen(state.id);
  }, [state && state.id]);

  // تشغيل الصوت/الفيديو تلقائيًا، وإن منعه المتصفح نظهر زر تشغيل ونوقف العدّاد
  useEffect(() => {
    setBlocked(false);
    if (!state || !state.media || state.media.type === 'image') return;
    const el = mediaRef.current;
    if (!el) return;
    const p = el.play();
    if (p && typeof p.catch === 'function') {
      p.catch(() => { setBlocked(true); setPaused(true); });
    }
  }, [i, state && state.id]);

  const togglePause = () => {
    const el = mediaRef.current;
    const willPause = !paused;
    setPaused(willPause);
    if (el && state && state.media && state.media.type !== 'image') {
      if (willPause) el.pause();
      else el.play().then(() => setBlocked(false)).catch(() => setBlocked(true));
    }
  };

  useEffect(() => {
    if (paused || whisperOpen || !state) return;
    const started = Date.now();
    const t = setInterval(() => {
      const p = (Date.now() - started) / dur;
      setProgress(Math.min(1, p));
      if (p >= 1) { clearInterval(t); nextRef.current(); }
    }, 60);
    return () => clearInterval(t);
  }, [i, paused, whisperOpen, dur, state && state.id]);

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') nextRef.current();
      if (e.key === 'ArrowRight') go(-1);
      if (e.key === ' ') { e.preventDefault(); setPaused((v) => !v); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [go, onClose]);

  const sendWhisper = async () => {
    if (!whisperText.trim() || !state) return;
    const done = await actions.whisper(state.id, state.author, whisperText);
    if (done) { setWhisperText(''); setWhisperOpen(false); }
  };

  if (!state) return null;

  return createPortal(
    <div className="story-viewer" role="dialog" aria-modal="true" aria-label="عرض الحالات">
      <div className="viewer-stage" onClick={() => nextRef.current()}>
        {/* صندوق الحالة الطولي ٩:١٦ — الوسائط والنصّ واللون السادة كلها داخله */}
        <div className={`viewer-box${state.media && state.media.type === 'video' ? ' is-video' : ''}`}>
        {state.media && (state.media.type === 'image' || state.media.type === 'video') && (
          <div className="viewer-frame">
            <MediaFrame
              src={mUrl(state.media.url)}
              overlaySrc={state.media.overlay ? mUrl(state.media.overlay) : null}
              type={state.media.type}
              dims={state.media.w && state.media.h ? { w: state.media.w, h: state.media.h } : null}
              view={state.media.view || null}
              mediaRef={mediaRef}
              videoProps={state.media.type === 'video' ? {
                key: state.id,
                autoPlay: true,
                playsInline: true,
                onEnded: () => nextRef.current(),
                onLoadedMetadata: (e) => {
                  const d = e.currentTarget.duration;
                  if (Number.isFinite(d) && d > 0) setDur(Math.max(4000, Math.min(30000, d * 1000 + 300)));
                },
              } : undefined}
            />
          </div>
        )}
        {state.media && state.media.type === 'audio' && (
          <div className="viewer-audio" onClick={(e) => e.stopPropagation()}>
            <span className="audio-halo"><Volume2 size={30} strokeWidth={1.8} /></span>
            <div className="waves" aria-hidden="true">
              {Array.from({ length: 22 }).map((_, n) => (
                <i key={n} style={{ height: `${18 + ((n * 37) % 62)}%`, animationDelay: `${(n % 7) * 0.13}s` }} />
              ))}
            </div>
            <audio
              key={state.id}
              ref={mediaRef}
              src={mUrl(state.media.url)}
              autoPlay
              controls
              playsInline
              onEnded={() => nextRef.current()}
              onLoadedMetadata={(e) => {
                const d = e.currentTarget.duration;
                if (Number.isFinite(d) && d > 0) setDur(Math.max(4000, Math.min(30000, d * 1000 + 300)));
              }}
            />
            <p className="audio-note">{state.text || 'تسجيل صوتي'}</p>
          </div>
        )}
        {!state.media && (
          <div
            className={`viewer-text${state.bg ? '' : ` grad-${(state.kind || 'moment').charAt(0)}`}`}
            style={state.bg ? { background: state.bg } : undefined}
          >
            <span className="layer-chip">{state.kind === 'moment' ? 'لحظة' : state.kind === 'ask' ? 'سؤال' : state.kind === 'need' ? 'حاجة' : state.kind === 'memory' ? 'أثر' : 'نشاط'}</span>
            <p>{state.text}</p>
            {state.place && (
              <span className="viewer-place"><MapPin size={14} strokeWidth={1.8} /> {state.place.name}</span>
            )}
          </div>
        )}

        {state.media && (state.text || state.place) && (
          <div className="viewer-caption">
            {state.text && <p>{state.text}</p>}
            {state.place && <span><MapPin size={13} strokeWidth={1.8} /> {state.place.name}</span>}
          </div>
        )}
        {blocked && (
          <button
            className="viewer-play"
            onClick={(e) => {
              e.stopPropagation();
              const el = mediaRef.current;
              if (el) el.play().then(() => setBlocked(false)).catch(() => null);
              setPaused(false);
            }}
          >
            <Play size={20} strokeWidth={2} /> تشغيل الصوت
          </button>
        )}
        </div>
      </div>

      <div className="viewer-hud">
        <Bars count={groupOf.list.length} index={groupOf.index} progress={progress} />

        <header className="viewer-head">
          <Avatar name={person.name} color={person.color} photo={person.avatar} size="sm" />
          <div className="grow">
            <div className="viewer-name">{person.name}{mine ? ' · أنت' : ''}</div>
            <div className="viewer-meta">
              {ago(state.createdAt)} · {state.msLeft ? 'متاحة الآن' : 'انتهت'}
              {state.audienceView && state.audienceView.scope !== 'circle' && (
                <span className="viewer-aud" title={`يراها: ${state.audienceView.label}`}>
                  {state.audienceView.scope === 'people' ? <Lock size={11} strokeWidth={2.2} /> : <Users size={11} strokeWidth={2.2} />}
                  {state.audienceView.label}
                </span>
              )}
            </div>
          </div>
          <button className="iconbtn light" onClick={(e) => { e.stopPropagation(); togglePause(); }} aria-label={paused ? 'تشغيل' : 'إيقاف مؤقت'}>
            {paused ? <Play size={17} strokeWidth={1.8} /> : <Pause size={17} strokeWidth={1.8} />}
          </button>
          <button className="iconbtn light" onClick={onClose} aria-label="إغلاق"><X size={18} strokeWidth={1.8} /></button>
        </header>

        <nav className="viewer-nav">
          <button className="viewer-arrow prev" onClick={(e) => { e.stopPropagation(); go(-1); }} disabled={i === 0} aria-label="السابق">
            <ChevronRight size={20} strokeWidth={2} />
          </button>
          <span className="viewer-tick">
            {state.media ? (state.media.type === 'image' ? <ImageIcon size={13} strokeWidth={1.8} />
              : state.media.type === 'video' ? <Video size={13} strokeWidth={1.8} />
                : <Mic size={13} strokeWidth={1.8} />) : <Sparkles size={13} strokeWidth={1.8} />}
            {i + 1} / {flat.length}
          </span>
          <button className="viewer-arrow next" onClick={(e) => { e.stopPropagation(); nextRef.current(); }} aria-label="التالي">
            <ChevronLeft size={20} strokeWidth={2} />
          </button>
        </nav>
      </div>

      <div className="viewer-foot" onClick={(e) => e.stopPropagation()}>
        {state.threshold > 0 && (
          <div className="threshold slim">
            <div className="trow">
              <strong>{state.question}</strong>
              <span>{(state.tally || {}).yes || 0} من {state.threshold}</span>
            </div>
            <div className="bar"><i style={{ width: `${state.progress || 0}%` }} /></div>
            <div className="tmeta">
              {!state.msLeft
                ? 'انتهت مدة الحالة'
                : state.roomId
                  ? 'اكتمل النصاب — الردود تتابع داخل الغرفة'
                  : `${Math.max(0, state.threshold - ((state.tally || {}).yes || 0))} أشخاص لنفتح غرفة`}
            </div>
          </div>
        )}

        {!mine && (
          <div className="respond compact">
            {state.options.map((o) => {
              const on = state.myChoice === o.key;
              return (
                <button
                  key={o.key}
                  className={`opt${on ? ' on' : ''}`}
                  disabled={busy || !state.msLeft || !!state.roomId}
                  onClick={() => actions.respond(state.id, o.key)}
                >
                  {on && <Check size={14} strokeWidth={2} />}
                  <span>{o.label}</span>
                  <em>{(state.tally || {})[o.key] || 0}</em>
                </button>
              );
            })}
          </div>
        )}

        <div className="viewer-actions">
          {!mine && (
            <button className="ghost-btn light" onClick={() => setWhisperOpen((v) => !v)}>
              <MessageSquareDashed size={15} strokeWidth={1.8} /> همسة خاصة
            </button>
          )}
          {state.roomId && (
            <button className="ghost-btn light" onClick={() => { onClose(); if (goRooms) goRooms(); }}>
              <DoorOpen size={15} strokeWidth={1.8} /> الغرفة المفتوحة
            </button>
          )}
          {mine && (
            <button className="ghost-btn light danger" onClick={() => actions.deleteState(state.id)} disabled={busy}>
              <Trash2 size={15} strokeWidth={1.8} /> احذف حالتي
            </button>
          )}
        </div>

        {whisperOpen && (
          <div className="whisper light">
            <input
              value={whisperText}
              onChange={(e) => setWhisperText(e.target.value)}
              placeholder={`رسالة جانبية إلى ${person.name}…`}
              onKeyDown={(e) => { if (e.key === 'Enter') sendWhisper(); }}
            />
            <button className="btn sm" onClick={sendWhisper} disabled={busy || !whisperText.trim()}>
              <Send size={14} strokeWidth={2} />
            </button>
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  LocateFixed, List, Plus, Loader2, RefreshCw, AlertCircle,
} from 'lucide-react';
import { api } from '../api.js';
import { zoomForRadius } from '../map.js';
import { readCache, saveCache } from '../cache.js';
import { currentPoint, geoUnavailable } from '../geoClient.js';
import { ensure, decisionOf } from '../permissions.js';
import AtharMap from './AtharMap.jsx';
import PulseSheet, { PlaceList, Legend } from './AtharSheets.jsx';
import AtharComposer from './AtharComposer.jsx';

// مركز مسقط الافتراضي — نبدأ منه قبل إذن الموقع
const CITY = { lat: 23.588, lng: 58.3829 };
// نطاق الاكتشاف: ٦٠ كم هو السقف — من أراد دائرة أضيق اختار واحدة أصغر
const RADII = [5, 20, 60];
const LS = { radius: 'sawa.athar.radius', point: 'sawa.athar.point' };

const readPoint = () => {
  try {
    const v = JSON.parse(localStorage.getItem(LS.point) || 'null');
    return v && Number.isFinite(v.lat) && Number.isFinite(v.lng) ? v : null;
  } catch (e) { return null; }
};

const readRadius = () => {
  const v = Number(localStorage.getItem(LS.radius));
  return RADII.includes(v) ? v : 60;
};

export default function AtharView({ data, actions, onError, dark }) {
  const [origin, setOrigin] = useState(() => readPoint() || CITY);
  const [located, setLocated] = useState(false);
  const [radius, setRadius] = useState(readRadius);
  // آخر لقطة من الخريطة من الذاكرة المحلية: تظهر فورًا ثم تُحدَّث من الشبكة
  const [payload, setPayload] = useState(() => {
    const c = readCache('athar', 30 * 60 * 1000);
    return c && Number(c.radiusKm) === readRadius() ? c : null;
  });
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(null);
  const [view, setView] = useState(null);
  const [zoom, setZoom] = useState(10);
  const [sel, setSel] = useState(null);
  const [listOpen, setListOpen] = useState(false);
  const [composeSeed, setComposeSeed] = useState(null);
  const [composeOpen, setComposeOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const boxRef = useRef(null);
  const framed = useRef('');

  const boxHeight = useCallback(() => {
    const h = boxRef.current ? boxRef.current.getBoundingClientRect().height : 0;
    return h > 200 ? h : 520;
  }, []);

  const frame = useCallback((center, km) => {
    setView({ lat: center.lat, lng: center.lng });
    setZoom(zoomForRadius(center.lat, km, boxHeight()));
  }, [boxHeight]);

  // ── جلب الآثار داخل النطاق حول موقع الناظر ──
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const d = await api.athar({ lat: origin.lat, lng: origin.lng, radiusKm: radius });
      setPayload(d);
      if (d && Number(d.radiusKm) === Number(radius)) saveCache('athar', d);
      setFailed(null);
      const key = `${d.center.lat.toFixed(3)},${d.center.lng.toFixed(3)},${d.radiusKm},${boxHeight()}`;
      if (framed.current !== key) {
        framed.current = key;
        frame(d.center, d.radiusKm);
      }
      return d;
    } catch (e) {
      setFailed(e.message || 'تعذّر تحميل الخريطة');
      return null;
    } finally {
      setLoading(false);
    }
  }, [origin.lat, origin.lng, radius, frame, boxHeight]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    localStorage.setItem(LS.radius, String(radius));
  }, [radius]);

  // ── الموقع: إذن واحد من المستخدم، ثم نقرأ الموقع بهدوء ──
  // ask=true يعني ضغطة صريحة على «موقعي» — حينها يجوز أن نُعيد السؤال.
  // وإن رُفض أو كنّا داخل إطار معاينة: نبني على مركز المدينة بلا أخطاء في الـ console.
  const locate = useCallback(async ({ ask = false } = {}) => {
    const res = await ensure('location', {
      force: ask,
      reason: 'لنعرف أقرب الأماكن إليك ونثبّت أثرك على المكان الذي أنت فيه.',
    });
    if (!res.ok) { setLocated(false); return null; }
    const p = (res.value && Number.isFinite(res.value.lat)) ? res.value : await currentPoint({ timeout: 4000 });
    if (!p) { setLocated(false); return null; }
    setOrigin(p);
    setLocated(true);
    try { localStorage.setItem(LS.point, JSON.stringify(p)); } catch (e) { /* تجاهل */ }
    framed.current = '';
    return p;
  }, []);

  // القراءة التلقائية عند الدخول تمرّ بلا سؤال: إن كان الإذن مُسموحًا سابقًا نقرأ
  // الموقع، وإلا نبقى على مركز المدينة وننتظر ضغطة «موقعي» (سؤال واحد فقط).
  useEffect(() => {
    if (readPoint() || geoUnavailable()) return;
    if (decisionOf('location').state === 'granted') locate();
  }, [locate]);

  const pulses = (payload && payload.pulses) || [];
  const items = (payload && payload.items) || [];
  const selected = useMemo(() => pulses.find((p) => p.id === sel) || null, [pulses, sel]);
  const placeNames = useMemo(() => [...new Set([
    ...pulses.map((p) => p.placeName),
    ...items.map((i) => i.place && i.place.name).filter(Boolean),
  ])], [pulses, items]);

  // الزيارة تُحسب على أثر من دائرتك — زيارتك لأثرك أنت لا تُضاف
  const visitTarget = (pulse) => (pulse.items
    .map((id) => items.find((i) => i.id === id))
    .filter(Boolean)
    .find((i) => !i.mine) || null);

  const visit = async (pulse) => {
    const target = visitTarget(pulse);
    if (!target) { onError('كل آثار هذا المكان لك — الزيارات تُحسب من دائرتك'); return; }
    setBusy(true);
    try {
      await api.visitAthar(target.id);
      const d = await load();
      if (d) setPayload(d);
      if (actions && actions.refresh) actions.refresh();
    } catch (e) {
      onError(e.message || 'تعذّر تسجيل الزيارة');
    } finally {
      setBusy(false);
    }
  };

  const publish = async (form) => {
    setBusy(true);
    try {
      const res = await actions.createAthar(form);
      if (res && res.athar) {
        setPayload(res.athar);
        setComposeOpen(false);
        setComposeSeed(null);
        const created = res.athar.pulses.find((p) => res.athar.items.some((i) => i.id === res.created && p.items.includes(i.id)));
        if (created) {
          setSel(created.id);
          setView({ lat: created.lat, lng: created.lng });
        }
      }
    } catch (e) {
      onError(e.message || 'تعذّر نشر الأثر');
    } finally {
      setBusy(false);
    }
  };

  const focusPlace = (p) => {
    setListOpen(false);
    setView({ lat: p.lat, lng: p.lng });
    setZoom((z) => Math.max(z, 11));
    setSel(p.id);
  };

  const goMine = async () => {
    if (located) { framed.current = ''; frame(origin, radius); return; }
    const p = await locate({ ask: true }); // ضغطة صريحة: يجوز أن نسأل عن الإذن هنا
    if (!p) { onError('تعذّر تحديد موقعك — نعرض نطاق المدينة'); return; }
    framed.current = '';
    frame(p, radius);
  };

  const summary = (payload && payload.summary) || { total: 0, places: 0, mine: 0, visits: 0, beyond: 0 };

  return (
    <div className="athar-view" ref={boxRef}>
      <AtharMap
        view={view || origin}
        onView={setView}
        zoom={zoom}
        onZoom={setZoom}
        origin={origin}
        pulses={pulses}
        ring={payload ? payload.ring : null}
        selectedId={sel}
        onSelect={setSel}
        dark={dark}
      >
        <div className="map-top">
          <div className="chips radius">
            {RADII.map((r) => (
              <button
                key={r}
                type="button"
                className={`chip${radius === r ? ' on' : ''}`}
                onClick={() => { setRadius(r); framed.current = ''; }}
              >
                {r} كم
              </button>
            ))}
          </div>
          <button type="button" className="iconbtn map-btn" onClick={goMine} aria-label="موقعي">
            <LocateFixed size={18} strokeWidth={1.8} />
          </button>
        </div>

        {loading && !payload && (
          <div className="map-loading"><Loader2 className="spin" size={20} strokeWidth={2} /> نجهّز الآثار القريبة…</div>
        )}

        {failed && !payload && (
          <div className="map-empty card">
            <div className="empty">
              <div className="circle"><AlertCircle size={22} strokeWidth={1.8} /></div>
              <strong>تعذّر فتح الخريطة</strong>
              <p>{failed}</p>
              <button type="button" className="btn sm" onClick={load}>
                <RefreshCw size={15} strokeWidth={1.8} /> إعادة المحاولة
              </button>
            </div>
          </div>
        )}

        {payload && !pulses.length && (
          <div className="map-empty card">
            <div className="empty">
              <div className="circle"><LocateFixed size={22} strokeWidth={1.8} /></div>
              <strong>لا آثار في نطاق {radius} كم</strong>
              <div className="chips radius inside">
                {RADII.filter((r) => r > radius).map((r) => (
                  <button key={r} type="button" className="chip" onClick={() => { setRadius(r); framed.current = ''; }}>
                    وسّع إلى {r} كم
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="map-bottom">
          <Legend legend={(payload && payload.legend) || []} />
          <div className="athar-dock">
            <div className="dock-stats">
              <div><b>{summary.total}</b><span>أثرًا في {radius} كم</span></div>
              <div><b>{summary.places}</b><span>مكانًا مضيئًا</span></div>
              {summary.beyond > 0 && (
                <span className="beyond" title="آثار أبعد من النطاق">
                  +{summary.beyond} خارج النطاق
                </span>
              )}
            </div>
            <div className="dock-actions">
              <button type="button" className="btn btn-ghost sm" onClick={() => setListOpen(true)} disabled={!pulses.length}>
                <List size={15} strokeWidth={1.8} /> الأماكن
              </button>
              <button
                type="button"
                className="btn btn-primary grow"
                onClick={() => { setComposeSeed({ lat: (view || origin).lat, lng: (view || origin).lng, name: '' }); setComposeOpen(true); }}
              >
                <Plus size={16} strokeWidth={2} /> أوثّق أثرًا
              </button>
            </div>
          </div>
        </div>
      </AtharMap>

      {selected && (
        <PulseSheet
          pulse={selected}
          items={items}
          busy={busy}
          onClose={() => setSel(null)}
          onVisit={visit}
          canVisit={Boolean(visitTarget(selected))}
          onCompose={(p) => {
            setSel(null);
            setComposeSeed({ lat: p.lat, lng: p.lng, name: p.placeName });
            setComposeOpen(true);
          }}
        />
      )}

      {listOpen && (
        <PlaceList
          pulses={pulses}
          radiusKm={radius}
          onOpen={(p) => { setListOpen(false); setSel(p.id); }}
          onFocus={focusPlace}
          onClose={() => setListOpen(false)}
        />
      )}

      {composeOpen && (
        <AtharComposer
          seed={composeSeed}
          me={data ? data.me : null}
          people={data && data.people ? data.people : []}
          origin={origin}
          located={located}
          placeNames={placeNames}
          pulses={pulses}
          dark={dark}
          busy={busy}
          onLocate={() => locate({ ask: true })}
          onClose={() => { setComposeOpen(false); setComposeSeed(null); }}
          onPublish={publish}
        />
      )}
    </div>
  );
}

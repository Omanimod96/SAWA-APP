import { initials } from '../useToast.js';

export default function Avatar({ name, color = '#1D4ED8', size = 'md', title, photo }) {
  const cls = size === 'sm' ? 'avatar sm' : size === 'lg' ? 'avatar lg' : 'avatar';
  // صورة العرض إن وُجدت، وإلا الأحرف الأولى على لون الشخص (نفس السلوك السابق)
  const pic = photo || '';
  return (
    <div className={`${cls}${pic ? ' has-photo' : ''}`} style={{ background: color }} title={title || name} aria-hidden="true">
      {pic ? <img src={pic} alt="" loading="lazy" /> : initials(name)}
    </div>
  );
}

export function AvatarRow({ members, people, max = 5 }) {
  const list = (members || [])
    .map((id) => (people || []).find((p) => p.id === id))
    .filter(Boolean)
    .slice(0, max);
  return (
    <div className="avatars-row">
      {list.map((p) => (
        <Avatar key={p.id} name={p.name} color={p.color} size="sm" photo={p.avatar} />
      ))}
    </div>
  );
}

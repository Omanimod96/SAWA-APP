import React from 'react';
import { Plus, Image as ImageIcon, Video, Mic, Sparkles, Lock, Users } from 'lucide-react';
import Avatar from './Avatar.jsx';

const BADGE = {
  image: ImageIcon,
  video: Video,
  audio: Mic,
};

function Ring({ unseen, mine, children }) {
  return (
    <span className={`ring${unseen ? ' unseen' : ''}${mine ? ' mine' : ''}`}>{children}</span>
  );
}

export default function StoriesStrip({ groups, me, myGroup, myIndex, onOpen, onAdd, busy }) {
  return (
    <div className="stories-wrap">
      <div className="stories" role="list" aria-label="الحالات">
        <button
          className={`story add${myGroup ? ' has' : ''}`}
          onClick={() => (myGroup ? onOpen(myIndex) : onAdd())}
          disabled={busy}
          role="listitem"
          title={myGroup ? 'اعرض حالتك' : 'أضف حالة'}
        >
          <Ring mine unseen={Boolean(myGroup)}>
            <Avatar name={me.name || 'أنت'} color={me.avatarColor || '#1D4ED8'} photo={me.avatar} size="md" />
            <span
              className="plus"
              role="button"
              aria-label="إضافة حالة"
              onClick={(e) => { e.stopPropagation(); onAdd(); }}
            >
              <Plus size={14} strokeWidth={2.2} />
            </span>
            {myGroup && myGroup.states[0] && myGroup.states[0].audienceView && myGroup.states[0].audienceView.scope !== 'circle' && (
              <span className="aud-dot" aria-label={`يراها ${myGroup.states[0].audienceView.label}`}>
                {myGroup.states[0].audienceView.scope === 'people' ? <Lock size={9} strokeWidth={2.2} /> : <Users size={9} strokeWidth={2.2} />}
              </span>
            )}
          </Ring>
          <span className="story-name">حالتك</span>
          {myGroup && myGroup.states.length > 1 && <span className="story-count">{myGroup.states.length}</span>}
        </button>

        {groups.map((g, i) => {
          const lastState = g.states[g.states.length - 1];
          const Badge = lastState.media ? BADGE[lastState.media.type] : Sparkles;
          const audView = lastState.audienceView;
          const limited = audView && audView.scope !== 'circle';
          return (
            <button
              key={g.person.id}
              className="story"
              role="listitem"
              onClick={() => onOpen(i)}
              disabled={busy}
              title={limited ? `يراها: ${audView.label}` : undefined}
            >
              <Ring unseen={g.unseen} mine={g.mine}>
                <Avatar name={g.person.name} color={g.person.color} photo={g.person.avatar} size="md" />
                <span className="kind-dot"><Badge size={11} strokeWidth={2} /></span>
                {limited && (
                  <span className="aud-dot" aria-label={`يراها ${audView.label}`}>
                    {audView.scope === 'people' ? <Lock size={9} strokeWidth={2.2} /> : <Users size={9} strokeWidth={2.2} />}
                  </span>
                )}
              </Ring>
              <span className="story-name">{String(g.person.name).split(' ')[0]}</span>
              {g.states.length > 1 && <span className="story-count">{g.states.length}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

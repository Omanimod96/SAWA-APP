import React, { useEffect, useState } from 'react';
import {
  Camera, Mic, MapPin, Images, ContactRound, ShieldCheck, Check, Loader2, ExternalLink, RotateCcw,
} from 'lucide-react';
import {
  PERMS, permById, allDecisions, isSupported, grant, forgetDecision, inFrame, hintFor, subscribe,
} from '../permissions.js';
import { contactsMode, contactsNote } from '../contacts.js';

const ICON = { camera: Camera, microphone: Mic, location: MapPin, media: Images, contacts: ContactRound };

const PILL = {
  granted: { text: 'مُسموح', cls: 'ok' },
  denied: { text: 'ممنوع من المتصفح', cls: 'bad' },
  later: { text: 'ليس الآن', cls: '' },
  unsupported: { text: 'غير مدعوم', cls: 'bad' },
};

// سجلّ الأذونات: ما سألنا عنه، وما كان جوابك، وكيف تغيّره — كله في هذا الجهاز وحده.
export default function DevicePerms() {
  const [rows, setRows] = useState(() => allDecisions());
  const [busyId, setBusyId] = useState(null);
  const [msg, setMsg] = useState('');
  const framed = inFrame();

  useEffect(() => subscribe(() => setRows(allDecisions())), []);

  const ask = async (id) => {
    setMsg('');
    setBusyId(id);
    const p = permById(id);
    // native: نطلب من الجهاز فعلًا · media: نكتفي بعدم السؤال مرّة أخرى
    // · contacts: داخل التطبيق إذن نظام حقيقي، وفي المتصفح لا إذن مسبق
    const real = p && (p.native || (p.id === 'contacts' && contactsMode() === 'native'));
    const res = await grant(id, real ? {} : { defer: true });
    setRows(allDecisions());
    setBusyId(null);
    if (!res.ok) setMsg(hintFor(res));
  };

  const forget = () => {
    PERMS.forEach((p) => forgetDecision(p.id));
    setRows(allDecisions());
    setMsg('نُسي القرار من هذا الجهاز — سنسألك مرّة واحدة عند أول استخدام.');
  };

  const openStandalone = () => {
    try { window.open(window.location.href.split('#')[0], '_blank', 'noopener'); } catch (e) { /* لا شيء */ }
  };

  return (
    <section className="card perm-card">
      <h3 className="card-title"><ShieldCheck size={16} strokeWidth={1.8} /> أذونات الجهاز</h3>

      <ul className="perm-list">
        {PERMS.map((p) => {
          const Icon = ICON[p.id] || ShieldCheck;
          const st = rows[p.id] || 'unasked';
          const supported = isSupported(p.id);
          const needsWindow = supported && framed && p.native;
          // جهات الاتصال في المتصفح: الزر يعمل داخل التطبيق، فلا نقول «غير مدعوم»
          const inAppOnly = p.id === 'contacts' && !supported;
          const pill = needsWindow
            ? { text: 'يحتاج نافذة مستقلة', cls: 'warn' }
            : inAppOnly
              ? { text: 'يعمل داخل التطبيق', cls: 'warn' }
              : (PILL[st] || { text: 'لم نُسأل بعد', cls: '' });
          return (
            <li key={p.id} className={`perm-row${st === 'granted' ? ' ok' : ''}`}>
              <span className="perm-ico sm"><Icon size={18} strokeWidth={1.8} /></span>
              <div className="perm-row-txt">
                <b>{p.title}</b>
                <small>{p.keep}</small>
              </div>
              {st === 'granted' || !supported ? (
                <span className={`perm-pill${pill.cls ? ` ${pill.cls}` : ''}`}>
                  {st === 'granted' ? <><Check size={12} strokeWidth={2.2} /> مُسموح</> : pill.text}
                </span>
              ) : needsWindow ? (
                <button type="button" className="btn btn-soft sm" onClick={openStandalone}>
                  <ExternalLink size={14} strokeWidth={1.8} /> افتح مستقلًا
                </button>
              ) : (
                <button
                  type="button"
                  className="btn btn-soft sm"
                  aria-label={`اسمح بالوصول إلى ${p.title}`}
                  onClick={() => ask(p.id)}
                  disabled={busyId === p.id}
                >
                  {busyId === p.id ? <Loader2 className="spin" size={14} strokeWidth={2} /> : null}
                  {st === 'denied' ? 'أعد الطلب' : st === 'later' ? 'اسألني الآن' : 'اسمح'}
                </button>
              )}
            </li>
          );
        })}
      </ul>

      {msg ? <p className="hint">{msg}</p> : null}

      <div className="actions">
        <button type="button" className="btn btn-ghost sm" onClick={forget}>
          <RotateCcw size={15} strokeWidth={1.8} /> انسَ قرارات هذا الجهاز
        </button>
      </div>
    </section>
  );
}

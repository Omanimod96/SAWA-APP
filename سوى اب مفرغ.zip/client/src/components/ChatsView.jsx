import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Search, Send, ArrowRight, MessageCircle, BadgeCheck, CheckCheck, Loader2, MapPin, Users,
  AtSign, UserPlus, ContactRound, Paperclip, FileText, X, Share2, VenetianMask, ThumbsUp,
  ThumbsDown, Lock, Phone, Video, PhoneIncoming, PhoneOutgoing, PhoneMissed,
} from 'lucide-react';
import Avatar from './Avatar.jsx';
import WhisperThread from './WhisperThread.jsx';
import { api, apiUrl } from '../api.js';
import { ensure, hintFor } from '../permissions.js';
import { contactsMode, contactsNote, pickContacts, matchPeople } from '../contacts.js';
import { TYPE_OF_ANY, CAP_MB, fmtSize, blobToDataUrl, shrinkImage, docLabel } from '../media.js';

const ATTACH_ACCEPT = 'image/*,video/*,application/pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip';

const timeOf = (iso) => {
  try { return new Date(iso).toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' }); }
  catch (e) { return ''; }
};

function dayLabel(iso) {
  const d = new Date(iso);
  const today = new Date();
  const yest = new Date(Date.now() - 864e5);
  const same = (a, b) => a.toDateString() === b.toDateString();
  if (same(d, today)) return 'اليوم';
  if (same(d, yest)) return 'أمس';
  try { return d.toLocaleDateString('ar-OM', { day: 'numeric', month: 'long' }); }
  catch (e) { return ''; }
}

const listStamp = (iso) => (dayLabel(iso) === 'اليوم' ? timeOf(iso) : dayLabel(iso));

// معاينة الرسالة في القائمة: نص، أو نوع المرفق إن كانت بلا نص
// وصف المكالمة في سطر المعاينة: النوع والحالة بلا أرقام طويلة
// حالة المكالمة بالعربية: الشيفرة الخادمية (missed · busy · unreachable …) لا
// تظهر للمستخدم أبدًا — كان سطر المكالمة يطبع «مكالمة صوتية · unreachable».
const CALL_STATUS_AR = {
  missed: 'فائتة',
  rejected: 'مرفوضة',
  canceled: 'أُلغيت',
  busy: 'مشغول',
  unreachable: 'غير متصل',
  dropped: 'انقطعت',
};

const callLine = (c) => {
  if (!c) return 'مكالمة';
  const kind = c.kind === 'video' ? 'مكالمة مرئية' : 'مكالمة صوتية';
  const dur = c.durationSec >= 1 ? ` · ${Math.floor(c.durationSec / 60)}:${String(c.durationSec % 60).padStart(2, '0')}` : '';
  const st = c.status === 'ended' ? '' : CALL_STATUS_AR[c.status];
  if (st) return `${kind} · ${st}`;
  return kind + dur;
};

const lastKind = (m) => {
  if (m && m.type === 'call') return callLine(m.call);
  const t = m && m.media && m.media.type;
  if (t === 'image') return 'صورة';
  if (t === 'video') return 'مقطع';
  if (t === 'doc') return 'مستند';
  return 'رسالة';
};

// معاينة رسالة الهمسة: نصوص الأحداث (تقييم · سؤال · كشف) لها وصفها لا نصها الفارغ
const whisperPreview = (m) => {
  if (!m) return 'لا رسائل بعد';
  if (m.kind === 'like') return m.mine ? 'أعجبني' : 'أعجبه';
  if (m.kind === 'dislike') return m.mine ? 'لم يعجبني' : 'لم يعجبه';
  if (m.kind === 'ask') return m.mine ? 'سألت: من صاحب الهمسة؟' : 'يسأل: من أنت؟';
  if (m.kind === 'reveal') return m.mine ? 'عرّفت بنفسك' : 'كُشفت الهوية';
  if (m.kind === 'deny') return 'فضّلت أن تبقى مجهولًا';
  return m.text || '';
};

export default function ChatsView({
  data, actions, busy, activeId, onOpen, onClose, toast,
  whisperId, onOpenWhisper, onCloseWhisper, call,
}) {
  // من متصل الآن (من قناة الإشارات): نقطة خضراء بجانب الاسم — بلا سؤال دوري.
  // الحضور مصفوفة أسماء؛ نُحصّن القراءة حتى لا يُسقط أي حقل مشوّه شاشة المحادثات.
  const onlineSet = useMemo(
    () => new Set(Array.isArray(call && call.online) ? call.online : []),
    [call],
  );
  const chats = data.chats || [];
  const whispers = data.whispers || [];
  const me = data.me || {};
  const [q, setQ] = useState('');
  // التواصل باسم المستخدم: لمن لا يملك رقمه
  const [user, setUser] = useState('');
  const [userErr, setUserErr] = useState(null);
  // من جهات الاتصال: نقرأ الأسماء فقط، ونطابقها محليًا مع دائرتك — بلا تخزين
  const [ctc, setCtc] = useState(null);
  const [ctcBusy, setCtcBusy] = useState(false);
  const [ctcMsg, setCtcMsg] = useState('');
  const [ctcAlt, setCtcAlt] = useState(false);

  const onAddUser = async (e) => {
    e.preventDefault();
    const u = String(user || '').toLowerCase().replace(/^@+/, '').replace(/[^a-z0-9_]/g, '');
    if (!u) return;
    setUserErr(null);
    const id = await actions.addByUsername(u);
    if (id) { setUser(''); onOpen(id); }
    else setUserErr('لا يوجد حساب بهذا الاسم — تأكّد من كتابته كما هو');
  };

  // المشاركة: نص واحد يخدم الدعوة الفردية والدعوة العامة
  const shareInvite = async (text) => {
    const url = window.location.href.split('#')[0];
    const body = `${text} — ${url}`;
    try {
      if (navigator.share) await navigator.share({ title: 'سوى', text, url });
      else { await navigator.clipboard.writeText(body); if (toast) toast('نُسخ نص الدعوة — أرسله لمن تريد', 'success'); }
    } catch (e) { /* أغلق المستخدم نافذة المشاركة */ }
  };

  // جهات الاتصال: زر واحد يعمل في كل بيئة.
  // داخل التطبيق: إذن نظام ثم دفتر الهاتف · في كروم أندرويد: منتقي المتصفح ·
  // وفي غيرهما (آيفون خاصةً): لا نُعطّل الزر — نفتح البديل الجاهز فورًا.
  const readContacts = async () => {
    setCtcMsg('');
    if (contactsMode() === 'fallback') {
      setCtc(null);
      setCtcAlt(true);
      setCtcMsg(contactsNote());
      return;
    }
    setCtcAlt(false);
    const perm = await ensure('contacts', { force: true, reason: 'لتعرف من منهم موجود في سوى فتبدأ معه محادثة بضغطة' });
    if (!perm.ok && perm.reason !== 'later') setCtcMsg(hintFor(perm));
    setCtcBusy(true);
    try {
      const picked = await pickContacts({ multiple: true });
      const matched = matchPeople(picked, data.people);
      setCtc(matched);
      if (!picked.length) setCtcMsg('لم تختر أحدًا — جرّب مرة أخرى متى شئت.');
      else if (!matched.some((m) => m.person)) setCtcMsg('لا أحد من الذين اخترتهم في سوى بعد — تقدر تدعوهم.');
    } catch (e) {
      setCtcAlt(true);
      if (e && e.code === 'denied') setCtcMsg('إذن جهات الاتصال ممنوع — افتح إعدادات الجهاز ثم «سوى» ثم فعّل جهات الاتصال. أو استخدم البديل الآن.');
      else setCtcMsg('لم نتمكن من قراءة جهات الاتصال الآن — استخدم البديل، أو جرّب مرة أخرى.');
    } finally { setCtcBusy(false); }
  };

  // البديل حين لا يوجد منتقٍ: نُري المستخدم مكان الاسم، ونفتح الدعوة بضغطة
  const focusUsername = () => {
    const el = document.querySelector('input[aria-label="اسم المستخدم"]');
    if (!el) return;
    try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { /* متصفح قديم */ }
    el.focus();
  };

  const inviteName = (name) =>
    shareInvite(`${name}، انضم إلى سوى${me.username ? ` وابحث عني بـ @${me.username}` : ''}`);

  const inviteLink = () =>
    shareInvite(`انضم إلى سوى${me.username ? ` وابحث عني بـ @${me.username}` : ''}`);

  // مطابقة البحث تشمل اسم المستخدم الآن (بلا @)
  const hit = (p, term) =>
    !term || p.name.includes(term) || (p.city || '').includes(term) ||
    String(p.username || '').toLowerCase().includes(term.toLowerCase().replace(/^@/, ''));
  const active = activeId
    ? chats.find((c) => c.personId === activeId) ||
      {
        id: `new-${activeId}`,
        personId: activeId,
        unread: 0,
        messages: [],
        last: null,
        person: data.people.find((p) => p.id === activeId) || null,
      }
    : null;

  const filtered = useMemo(() => {
    const term = q.trim();
    if (!term) return chats;
    return chats.filter((c) => c.person && hit(c.person, term));
  }, [chats, q]);

  const reachable = useMemo(() => {
    const term = q.trim();
    return data.people.filter((p) => !chats.some((c) => c.personId === p.id) && hit(p, term));
  }, [data.people, chats, q]);

  if (whisperId) {
    const thread = whispers.find((w) => w.id === whisperId);
    if (thread) {
      return (
        <WhisperThread
          thread={thread}
          actions={actions}
          busy={busy}
          onClose={onCloseWhisper}
          toast={toast}
        />
      );
    }
  }

  if (active) {
    return <Thread chat={active} actions={actions} busy={busy} onClose={onClose} toast={toast} call={call} online={onlineSet} />;
  }

  return (
    <div className="view">
      <div className="searchbar">
        <Search size={16} strokeWidth={1.8} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث باسم أو @اسم مستخدم…" />
      </div>

      {whispers.length > 0 && (
        <section className="wsec">
          <div className="wsec-head">
            <VenetianMask size={15} strokeWidth={1.8} />
            <b>همسات</b>
            <span>محادثات من أشخاص تعرفهم — بلا أسماء</span>
          </div>
          <ul className="threads">
            {whispers.map((w, i) => (
              <li key={w.id}>
                <button
                  className={`thread wthread${w.unread ? ' unread' : ''} fade-up d${(i % 3) + 1}`}
                  onClick={() => onOpenWhisper(w.id)}
                >
                  {w.peer ? (
                    <Avatar name={w.peer.name} color={w.peer.color} photo={w.peer.avatar} />
                  ) : (
                    <span className="mask-avatar" aria-hidden="true">
                      <VenetianMask size={19} strokeWidth={1.7} />
                    </span>
                  )}
                  <div className="grow">
                    <div className="pname">
                      {w.peer ? w.peer.name : 'همسة مجهولة'}
                      {w.peer ? null : <span className="anon-tag"><Lock size={11} strokeWidth={2.2} /> بلا اسم</span>}
                      {w.direction === 'out' ? <span className="out-tag">أرسلتها أنت</span> : null}
                    </div>
                    <div className="t-preview">
                      {w.last ? `${w.last.mine ? 'أنت: ' : ''}${whisperPreview(w.last)}` : 'لا رسائل بعد'}
                    </div>
                  </div>
                  <div className="t-side">
                    <span className="t-time">{w.last ? listStamp(w.last.at) : ''}</span>
                    {w.reaction === 'like' && <ThumbsUp size={12} strokeWidth={2.2} className="rx good" />}
                    {w.reaction === 'dislike' && <ThumbsDown size={12} strokeWidth={2.2} className="rx bad" />}
                    {w.unread > 0 && <span className="t-count">{w.unread}</span>}
                  </div>
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      {filtered.length === 0 ? (
        <div className="empty">
          <div className="circle"><MessageCircle size={22} strokeWidth={1.8} /></div>
          <strong>{chats.length === 0 ? 'لا محادثات بعد' : 'لا نتائج مطابقة'}</strong>
          <p>{chats.length === 0 ? 'اختر شخصًا من دائرتك.' : 'جرّب اسمًا آخر.'}</p>
        </div>
      ) : (
        <ul className="threads">
          {filtered.map((c, i) => (
            <li key={c.id}>
              <button
                className={`thread${c.unread ? ' unread' : ''} fade-up d${(i % 3) + 1}`}
                onClick={() => onOpen(c.personId)}
              >
                <Avatar
                  name={c.person ? c.person.name : '؟'}
                  color={c.person ? c.person.color : '#94A3B8'}
                  photo={c.person ? c.person.avatar : ''}
                />
                <div className="grow">
                  <div className="pname">
                    {c.person ? c.person.name : 'محادثة'}
                    {c.person && c.person.verified && <BadgeCheck size={15} strokeWidth={2} className="verified" />}
                    {c.person && c.person.username && onlineSet.has(c.person.username) && (
                      <span className="online-dot" title="متصل الآن" aria-label="متصل الآن" />
                    )}
                  </div>
                  <div className="t-preview">
                    {c.last ? `${c.last.from === 'u-me' ? 'أنت: ' : ''}${c.last.text || lastKind(c.last)}` : 'لا رسائل بعد'}
                  </div>
                </div>
                <div className="t-side">
                  <span className="t-time">{c.last ? listStamp(c.last.at) : ''}</span>
                  {c.unread > 0 && <span className="t-count">{c.unread}</span>}
                </div>
              </button>
            </li>
          ))}
        </ul>
      )}

      <section className="card start-chat">
        <h3 className="card-title"><AtSign size={16} strokeWidth={1.8} /> تواصل باسم المستخدم</h3>
        <form className="user-add" onSubmit={onAddUser}>
          <div className="userfield">
            <span className="at" dir="ltr">@</span>
            <input
              value={user}
              onChange={(e) => { setUser(e.target.value.replace(/^@+/, '')); setUserErr(null); }}
              dir="ltr"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck="false"
              placeholder="sawa4567"
              aria-label="اسم المستخدم"
            />
          </div>
          <button className="btn btn-soft sm" disabled={busy || !user.trim()}>
            {busy ? <Loader2 className="spin" size={15} strokeWidth={2} /> : <UserPlus size={15} strokeWidth={1.8} />}
            أضف وابدأ الحديث
          </button>
        </form>
        {userErr && <p className="hint bad">{userErr}</p>}
      </section>

      <section className="card start-chat">
        <h3 className="card-title"><ContactRound size={16} strokeWidth={1.8} /> من جهات الاتصال</h3>
        <p className="ctc-note">{contactsNote()}</p>
        <div className="row2">
          <button className="btn btn-soft sm" onClick={readContacts} disabled={ctcBusy || busy}>
            {ctcBusy ? <Loader2 className="spin" size={15} strokeWidth={2} /> : <ContactRound size={15} strokeWidth={1.8} />}
            {contactsMode() === 'fallback' ? 'أضِف صديقًا' : 'اقرأ جهات الاتصال'}
          </button>
        </div>
        {ctcMsg && <p className="hint">{ctcMsg}</p>}
        {ctcAlt && (
          <div className="ctc-alt row2">
            <button type="button" className="btn btn-soft sm" onClick={focusUsername}>
              <AtSign size={15} strokeWidth={1.8} /> ابحث باسم المستخدم
            </button>
            <button type="button" className="btn btn-soft sm" onClick={inviteLink}>
              <Share2 size={15} strokeWidth={1.8} /> ادعُ برابط
            </button>
          </div>
        )}
        {ctc && ctc.length > 0 && (
          <ul className="quick-people">
            {ctc.map((row) => (
              <li key={row.name}>
                {row.person ? (
                  <button className="quick" onClick={() => onOpen(row.person.id)}>
                    <Avatar name={row.person.name} color={row.person.color} size="sm" photo={row.person.avatar} />
                    <span>{row.person.name}<em className="rel">{row.name}</em></span>
                    <MessageCircle size={15} strokeWidth={1.8} />
                  </button>
                ) : (
                  <button className="quick ghost" onClick={() => inviteName(row.name)}>
                    <Avatar name={row.name} color="#94A3B8" size="sm" />
                    <span>{row.name}<em className="rel">ليس في سوى بعد</em></span>
                    <Share2 size={15} strokeWidth={1.8} />
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>

      {reachable.length > 0 && (
        <section className="card start-chat">
          <h3 className="card-title"><Users size={16} strokeWidth={1.8} /> ابدأ محادثة مع دائرتك</h3>
          <ul className="quick-people">
            {reachable.map((p) => (
              <li key={p.id}>
                <button className="quick" onClick={() => onOpen(p.id)}>
                  <Avatar name={p.name} color={p.color} size="sm" photo={p.avatar} />
                  <span>{p.name}</span>
                  <MessageCircle size={15} strokeWidth={1.8} />
                </button>
              </li>
            ))}
          </ul>
        </section>
      )}

      <div className="notice">
        <MessageCircle size={16} strokeWidth={1.8} />
        <div>
          المحادثات محفوظة لك وحدك داخل دائرتك. من خارج دائرتك لا يستطيع الوصول إليك ولا مراسلتك.
        </div>
      </div>
    </div>
  );
}

function Thread({ chat, actions, busy, onClose, toast, call, online }) {
  const person = chat.person || { name: 'محادثة', color: '#94A3B8', city: '', lastSeen: '' };
  const onlineNow = Boolean(person.username && online && online.has(person.username));
  const inCall = Boolean(call && call.state && call.state.phase !== 'idle' && call.state.phase !== 'ended');
  // البدء: المتجر الشخصي واحد في الحالتين، والفشل يُبلَّغ رسالةً واحدة (في App)
  const dial = (kind) => {
    if (!call || !chat.personId) return;
    call.actions.start(chat.personId, kind);
  };
  const messages = chat.messages || [];
  const [draft, setDraft] = useState('');
  const [att, setAtt] = useState(null);
  const [attBusy, setAttBusy] = useState(false);
  const endRef = useRef(null);
  const fileRef = useRef(null);

  // تعليم الرسائل كمقروءة مرة واحدة لكل محادثة (يمنع أي حلقة تحديث)
  const readOnce = useRef(null);
  useEffect(() => {
    if (readOnce.current === chat.personId) return;
    readOnce.current = chat.personId;
    if (chat.unread > 0) actions.readChat(chat.personId);
  }, [chat.personId, chat.unread, actions]);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
  }, [messages.length, chat.personId]);

  // المرفقات: إذن واحد لفتح الاستوديو/الملفات، ثم يُرفع الملف عند الإرسال فقط
  const pick = async () => {
    const perm = await ensure('media', { reason: 'لتختار صورة أو مقطعًا أو مستندًا لمشاركته في المحادثة' });
    if (!perm.ok) {
      if (perm.reason !== 'later' && toast) toast(hintFor(perm), 'error');
      return;
    }
    const f = fileRef.current;
    if (!f) return;
    f.accept = ATTACH_ACCEPT;
    f.removeAttribute('capture');
    f.click();
  };

  const onFile = async (e) => {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    const t = TYPE_OF_ANY(file);
    if (!t) { if (toast) toast('الصيغة غير مدعومة — صورة، مقطع، أو مستند (PDF · Word · Excel…)', 'error'); return; }
    if (file.size > CAP_MB[t] * 1024 * 1024) {
      if (toast) toast(`حجم الملف أكبر من ${CAP_MB[t]} ميجابايت`, 'error');
      return;
    }
    setAttBusy(true);
    try {
      if (t === 'image') {
        const small = await shrinkImage(file, 1600, 0.86);
        setAtt({ dataUrl: small.dataUrl, type: 'image', size: small.size, name: file.name });
      } else {
        const dataUrl = await blobToDataUrl(file);
        setAtt({ dataUrl, type: t, size: file.size, name: file.name });
      }
    } catch (err) {
      if (toast) toast('تعذّر تجهيز الملف — جرّب ملفًا آخر', 'error');
    } finally { setAttBusy(false); }
  };

  const send = async () => {
    const text = draft.trim();
    if ((!text && !att) || busy || attBusy) return;
    let media = null;
    if (att) {
      try {
        const up = await api.uploadMedia({ type: att.type, dataUrl: att.dataUrl });
        media = { url: up.url, type: att.type, name: att.name || '', size: att.size || 0 };
      } catch (err) {
        if (toast) toast(err.message || 'تعذّر رفع المرفق', 'error');
        return;
      }
    }
    const keepAtt = att;
    const keepText = draft;
    setDraft('');
    setAtt(null);
    const done = await actions.sendMessage(chat.personId, text, media);
    if (!done) { setDraft(keepText); setAtt(keepAtt); }
  };

  return (
    <div className="view chat-view">
      <div className="chat-head">
        <button className="iconbtn" onClick={onClose} aria-label="رجوع إلى المحادثات">
          <ArrowRight size={18} strokeWidth={1.8} />
        </button>
        <Avatar name={person.name} color={person.color} size="sm" photo={person.avatar} />
        <div className="grow">
          <div className="pname">
            {person.name}
            {person.verified && <BadgeCheck size={15} strokeWidth={2} className="verified" />}
          </div>
          <div className="meta">
            {onlineNow ? <span className="online-now">متصل الآن</span> : null}
            {onlineNow && person.username ? <span className="sep">·</span> : null}
            {person.username ? <span dir="ltr">@{person.username}</span> : null}
            {person.username && person.lastSeen ? <span className="sep">·</span> : null}
            {person.lastSeen && !onlineNow ? <span>آخر ظهور {person.lastSeen}</span> : null}
            {person.city ? (
              <>
                <span className="sep">·</span>
                <MapPin size={12} strokeWidth={1.8} />
                <span>{person.city}</span>
              </>
            ) : null}
          </div>
        </div>
        {person.username ? (
          <>
            <button
              className="iconbtn"
              onClick={() => dial('audio')}
              disabled={inCall}
              aria-label={`مكالمة صوتية إلى ${person.name}`}
              title="مكالمة صوتية"
            >
              <Phone size={18} strokeWidth={1.8} />
            </button>
            <button
              className="iconbtn"
              onClick={() => dial('video')}
              disabled={inCall}
              aria-label={`مكالمة مرئية إلى ${person.name}`}
              title="مكالمة مرئية"
            >
              <Video size={18} strokeWidth={1.8} />
            </button>
          </>
        ) : null}
      </div>

      <div className="chat-body">
        {messages.length === 0 && (
          <div className="empty">
            <div className="circle"><MessageCircle size={22} strokeWidth={1.8} /></div>
            <strong>ابدأ الحديث</strong>
            <p>{person.name}</p>
          </div>
        )}
        {messages.map((m, i) => {
          const prev = messages[i - 1];
          const showDay = !prev || dayLabel(prev.at) !== dayLabel(m.at);
          const mine = m.from === 'u-me';
          // رسالة مكالمة: لا فقاعة نصّ — سطر مكالمة بوصفه وأيقونته وزرّ إعادة الاتصال
          if (m.type === 'call') {
            const c = m.call || {};
            const missedCall = c.status === 'missed' || c.status === 'rejected' || c.status === 'canceled';
            const incoming = Boolean(c.caller && person.username && c.caller.username === person.username);
            const Ico = missedCall ? PhoneMissed : incoming ? PhoneIncoming : PhoneOutgoing;
            return (
              <React.Fragment key={m.id || i}>
                {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
                <div className={`call-row${missedCall ? ' missed' : ''}`}>
                  <span className="call-ico" aria-hidden="true"><Ico size={16} strokeWidth={2} /></span>
                  <div className="grow">
                    <b>{callLine(c)}</b>
                    <small>
                      {incoming ? 'مكالمة واردة' : 'مكالمة صادرة'}
                      {c.status === 'missed' ? ' · بلا ردّ' : ''}
                      {c.status === 'rejected' ? ' · مرفوضة' : ''}
                      {c.status === 'busy' ? ' · مشغول' : ''}
                      {c.status === 'unreachable' ? ' · غير متصل' : ''}
                      {c.status === 'dropped' ? ' · انقطعت' : ''}
                    </small>
                  </div>
                  <span className="call-at">{timeOf(m.at)}</span>
                  <button
                    className="iconbtn sm"
                    onClick={() => dial(c.kind || 'audio')}
                    disabled={inCall}
                    aria-label={`أعد الاتصال بـ${person.name}`}
                    title="أعد الاتصال"
                  >
                    <Phone size={14} strokeWidth={2} />
                  </button>
                </div>
              </React.Fragment>
            );
          }
          return (
            <React.Fragment key={m.id || i}>
              {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
              <div className={`bubble-row${mine ? ' mine' : ''}`}>
                <div className={`bubble${mine ? ' mine' : ''}${m.media ? ' with-media' : ''}`}>
                  {m.media && m.media.type === 'image' ? (
                    <a className="bubble-media" href={apiUrl(m.media.url)} target="_blank" rel="noreferrer">
                      <img src={apiUrl(m.media.url)} alt={m.media.name || 'صورة مرفقة'} loading="lazy" />
                    </a>
                  ) : null}
                  {m.media && m.media.type === 'video' ? (
                    <video className="bubble-media" src={apiUrl(m.media.url)} controls playsInline preload="metadata" />
                  ) : null}
                  {m.media && m.media.type === 'doc' ? (
                    <a className="bubble-doc" href={apiUrl(m.media.url)} target="_blank" rel="noreferrer">
                      <FileText size={18} strokeWidth={1.8} />
                      <span>
                        <b>{m.media.name || 'مستند'}</b>
                        <small>{docLabel(m.media.name, m.media.mime)}{m.media.size ? ` · ${fmtSize(m.media.size)}` : ''}</small>
                      </span>
                    </a>
                  ) : null}
                  {m.text ? <span>{m.text}</span> : null}
                  <span className="b-time">
                    {timeOf(m.at)}
                    {mine && <CheckCheck size={13} strokeWidth={2} />}
                  </span>
                </div>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={endRef} />
      </div>

      {att && (
        <div className="chat-attach">
          {att.type === 'image' ? <img src={att.dataUrl} alt="معاينة المرفق" />
            : att.type === 'video' ? <video src={att.dataUrl} muted playsInline preload="metadata" />
              : <span className="doc-ico"><FileText size={18} strokeWidth={1.8} /></span>}
          <div className="grow">
            <b>{att.type === 'image' ? 'صورة جاهزة' : att.type === 'video' ? 'مقطع جاهز' : docLabel(att.name)}</b>
            <small>{att.name ? `${att.name} · ` : ''}{fmtSize(att.size)}</small>
          </div>
          <button className="iconbtn sm" onClick={() => setAtt(null)} aria-label="إزالة المرفق">
            <X size={14} strokeWidth={2} />
          </button>
        </div>
      )}

      <div className="chat-bar">
        <button
          className="attach-btn"
          onClick={pick}
          disabled={attBusy}
          aria-label="أرفق صورة أو مقطعًا أو مستندًا"
          title="أرفق صورة، مقطعًا، أو مستندًا"
        >
          {attBusy ? <Loader2 className="spin" size={18} strokeWidth={2} /> : <Paperclip size={18} strokeWidth={1.8} />}
        </button>
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
          placeholder={`اكتب رسالة إلى ${person.name}…`}
          aria-label="نص الرسالة"
        />
        <button
          className="send-btn"
          onClick={send}
          disabled={busy || attBusy || (!draft.trim() && !att)}
          aria-label="إرسال"
        >
          {busy ? <Loader2 className="spin" size={18} strokeWidth={2} /> : <Send size={18} strokeWidth={1.8} />}
        </button>
      </div>

      <input ref={fileRef} type="file" className="file-sr" tabIndex={-1} onChange={onFile} aria-label="اختيار ملف للإرفاق" />
    </div>
  );
}

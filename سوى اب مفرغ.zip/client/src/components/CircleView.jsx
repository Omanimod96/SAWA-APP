import React, { useMemo, useState } from 'react';
import {
  UserPlus, Search, BadgeCheck, Users, Loader2, MessageCircle, MapPin,
} from 'lucide-react';
import Avatar from './Avatar.jsx';

function InviteCard({ onInvite, busy, city }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', relation: 'دائرة قريبة' });
  const [link, setLink] = useState('');

  const submit = async () => {
    if (!form.name.trim()) return;
    const done = await onInvite(form);
    if (done) {
      setLink(`sawa.app/j/${Math.random().toString(36).slice(2, 7)}`);
      setForm({ name: '', relation: 'دائرة قريبة' });
    }
  };

  if (!open) {
    return (
      <button className="composer-trigger" onClick={() => setOpen(true)}>
        <UserPlus size={18} strokeWidth={2} />
        <span>ادعُ شخصًا تعرفه في الواقع</span>
      </button>
    );
  }

  return (
    <div className="card composer">
      <div className="field">
        <span>الاسم</span>
        <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="اسم الشخص" />
      </div>
      <div className="field">
        <span>الدائرة</span>
        <select value={form.relation} onChange={(e) => setForm({ ...form, relation: e.target.value })}>
          <option>دائرة قريبة</option>
          <option>العائلة</option>
          <option>الزملاء</option>
          <option>الجيران</option>
        </select>
      </div>
      {link && <div className="invite-link">رابط الدعوة: <b>{link}</b> — صالح ٧ أيام</div>}
      <div className="actions">
        <button className="btn ghost" onClick={() => setOpen(false)}>إغلاق</button>
        <button className="btn" onClick={submit} disabled={busy || !form.name.trim()}>
          {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <UserPlus size={16} strokeWidth={1.8} />}
          أرسل الدعوة
        </button>
      </div>
    </div>
  );
}

export default function CircleView({ data, actions, busy, onMessage }) {
  const [q, setQ] = useState('');
  const [rel, setRel] = useState('all');

  const relations = useMemo(() => ['all', ...new Set(data.people.map((p) => p.relation))], [data.people]);

  const list = useMemo(() => {
    const term = q.trim();
    return data.people.filter(
      (p) => (rel === 'all' || p.relation === rel) && (!term || p.name.includes(term) || p.city.includes(term))
    );
  }, [data.people, q, rel]);

  return (
    <div className="view">
      <InviteCard onInvite={actions.invite} busy={busy} city={data.me.city} />

      <div className="searchbar">
        <Search size={16} strokeWidth={1.8} />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث باسم أو مدينة…" />
      </div>

      <div className="chips filter">
        {relations.map((r) => (
          <button key={r} className={`chip${rel === r ? ' on' : ''}`} onClick={() => setRel(r)}>
            {r === 'all' ? 'الكل' : r}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <div className="empty">
          <div className="circle"><Users size={22} strokeWidth={1.8} /></div>
          <strong>لا نتائج مطابقة</strong>
          <p>جرّب اسمًا آخر أو أزل التصفية.</p>
        </div>
      ) : (
        <ul className="people">
          {list.map((p, i) => (
            <li key={p.id} className={`card person fade-up d${(i % 3) + 1}`}>
              <Avatar name={p.name} color={p.color} photo={p.avatar} />
              <div className="grow">
                <div className="pname">
                  {p.name}
                  {p.verified ? (
                    <BadgeCheck size={15} strokeWidth={2} className="verified" />
                  ) : null}
                </div>
                <div className="meta">
                  <span>{p.relation}</span>
                  <span className="sep">·</span>
                  <MapPin size={12} strokeWidth={1.8} />
                  <span>{p.city}</span>
                  <span className="sep">·</span>
                  <span>{p.lastSeen}</span>
                </div>
              </div>
              <span className="trust">{p.verified ? 'موثّق' : 'بانتظار التأكيد'}</span>
              <button
                className="iconbtn sm"
                title={`محادثة مع ${p.name}`}
                aria-label={`محادثة مع ${p.name}`}
                onClick={() => onMessage && onMessage(p.id)}
              >
                <MessageCircle size={16} strokeWidth={1.8} />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

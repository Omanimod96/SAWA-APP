import React, { useEffect, useRef, useState } from 'react';
import {
  HardDriveDownload, FileCheck2, RotateCcw, Loader2, AlertCircle, Check, FolderOpen, X,
} from 'lucide-react';
import {
  vaultSupported, readMeta, pickVault, saveNow, readVault, readFileObject, downloadSnapshot,
  applySnapshot, countOf, sizeLabel, timeLabel, idbDelete, VAULT_NAME,
} from '../vault.js';

// لوحة «خزنة الجهاز»: ملف واحد على جهاز المستخدم يحفظ المحادثات والبيانات،
// ويُحدَّث تلقائيًا بعد كل تغيير. الاستعادة تُطبّق ما في الملف على العرض.
export default function VaultPanel({ data, account, onRestore, addToast }) {
  const [meta, setMeta] = useState(() => readMeta());
  const [busy, setBusy] = useState(null);
  const [msg, setMsg] = useState(null);
  const [loaded, setLoaded] = useState(null);
  const fileRef = useRef(null);
  const supported = vaultSupported();
  const counts = data ? countOf(applySnapshot({}, data)) : null;

  // حفظ تلقائي بلا إزعاج: نُحدّث الحالة المعروضة بعد كل كتابة
  useEffect(() => {
    const onSaved = () => setMeta(readMeta());
    window.addEventListener('sawa:vault', onSaved);
    return () => window.removeEventListener('sawa:vault', onSaved);
  }, []);

  const choose = async () => {
    setBusy('pick'); setMsg(null);
    try {
      const res = await pickVault(data, account);
      setMeta(readMeta());
      setMsg({ type: 'ok', text: `أُنشئ الملف ${res.name} على جهازك — ${sizeLabel(res.bytes)}` });
      if (addToast) addToast('صار لبياناتك ملف على جهازك', 'success');
    } catch (e) {
      if (e && e.name === 'AbortError') setMsg(null);
      else setMsg({ type: 'bad', text: (e && e.message) || 'تعذّر إنشاء الملف' });
    } finally { setBusy(null); }
  };

  const save = async () => {
    setBusy('save'); setMsg(null);
    const res = await saveNow(data, account);
    setBusy(null);
    setMeta(readMeta());
    if (res.error) setMsg({ type: 'bad', text: res.error });
    else setMsg({ type: 'ok', text: `حُفظت نسخة — ${sizeLabel(res.bytes)}` });
  };

  const restore = async () => {
    setBusy('read'); setMsg(null);
    const res = await readVault();
    setBusy(null);
    if (res.error) { setMsg({ type: 'bad', text: res.error }); return; }
    setLoaded({ name: res.name, doc: res.doc, counts: countOf(res.doc) });
  };

  const onFile = async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    setBusy('read'); setMsg(null);
    const res = await readFileObject(f);
    setBusy(null);
    if (res.error) { setMsg({ type: 'bad', text: res.error }); return; }
    setLoaded({ name: res.name || f.name, doc: res.doc, counts: countOf(res.doc) });
  };

  const confirmRestore = () => {
    if (!loaded) return;
    onRestore(loaded.doc);
    setMsg({ type: 'ok', text: 'استُعيدت البيانات من ملفك على هذا الجهاز' });
    setLoaded(null);
    if (addToast) addToast('استُعيدت بياناتك من الملف', 'success');
  };

  const stop = async () => {
    await idbDelete();
    setMeta(null);
    setMsg({ type: 'ok', text: 'أُوقف الحفظ في الملف (الملف نفسه لم يُحذف)' });
  };

  return (
    <section className="card vault-panel">
      <header className="vp-head">
        <HardDriveDownload size={17} strokeWidth={1.8} />
        <div>
          <strong>ملف بياناتي على الجهاز</strong>
          <span>محادثاتك وبياناتك تُحفظ في ملف داخل جهازك — تُحدَّث تلقائيًا</span>
        </div>
      </header>
      <p className="vp-note">
        الخزنة ملف واحد باسم <code>{VAULT_NAME}</code>: من كان معك، وما قلت، وأين كان الأثر.
        افتحه من أي جهاز لتستعيد ما فيه.
      </p>
      {counts && (
        <div className="vp-counts">
          <span><b>{counts.people}</b> شخصًا</span>
          <span><b>{counts.chats}</b> محادثة</span>
          <span><b>{counts.messages}</b> رسالة</span>
          <span><b>{counts.athar}</b> أثرًا</span>
          <span><b>{counts.whispers}</b> همسة</span>
        </div>
      )}
      {loaded ? (
        <div className="vp-loaded">
          <p>
            من <b>{loaded.name}</b>: {loaded.counts.people} شخصًا · {loaded.counts.chats} محادثة ·{' '}
            {loaded.counts.messages} رسالة · {loaded.counts.athar} أثرًا.
          </p>
          <div className="vp-row">
            <button className="btn" onClick={confirmRestore}>استعد الآن</button>
            <button className="btn ghost" onClick={() => setLoaded(null)}>
              <X size={15} strokeWidth={1.8} /> إلغاء
            </button>
          </div>
        </div>
      ) : (
        <div className="vp-row">
          {supported ? (
            <button className="btn" onClick={choose} disabled={busy === 'pick' || !data}>
              {busy === 'pick' ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <FolderOpen size={16} strokeWidth={1.8} />}
              {meta && meta.name ? 'تغيير الملف' : 'اختر ملفًا على جهازي'}
            </button>
          ) : (
            <button className="btn" onClick={() => { const r = downloadSnapshot(data, account); setMsg({ type: 'ok', text: `نُزّلت نسخة ${VAULT_NAME} — ${sizeLabel(r.bytes)}` }); }} disabled={!data}>
              <HardDriveDownload size={16} strokeWidth={1.8} /> نزّل نسخة
            </button>
          )}
          <button className="btn ghost" onClick={() => fileRef.current && fileRef.current.click()} disabled={busy === 'read'}>
            {busy === 'read' ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <RotateCcw size={16} strokeWidth={1.8} />}
            استعادة من ملف
          </button>
          {meta && meta.name && supported && (
            <button className="btn ghost" onClick={save} disabled={busy === 'save'}>
              {busy === 'save' ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <FileCheck2 size={16} strokeWidth={1.8} />}
              احفظ الآن
            </button>
          )}
          <input ref={fileRef} type="file" accept="application/json,.json" onChange={onFile} hidden />
        </div>
      )}
      {meta && meta.name && (
        <p className="vp-file">
          <FileCheck2 size={14} strokeWidth={1.8} /> {meta.name} · {sizeLabel(meta.bytes)} · {timeLabel(meta.lastAt)}
          {meta.pending ? ' · ينتظر إذنك للكتابة (اضغط «احفظ الآن»)' : ''}
          {' · '}
          <button type="button" className="vp-link" onClick={stop}>إيقاف</button>
        </p>
      )}
      {!supported && (
        <p className="vp-note vp-warn">
          متصفحك لا يسمح بالكتابة في ملف مباشرة — النسخة تُنزَّل، والاستعادة من نفس الملف.
        </p>
      )}
      {msg && (
        <p className={`vp-msg ${msg.type === 'bad' ? 'bad' : 'ok'}`}>
          {msg.type === 'bad' ? <AlertCircle size={14} strokeWidth={1.8} /> : <Check size={14} strokeWidth={1.8} />}
          {msg.text}
        </p>
      )}
    </section>
  );
}

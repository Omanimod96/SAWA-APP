import React, { useState } from 'react';
import {
  CalendarClock, Plus, Vote, CheckCircle2, Bell, Loader2, MapPin, Users,
  CalendarDays, AlarmClock, Ban,
} from 'lucide-react';
import { fmtWhen, countdown, defaultSlot, fromInputValue } from '../datetime.js';

const REMIND_OPTIONS = [
  { minutes: 1440, label: 'قبل يوم' },
  { minutes: 60, label: 'قبل ساعة' },
  { minutes: 30, label: 'قبل نصف ساعة' },
];

const REMIND_STATE = {
  sent: 'أُرسل',
  due: 'يُرسل الآن',
  skipped: 'مضى وقته',
  upcoming: 'قادم',
};

const split = (v) => String(v || '').split('\n').map((s) => s.trim()).filter(Boolean);

function ReminderPicker({ value, onChange, disabled }) {
  const toggle = (m) => onChange(value.includes(m) ? value.filter((x) => x !== m) : [...value, m]);
  return (
    <div className="field">
      <span>وقت التذكير</span>
      <div className="chips">
        {REMIND_OPTIONS.map((o) => (
          <button
            key={o.minutes}
            type="button"
            className={`chip${value.includes(o.minutes) ? ' on' : ''}`}
            aria-pressed={value.includes(o.minutes)}
            disabled={disabled}
            onClick={() => toggle(o.minutes)}
          >
            <Bell size={13} strokeWidth={1.8} /> {o.label}
          </button>
        ))}
      </div>
      {value.length === 0 ? (
        <span className="err">اختر تذكيرًا واحدًا على الأقل — بدونه لن يصلك إشعار قبل الموعد.</span>
      ) : null}
    </div>
  );
}

function WhenField({ value, onChange, optional, disabled }) {
  const inputRef = React.useRef(null);
  return (
    <div className="field">
      <span>{optional ? 'الموعد المتوقع (اختياري)' : 'التاريخ والوقت'}</span>
      <div className="when-input">
        <CalendarDays size={16} strokeWidth={1.8} />
        <input
          ref={inputRef}
          type="datetime-local"
          value={value}
          disabled={disabled}
          onChange={(e) => onChange(e.target.value)}
        />
        <button
          type="button"
          className="ghost-btn"
          onClick={() => { onChange(defaultSlot()); if (inputRef.current) inputRef.current.focus(); }}
        >
          غدًا ٨ مساءً
        </button>
      </div>
      {value && new Date(value).getTime() > 0 ? (
        <span className="hint">
          <AlarmClock size={12} strokeWidth={1.8} /> {fmtWhen(value)} · {countdown(new Date(value).getTime() - Date.now())}
        </span>
      ) : null}
    </div>
  );
}

function CreateMeeting({ onCreate, busy }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState('vote');
  const [title, setTitle] = useState('');
  const [slots, setSlots] = useState('الخميس ٩:٠٠ مساءً\nالجمعة ٥:٠٠ مساءً');
  const [places, setPlaces] = useState('بيت الجدة — الخوض');
  const [attendees, setAttendees] = useState('5');
  const [when, setWhen] = useState(defaultSlot());
  const [voteWhen, setVoteWhen] = useState('');
  const [reminders, setReminders] = useState([1440, 60]);

  const reset = () => { setTitle(''); setWhen(defaultSlot()); setVoteWhen(''); };

  const submit = async () => {
    if (!title.trim()) return;
    if (mode === 'fixed' && !when) return;
    const payload = mode === 'fixed'
      ? {
        kind: 'fixed', title, place: split(places)[0] || 'يُحدَّد لاحقًا',
        at: fromInputValue(when), attendees: Number(attendees), reminders,
      }
      : {
        kind: 'vote', title, slots: split(slots), places: split(places),
        at: fromInputValue(voteWhen), attendees: Number(attendees), reminders,
      };
    const done = await onCreate(payload);
    if (done) { reset(); setOpen(false); }
  };

  if (!open) {
    return (
      <button className="composer-trigger" onClick={() => setOpen(true)}>
        <Plus size={18} strokeWidth={2} />
        <span>اجتماع: تصويت على وقت، أو موعد بتذكير</span>
        <CalendarClock size={16} strokeWidth={1.8} />
      </button>
    );
  }

  return (
    <div className="card composer">
      <div className="seg" role="tablist" aria-label="نوع الاجتماع">
        <button
          className={`seg-btn${mode === 'vote' ? ' on' : ''}`}
          onClick={() => setMode('vote')}
          role="tab"
          aria-selected={mode === 'vote'}
        >
          <Vote size={15} strokeWidth={1.8} /> طرح للتصويت
        </button>
        <button
          className={`seg-btn${mode === 'fixed' ? ' on' : ''}`}
          onClick={() => setMode('fixed')}
          role="tab"
          aria-selected={mode === 'fixed'}
        >
          <Bell size={15} strokeWidth={1.8} /> موعد بتذكير
        </button>
      </div>

      <div className="field">
        <span>عنوان الاجتماع</span>
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="قهوة العائلة الشهرية" />
      </div>

      {mode === 'vote' ? (
        <>
          <label className="field">
            <span>الأوقات المقترحة (سطر لكل وقت)</span>
            <textarea rows={3} value={slots} onChange={(e) => setSlots(e.target.value)} />
          </label>
          <WhenField value={voteWhen} onChange={setVoteWhen} optional />
        </>
      ) : (
        <>
          <WhenField value={when} onChange={setWhen} />
          <label className="field">
            <span>المكان</span>
            <input value={places} onChange={(e) => setPlaces(e.target.value)} placeholder="عيادة الخوض — د. سالم" />
          </label>
          <div className="note-box">
            <Ban size={14} strokeWidth={1.8} />
            <span>موعد ثابت بلا تصويت: يُثبَّت فورًا على التاريخ والوقت المحدَّدين.</span>
          </div>
        </>
      )}

      {mode === 'vote' && (
        <label className="field">
          <span>الأماكن المقترحة</span>
          <textarea rows={2} value={places} onChange={(e) => setPlaces(e.target.value)} />
        </label>
      )}

      <div className="field">
        <span>عدد المدعوين</span>
        <select value={attendees} onChange={(e) => setAttendees(e.target.value)}>
          {[2, 3, 4, 5, 6, 8, 10, 12].map((n) => <option key={n} value={n}>{n} أشخاص</option>)}
        </select>
      </div>

      <ReminderPicker value={reminders} onChange={setReminders} disabled={busy} />

      <div className="actions">
        <button className="btn ghost" onClick={() => setOpen(false)}>إلغاء</button>
        <button
          className="btn"
          onClick={submit}
          disabled={busy || !title.trim() || reminders.length === 0}
        >
          {busy ? <Loader2 className="spin" size={16} strokeWidth={2} />
            : (mode === 'fixed' ? <Bell size={16} strokeWidth={1.8} /> : <Vote size={16} strokeWidth={1.8} />)}
          {mode === 'fixed' ? 'احفظ الموعد وشغّل التذكير' : 'اطرح للتصويت'}
        </button>
      </div>
    </div>
  );
}

function WhenBox({ meeting }) {
  const ms = new Date(meeting.atIso).getTime() - Date.now();
  return (
    <div className={`when-box${meeting.overdue ? ' past' : ''}`}>
      <div className="when-top">
        <CalendarClock size={16} strokeWidth={1.8} />
        <b>{fmtWhen(meeting.atIso)}</b>
        <span className="count">{meeting.overdue ? 'انتهى' : countdown(ms)}</span>
      </div>
      {meeting.place && (
        <div className="meta">
          <MapPin size={12} strokeWidth={1.8} /> {meeting.place}
          {meeting.kind === 'fixed' && (<><span className="sep">·</span><Ban size={12} strokeWidth={1.8} /> بلا تصويت</>)}
        </div>
      )}
      <ul className="remind-list">
        {meeting.reminderView.map((b) => (
          <li key={b.minutes} className={b.status}>
            <Bell size={12} strokeWidth={1.8} />
            <span>تذكير {b.label}</span>
            <em>{REMIND_STATE[b.status] || 'قادم'}</em>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ConfirmPanel({ meeting, onConfirm, busy }) {
  const [when, setWhen] = useState(defaultSlot());
  const [reminders, setReminders] = useState(meeting.reminders || [1440, 60]);
  const top = meeting.slots.slice().sort((a, b) => b.votes - a.votes)[0];
  return (
    <div className="confirm-panel">
      <WhenField value={when} onChange={setWhen} />
      <ReminderPicker value={reminders} onChange={setReminders} disabled={busy} />
      <div className="actions">
        <button
          className="btn sm"
          disabled={busy || reminders.length === 0}
          onClick={() => onConfirm({
            slotId: top && top.id, at: fromInputValue(when), reminders,
          })}
        >
          <CheckCircle2 size={15} strokeWidth={1.8} /> ثبّت الأكثر تصويتًا
        </button>
      </div>
    </div>
  );
}

function VoteRow({ meeting, slot, total, onVote, busy }) {
  const pct = total ? Math.round((slot.votes / total) * 100) : 0;
  const mine = meeting.myVote === slot.id;
  return (
    <button className={`vote${mine ? ' on' : ''}`} onClick={() => onVote(slot.id)} disabled={busy}>
      <span className="vlabel">{slot.label}</span>
      <span className="vbar"><i style={{ width: `${pct}%` }} /></span>
      <span className="vcount">{slot.votes}</span>
    </button>
  );
}

function MeetingCard({ meeting, actions, busy }) {
  const total = (meeting.slots || []).reduce((a, s) => a + s.votes, 0);
  const confirmed = meeting.status === 'confirmed';
  const voting = meeting.status === 'voting';
  const top = (meeting.slots || []).slice().sort((a, b) => b.votes - a.votes)[0];
  const chosen = confirmed && meeting.confirmed
    ? ((meeting.slots || []).find((s) => s.id === meeting.confirmed.slotId) || top)
    : null;

  return (
    <article className={`card meeting${confirmed || meeting.scheduled ? ' confirmed' : ''}`}>
      <header className="room-head">
        <div className="room-icon">{meeting.kind === 'fixed'
          ? <Bell size={18} strokeWidth={1.8} />
          : <CalendarClock size={18} strokeWidth={1.8} />}
        </div>
        <div className="grow">
          <div className="pname">{meeting.title}</div>
          <div className="meta">
            <Users size={12} strokeWidth={1.8} />
            <span>{meeting.attendees} مدعوًا</span>
            <span className="sep">·</span>
            <span>{voting ? `${total} صوتًا` : (meeting.kind === 'fixed' ? 'موعد ثابت' : 'مؤكَّد')}</span>
          </div>
        </div>
        <span className={`tag${voting ? '' : ' ok'}`}>
          {voting ? 'تصويت' : (meeting.overdue ? 'انتهى' : 'مثبّت')}
        </span>
      </header>

      {meeting.atIso && <WhenBox meeting={meeting} />}

      {voting && (
        <div className="slots">
          {(meeting.slots || []).map((s) => (
            <VoteRow
              key={s.id}
              meeting={meeting}
              slot={s}
              total={total}
              busy={busy}
              onVote={(slotId) => actions.vote(meeting.id, slotId)}
            />
          ))}
        </div>
      )}

      {confirmed && chosen && meeting.kind !== 'fixed' && (
        <div className="confirmed-box">
          <CheckCircle2 size={16} strokeWidth={1.8} />
          <div>
            <b>{chosen.label}</b>
            <div className="meta">الوقت المثبّت بالتصويت</div>
          </div>
        </div>
      )}

      {voting && (
        <ConfirmPanel meeting={meeting} busy={busy} onConfirm={(p) => actions.confirmMeeting(meeting.id, p)} />
      )}
    </article>
  );
}

function NextUp({ meeting }) {
  return (
    <div className="card next-up">
      <div className="room-icon"><AlarmClock size={18} strokeWidth={1.8} /></div>
      <div className="grow">
        <div className="pname">{meeting.title}</div>
        <div className="meta">
          {fmtWhen(meeting.atIso)} · {meeting.place}
        </div>
      </div>
      <span className="count">{meeting.overdue ? 'انتهى' : countdown(new Date(meeting.atIso).getTime() - Date.now())}</span>
    </div>
  );
}

export default function MeetingsView({ data, actions, busy }) {
  const meetings = data.meetings || [];
  const next = (meetings.filter((m) => m.atIso && !m.overdue)
    .sort((a, b) => new Date(a.atIso) - new Date(b.atIso))[0]) || null;

  return (
    <div className="view">
      <CreateMeeting onCreate={actions.createMeeting} busy={busy} />

      {next && <NextUp meeting={next} />}

      {meetings.map((m, i) => (
        <div key={m.id} className={`fade-up d${(i % 3) + 1}`}>
          <MeetingCard meeting={m} actions={actions} busy={busy} />
        </div>
      ))}
    </div>
  );
}

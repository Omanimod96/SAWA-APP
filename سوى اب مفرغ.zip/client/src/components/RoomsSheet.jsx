import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X, DoorOpen, Sparkles, Users, Archive } from 'lucide-react';
import RoomsPanel from './RoomsPanel.jsx';
import RoomChat from './RoomChat.jsx';

const GROUPS = [
  { id: 'rooms-new', key: 'fresh', label: 'جديدة', Icon: Sparkles },
  { id: 'rooms-inside', key: 'inside', label: 'انضممت إليها', Icon: Users },
  { id: 'rooms-athar', key: 'athar', label: 'صارت أثرًا', Icon: Archive },
];

// نافذة الغرف — تعيش داخل نافذة الحالات: ورقة واحدة فوق الشاشة، بثلاث مجموعات مفصولة.
export default function RoomsSheet({ open, data, actions, busy, focus, onClose, onGoAthar }) {
  const [chatId, setChatId] = useState(null);
  const [flashId, setFlashId] = useState(null);
  const applied = useRef(null); // كل طلب فتح غرفة يُنفَّذ مرة واحدة فقط
  const rooms = (data && data.rooms) || [];

  const counts = useMemo(() => ({
    fresh: rooms.filter((r) => r.status === 'open' && !r.joined).length,
    inside: rooms.filter((r) => r.status === 'open' && r.joined).length,
    athar: rooms.filter((r) => r.status !== 'open' && r.joined).length,
  }), [rooms]);

  const chat = chatId ? rooms.find((r) => r.id === chatId) : null;

  // إغلاق الورقة → لا دردشة معلّقة في المرة القادمة
  useEffect(() => { if (!open) { setChatId(null); setFlashId(null); } }, [open]);

  // غرفة مطلوبة من بطاقة حالة أو قصة: كنت داخلها ⇒ تُفتح دردشتها فورًا،
  // وإلا تُبرز في مجموعتها. القرار هنا لا في اللوحة، لأن اللوحة تُفكَّك عند فتح الدردشة
  // فيضيع أثر «نُفِّذ الطلب» وتعود الدردشة تفتح نفسها بعد كل رجوع.
  useEffect(() => {
    if (!open || !focus || !focus.at) return undefined;
    if (applied.current === focus.at) return undefined;
    applied.current = focus.at;
    const room = rooms.find((r) => r.id === focus.id);
    if (!room) return undefined;
    if (room.status === 'open' && room.joined) { setChatId(room.id); return undefined; }
    setFlashId(room.id);
    const off = setTimeout(() => setFlashId(null), 2600);
    return () => clearTimeout(off);
  }, [open, focus, rooms]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      if (chatId) setChatId(null); else onClose();
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, chatId, onClose]);

  if (!open || !data) return null;

  const jump = (id) => {
    const el = document.getElementById(id);
    if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', behavior: 'smooth' });
  };

  return createPortal(
    <div className="overlay rooms-overlay" onClick={onClose} role="dialog" aria-modal="true" aria-label="الغرف">
      <div className="sheet rooms-sheet" onClick={(e) => e.stopPropagation()}>
        <div className="grabber" />
        <div className="sheet-head">
          <div>
            <h3>الغرف</h3>
            <p className="sheet-sub">غرف مؤقتة بدائرتك — تنتهي، وتبقى أثرًا.</p>
          </div>
          <button className="iconbtn" onClick={onClose} aria-label="إغلاق الغرف">
            <X size={18} strokeWidth={1.8} />
          </button>
        </div>

        {!chat && (
          <div className="rooms-groups">
            {GROUPS.map(({ id, key, label, Icon }) => (
              <button key={key} className={`group-chip g-${key}${counts[key] ? ' on' : ''}`} onClick={() => jump(id)}>
                <Icon size={14} strokeWidth={1.9} />
                <span>{label}</span>
                <b>{counts[key]}</b>
              </button>
            ))}
          </div>
        )}

        <div className="rooms-body">
          {chat
            ? <div className="rooms-chat"><RoomChat room={chat} actions={actions} busy={busy} onClose={() => setChatId(null)} /></div>
            : (
              <RoomsPanel
                data={data}
                actions={actions}
                busy={busy}
                flashId={flashId}
                onOpenChat={setChatId}
                onGoAthar={onGoAthar ? () => { onClose(); onGoAthar(); } : null}
              />
            )}
        </div>
      </div>
    </div>,
    document.body
  );
}

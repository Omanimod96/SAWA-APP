// ─────────────────────────────────────────────────────────────────────────────
// CallScreen.jsx — شاشة المكالمة (صوتية/مرئية).
//
// مبدآن في التصميم:
//   • لا شيء يغطّي الشاشة بلا سبب: تظهر الشاشة عند رنين/مكالمة قائمة فقط.
//   • كل زرّ باسمه المقروء (aria-label)، وهدف لمس ≥ 56px كما في باقي التطبيق.
// الوسائط تُرسم من كائن MediaStream يُسلَّم للعنصر مباشرة — لا تمرّ من الخادم.
// ─────────────────────────────────────────────────────────────────────────────
import React, { useEffect, useRef } from 'react';
import {
  Phone, PhoneOff, Video, VideoOff, Mic, MicOff, SwitchCamera, Loader2,
} from 'lucide-react';
import Avatar from './Avatar.jsx';

const fmtDuration = (sec) => {
  const s = Math.max(0, Number(sec) || 0);
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, '0')}`;
};

const statusText = (call, phase) => {
  const status = (call && call.status) || '';
  if (status === 'busy') return 'الطرف الآخر في مكالمة أخرى';
  if (status === 'unreachable') return 'الطرف الآخر غير متصل الآن';
  if (status === 'missed') return 'لا يوجد ردّ';
  if (status === 'rejected') return 'المكالمة رُفضت';
  if (status === 'dropped') return 'انقطعت المكالمة';
  if (status === 'canceled') return 'أُلغيت المكالمة';
  if (status === 'ended') return 'انتهت المكالمة';
  if (phase === 'incoming') return call && call.kind === 'video' ? 'مكالمة مرئية واردة' : 'مكالمة صوتية واردة';
  if (phase === 'outgoing') return 'يرنّ…';
  if (phase === 'connecting') return 'جارٍ الاتصال…';
  return '';
};

// يُسند دفق الوسائط إلى عنصر الفيديو (لا srcObject في JSX)
function Stream({ stream, kind, muted = false, className = '' }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    try { el.srcObject = stream || null; } catch (e) { /* متصفح قديم */ }
  }, [stream]);
  if (!stream) return null;
  return <video ref={ref} className={className} autoPlay playsInline muted={muted} data-kind={kind} />;
}

export default function CallScreen({ state, actions, local, remote }) {
  const { phase, call } = state;
  const peer = (call && call.peer) || {};
  const kind = (call && call.kind) || 'audio';
  const ringing = phase === 'incoming' || phase === 'outgoing' || phase === 'connecting';
  const live = phase === 'active' || phase === 'connecting';
  const videoOn = kind === 'video' && !state.camOff;
  const showRemote = kind === 'video' && state.remoteReady && !state.peerCamOff;

  if (phase === 'idle') return null;

  return (
    <div className={`call-screen${live ? ' live' : ''}`} role="dialog" aria-label="مكالمة" aria-modal="true">
      <div className="call-stage">
        {showRemote ? (
          <Stream stream={remote} kind="remote" className="call-remote" />
        ) : (
          <div className="call-face">
            <div className={`call-pulse${ringing ? ' on' : ''}`} aria-hidden="true" />
            <Avatar name={peer.name || 'مكالمة'} color={peer.color} size="lg" photo={peer.avatar} />
          </div>
        )}
        {kind === 'video' && state.localReady && !state.camOff ? (
          <div className="call-pip">
            <Stream stream={local} kind="local" muted className="call-local" />
          </div>
        ) : null}
      </div>

      <div className="call-info">
        <div className="call-name">{peer.name || 'مكالمة'}</div>
        <div className="call-why">
          {phase === 'active'
            ? (
              <>
                <span className="call-timer" dir="ltr">{fmtDuration(state.durationSec)}</span>
                {state.peerMuted ? <span className="call-tag"><MicOff size={13} strokeWidth={2} /> كتم طرفه</span> : null}
                {state.peerCamOff && kind === 'video' ? <span className="call-tag"><VideoOff size={13} strokeWidth={2} /> أطفأ كاميرته</span> : null}
              </>
            )
            : statusText(call, phase)}
        </div>
        {state.notice ? <div className="call-notice">{state.notice}</div> : null}
        {state.error ? <div className="call-error">{state.error}</div> : null}
      </div>

      <div className="call-bar">
        {phase === 'incoming' ? (
          <>
            <button className="call-btn reject" onClick={() => actions.reject('declined')} aria-label="ارفض المكالمة">
              <PhoneOff size={24} strokeWidth={1.8} />
              <span>رفض</span>
            </button>
            <button className="call-btn accept" onClick={() => actions.accept()} aria-label={kind === 'video' ? 'اقبل المكالمة المرئية' : 'اقبل المكالمة الصوتية'}>
              {kind === 'video' ? <Video size={24} strokeWidth={1.8} /> : <Phone size={24} strokeWidth={1.8} />}
              <span>قبول</span>
            </button>
          </>
        ) : phase === 'ended' ? (
          <button className="call-btn wide" onClick={() => actions.dismiss()} aria-label="إغلاق">
            <span>إغلاق</span>
          </button>
        ) : (
          <>
            <button
              className={`call-btn round${state.muted ? ' off' : ''}`}
              onClick={() => actions.toggleMute()}
              aria-label={state.muted ? 'ألغِ كتم الميكروفون' : 'اكتم الميكروفون'}
            >
              {state.muted ? <MicOff size={22} strokeWidth={1.8} /> : <Mic size={22} strokeWidth={1.8} />}
            </button>
            {kind === 'video' ? (
              <>
                <button
                  className={`call-btn round${state.camOff ? ' off' : ''}`}
                  onClick={() => actions.toggleCam()}
                  aria-label={state.camOff ? 'شغّل الكاميرا' : 'أطفئ الكاميرا'}
                >
                  {state.camOff ? <VideoOff size={22} strokeWidth={1.8} /> : <Video size={22} strokeWidth={1.8} />}
                </button>
                <button className="call-btn round" onClick={() => actions.flipCamera()} aria-label="بدّل بين الكاميرتين">
                  <SwitchCamera size={22} strokeWidth={1.8} />
                </button>
              </>
            ) : null}
            <button className="call-btn round hang" onClick={() => actions.hangup()} aria-label="أنه المكالمة">
              {phase === 'outgoing' || phase === 'connecting' ? <PhoneOff size={22} strokeWidth={1.8} /> : <PhoneOff size={22} strokeWidth={1.8} />}
            </button>
            {phase === 'outgoing' && state.channel === '' ? (
              <span className="call-wait"><Loader2 className="spin" size={14} strokeWidth={2} /> نجمع القناة…</span>
            ) : null}
          </>
        )}
      </div>
    </div>
  );
}

import { useState } from 'react';
import { MessageCircle, MapPin, Clock, DoorOpen, Send, VenetianMask } from 'lucide-react';
import Avatar from './Avatar.jsx';
import Sheet from './Sheet.jsx';
import { formatLeft } from '../useToast.js';

export default function StateCard({ state, people, me, onRespond, onWhisper, onOpenRoom, onOpenWhisper, index }) {
  const [open, setOpen] = useState(false);
  const [text, setText] = useState('');
  const author = people.find((p) => p.id === state.author);
  const isMine = state.author === 'u-me' || !!state.authorIsMe;
  const who = isMine ? 'أنت' : author ? author.name : 'عضو في دائرتك';
  // حماية: أي حالة بلا حقل tally (بيانات قديمة أو ناقصة) كانت تُسقط الشجرة كلها
  const tally = state.tally || {};
  const yes = tally.yes || 0;
  const expired = !state.msLeft;
  const doneRoom = !!state.roomId;
  // لا ردّ على حالتك، ولا ردّ بعد انتهائها أو بعد فتح الغرفة
  const canRespond = !isMine && !expired && !doneRoom;

  return (
    <article className={`card tap d${(index % 3) + 1}`}>
      <div className="card-head">
        <Avatar name={isMine ? me.name : author ? author.name : 'عضو'} color={isMine ? me.avatarColor : (author && author.color)} photo={isMine ? me.avatar : (author && author.avatar)} />
        <div className="who">
          <div className="name">{who}</div>
          <div className="meta">
            <span>{author ? author.relation : me.trust}</span>
            <span>·</span>
            <span>{formatLeft(new Date(state.expiresIn).getTime() - Date.now())} متبقية</span>
          </div>
        </div>
        <span className="layer-tag">{state.layer}</span>
      </div>

      <p className="card-text">{state.text}</p>

      {state.place && (
        <div className="row muted" style={{ gap: '.35rem' }}>
          <MapPin size={14} strokeWidth={1.8} />
          <span>{state.place.name} · {state.place.km} كم عنك</span>
        </div>
      )}

      {state.threshold > 0 && (
        <div className="progress-wrap">
          <div className="progress-top">
            <span>{state.question}</span>
            <span>{yes} / {state.threshold} للنصاب</span>
          </div>
          <div className="progress"><i style={{ width: `${state.progress}%` }} /></div>
          <div className="muted" style={{ fontSize: '.74rem' }}>
            {isMine
              ? 'حالتك — الردود تُحسب من دائرتك أنت'
              : doneRoom
                ? 'اكتمل النصاب — الردود تتابع داخل الغرفة'
                : expired
                  ? 'انتهت مدة الحالة'
                  : `يتبقى ${Math.max(0, state.threshold - yes)} لنفتح الغرفة`}
          </div>
        </div>
      )}

      <div className="options">
        {state.options.map((o) => (
          <button
            key={o.key}
            className={`opt${state.myChoice === o.key ? ' chosen' : ''}`}
            disabled={!canRespond}
            title={canRespond ? '' : isMine ? 'هذه حالتك — يردّ عليها من دائرتك' : doneRoom ? 'الردود داخل الغرفة' : 'انتهت مدة الحالة'}
            onClick={() => (canRespond ? onRespond(state.id, o.key) : null)}
          >
            <span>{o.label}</span>
            <small>{tally[o.key] || 0} شخص</small>
          </button>
        ))}
      </div>

      {state.roomId && (
        <div className="row between pad-t">
          <span className="badge good"><DoorOpen size={13} strokeWidth={2} /> فُتحت غرفة تلقائيًا</span>
          <button className="btn btn-soft" onClick={() => onOpenRoom(state.roomId)}>ادخل الغرفة</button>
        </div>
      )}

      {state.whisperId && (
        <button className="wchip" onClick={() => onOpenWhisper && onOpenWhisper(state.whisperId)}>
          <span className="mask-avatar sm" aria-hidden="true"><VenetianMask size={15} strokeWidth={1.8} /></span>
          <span className="grow">
            <b>{isMine ? 'وصلتك همسة مجهولة على حالتك' : 'همسة صارت محادثة'}</b>
            <small>تابعها في المحادثات — لا يراها غيركما</small>
          </span>
          {state.whisperUnread > 0 && <span className="t-count">{state.whisperUnread}</span>}
          <MessageCircle size={15} strokeWidth={1.8} />
        </button>
      )}

      <div className="row between pad-t">
        <button
          className="btn btn-ghost"
          style={{ padding: '.45rem .8rem', fontSize: '.78rem' }}
          aria-label={`اكتب همسة إلى ${who}`}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <MessageCircle size={15} strokeWidth={1.8} /> همسة
        </button>
        <span className="muted"><Clock size={13} strokeWidth={1.8} /> {new Date(state.createdAt).toLocaleDateString('ar-OM')}</span>
      </div>

      {open && (
        <div className="whisper-form">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            aria-label="نص الهمسة"
            placeholder="اكتب همسة… تصير محادثة بينكما"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && text.trim()) { onWhisper(state.id, state.author, text); setText(''); setOpen(false); }
            }}
          />
          <button className="btn btn-primary" style={{ padding: '.5rem .8rem' }} onClick={() => { if (text.trim()) { onWhisper(state.id, state.author, text); setText(''); setOpen(false); } }}>
            <Send size={15} strokeWidth={1.8} />
          </button>
        </div>
      )}
      {open && (
        <p className="hint whisper-hint">
          الهمسة صارت محادثة كاملة: تُفتح في تبويب المحادثات، وفيها أعجبني · لم يعجبني · من صاحب الهمسة؟
        </p>
      )}
    </article>
  );
}

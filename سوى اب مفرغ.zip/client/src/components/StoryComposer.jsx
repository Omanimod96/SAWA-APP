import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  X, Mic, Square, Trash2, Loader2,
  Send, ChevronDown, MapPin, Clock, Check, ShieldQuestion, Lock, Crosshair,
  Images, Camera, Palette, Users, ChevronUp, SlidersHorizontal,
} from 'lucide-react';
import Avatar from './Avatar.jsx';
import AtharMap from './AtharMap.jsx';
import CameraCapture from './CameraCapture.jsx';
import MediaTools from './MediaTools.jsx';
import MediaFrame from '../MediaFrame.jsx';
import { zoomForRadius } from '../map.js';
import { api } from '../api.js';
import { TYPE_OF, CAP_MB, fmtSize, blobToDataUrl, shrinkImage, mediaDurationMs } from '../media.js';
import { ensure, hintFor } from '../permissions.js';
import { STORY_BG, DEFAULT_BG, bgLabel } from '../storyBg.js';

// «أثر»: مركز افتراضي + آخر موقع محفوظ من الخريطة حتى يبدأ الناشر من مكانه لا من الصفر
const CITY = { lat: 23.588, lng: 58.3829 };
const readSpot = () => {
  try {
    const v = JSON.parse(localStorage.getItem('sawa.athar.point') || 'null');
    return v && Number.isFinite(v.lat) && Number.isFinite(v.lng) ? v : null;
  } catch (e) { return null; }
};

// خصائص الحالة النصّية صارت لونًا سادة واحدًا (STORY_BG): تُختار بضغطة، ثم
// ينتقل النموذج إلى معاينة الحالة/الأثر قبل الإرسال.

// كلمة واحدة في الأسفل: ضغطة واحدة تبدّل بين ١) حالة ٢) أثر ٣) أثر وحالة
// سؤال التفاعل له نصّ افتراضي جاهز — لا يُحسب «خيارًا مفعّلًا» ما لم يُغيَّر
const QUESTION_DEFAULT = 'من معنا؟';
const MODES = ['state', 'athar', 'both'];
const MODE_LABEL = { state: 'حالة', athar: 'أثر', both: 'أثر وحالة' };
const MODE_HINT = { state: 'حتى ٢٤ ساعة', athar: 'يبقى على المكان', both: 'يبقى + حالة مؤقتة' };

const AUD_MODES = [
  { id: 'circle', label: 'كل دائرتي', hint: 'يراها كل من في دائرتك' },
  { id: 'groups', label: 'دوائر محددة', hint: 'اختر دوائر بعينها' },
  { id: 'people', label: 'أشخاص محدّدون', hint: 'اختر أشخاصًا بأسمائهم' },
];
// الاختصار الظاهر على زر «الدائرة» في التذييل
const AUD_SHORT = { circle: 'كل دائرتي', groups: 'دوائر محددة', people: 'أشخاص محدّدون' };

export default function StoryComposer({ open, onClose, busy, actions, onError, me, people, initialFile, onOpenRooms }) {
  const [type, setType] = useState('text');
  const [text, setText] = useState('');
  const [kind, setKind] = useState('moment');
  const [bg, setBg] = useState(DEFAULT_BG); // لون الحالة النصّية (سادة)
  const [step, setStep] = useState('edit'); // edit → preview قبل الإرسال
  const [mode, setMode] = useState('state'); // حالة / أثر / أثر وحالة
  const [place, setPlace] = useState('');
  const [hours, setHours] = useState('24');
  const [threshold, setThreshold] = useState('0');
  const [question, setQuestion] = useState(QUESTION_DEFAULT);
  const [aud, setAud] = useState('circle');
  const [audGroups, setAudGroups] = useState([]);
  const [audPeople, setAudPeople] = useState([]);
  const [audOpen, setAudOpen] = useState(false); // قائمة «الدائرة» في التذييل
  const [modeFlash, setModeFlash] = useState(false); // إبراز فوري لأثر اختيار النوع
  const [flashN, setFlashN] = useState(0); // عدّاد الضغطة — يعمل حتى لو اختير النوع نفسه
  const [media, setMedia] = useState(null);
  const [uploading, setUploading] = useState(false);
  // إرسال قيد التنفيذ: أثرٌ لا يمرّ بــ`busy` العام (run في App) — فكان الزرّ
  // يبقى بنصّه بلا دوران ولا تعطيل لثوانٍ، فيظنّ المستخدم أنه لا يعمل ويضغط ثانية.
  const [sending, setSending] = useState(false);
  // ٣.٦: الافتراضي أضيق نطاق — «كل دائرتي» لا يكون افتراضيًا لمجرّد أنه أوسع.
  // يُطبَّق مرة واحدة عند كل فتح، فلا يُلغي اختيار المستخدم داخل الجلسة نفسها.
  const narrowDone = useRef(false);
  useEffect(() => {
    if (!open) { narrowDone.current = false; return; }
    if (narrowDone.current) return;
    narrowDone.current = true;
    const counts = {};
    (peopleList || []).forEach((p) => { const r = String(p.relation || '').trim(); if (r) counts[r] = (counts[r] || 0) + 1; });
    const narrow = Object.keys(counts).sort((a, b) => counts[a] - counts[b])[0];
    if (narrow) { setAud('groups'); setAudGroups([narrow]); } else { setAud('circle'); setAudGroups([]); }
    // الاعتماد على الخاصية `people` لا على `peopleList`: مصفوفة الاعتماد تُقيَّم وقت
    // الرسم، و`peopleList` تُعرَّف لاحقًا في الدالة ⇒ خطأ TDZ يسقط الشجرة كلها
    // («Cannot access 'Rt' before initialization») وتظهر شاشة بيضاء.
  }, [open, people]);
  const [recording, setRecording] = useState(false);
  const [secs, setSecs] = useState(0);
  const [more, setMore] = useState(false);
  const [cam, setCam] = useState(false); // شاشة التصوير (مدخل إنشاء الحالة)
  // هل تُفتح صفحة الوسائط ملء الشاشة مع أوّل ظهور للوسائط؟ (المعاينة إلزامية
  // بعد التصوير/الاستوديو — لكن «رجوع للتعديل» يعود إلى النموذج لا إلى الصفحة)
  const [startTools, setStartTools] = useState(true);
  // «أثر»: نقطة المكان واسمه، وخريطة مصغّرة داخل النموذج
  const [spot, setSpot] = useState(null);
  const [spotName, setSpotName] = useState('');
  const [spotNames, setSpotNames] = useState([]);
  const [nearPulses, setNearPulses] = useState([]);
  const [locating, setLocating] = useState(false);
  const [mapView, setMapView] = useState(() => readSpot() || CITY);
  const [mapZoom, setMapZoom] = useState(() => Math.max(10, zoomForRadius((readSpot() || CITY).lat, 12, 210)));

  const atharRef = useRef(null); // لوحة المكان — نُمرّر إليها عند اختيار «أثر»
  const consumedRef = useRef(null); // آخر ملف جاهز استُقبل — لا نُكرّره
  const attachRef = useRef(null); // يُشير إلى attach في كل رسمة
  const toolsRef = useRef(null); // «تثبيت» أدوات الوسائط — نستدعيه قبل المعاينة
  const mediaRef = useRef(null); // أحدث وسائط — يقرأها النشر بعد التثبيت غير المتزامن
  const fileRef = useRef(null);
  const recRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const timerRef = useRef(null);

  const circleNames = (me && me.circles) || [];
  const peopleList = people || [];

  useEffect(() => {
    if (!open) {
      setType('text'); setText(''); setMedia(null); setSecs(0); setRecording(false);
      setMore(false); setPlace(''); setKind('moment'); setCam(false);
      setBg(DEFAULT_BG); setStep('edit'); setStartTools(true);
      seenMediaRef.current = null;
      setSpot(null); setSpotName(''); setSpotNames([]); setNearPulses([]); setLocating(false);
      setAud('circle'); setAudGroups([]); setAudPeople([]); setAudOpen(false);
    }
  }, [open]);

  // ملف وصل من شاشة التصوير (أو من الاستوديو): يُعرض جاهزًا في نموذج النشر.
  // `attach` معرّف أسفل دالة المكوّن، والنداء يقع بعد اكتمال الرسمة الأولى — لا مشكلة.
  useEffect(() => {
    if (!open || !initialFile || consumedRef.current === initialFile) return;
    consumedRef.current = initialFile;
    attachRef.current(initialFile);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialFile]);

  // المعاينة إلزامية للوسائط الصوتية أيضًا: التصوير/الاستوديو للصوت ينقل النموذج
  // إلى المعاينة تلقائيًا (الصور تفتح أدواتها ملء الشاشة ثم «تم» ينقل للمعاينة).
  const seenMediaRef = useRef(null);
  useEffect(() => {
    if (!open || !media || media.type !== 'audio') return;
    if (seenMediaRef.current === media.dataUrl) return;
    seenMediaRef.current = media.dataUrl;
    setStep('preview');
  }, [open, media]);

  useEffect(() => () => {
    if (timerRef.current) clearInterval(timerRef.current);
    if (streamRef.current) streamRef.current.getTracks().forEach((t) => t.stop());
  }, []);

  // من يرى الحالة؟ — الجمهور المختار وعدده
  const audience = useMemo(() => {
    if (aud === 'groups') return { scope: 'groups', groups: audGroups, people: [] };
    if (aud === 'people') return { scope: 'people', groups: [], people: audPeople };
    return { scope: 'circle', groups: [], people: [] };
  }, [aud, audGroups, audPeople]);

  const audienceInfo = useMemo(() => {
    if (aud === 'groups') {
      if (!audGroups.length) return { label: 'اختر دائرة واحدة على الأقل', count: 0, ready: false };
      const count = peopleList.filter((p) => audGroups.includes(p.relation)).length;
      return { label: audGroups.join(' و '), count, ready: count > 0 };
    }
    if (aud === 'people') {
      if (!audPeople.length) return { label: 'اختر من تراه حالتك', count: 0, ready: false };
      const names = audPeople.map((id) => {
        const p = peopleList.find((x) => x.id === id);
        return p ? String(p.name).split(' ')[0] : '';
      }).filter(Boolean);
      const label = names.length > 2 ? `${names[0]}، ${names[1]} وآخرون` : names.join('، ');
      return { label, count: audPeople.length, ready: true };
    }
    return { label: 'كل دائرتك', count: peopleList.length, ready: true };
  }, [aud, audGroups, audPeople, peopleList]);

  // دخول «أثر» أو «أثر وحالة»: نفتح لوحة المكان ونبدأ من آخر موقع معروف.
  // مكان هذا الأثر **قبل** أي `return` مبكر: كل الخطّافات (hooks) تُنادى في كل
  // رسمة. لو نُودي بعد `if (!open) return null` لصار ترتيب الخطّافات مختلفًا عند
  // الفتح (خطّاف زائد) فينفجر React بالخطأ #310 ويُسقط الشجرة كلها — وهو سبب توقّف
  // زر «أضف حالة» عن العمل فعلًا (شاشة بيضاء بعد الضغط).
  useEffect(() => {
    if (!open || mode === 'state') return;
    if (type === 'video' || type === 'audio') setType('text'); // الأثر نصّ أو صورة
    if (!spot) openAthar();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, mode]);

  // أثر اختيار النوع يظهر فورًا: نبضة على السطر تحت الأزرار + تمرير إلى لوحة المكان.
  // السبب: كان تبديل النوع يُغيّر عنوانًا في أعلى الورقة ولوحةً قد تكون خارج الشاشة،
  // فيضغط المستخدم «أثر» ولا يرى شيئًا فيظنّ الزرّ معطّلًا (شُوهد حيًّا).
  useEffect(() => {
    if (!open) return undefined;
    setModeFlash(true);
    const t = window.setTimeout(() => setModeFlash(false), 950);
    const s = window.setTimeout(() => {
      const el = atharRef.current;
      if (el && el.scrollIntoView) { try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { /* تجاهل */ } }
    }, 80);
    return () => { window.clearTimeout(t); window.clearTimeout(s); };
  }, [open, mode, flashN]);

  if (!open) return null;

  const clearMedia = () => { setMedia(null); setSecs(0); if (fileRef.current) fileRef.current.value = ''; };

  mediaRef.current = media; // تحديث في كل رسمة

  // أيقونة المنزل داخل أدوات المعاينة: غرفة مؤقتة تنطلق من هذه اللحظة نفسها
  const createRoom = async (payload) => {
    if (!actions || !actions.createRoom) return false;
    const done = await actions.createRoom(payload);
    return Boolean(done);
  };

  // ── نقطة الوصول الأولى للوسائط: كل ملف جديد يمرّ من هنا (كاميرا أو استوديو) ──
  // `setStartTools(true)` مقصود: المحرّر يُفتح مع كل وسائط **جديدة**، ويبقى مغلقًا
  // عند العودة من المعاينة إلى التعديل. قبل هذا كان المحرّر يُفتح مع كل تركيب
  // للمكوّن، فتصير «رجوع للتعديل» رجوعًا إلى المحرّر نفسه: الأزرار تحته لا تُلمس
  // («إعادة التصوير» و«إزالة») — وهو عطل شوهد حيًّا.
  const attach = async (file) => {
    if (!file) return;
    setStartTools(true); // وسائط جديدة ⇒ الصورة تُعرض ملء الشاشة تلقائيًا
    const t = TYPE_OF(file);
    if (!t) return onError('الصيغة غير مدعومة — اختر صورة أو فيديو أو ملف صوت.');
    if (file.size > CAP_MB[t] * 1024 * 1024) {
      return onError(`حجم الملف أكبر من ${CAP_MB[t]} ميجابايت — اختر ملفًا أصغر.`);
    }
    setUploading(true);
    try {
      if (t === 'image') {
        const shrunk = await shrinkImage(file);
        setMedia({ dataUrl: shrunk.dataUrl, type: 'image', size: shrunk.size, name: file.name, durationMs: 0 });
      } else {
        const dataUrl = await blobToDataUrl(file);
        const durationMs = await mediaDurationMs(dataUrl, t);
        setMedia({ dataUrl, type: t, size: file.size, name: file.name, durationMs });
      }
      setType(t);
    } catch (e) {
      onError(e.message || 'تعذّر تجهيز الملف');
    } finally {
      setUploading(false);
    }
  };

  attachRef.current = attach; // مرجع حيّ: يخدم الاستقبال المبكر للملف الجاهز

  const startRec = async () => {
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      return onError('التسجيل غير مدعوم على هذا المتصفح — ارفع ملف صوت بدلًا من ذلك.');
    }
    // إذن الميكروفون: نطلبه مرة واحدة في سياق التسجيل نفسه
    const perm = await ensure('microphone', { force: true, reason: 'لتسجيل حالة صوتية بضغطة واحدة' });
    if (!perm.ok) return onError(hintFor(perm));
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      const rec = new MediaRecorder(stream);
      recRef.current = rec;
      const startedAt = Date.now();
      rec.ondataavailable = (e) => { if (e.data && e.data.size) chunksRef.current.push(e.data); };
      rec.onstop = async () => {
        if (timerRef.current) clearInterval(timerRef.current);
        const ms = Date.now() - startedAt;
        stream.getTracks().forEach((t) => t.stop());
        streamRef.current = null;
        setRecording(false);
        try {
          const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' });
          if (!blob.size) return onError('لم يُسجَّل صوت — جرّب مرة أخرى.');
          if (blob.size > CAP_MB.audio * 1024 * 1024) return onError('التسجيل طويل جدًا — اجعله أقصر.');
          const dataUrl = await blobToDataUrl(blob);
          setMedia({ dataUrl, type: 'audio', size: blob.size, name: 'تسجيل صوتي', durationMs: ms });
          setType('audio');
        } catch (e) { onError('تعذّر تجهيز التسجيل'); }
      };
      rec.start();
      setRecording(true);
      setSecs(0);
      timerRef.current = setInterval(() => setSecs((s) => s + 1), 1000);
    } catch (e) {
      onError('لم نتمكن من الوصول إلى الميكروفون — اسمح بالوصول ثم أعد المحاولة.');
    }
  };

  const stopRec = () => { if (recRef.current && recRef.current.state === 'recording') recRef.current.stop(); };


  const toggleGroup = (g) => setAudGroups((list) => (list.includes(g) ? list.filter((x) => x !== g) : [...list, g]));
  const togglePerson = (id) => setAudPeople((list) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]));

  // فتح لوحة «أثر»: نبدأ من آخر موقع معروف، ونجلب أسماء الأماكن القريبة كاقتراحات
  const openAthar = async (pt) => {
    const p = pt || spot || readSpot() || CITY;
    setMapView(p);
    if (!spot) setSpot(p);
    try {
      const d = await api.athar({ lat: p.lat, lng: p.lng, radiusKm: 60 });
      const pulses = (d && d.pulses) || [];
      setNearPulses(pulses);
      const names = [...new Set(pulses.map((x) => x.placeName).filter(Boolean))].slice(0, 6);
      setSpotNames(names);
    } catch (e) { /* الاقتراحات كمالية — لا تُعطّل النشر */ }
  };

  // اختيار اللون: يُحفظ فورًا، وينتقل إلى المعاينة إن كان النموذج جاهزًا للنشر
  const pickBg = (hex) => {
    setBg(hex);
    if (!validate()) setStep('preview');
  };

  const wantsAthar = mode !== 'state';
  const wantsState = mode !== 'athar';
  // إطار مرئي (صورة أو مقطع) — الحالة الصوتية وحدها بلا إطار
  const hasFrame = Boolean(media && media.type !== 'audio');

  // الاستوديو: نافذة الجهاز تُفتح **في سياق هذه الضغطة نفسها** (f.click() قبل أي
  // انتظار). الانتظار قبلها يُلغي تفعيل المستخدم فيسكُت المتصفح الطلب بلا رسالة —
  // وهذا كان السبب الحقيقي في أن زر الإنشاء لا يفتح شيئًا. بطاقة الإذن تبقى تعمل،
  // لكن في الخلفية، ولا تحجب الاختيار.
  const openStudio = () => {
    const f = fileRef.current;
    if (!f) return;
    try { f.value = ''; } catch (e) { /* تجاهل */ }
    f.removeAttribute('capture');
    f.accept = type === 'audio' ? 'audio/*' : 'image/*,video/*';
    f.click();
    ensure('media', {
      reason: type === 'audio' ? 'لتختار ملفًا صوتيًا من جهازك' : 'لتختار صورة أو مقطعًا من استوديو جهازك',
    }).catch(() => {});
  };

  // الكاميرا: شاشة داخل التطبيق (لا منتقي ملفات) — الدائرة البيضاء للتصوير
  const openCamera = () => setCam(true);

  const locate = async () => {
    if (!navigator.geolocation) {
      return onError('جهازك لا يدعم تحديد الموقع — اسحب الخريطة وثبّت المكان يدويًا.');
    }
    const perm = await ensure('location', { force: true, reason: 'لتثبيت الأثر على المكان الذي أنت فيه فعلًا' });
    if (!perm.ok) return onError(hintFor(perm));
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const p = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setSpot(p); setMapView(p); setLocating(false);
        try { localStorage.setItem('sawa.athar.point', JSON.stringify(p)); } catch (e) { /* تجاهل */ }
        openAthar(p);
      },
      () => { setLocating(false); onError('لم نصل إلى موقعك — اسحب الخريطة وثبّت المكان يدويًا.'); },
      { enableHighAccuracy: true, timeout: 8000, maximumAge: 300000 },
    );
  };

  // ما يمنع النشر الآن؟ رسالة واحدة واضحة، أو null إن كان كل شيء جاهزًا.
  // نفس الفحص يخدم المعاينة التلقائية وزر النشر معًا — فلا يُنشر ناقص بلا سبب.
  const validate = () => {
    const point = mapView;
    const hasPoint = point && Number.isFinite(point.lat) && Number.isFinite(point.lng);
    if (wantsAthar) {
      if (!hasPoint) return 'حدّد موقع الأثر على الخريطة أولًا.';
      if (!spotName.trim()) return 'اكتب اسم المكان — الأثر يُنسب إلى مكان.';
    }
    if (wantsState) {
      if (!text.trim() && !media) return 'اكتب نصًا أو أضف صورة أو مقطعًا للحالة.';
      if (!audienceInfo.ready) return 'حدّد من يرى حالتك أولًا.';
    }
    return null;
  };

  const goPreview = async () => {
    const bad = validate();
    if (bad) return onError(bad);
    // نُثبّت أولًا أي رسم أو ملصق أو نصّ ما زال طبقة حيّة فوق الصورة، ثم ننتقل
    const flush = toolsRef.current;
    if (flush) { try { await flush(); } catch (e) { /* لا نُعطّل المعاينة بسبب تفصيل تصوير */ } }
    setStep('preview');
  };

  const publish = async () => {
    if (recording) stopRec();
    if (sending) return; // ضغطة ثانية أثناء الإرسال لا تُنشئ أثرًا مكرّرًا
    const bad = validate();
    if (bad) return onError(bad);
    // الطبقّة الحيّة في المحرّر تُثبَّت قبل النشر — فلا يضيع رسم لم يُحفظ
    const flush = toolsRef.current;
    if (flush) { try { await flush(); } catch (e) { /* لا نُعطّل النشر بسبب تفصيل تصوير */ } }
    const m = mediaRef.current; // وسائط هذه اللحظة — بعد تثبيت طبقات المحرّر
    const point = mapView;
    const hasPoint = point && Number.isFinite(point.lat) && Number.isFinite(point.lng);

    setSending(true); // الإشعار البصري يبدأ من هذه اللحظة لا من وصول الردّ
    try {
      if (wantsState) {
        // «أثر وحالة»: ينشئ الخادم الاثنين معًا ويبقى الأثر مربوطًا بالحالة
        const done = await actions.shareStory({
          text: text.trim() || (wantsAthar ? spotName.trim() : ''),
          kind: wantsAthar ? 'memory' : kind,
          bg: m ? null : bg,
          question,
          place: (wantsAthar ? spotName.trim() : '') || place.trim() || null,
          geo: wantsAthar ? { lat: point.lat, lng: point.lng } : null,
          hours: Number(hours),
          threshold: Number(threshold),
          audience,
          media: m ? { type: m.type, dataUrl: m.dataUrl, durationMs: m.durationMs || 0, view: m.view || null, dims: m.dims || null } : null,
        });
        if (!done) return;
      } else {
        await actions.createAthar({
          text: text.trim() || spotName.trim(),
          bg: m && m.type === 'image' ? null : bg,
          place: { name: spotName.trim(), lat: point.lat, lng: point.lng },
          audience,
          media: m && m.type === 'image' ? { type: 'image', dataUrl: m.dataUrl, view: m.view || null, dims: m.dims || null } : null,
        });
      }
      if (hasPoint) {
        try { localStorage.setItem('sawa.athar.point', JSON.stringify(point)); } catch (e) { /* تجاهل */ }
      }
      setStep('edit');
      onClose();
    } catch (e) {
      onError(e.message || 'تعذّر النشر');
    } finally {
      setSending(false);
    }
  };

  const sendLabel = mode === 'athar' ? 'ثبّت الأثر' : mode === 'both' ? 'انشر أثرًا وحالة' : 'انشر الحالة';
  // ضغطة النوع: تُغلق قائمة «الدائرة» إن كانت مفتوحة (الضغطة تخصّ النوع لا القائمة)
  // وتُبدّل النوع وتُبرزه. العدّاد يجعل الأثر يظهر حتى عند اختيار النوع المختار نفسه.
  const pickMode = (m) => { setAudOpen(false); setMode(m); setFlashN((n) => n + 1); };
  const canSend = (wantsState ? audienceInfo.ready && (text.trim() || media) : true)
    && (wantsAthar ? Boolean(spotName.trim()) && Boolean(mapView) : true);
  // عدد الخيارات الإضافية المفعّلة — يظهر كشارة صغيرة بدل سطر طويل يسمّيها كلها
  const extraCount = [
    place.trim(), String(hours) !== '24', String(threshold) !== '0',
    question.trim() !== QUESTION_DEFAULT && question.trim(),
  ].filter(Boolean).length;

  const clock = `${String(Math.floor(secs / 60)).padStart(2, '0')}:${String(secs % 60).padStart(2, '0')}`;

  return createPortal(
    <div className="overlay story-composer" role="dialog" aria-modal="true" aria-label="مشاركة حالة">
      <div className={`composer-sheet${step === 'preview' && hasFrame ? ' pv-full' : ''}`}>
        <div className="grabber" />
        <div className="sheet-head">
          <h3>{mode === 'athar' ? 'ثبّت أثرًا' : mode === 'both' ? 'أثر وحالة' : 'شارك حالة'}</h3>
          <button className="iconbtn" onClick={onClose} aria-label="إغلاق"><X size={18} strokeWidth={1.8} /></button>
        </div>

        <div className="sheet-body">
          {step === 'preview' ? (
            <div className="preview-pane fill">
              <div className={`pv-card fill${media ? ' has-media' : ''}${hasFrame ? ' over' : ''}`} style={media ? undefined : { background: bg }}>
                <span className="pv-chip">{MODE_LABEL[mode]}</span>
                {hasFrame && (
                  <div className="pv-frame">
                    <MediaFrame
                      src={media.dataUrl}
                      overlaySrc={media.overlay || null}
                      type={media.type}
                      dims={media.dims || null}
                      view={media.view || null}
                      videoProps={media.type === 'video' ? { autoPlay: true, loop: true, muted: true, playsInline: true } : undefined}
                    />
                  </div>
                )}
                {media && media.type === 'audio' && (
                  <div className="pv-audio"><Mic size={18} strokeWidth={1.8} /><span>تسجيل صوتي</span></div>
                )}
                <div className="pv-over">
                  {text.trim() && <p className="pv-text">{text.trim()}</p>}
                  {wantsAthar && spotName.trim() && (
                    <span className="pv-place"><MapPin size={13} strokeWidth={1.8} /> {spotName.trim()}</span>
                  )}
                  {!wantsAthar && place.trim() && (
                    <span className="pv-place"><MapPin size={13} strokeWidth={1.8} /> {place.trim()}</span>
                  )}
                </div>
              </div>
              <div className="pv-meta">
                <Avatar name={me && me.name ? me.name : 'أنت'} color={(me && me.avatarColor) || '#1D4ED8'} photo={me && me.avatar} size="sm" />
                <span>
                  {wantsState ? 'يراها' : 'يراه'} {audienceInfo.label}
                  {wantsState ? ` · تختفي بعد ${hours === '3' ? '٣ ساعات' : hours === '6' ? '٦ ساعات' : '٢٤ ساعة'}` : ' · يبقى على المكان'}
                </span>
              </div>
              <button type="button" className="ghost-btn pv-back" onClick={() => { setStartTools(false); setStep('edit'); }}>رجوع للتعديل</button>
            </div>
          ) : (
          <>
          {/* الوسائط أولًا: صورة أو مقطع من الكاميرا أو الاستوديو، وأدواته على يمين المعاينة */}
          <div className="media-pane">
            {!media && !recording && (
              <div className="media-drop pick">
                {/* صفّ واحد منظّم بدل ثلاث كتل متراكبة: الكاميرا · الاستوديو · صوتية */}
                <div className="pick-row" role="group" aria-label="طريقة إضافة الوسائط">
                  <button
                    type="button"
                    className={`pick-btn${type !== 'audio' ? ' on' : ''}`}
                    aria-pressed={type !== 'audio'}
                    onClick={() => { setType('image'); openCamera(); }}
                  >
                    <Camera size={19} strokeWidth={1.9} />
                    <b>الكاميرا</b>
                  </button>
                  <button type="button" className="pick-btn" onClick={openStudio}>
                    <Images size={19} strokeWidth={1.9} />
                    <b>الاستوديو</b>
                  </button>
                  <button
                    type="button"
                    className={`pick-btn${type === 'audio' ? ' on' : ''}`}
                    aria-pressed={type === 'audio'}
                    onClick={() => setType('audio')}
                  >
                    <Mic size={19} strokeWidth={1.9} />
                    <b>صوتية</b>
                  </button>
                </div>
                {type === 'audio' ? (
                  <>
                    <button className="btn pick-go" onClick={startRec}>
                      <Mic size={15} strokeWidth={1.8} /> سجّل الآن
                    </button>
                    <p className="pick-hint">أو اختر ملفًا صوتيًا من الاستوديو.</p>
                  </>
                ) : (
                  <p className="pick-hint">صوّر لحظتك الآن، أو اختر صورة أو مقطعًا من جهازك.</p>
                )}
              </div>
            )}

            {recording && (
              <div className="rec-live">
                <span className="pulse" />
                <strong>جارٍ التسجيل…</strong>
                <em>{clock}</em>
                <button className="btn danger" onClick={stopRec}>
                  <Square size={14} strokeWidth={2} /> إيقاف
                </button>
              </div>
            )}

            {media && (
              <div className="media-preview">
                {media.type === 'audio'
                  ? <audio src={media.dataUrl} controls />
                  : (
                    <MediaTools
                      media={media}
                      onApply={setMedia}
                      onError={onError}
                      onRoom={createRoom}
                      onOpenRooms={onOpenRooms}
                      flushRef={toolsRef}
                      onDone={goPreview}
                      startOpen={startTools}
                    />
                  )}
                <div className="media-meta">
                  <span>{media.type === 'image' ? 'صورة' : media.type === 'video' ? 'فيديو' : 'تسجيل صوتي'}</span>
                  <span>· {fmtSize(media.size)}</span>
                  {media.durationMs ? <span>· {Math.round(media.durationMs / 1000)} ث</span> : null}
                  {media.type !== 'audio' && (
                    <button className="ghost-btn" onClick={openCamera}>
                      <Camera size={13} strokeWidth={1.8} /> إعادة التصوير
                    </button>
                  )}
                  <button className="ghost-btn" onClick={clearMedia}>
                    <Trash2 size={14} strokeWidth={1.8} /> إزالة
                  </button>
                </div>
              </div>
            )}

            <input
              ref={fileRef}
              type="file"
              className="hidden-input"
              onChange={(e) => attach(e.target.files && e.target.files[0])}
            />
          </div>

          {/* نصّ الحالة: هو النصّ نفسه حين لا وسائط، ووصف مرافق حين توجد */}
          <div className="field">
            <textarea
              rows={media ? 2 : 3}
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={media
                ? 'نص مرافق للحالة (اختياري)'
                : 'اكتب حالتك… مثال: الجو حلو بعد المغرب، من معنا على البحر؟'}
            />
          </div>

          {/* خصائص الحالة النصّية: لون سادة واحد — وبعد اختياره تُعرض المعاينة */}
          {!media && (
            <div className="swatch-box cmp">
              <div className="swatch-head">
                <Palette size={14} strokeWidth={1.8} />
                <span>اللون</span>
                <em>{bgLabel(bg)}</em>
              </div>
              <div className="swatches" role="group" aria-label="لون الحالة">
                {STORY_BG.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    className={`swatch${bg === c.hex ? ' on' : ''}`}
                    style={{ backgroundColor: c.hex }}
                    aria-label={`لون ${c.label}`}
                    aria-pressed={bg === c.hex}
                    title={c.label}
                    onClick={() => pickBg(c.hex)}
                  >
                    {bg === c.hex ? <Check size={15} strokeWidth={2.6} /> : null}
                  </button>
                ))}
              </div>
            </div>
          )}

          {wantsAthar && (
            <div className={`athar-inbox${modeFlash ? ' flash' : ''}`} ref={atharRef}>
              <div className="athar-map">
                <AtharMap
                  view={mapView}
                  onView={setMapView}
                  zoom={mapZoom}
                  onZoom={setMapZoom}
                  origin={mapView}
                  pulses={nearPulses}
                  picking
                  dark={typeof document !== 'undefined' && document.body.classList.contains('dark')}
                />
                <span className="crosshair"><i /><i /></span>
              </div>
              <div className="athar-row">
                <button className="chip" onClick={locate} disabled={locating}>
                  {locating ? <Loader2 size={14} strokeWidth={1.8} /> : <Crosshair size={14} strokeWidth={1.8} />} موقعي
                </button>
                <em className="athar-coords">
                  {mapView ? `${mapView.lat.toFixed(4)}, ${mapView.lng.toFixed(4)}` : 'لم يُحدَّد الموقع'}
                </em>
              </div>
              <label className="field">
                <span>اسم المكان</span>
                <input
                  value={spotName}
                  onChange={(e) => setSpotName(e.target.value)}
                  placeholder="كورنيش القرم"
                />
              </label>
              {spotNames.length > 0 && (
                <div className="chips athar-names">
                  {spotNames.map((n) => (
                    <button
                      key={n}
                      className={`chip${spotName === n ? ' on active' : ''}`}
                      onClick={() => setSpotName(n)}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}


          {/* الخيارات الإضافية: تُخفى كلها حين لا يكون للحالة نصّية لوحة (أثر وحده) */}
          {wantsState && (
            <button
              className={`more-toggle${more ? ' open' : ''}`}
              onClick={() => setMore((v) => !v)}
              aria-expanded={more}
            >
              <SlidersHorizontal size={15} strokeWidth={1.9} />
              <b>خيارات إضافية</b>
              {extraCount > 0 && <em className="more-count">{extraCount}</em>}
              <ChevronDown size={15} strokeWidth={2} style={{ transform: more ? 'rotate(180deg)' : 'none' }} />
            </button>
          )}

          {more && (
            <div className="more-pane">
              {wantsState ? (
                <>
                  <div className="row2">
                    <label className="field">
                      <span><MapPin size={13} strokeWidth={1.8} /> المكان (اختياري)</span>
                      <input value={place} onChange={(e) => setPlace(e.target.value)} placeholder="كورنيش القرم" />
                    </label>
                    <label className="field">
                      <span><Clock size={13} strokeWidth={1.8} /> تختفي بعد</span>
                      <select value={hours} onChange={(e) => setHours(e.target.value)}>
                        <option value="3">٣ ساعات</option>
                        <option value="6">٦ ساعات</option>
                        <option value="24">٢٤ ساعة</option>
                      </select>
                    </label>
                  </div>
                  <label className="field">
                    <span>سؤال التفاعل</span>
                    <input value={question} onChange={(e) => setQuestion(e.target.value)} />
                  </label>
                  <label className="field">
                    <span>فتح غرفة عند اكتمال النصاب</span>
                    <select value={threshold} onChange={(e) => setThreshold(e.target.value)}>
                      <option value="0">بدون نصاب</option>
                      <option value="3">٣ أشخاص</option>
                      <option value="4">٤ أشخاص</option>
                      <option value="6">٦ أشخاص</option>
                      <option value="8">٨ أشخاص</option>
                    </select>
                  </label>
                </>
              ) : null}
            </div>
          )}
          </>
          )}
        </div>

        <div className="sheet-foot">
          <div className="foot-mode">
            {/* ثلاثة أزرار ظاهرة معًا: حالة · أثر · أثر وحالة — بلا تدوير مخفيّ */}
            <div className="mode-tabs" role="tablist" aria-label="نوع النشر">
              {MODES.map((m) => (
                <button
                  key={m}
                  type="button"
                  role="tab"
                  data-mode={m}
                  aria-selected={mode === m}
                  disabled={sending}
                  className={`mode-word m-${m}${mode === m ? ' on' : ''}`}
                  onClick={() => pickMode(m)}
                  title={MODE_HINT[m]}
                  aria-label={`نوع النشر: ${MODE_LABEL[m]}${mode === m ? ' — المختار' : ''}`}
                >
                  <span className="mode-ring" aria-hidden="true" />
                  <b>{MODE_LABEL[m]}</b>
                </button>
              ))}
            </div>

            {/* «الدائرة»: بجانب نوع النشر — ضغطة واحدة تفتح قائمة من يرى الحالة/الأثر */}
            <button
              type="button"
              className={`mode-word aud-word${audOpen ? ' open' : ''}${audienceInfo.ready ? '' : ' need'}`}
              onClick={() => setAudOpen((v) => !v)}
              disabled={sending}
              aria-expanded={audOpen}
              aria-haspopup="dialog"
              title={`من يرى: ${audienceInfo.label}`}
              aria-label={`من يرى منشورك — ${AUD_SHORT[aud]}`}
            >
              {aud === 'people' ? <Lock size={14} strokeWidth={2} /> : <Users size={14} strokeWidth={2} />}
              <b>{AUD_SHORT[aud]}</b>
              <ChevronUp size={14} strokeWidth={2} style={{ transform: audOpen ? 'rotate(180deg)' : 'none' }} />
            </button>

            {audOpen && (
              <>
                <div className="aud-scrim" onClick={() => setAudOpen(false)} />
                <div className="aud-menu" role="dialog" aria-label="من يرى منشورك">
                  <div className="aud-menu-head">
                    <ShieldQuestion size={15} strokeWidth={1.8} />
                    <b>{mode === 'athar' ? 'من يرى أثرك؟'
                      : mode === 'both' ? 'من يرى أثرك وحالتك؟' : 'من يرى حالتك؟'}</b>
                    <em className="aud-live">{audienceInfo.label}</em>
                    <button className="iconbtn" onClick={() => setAudOpen(false)} aria-label="إغلاق">
                      <X size={16} strokeWidth={1.8} />
                    </button>
                  </div>

                  <div className="aud-modes" role="tablist" aria-label="نطاق الجمهور">
                    {AUD_MODES.map((m) => (
                      <button
                        key={m.id}
                        role="tab"
                        aria-selected={aud === m.id}
                        className={`aud-mode${aud === m.id ? ' on' : ''}`}
                        title={m.hint}
                        onClick={() => setAud(m.id)}
                      >
                        {m.label}
                      </button>
                    ))}
                  </div>

                  {aud === 'circle' && (
                    <div className="aud-groups">
                      {circleNames.length ? circleNames.map((g) => (
                        <button
                          key={g}
                          className="chip"
                          title={`اقتصر على «${g}»`}
                          onClick={() => { setAud('groups'); setAudGroups([g]); }}
                        >
                          <Users size={13} strokeWidth={2} />
                          {g} <small>{peopleList.filter((p) => p.relation === g).length}</small>
                        </button>
                      )) : <p className="aud-note">لا دوائر بعد — أضف أشخاصًا إلى دائرتك ليظهروا هنا.</p>}
                      <p className="aud-note">اضغط دائرة لتقصر حالتك عليها بدل كل دائرتك.</p>
                    </div>
                  )}

                  {aud === 'groups' && (
                    <div className="aud-groups">
                      {circleNames.map((g) => {
                        const n = peopleList.filter((p) => p.relation === g).length;
                        return (
                          <button
                            key={g}
                            className={`chip${audGroups.includes(g) ? ' on active' : ''}`}
                            aria-pressed={audGroups.includes(g)}
                            onClick={() => toggleGroup(g)}
                          >
                            {audGroups.includes(g) && <Check size={13} strokeWidth={2.2} />}
                            {g} <small>{n}</small>
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {aud === 'people' && (
                    <div className="aud-people">
                      {peopleList.map((p) => (
                        <button
                          key={p.id}
                          className={`aud-person${audPeople.includes(p.id) ? ' on' : ''}`}
                          aria-pressed={audPeople.includes(p.id)}
                          onClick={() => togglePerson(p.id)}
                        >
                          <Avatar name={p.name} color={p.color} size="sm" />
                          <span className="pname">{p.name}</span>
                          <span className="rel">{p.relation}</span>
                          <span className="tick">{audPeople.includes(p.id) ? <Check size={14} strokeWidth={2.2} /> : null}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {!audienceInfo.ready && <p className="aud-note warn">لن تُنشر الحالة قبل تحديد من يراها.</p>}
                  {/* ٤.٥: حدود الحذف تُقال صراحةً عند اختيار من يرى الأثر */}
                  {wantsAthar && (
                    <p className="aud-note">الحذف فوري من الخادم ومن كل جهاز متصل؛ ولا يمكن سحب نسخة ظهرت سابقًا على جهاز غير متصل.</p>
                  )}

                  <button className="aud-done" onClick={() => setAudOpen(false)}>
                    <Check size={15} strokeWidth={2.2} />
                    تم — {wantsAthar && !wantsState ? 'يراه' : 'يراها'} {audienceInfo.count} {aud === 'people' ? 'محدّدًا' : 'شخصًا'}
                  </button>
                </div>
              </>
            )}
          </div>

          {/* السطر الفوري: يشرح النوع المختار ومن يراه في مكان الضغط نفسه — بدل
              عنوان في أعلى الورقة قد يكون خارج الشاشة فيبدو الزرّ بلا أثر. */}
          <p
            className={`mode-note${mode === 'state' ? '' : ' on-athar'}${modeFlash ? ' flash' : ''}`}
            role="status"
            aria-live="polite"
            data-mode={mode}
          >
            <i className="mode-dot" aria-hidden="true" />
            <b>{MODE_LABEL[mode]}</b>
            <span>· {MODE_HINT[mode]}</span>
            <span>· {audienceInfo.label}</span>
          </p>
          <div className="foot-row">
            <div className="who-row">
              {aud === 'people' ? <Lock size={13} strokeWidth={2} /> : <Avatar name={me && me.name ? me.name : 'أنت'} color={(me && me.avatarColor) || '#1D4ED8'} photo={me && me.avatar} size="sm" />}
              <span>
                {wantsAthar && !wantsState ? 'يراه' : 'يراها'} <b>{audienceInfo.label}</b>
                {audienceInfo.count ? ` · ${audienceInfo.count} ${aud === 'people' ? 'محدّدًا' : 'شخصًا'}` : ''}
              </span>
            </div>
            <button
              className="btn send"
              onClick={publish}
              disabled={busy || uploading || sending || recording || !canSend}
              aria-busy={busy || uploading || sending}
              aria-label={busy || uploading || sending ? 'جارٍ النشر' : sendLabel}
            >
              {busy || uploading || sending ? <Loader2 className="spin" size={16} strokeWidth={2} />
                : <Send size={16} strokeWidth={1.8} />}
              {uploading ? 'جارٍ الرفع…' : busy || sending ? 'جارٍ النشر…' : sendLabel}
            </button>
          </div>
        </div>
      </div>

      {/* شاشة التصوير فوق النموذج: الدائرة البيضاء للتصوير، والمستطيل للاستوديو، وX للرجوع */}
      <CameraCapture
        open={cam}
        kind={type === 'video' ? 'video' : 'image'}
        onClose={() => setCam(false)}
        onMedia={(file) => { setCam(false); attach(file); }}
      />
    </div>,
    document.body
  );
}

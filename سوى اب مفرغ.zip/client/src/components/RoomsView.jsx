import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  DoorOpen, Lock, Plus, Users, MapPin, Hourglass, Archive, CheckCircle2, Loader2, NotebookPen, Clock,
  MessageCircle, ArrowRight, Send, CheckCheck, Crown,
} from 'lucide-react';
import Avatar, { AvatarRow } from './Avatar.jsx';
import { formatLeft } from '../useToast.js';

function useTick(ms = 1000) {
  const [, setN] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setN((n) => n + 1), ms);
    return () => clearInterval(t);
  }, [ms]);
}

const timeOf = (iso) => {
  try { return new Date(iso).toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' }); }
  catch (e) { return ''; }
};

function dayLabel(iso) {
  const d = new Date(iso);
  const today = new Date();
  const yest = new Date(Date.now() - 864e5);
  const same = (a, b) => a.toDateString() === b.toDateString();
  if (same(d, today)) return 'اليوم';
  if (same(d, yest)) return 'أمس';
  try { return d.toLocaleDateString('ar-OM', { day: 'numeric', month: 'long' }); }
  catch (e) { return ''; }
}

const listStamp = (iso) => (dayLabel(iso) === 'اليوم' ? timeOf(iso) : dayLabel(iso));

// اسم المرسل داخل الغرفة: أنت / اسم العضو / تنبيه النظام
function senderName(room, from) {
  if (from === 'u-me') return 'أنت';
  const p = (room.roster || []).find((x) => x.id === from);
  return p ? p.name.split(' ')[0] : 'عضو';
}

function CreateRoom({ onCreate, busy }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: '', place: '', capacity: '8', hours: '6', kind: 'نشاط' });

  const submit = async () => {
    if (!form.title.trim()) return;
    const done = await onCreate({ ...form, capacity: Number(form.capacity), hours: Number(form.hours) });
    if (done) { setForm({ title: '', place: '', capacity: '8', hours: '6', kind: 'نشاط' }); setOpen(false); }
  };

  if (!open) {
    return (
      <button className="composer-trigger" onClick={() => setOpen(true)}>
        <Plus size={18} strokeWidth={2} />
        <span>افتح غرفة مؤقتة</span>
        <Hourglass size={16} strokeWidth={1.8} />
      </button>
    );
  }

  return (
    <div className="card composer">
      <div className="field">
        <span>اسم الغرفة</span>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="جلسة القرم" />
      </div>
      <div className="row2">
        <label className="field">
          <span>المكان</span>
          <input value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value })} placeholder="كورنيش القرم" />
        </label>
        <label className="field">
          <span>النوع</span>
          <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            <option>نشاط</option>
            <option>مناسبة</option>
            <option>مساعدة</option>
            <option>درس</option>
          </select>
        </label>
      </div>
      <div className="row2">
        <label className="field">
          <span>السعة</span>
          <select value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })}>
            {[4, 6, 8, 12, 20].map((n) => <option key={n} value={n}>{n} أشخاص</option>)}
          </select>
        </label>
        <label className="field">
          <span>تُقفل بعد</span>
          <select value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })}>
            {[2, 4, 6, 12, 24].map((n) => <option key={n} value={n}>{n} ساعات</option>)}
          </select>
        </label>
      </div>
      <div className="actions">
        <button className="btn ghost" onClick={() => setOpen(false)}>إلغاء</button>
        <button className="btn" onClick={submit} disabled={busy || !form.title.trim()}>
          {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <DoorOpen size={16} strokeWidth={1.8} />}
          افتح الغرفة
        </button>
      </div>
    </div>
  );
}

function RoomCard({ room, actions, busy, onOpenChat }) {
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState('');
  const full = room.members.length >= room.capacity;
  const closingSoon = room.msLeft < 60 * 60 * 1000;

  const addNote = async () => {
    if (!note.trim()) return;
    const done = await actions.addMemory(room.id, note);
    if (done) { setNote(''); setNoteOpen(false); }
  };

  return (
    <article className={`card room${closingSoon ? ' urgent' : ''}`}>
      <header className="room-head">
        <div className="room-icon">{room.mine ? <Crown size={18} strokeWidth={1.8} /> : <DoorOpen size={18} strokeWidth={1.8} />}</div>
        <div className="grow">
          <div className="pname">{room.title}</div>
          <div className="meta">
            <span className={`room-tag${room.mine ? ' mine' : ''}`}>{room.mine ? 'أنشأتها' : 'منضم إليها'}</span>
            <span className="sep">·</span>
            <span>{room.kind}</span>
            {room.place && (
              <>
                <span className="sep">·</span>
                <MapPin size={12} strokeWidth={1.8} />
                <span>{room.place}</span>
              </>
            )}
          </div>
        </div>
        <span className="timer">
          <Clock size={13} strokeWidth={1.8} />
          {formatLeft(room.msLeft)}
        </span>
      </header>

      <div className="room-body">
        <div className="members">
          <AvatarRow members={room.members} people={room.roster} max={6} />
          <span className="mcount">{room.members.length} / {room.capacity}</span>
        </div>
        <div className="bar"><i style={{ width: `${Math.min(100, room.fill)}%` }} /></div>
      </div>

      {room.agenda && room.agenda.length > 0 && (
        <ul className="agenda">
          {room.agenda.map((a, i) => (
            <li key={i}><CheckCircle2 size={14} strokeWidth={1.8} /> {a}</li>
          ))}
        </ul>
      )}

      {room.status === 'open' ? (
        <div className="actions">
          {room.joined ? (
            <button className="btn sm chat-cta" disabled={busy} onClick={() => onOpenChat(room.id)}>
              <MessageCircle size={15} strokeWidth={1.8} />
              دردشة الغرفة
              {room.unread > 0 && <span className="t-count">{room.unread}</span>}
            </button>
          ) : (
            <button className="btn sm" disabled={busy || full} onClick={() => actions.joinRoom(room.id)}>
              <Users size={15} strokeWidth={1.8} />
              {full ? 'ممتلئة' : 'انضم للدردشة'}
            </button>
          )}
          {room.joined && (
            <button className="btn sm ghost" disabled={busy} onClick={() => setNoteOpen((v) => !v)}>
              <NotebookPen size={15} strokeWidth={1.8} /> أثر
            </button>
          )}
          {room.mine && (
            <button className="btn sm danger" disabled={busy} onClick={() => actions.closeRoom(room.id)}>
              <Lock size={15} strokeWidth={1.8} /> اقفل
            </button>
          )}
        </div>
      ) : (
        <div className="closed-note">
          <Archive size={15} strokeWidth={1.8} /> غرفة مغلقة — أُرشفت في «أثر»
        </div>
      )}

      {noteOpen && (
        <div className="whisper">
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="خلاصة سريعة تُحفظ في أثر…"
            onKeyDown={(e) => { if (e.key === 'Enter') addNote(); }}
          />
          <button className="btn sm" onClick={addNote} disabled={busy || !note.trim()}>حفظ</button>
        </div>
      )}

      {room.memories && room.memories.length > 0 && (
        <ul className="memory">
          {room.memories.slice(-3).map((m, i) => (
            <li key={i}><span className="dotm" />{m.text}</li>
          ))}
        </ul>
      )}

      {room.last && (
        <div className="room-last">
          <MessageCircle size={13} strokeWidth={1.8} />
          <span className="who">{senderName(room, room.last.from)}:</span>
          <span className="txt">{room.last.text}</span>
          <span className="t-time">{listStamp(room.last.at)}</span>
        </div>
      )}
    </article>
  );
}

function RoomChat({ room, actions, busy, onClose }) {
  const [draft, setDraft] = useState('');
  const endRef = useRef(null);
  const messages = room.messages || [];
  const closed = room.status !== 'open';
  const others = (room.roster || []).filter((p) => p.id !== 'u-me');
  const readKey = useRef(null);

  // تعليم رسائل الغرفة كمقروءة عند فتحها أو عند وصول رسالة جديدة
  const key = `${room.id}:${room.unread}`;
  useEffect(() => {
    if (room.unread > 0 && readKey.current !== key) {
      readKey.current = key;
      actions.readRoom(room.id);
    }
  }, [key, room.id, room.unread, actions]);

  // تحديث دوري أثناء فتح الدردشة حتى تظهر رسائل بقية الأعضاء
  useEffect(() => {
    const t = setInterval(() => { if (!document.hidden) actions.refresh(); }, 6000);
    return () => clearInterval(t);
  }, [actions]);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
  }, [messages.length, room.id]);

  const send = async () => {
    const text = draft.trim();
    if (!text || busy || closed) return;
    setDraft('');
    const done = await actions.sendRoomMessage(room.id, text);
    if (!done) setDraft(text);
  };

  return (
    <div className="view chat-view">
      <div className="chat-head">
        <button className="iconbtn" onClick={onClose} aria-label="رجوع إلى الغرف">
          <ArrowRight size={18} strokeWidth={1.8} />
        </button>
        <div className="room-icon"><DoorOpen size={17} strokeWidth={1.8} /></div>
        <div className="grow">
          <div className="pname">{room.title}</div>
          <div className="meta">
            <span>{closed ? 'غرفة مغلقة' : 'مفتوحة الآن'}</span>
            <span className="sep">·</span>
            <Users size={12} strokeWidth={1.8} />
            <span>{room.members.length} من {room.capacity} داخل الغرفة</span>
          </div>
        </div>
        <span className="timer">
          <Clock size={13} strokeWidth={1.8} />
          {closed ? 'انتهت' : formatLeft(room.msLeft)}
        </span>
      </div>

      <div className="room-notice">
        <MessageCircle size={15} strokeWidth={1.8} />
        <div>
          دردشة جماعية للغرفة — كل من دخلها ({room.members.length}) يرى الرسائل، ومنهم {others.length} من دائرتك.
        </div>
      </div>

      <div className="chat-body">
        {messages.length === 0 && (
          <div className="empty">
            <div className="circle"><MessageCircle size={22} strokeWidth={1.8} /></div>
            <strong>لا رسائل بعد</strong>
          </div>
        )}
        {messages.map((m, i) => {
          const prev = messages[i - 1];
          const showDay = !prev || dayLabel(prev.at) !== dayLabel(m.at);
          if (m.from === 'sys') {
            return (
              <React.Fragment key={m.id || i}>
                {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
                <div className="sysnote">{m.text}</div>
              </React.Fragment>
            );
          }
          const mine = m.from === 'u-me';
          const sender = (room.roster || []).find((p) => p.id === m.from);
          return (
            <React.Fragment key={m.id || i}>
              {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
              <div className={`bubble-row${mine ? ' mine' : ''}`}>
                {!mine && <Avatar name={sender ? sender.name : 'عضو'} color={sender ? sender.color : '#94A3B8'} photo={sender && sender.avatar} size="sm" />}
                <div className={`bubble${mine ? ' mine' : ''}`}>
                  {!mine && <span className="bubble-name">{sender ? sender.name.split(' ')[0] : 'عضو'}</span>}
                  <span>{m.text}</span>
                  <span className="b-time">
                    {timeOf(m.at)}
                    {mine && <CheckCheck size={13} strokeWidth={2} />}
                  </span>
                </div>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={endRef} />
      </div>

      {closed ? (
        <div className="closed-note">
          <Lock size={15} strokeWidth={1.8} /> أُقفلت الغرفة — الدردشة محفوظة للقراءة فقط.
        </div>
      ) : (
        <div className="chat-bar">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
            placeholder={`اكتب رسالة إلى غرفة «${room.title}»…`}
            aria-label="نص رسالة الغرفة"
          />
          <button className="send-btn" onClick={send} disabled={busy || !draft.trim()} aria-label="إرسال">
            {busy ? <Loader2 className="spin" size={18} strokeWidth={2} /> : <Send size={18} strokeWidth={1.8} />}
          </button>
        </div>
      )}
    </div>
  );
}

function SectionHead({ title, count }) {
  return (
    <div className="section-head">
      <h3>{title}</h3>
      {typeof count === 'number' && <span className="pill-count">{count}</span>}
    </div>
  );
}

export default function RoomsView({ data, actions, busy }) {
  useTick(1000);
  const [showArchive, setShowArchive] = useState(false);
  const [chatId, setChatId] = useState(null);

  const rooms = data.rooms || [];

  const created = useMemo(() => rooms.filter((r) => r.mine && r.status === 'open'), [rooms]);
  const joined = useMemo(
    () => rooms.filter((r) => !r.mine && r.joined && r.status === 'open'),
    [rooms]
  );
  const discover = useMemo(() => rooms.filter((r) => !r.joined && r.status === 'open'), [rooms]);
  const closed = useMemo(() => rooms.filter((r) => r.status !== 'open' && r.joined), [rooms]);

  const active = chatId ? rooms.find((r) => r.id === chatId) : null;
  if (active) {
    return <RoomChat room={active} actions={actions} busy={busy} onClose={() => setChatId(null)} />;
  }

  return (
    <div className="view">
      <CreateRoom onCreate={actions.createRoom} busy={busy} />

      <SectionHead title="غرف أنشأتها" count={created.length} />
      {created.length === 0 ? (
        <div className="empty small">
          <div className="circle"><Crown size={20} strokeWidth={1.8} /></div>
          <strong>لم تنشئ غرفة بعد</strong>
        </div>
      ) : (
        created.map((r, i) => (
          <div key={r.id} className={`fade-up d${(i % 3) + 1}`}>
            <RoomCard room={r} actions={actions} busy={busy} onOpenChat={setChatId} />
          </div>
        ))
      )}

      <SectionHead title="غرف انضممت إليها" count={joined.length} />

      {joined.length === 0 ? (
        <div className="empty small">
          <div className="circle"><Users size={20} strokeWidth={1.8} /></div>
          <strong>لا غرف منضم إليها الآن</strong>
        </div>
      ) : (
        joined.map((r, i) => (
          <div key={r.id} className={`fade-up d${(i % 3) + 1}`}>
            <RoomCard room={r} actions={actions} busy={busy} onOpenChat={setChatId} />
          </div>
        ))
      )}

      {discover.length > 0 && (
        <>
          <SectionHead title="غرف دائرتك — لم تنضم بعد" count={discover.length} />
          {discover.map((r) => (
            <article key={r.id} className="card room discover">
              <header className="room-head">
                <div className="room-icon muted"><DoorOpen size={17} strokeWidth={1.8} /></div>
                <div className="grow">
                  <div className="pname">{r.title}</div>
                  <div className="meta">
                    <span>بإدارة {senderName(r, r.owner)}</span>
                    {r.place ? (<><span className="sep">·</span><MapPin size={12} strokeWidth={1.8} /><span>{r.place}</span></>) : null}
                    <span className="sep">·</span>
                    <span>{r.members.length} / {r.capacity}</span>
                  </div>
                </div>
                <span className="timer"><Clock size={13} strokeWidth={1.8} />{formatLeft(r.msLeft)}</span>
              </header>
              <div className="actions">
                <button
                  className="btn sm"
                  disabled={busy || r.members.length >= r.capacity}
                  onClick={() => actions.joinRoom(r.id)}
                >
                  <Users size={15} strokeWidth={1.8} />
                  {r.members.length >= r.capacity ? 'ممتلئة' : 'انضم للدردشة'}
                </button>
              </div>
            </article>
          ))}
        </>
      )}

      <SectionHead title="أثر" count={closed.length} />
      <button className="ghost-btn wide" onClick={() => setShowArchive((v) => !v)}>
        {showArchive ? 'إخفاء الغرف المغلقة' : `عرض الغرف المغلقة (${closed.length})`}
      </button>

      {showArchive && (closed.length === 0 ? (
        <p className="muted-note">لا شيء في أثر بعد.</p>
      ) : (
        closed.map((r) => (
          <article key={r.id} className="card archive">
            <header className="room-head">
              <div className="room-icon muted"><Archive size={17} strokeWidth={1.8} /></div>
              <div className="grow">
                <div className="pname">{r.title}</div>
                <div className="meta">
                  <span>{r.place || 'مكان غير محدد'}</span>
                  <span className="sep">·</span>
                  <span>حضر {r.members.length} من {r.capacity}</span>
                  <span className="sep">·</span>
                  <span>{r.messageCount} رسالة</span>
                </div>
              </div>
            </header>
            <ul className="memory">
              {(r.memories || []).slice(-3).map((m, i) => (
                <li key={i}><span className="dotm" />{m.text}</li>
              ))}
              {(!r.memories || r.memories.length === 0) && (
                <li><span className="dotm" />أُقفلت الغرفة دون خلاصات مكتوبة.</li>
              )}
            </ul>
            <div className="actions">
              <button className="btn sm ghost" onClick={() => setChatId(r.id)}>
                <MessageCircle size={15} strokeWidth={1.8} /> قراءة دردشة الغرفة
              </button>
            </div>
          </article>
        ))
      ))}
    </div>
  );
}

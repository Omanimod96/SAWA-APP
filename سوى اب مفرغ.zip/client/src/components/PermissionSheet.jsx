import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  ShieldCheck, Loader2, Check, X, Lock,
} from 'lucide-react';
import {
  PERMS, permById, subscribe, currentPending, grant, allDecisions, isSupported, markIntroSeen,
  introOpenNow,
} from '../permissions.js';
import { permIcon } from '../permIcons.js';

const ICON = PERMS.reduce((acc, p) => { acc[p.id] = permIcon(p.id); return acc; }, {});

const STATE_LABEL = {
  granted: 'مُسموح',
  denied: 'ممنوع من المتصفح',
  later: 'ليس الآن',
  unsupported: 'غير مدعوم',
  unasked: '',
};

// ── ورقة الطلب الواحدة: تُفتح من أي زر يحتاج إذنًا في التطبيق ──
export function PermissionHost() {
  const [pending, setPending] = useState(() => currentPending());
  useEffect(() => subscribe(() => setPending(currentPending())), []);
  // لا ورقتان فوق بعض: لوحة الأذونات الأولى تبقى وحدها على الشاشة، وطلب الإذن
  // الواحد يظهر بعدها فقط إن بقي بلا جواب.
  if (!pending || introOpenNow()) return null;

  const p = pending.perm;
  const Icon = ICON[p.id] || ShieldCheck;
  const answer = (yes) => { if (pending) pending.settle(yes); };

  return createPortal(
    <div className="overlay" role="dialog" aria-modal="true" aria-label={p.title}>
      <div className="sheet perm-sheet">
        <div className="grabber" />
        <div className="sheet-head">
          <h3>إذن الجهاز</h3>
          <button className="iconbtn" onClick={() => answer(false)} aria-label="إغلاق">
            <X size={18} strokeWidth={1.8} />
          </button>
        </div>

        {pending.reason ? <p className="perm-ctx">{pending.reason}</p> : null}

        <div className="perm-hero">
          <span className="perm-ico"><Icon size={24} strokeWidth={1.8} /></span>
          <div>
            <b>{p.ask}</b>
            <p>{p.why}</p>
          </div>
        </div>

        <p className="perm-keep"><ShieldCheck size={14} strokeWidth={1.8} /> {p.keep}</p>

        <div className="perm-actions">
          <button className="btn" onClick={() => answer(true)}>
            <Check size={16} strokeWidth={2.2} /> اسمح
          </button>
          <button className="btn ghost" onClick={() => answer(false)}>ليس الآن</button>
        </div>

        <p className="perm-foot">
          <Lock size={13} strokeWidth={1.8} />
          <span>لا يُخزَّن شيء في سوى — الصور والأصوات والموقع تبقى على جهازك، ولا يُرفع إلا ما تنشره أنت.</span>
        </p>
      </div>
    </div>,
    document.body,
  );
}

// ── الورقة الأولى: سؤال واحد عند أول استخدام، ثم لا نُعيده ──
export function PermissionIntro({ open, onClose, onNotice }) {
  const [rows, setRows] = useState(() => allDecisions());
  const [busyId, setBusyId] = useState(null);

  useEffect(() => { if (open) setRows(allDecisions()); }, [open]);
  if (!open) return null;

  const runGrant = async (id) => {
    const perm = permById(id);
    if (!perm || !isSupported(id)) return null;
    setBusyId(id);
    // native: نطلب من الجهاز فعلًا · غير native: نكتفي بعدم السؤال مرة أخرى
    const res = await grant(id, perm.native ? {} : { defer: true });
    setRows(allDecisions());
    setBusyId(null);
    return res;
  };

  // «اسمح للكل» يسأل بالترتيب: الكاميرا ثم الميكروفون ثم الموقع — كما يتوقّع المستخدم
  const allowAll = async () => {
    for (let i = 0; i < PERMS.length; i += 1) {
      const p = PERMS[i];
      if (!isSupported(p.id) || allDecisions()[p.id] === 'granted') continue;
      // eslint-disable-next-line no-await-in-loop
      await runGrant(p.id);
    }
    markIntroSeen();
    if (onNotice) onNotice('جاهز — لن يسألك سوى عن الأذونات مرة أخرى', 'success');
    onClose();
  };

  const close = () => { markIntroSeen(); onClose(); };

  return createPortal(
    <div className="overlay" role="dialog" aria-modal="true" aria-label="أذونات سوى">
      <div className="sheet perm-sheet">
        <div className="grabber" />
        <div className="sheet-head">
          <h3>أذونات سوى — مرة واحدة</h3>
          <button className="iconbtn" onClick={close} aria-label="إغلاق">
            <X size={18} strokeWidth={1.8} />
          </button>
        </div>

        <ul className="perm-list">
          {PERMS.map((p) => {
            const Icon = ICON[p.id] || ShieldCheck;
            const st = rows[p.id] || 'unasked';
            const supported = isSupported(p.id);
            return (
              <li key={p.id} className={`perm-row${st === 'granted' ? ' ok' : ''}`}>
                <span className="perm-ico sm"><Icon size={18} strokeWidth={1.8} /></span>
                <div className="perm-row-txt">
                  <b>{p.title}</b>
                  <small>{p.why}</small>
                </div>
                {supported && st !== 'granted' ? (
                  <button
                    className="btn btn-soft sm"
                    aria-label={`اسمح بالوصول إلى ${p.title}`}
                    onClick={() => runGrant(p.id)}
                    disabled={busyId === p.id}
                  >
                    {busyId === p.id ? <Loader2 className="spin" size={14} strokeWidth={2} /> : null}
                    {st === 'denied' ? 'أعد الطلب' : 'اسمح'}
                  </button>
                ) : (
                  <span className={`perm-pill${st === 'granted' ? ' ok' : supported ? '' : ' bad'}`}>
                    {st === 'granted'
                      ? <><Check size={12} strokeWidth={2.2} /> مُسموح</>
                      : STATE_LABEL[st] || (supported ? '' : 'غير مدعوم')}
                  </span>
                )}
              </li>
            );
          })}
        </ul>

        <div className="perm-actions">
          <button className="btn" onClick={allowAll} disabled={Boolean(busyId)}>
            {busyId ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <ShieldCheck size={16} strokeWidth={1.8} />}
            اسمح للكل
          </button>
          <button className="btn ghost" onClick={close}>لاحقًا</button>
        </div>

        <p className="perm-foot">
          <Lock size={13} strokeWidth={1.8} />
          <span>بلا تخزين على المنصة · تستطيع تغيير أي إذن متى شئت من «أنا ← أذونات الجهاز».</span>
        </p>
      </div>
    </div>,
    document.body,
  );
}

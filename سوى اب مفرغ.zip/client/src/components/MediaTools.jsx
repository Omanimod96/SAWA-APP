import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  Pencil, Sticker, Type, Home, Undo2, Trash2, Check, Loader2, DoorOpen,
  Crop, SlidersHorizontal, RotateCw, FlipHorizontal2, FlipVertical2,
  X, Maximize2, Move, RotateCcw,
} from 'lucide-react';
import MediaFrame from '../MediaFrame.jsx';
import { FILTERS, RATIOS, normView, patchView, filterCss, viewDims, isPlainView } from '../mediaView.js';

// محرّر الوسائط — صفحة كاملة على طريقة واتساب: الوسائط تملأ الشاشة، وفوقها شريط
// أيقونات دائري (رسم · ملصقات · نص · قصّ · تنسيق · غرفة)، وأدوات الأداة المختارة
// في شريط سفلي هادئ. بلا قوائم منسدلة وبلا زرّ طيّ.
//  ١) قلم   → رسم حرّ فوق الوسائط.
//  ٢) ملصقات → ملصق يُسحب بالإصبع.
//  ٣) نص    → كتابة نصّ مع إيموجي، ويُسحب أيضًا.
//  ٤) قصّ   → إطار قصّ: حرّ أو نِسَب جاهزة (مربّع · ٤:٥ · ٩:١٦ · ١٦:٩).
//  ٥) تنسيق → تدوير وقلب وفلاتر لونية.
//  ٦) غرفة  → إنشاء غرفة مؤقتة من هذه اللحظة نفسها.
// الإحداثيات نسبية (٠..١ من مساحة العرض) فيبقى الرسم دقيقًا مهما تغيّر المقاس،
// والتصدير بالحجم الأصلي بلا انحراف. «القصّ» و«التنسيق» لا يُعيدان ترميز الأصل:
// يُحفظان مع الوسائط (view) وتُطبَّق بنفس الطريقة في المحرّر والمعاينة والعارض.
const COLORS = ['#FFD400', '#FF5A5A', '#FFFFFF', '#4ADE80', '#60A5FA', '#111827'];
const BRUSHES = [0.006, 0.012, 0.022];
const STICKERS = [
  '❤️', '✨', '🔥', '🌊', '☕', '🌴', '☀️', '🌙', '⭐', '🌸',
  '😂', '😍', '👍', '🙌', '🎉', '🎵', '🍽️', '🚗', '🐾', '🕌',
];
const EMOJIS = ['😀', '😂', '😍', '🥺', '😎', '🤔', '👍', '🙏', '❤️', '🔥', '✨', '🌊', '☀️', '🌙', '☕', '🎉'];

const TOOLS = [
  { id: 'draw', label: 'رسم', hint: 'ارسم على الصورة بإصبعك', Icon: Pencil },
  { id: 'sticker', label: 'ملصقات', hint: 'أضف ملصقًا وحرّكه', Icon: Sticker },
  { id: 'text', label: 'نص', hint: 'اكتب نصًا مع إيموجي', Icon: Type },
  { id: 'crop', label: 'قصّ', hint: 'اقتطع الإطار الذي تريده — إطار حرّ أو نسبة جاهزة', Icon: Crop },
  { id: 'fx', label: 'تنسيق', hint: 'تدوير · قلب · فلتر لوني', Icon: SlidersHorizontal },
  { id: 'room', label: 'غرفة', hint: 'افتح غرفة مؤقتة من هذه اللحظة', Icon: Home },
];

const MIN = 0.16; // أصغر إطار قصّ (نسبةً من مساحة العرض)
const uid = () => `m${Math.random().toString(36).slice(2, 9)}`;
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const plain = (d) => (d && d.w && d.h ? { w: d.w, h: d.h } : null);
const loadImg = (src) => new Promise((ok, no) => {
  const i = new Image();
  i.onload = () => ok(i);
  i.onerror = () => no(new Error('bad image'));
  i.src = src;
});
const KIND = { image: 'صورة', video: 'مقطع', audio: 'تسجيل صوتي' };

export default function MediaTools({ media, onApply, onError, onRoom, onOpenRooms, flushRef, onDone, startOpen = true }) {
  const [tool, setTool] = useState(null);
  const [open, setOpen] = useState(startOpen); // صفحة التحرير الكاملة (تُفتح تلقائيًا مع وسائط جديدة)
  const [dims, setDims] = useState(() => plain(media.dims));
  const [view, setView] = useState(() => normView(media.view));
  const [ratioId, setRatioId] = useState('free');
  const [strokes, setStrokes] = useState([]);
  const [stickers, setStickers] = useState([]);
  const [texts, setTexts] = useState([]);
  const [color, setColor] = useState(COLORS[0]);
  const [brush, setBrush] = useState(BRUSHES[1]);
  const [draft, setDraft] = useState('');
  const [room, setRoom] = useState({ title: '', place: '' });
  const [saving, setSaving] = useState(false);
  const [opened, setOpened] = useState(null);
  const [fit, setFit] = useState(null);
  const [boxW, setBoxW] = useState(0);

  const fitRef = useRef(null);
  const stageRef = useRef(null);
  const canvasRef = useRef(null);
  const dragRef = useRef(null);
  const cropRef = useRef(null);
  const lastTextRef = useRef(null);

  const v = normView(view);
  const swap = v.rot % 180 !== 0;
  const vd = dims ? viewDims(v, dims) : null;
  const hasWork = strokes.length > 0 || stickers.length > 0 || texts.some((t) => t.text.trim());

  // المقاس الأصلي: منه نبني مساحة العرض ونُصدّر بلا تمدد
  useEffect(() => {
    let alive = true;
    setStrokes([]); setStickers([]); setTexts([]); setTool(null); setOpened(null);
    setDraft(''); lastTextRef.current = null; setOpen(startOpen); setRatioId('free');
    setView(normView(media.view));
    if (plain(media.dims)) setDims(plain(media.dims));
    if (media.type === 'image') {
      loadImg(media.dataUrl).then((i) => {
        if (alive) setDims({ w: i.naturalWidth || 1080, h: i.naturalHeight || 1080 });
      }).catch(() => { if (alive) setDims({ w: 1080, h: 1080 }); });
    } else {
      const el = document.createElement('video');
      el.preload = 'metadata';
      el.onloadedmetadata = () => { if (alive) setDims({ w: el.videoWidth || 720, h: el.videoHeight || 1280 }); };
      el.onerror = () => { if (alive) setDims({ w: 720, h: 1280 }); };
      el.src = media.dataUrl;
    }
    return () => { alive = false; };
  }, [media.dataUrl, media.type]);

  // إعادة رسم الطبقات على الكانفاس كلما تغيّرت (أو تغيّر مقاس المسرح)
  useEffect(() => {
    const c = canvasRef.current;
    const stage = stageRef.current;
    if (!c || !stage) return;
    const box = stage.getBoundingClientRect();
    if (!box.width) return;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = Math.round(box.width * dpr);
    c.height = Math.round(box.height * dpr);
    const g = c.getContext('2d');
    if (!g) return;
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    g.clearRect(0, 0, box.width, box.height);
    g.lineCap = 'round';
    g.lineJoin = 'round';
    strokes.forEach((s) => {
      if (s.points.length < 2) {
        if (s.points.length === 1) {
          g.fillStyle = s.color;
          g.beginPath();
          g.arc(s.points[0][0] * box.width, s.points[0][1] * box.height, (s.width * box.width) / 2, 0, Math.PI * 2);
          g.fill();
        }
        return;
      }
      g.strokeStyle = s.color;
      g.lineWidth = s.width * box.width;
      g.beginPath();
      s.points.forEach(([x, y], i) => (i ? g.lineTo(x * box.width, y * box.height) : g.moveTo(x * box.width, y * box.height)));
      g.stroke();
    });
  }, [strokes, dims, tool, open, swap]);

  // المساحة المتاحة للوسائط: منها نحسب مقاس مساحة العرض (نسبة الأصل بلا تشويه)
  useEffect(() => {
    const el = fitRef.current;
    if (!el || !open) return undefined;
    const calc = () => {
      const b = el.getBoundingClientRect();
      if (b.width && b.height) setFit({ w: Math.round(b.width), h: Math.round(b.height) });
    };
    calc();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(calc);
    ro.observe(el);
    return () => ro.disconnect();
  }, [open]);

  // عرض مساحة العرض: لقياس خطوط الملصقات والنصوص الكبيرة
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return undefined;
    const read = () => setBoxW(stage.getBoundingClientRect().width);
    read();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(read);
    ro.observe(stage);
    return () => ro.disconnect();
  }, [open, v.rot, media.dataUrl]);

  const rel = (e) => {
    const box = stageRef.current.getBoundingClientRect();
    return [
      clamp((e.clientX - box.left) / box.width, 0, 1),
      clamp((e.clientY - box.top) / box.height, 0, 1),
    ];
  };

  // ── الرسم ──
  const onDown = (e) => {
    if (tool !== 'draw') return;
    // ضغطة على أزرار الأدوات/إطار القصّ ليست خطًّا: نتركها لأصحابها
    if (e.target && e.target.closest && e.target.closest('.mt-rail, .mt-crop, .mt-crop-dot')) return;
    dragRef.current = null;
    e.preventDefault();
    const p = rel(e);
    setStrokes((s) => [...s, { color, width: brush, points: [p] }]);
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) { /* تجاهل */ }
  };
  const onMove = (e) => {
    if (tool !== 'draw' || !e.buttons) return;
    const p = rel(e);
    setStrokes((s) => {
      if (!s.length) return s;
      const last = s[s.length - 1];
      return [...s.slice(0, -1), { ...last, points: [...last.points, p] }];
    });
  };
  const drop = () => { dragRef.current = null; };

  // ── تحريك الملصق أو النصّ بالإصبع ──
  const grab = (e, kind, id) => {
    if (tool === 'draw' || tool === 'crop') return;
    e.stopPropagation();
    const box = stageRef.current.getBoundingClientRect();
    const item = (kind === 'sticker' ? stickers : texts).find((x) => x.id === id);
    if (!item) return;
    dragRef.current = {
      kind,
      id,
      dx: (e.clientX - box.left) / box.width - item.x,
      dy: (e.clientY - box.top) / box.height - item.y,
    };
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) { /* تجاهل */ }
  };
  const drag = (e) => {
    const d = dragRef.current;
    if (!d || !e.buttons) return;
    const box = stageRef.current.getBoundingClientRect();
    const x = clamp((e.clientX - box.left) / box.width - d.dx, 0.02, 0.98);
    const y = clamp((e.clientY - box.top) / box.height - d.dy, 0.02, 0.98);
    const bump = (arr) => arr.map((it) => (it.id === d.id ? { ...it, x, y } : it));
    if (d.kind === 'sticker') setStickers(bump); else setTexts(bump);
  };

  const addSticker = (emoji) => {
    setStickers((s) => [...s, { id: uid(), emoji, x: 0.5, y: 0.42 + (s.length % 3) * 0.06, size: 0.16 }]);
  };
  // الكتابة في الحقل: إن لم يكن هناك نصّ مُضاف بعد، نُضيفه بأول حرف يكتبه
  // (سلوك واتساب) ثم نبقيه مرتبطًا بالحقل ويسحبه بإصبعه إلى مكانه.
  const editText = (v2) => {
    setDraft(v2);
    const id = lastTextRef.current;
    if (!id) {
      if (!v2.trim()) return;
      const nid = uid();
      setTexts((t) => [...t, { id: nid, text: v2, x: 0.5, y: 0.34, size: 0.075, color: '#FFFFFF' }]);
      lastTextRef.current = nid;
      return;
    }
    setTexts((t) => t.map((it) => (it.id === id ? { ...it, text: v2 } : it)));
  };
  const rmText = (id) => setTexts((t) => t.filter((x) => x.id !== id));
  const rmSticker = (id) => setStickers((s) => s.filter((x) => x.id !== id));
  const dropText = () => setTexts((t) => {
    const rest = t.slice(0, -1);
    if (lastTextRef.current && !rest.some((x) => x.id === lastTextRef.current)) lastTextRef.current = null;
    return rest;
  });

  const layerCount = strokes.length + stickers.length + texts.filter((t) => t.text.trim()).length;
  const undo = () => {
    if (tool === 'draw') return setStrokes((s) => s.slice(0, -1));
    if (tool === 'sticker') return setStickers((s) => s.slice(0, -1));
    return dropText();
  };
  const clearLayers = () => { setStrokes([]); setStickers([]); setTexts([]); setDraft(''); lastTextRef.current = null; };

  // ── القصّ: إطار يُسحب، أو نسبة جاهزة ──
  const cbox = v.crop || { x: 0, y: 0, w: 1, h: 1 };
  const setCrop = (c) => setView((vv) => patchView(vv, { crop: c }));
  const resetCrop = () => { setRatioId('free'); setCrop(null); };
  const startCrop = (e, handle) => {
    if (tool !== 'crop') return;
    e.preventDefault(); e.stopPropagation();
    const box = stageRef.current.getBoundingClientRect();
    cropRef.current = {
      handle,
      box,
      start: { ...cbox },
      p0: [(e.clientX - box.left) / box.width, (e.clientY - box.top) / box.height],
    };
    try { e.currentTarget.setPointerCapture(e.pointerId); } catch (err) { /* تجاهل */ }
  };
  const cropMove = (e) => {
    const d = cropRef.current;
    if (!d || !e.buttons) return;
    const dx = (e.clientX - d.box.left) / d.box.width - d.p0[0];
    const dy = (e.clientY - d.box.top) / d.box.height - d.p0[1];
    const s = d.start;
    const right = s.x + s.w;
    const bottom = s.y + s.h;
    const c = { ...s };
    if (d.handle === 'move') {
      c.x = clamp(s.x + dx, 0, 1 - s.w);
      c.y = clamp(s.y + dy, 0, 1 - s.h);
    } else {
      if (d.handle.includes('w')) { const nx = clamp(s.x + dx, 0, right - MIN); c.x = nx; c.w = right - nx; }
      if (d.handle.includes('e')) { c.w = clamp(right + dx, s.x + MIN, 1) - s.x; }
      if (d.handle.includes('n')) { const ny = clamp(s.y + dy, 0, bottom - MIN); c.y = ny; c.h = bottom - ny; }
      if (d.handle.includes('s')) { c.h = clamp(bottom + dy, s.y + MIN, 1) - s.y; }
    }
    setRatioId('free');
    setCrop(c);
  };
  const cropEnd = () => { cropRef.current = null; };
  const pickRatio = (id) => {
    setRatioId(id);
    const r = (RATIOS.find((x) => x.id === id) || {}).r;
    if (!r || !vd) { if (!r) resetCrop(); return; }
    const ar = vd.w / vd.h;
    let w = 0.92;
    let h = (w * ar) / r;
    if (h > 0.92) { h = 0.92; w = (h * r) / ar; }
    setCrop({ x: (1 - w) / 2, y: (1 - h) / 2, w, h });
  };

  // ── التنسيق: تدوير · قلب · فلتر ──
  const rotate = () => setView((vv) => patchView(vv, { rot: (normView(vv).rot + 90) % 360 }));
  const flipH = () => setView((vv) => patchView(vv, { flipH: !normView(vv).flipH }));
  const flipV = () => setView((vv) => patchView(vv, { flipV: !normView(vv).flipV }));
  const pickFilter = (id) => setView((vv) => patchView(vv, { filter: id }));
  const resetFx = () => setView((vv) => patchView(vv, { rot: 0, flipH: false, flipV: false, filter: 'none' }));
  const fxDirty = !isPlainView({ ...v, crop: null });

  // ── التصدير: نُرسم الطبقات بالحجم الأصلي للوسائط ──
  //  • صورة → تُدمج الطبقات (والدوران) في الصورة نفسها، و«القصّ/الفلتر» يبقيان
  //    إعدادات عرض قابلة للتراجع.
  //  • مقطع → تُصدَّر الطبقات صورة شفافة تُعرض فوق المقطع كما تُعرض فوقه هنا.
  const drawLayers = (g, outW, outH) => {
    g.lineCap = 'round';
    g.lineJoin = 'round';
    strokes.forEach((s) => {
      if (!s.points.length) return;
      g.strokeStyle = s.color;
      g.fillStyle = s.color;
      g.lineWidth = Math.max(2, s.width * outW);
      if (s.points.length === 1) {
        g.beginPath();
        g.arc(s.points[0][0] * outW, s.points[0][1] * outH, g.lineWidth / 2, 0, Math.PI * 2);
        g.fill();
        return;
      }
      g.beginPath();
      s.points.forEach(([x, y], i) => (i ? g.lineTo(x * outW, y * outH) : g.moveTo(x * outW, y * outH)));
      g.stroke();
    });
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    stickers.forEach((s) => {
      g.font = `${Math.round(s.size * outW)}px "Apple Color Emoji", "Segoe UI Emoji", serif`;
      g.fillStyle = '#fff';
      g.fillText(s.emoji, s.x * outW, s.y * outH);
    });
    texts.forEach((t) => {
      if (!t.text.trim()) return;
      g.font = `700 ${Math.round(t.size * outW)}px "Segoe UI", system-ui, sans-serif`;
      g.direction = 'rtl';
      g.lineWidth = Math.max(3, outW * 0.006);
      g.strokeStyle = 'rgba(4,7,15,.55)';
      g.strokeText(t.text, t.x * outW, t.y * outH);
      g.fillStyle = t.color;
      g.fillText(t.text, t.x * outW, t.y * outH);
    });
  };

  const outSize = (vv) => {
    const d = viewDims(vv, dims);
    const w = Math.min(1440, d ? d.w : 1080);
    const h = Math.max(1, Math.round((w * (d ? d.h : 1080)) / (d ? d.w : 1080)));
    return { w, h, swap: !!(d && d.swap) };
  };

  const bakeImage = async (vv, baked) => {
    if (media.type !== 'image' || !dims || (!hasWork && !baked)) return null;
    const { w: outW, h: outH, swap: sw } = outSize(vv);
    const c = document.createElement('canvas');
    c.width = outW; c.height = outH;
    const g = c.getContext('2d');
    if (!g) return null;
    const img = await loadImg(media.dataUrl);
    const dw = sw ? outH : outW;
    const dh = sw ? outW : outH;
    g.save();
    g.translate(outW / 2, outH / 2);
    g.rotate((vv.rot * Math.PI) / 180);
    g.scale(vv.flipH ? -1 : 1, vv.flipV ? -1 : 1);
    g.drawImage(img, -dw / 2, -dh / 2, dw, dh);
    g.restore();
    drawLayers(g, outW, outH);
    return c.toDataURL('image/jpeg', 0.92);
  };

  const bakeOverlay = async (vv) => {
    if (media.type === 'image' || !dims || (!hasWork && !media.overlay)) return null;
    const { w: outW, h: outH } = outSize(vv);
    const c = document.createElement('canvas');
    c.width = outW; c.height = outH;
    const g = c.getContext('2d');
    if (!g) return null;
    if (media.overlay) {
      try { g.drawImage(await loadImg(media.overlay), 0, 0, outW, outH); } catch (e) { /* تجاهل */ }
    }
    drawLayers(g, outW, outH);
    return c.toDataURL('image/png');
  };

  const commit = async (closeAfter) => {
    if (saving) return;
    const vv = normView(view);
    const baked = media.type === 'image' && (vv.rot !== 0 || vv.flipH || vv.flipV);
    if (!hasWork && !baked && isPlainView(vv)) {
      setTool(null);
      if (closeAfter) { setOpen(false); if (onDone) onDone(); }
      return;
    }
    setSaving(true);
    try {
      let next = { ...media };
      let nd = dims;
      if (media.type === 'image') {
        const data = await bakeImage(vv, baked);
        if (data) {
          next = { ...next, dataUrl: data, overlay: null, size: Math.round(data.length * 0.75) };
          nd = plain(viewDims(vv, dims));
        }
      } else {
        const ov = await bakeOverlay(vv);
        if (ov) next = { ...next, overlay: ov };
      }
      const nv = baked ? patchView(vv, { rot: 0, flipH: false, flipV: false }) : vv;
      next = { ...next, view: nv, dims: nd || null };
      setDims(nd);
      setView(nv);
      setStrokes([]); setStickers([]); setTexts([]); setDraft('');
      lastTextRef.current = null;
      setTool(null);
      lastUrlRef.current = next.dataUrl || null; // تثبيتنا نحن — ليس وسائط جديدة
      onApply(next);
    } catch (e) {
      onError('تعذّر تثبيت التعديل — جرّب مرة أخرى.');
    } finally {
      setSaving(false);
      if (closeAfter) {
        setOpen(false);
        // «تم» يعني: انتهيت من التعديل — فينتقل النموذج تلقائيًا إلى المعاينة
        // الإلزامية بلا زرّ معاينة.
        if (onDone) onDone();
      }
    }
  };

  // المعاينة إلزامية: كل وسائط جديدة (تصوير أو استوديو) تفتح الصفحة الكاملة
  // تلقائيًا — الصورة تملأ الشاشة والأيقونات فوقها — بلا ضغط أي زرّ.
  // ونتجاهل التغيير الذي نصنعه نحن بـ«تثبيت» (نفس الوسائط بعد الدمج) حتى لا
  // تنفتح الصفحة من جديد أثناء المعاينة.
  const lastUrlRef = useRef(media.dataUrl);
  useEffect(() => {
    if (media.dataUrl === lastUrlRef.current) return;
    lastUrlRef.current = media.dataUrl;
    setOpen(true);
  }, [media.dataUrl]);

  // «تثبيت» يُتاح للنموذج الأب أيضًا: قبل الانتقال إلى المعاينة نُثبّت أي رسم
  // أو ملصق أو نصّ أو إطار ما زال حيًّا، حتى لا يضيع عمل صاحبه بضغطة واحدة.
  useEffect(() => {
    if (!flushRef) return undefined;
    const fn = () => commit(false);
    flushRef.current = fn;
    return () => { if (flushRef.current === fn) flushRef.current = null; };
  });

  const openRoom = async () => {
    if (!room.title.trim() || saving) return;
    setSaving(true);
    try {
      const okDone = await onRoom({ title: room.title.trim(), place: room.place.trim(), capacity: 8, hours: 6, kind: 'نشاط' });
      if (okDone) setOpened({ title: room.title.trim() });
    } finally {
      setSaving(false);
    }
  };

  const active = TOOLS.find((t) => t.id === tool);
  const px = (frac) => `${Math.max(9, Math.round(frac * (boxW || 320)))}px`;
  const dirty = hasWork || !isPlainView(v);

  const stageStyle = fit && vd
    ? { width: `${Math.round(vd.w * Math.min(fit.w / vd.w, fit.h / vd.h))}px`, height: `${Math.round(vd.h * Math.min(fit.w / vd.w, fit.h / vd.h))}px` }
    : { width: '100%', maxHeight: '58dvh', aspectRatio: vd ? `${vd.w} / ${vd.h}` : '4 / 5' };
  const rotStyle = {
    width: vd ? `${((swap ? vd.h : vd.w) / vd.w) * 100}%` : '100%',
    height: vd ? `${((swap ? vd.w : vd.h) / vd.h) * 100}%` : '100%',
    transform: `translate(-50%, -50%) rotate(${v.rot}deg) scaleX(${v.flipH ? -1 : 1}) scaleY(${v.flipV ? -1 : 1})`,
  };
  const applyBtn = (cls) => (
    <button
      type="button"
      className={`mt-apply${cls ? ` ${cls}` : ''}`}
      onClick={() => commit(false)}
      disabled={saving || !dirty}
      aria-label="تثبيت التعديل على الوسائط"
      title="تثبيت"
    >
      {saving ? <Loader2 className="spin" size={14} strokeWidth={2} /> : <Check size={15} strokeWidth={2.4} />}
      تثبيت
    </button>
  );

  return (
    <>
      {/* بطاقة الوسائط داخل النموذج: مصغّرة + زرّ تعديل يفتح صفحة المحرّر الكاملة */}
      <div className="mt-card">
        <div className="mt-thumb">
          <MediaFrame src={media.dataUrl} type={media.type} dims={dims} view={v} />
        </div>
        <div className="mt-card-info">
          <strong>{KIND[media.type] || 'وسائط'}</strong>
          <em>{v.crop ? 'إطار مقصوص' : 'الإطار كامل'}{fxDirty ? ' · منسّق' : ''}</em>
        </div>
        <button type="button" className="btn sm mt-open" onClick={() => setOpen(true)}>
          <Maximize2 size={15} strokeWidth={1.8} /> تعديل
        </button>
      </div>

      {open ? createPortal((
        <div className="mt-editor" role="dialog" aria-modal="true" aria-label="محرّر الوسائط">
          <div className="mt-top">
            <button type="button" className="mt-close" onClick={() => setOpen(false)} aria-label="رجوع إلى النموذج" title="رجوع">
              <X size={18} strokeWidth={2} />
            </button>
            <span className="mt-top-name">{KIND[media.type] || 'وسائط'} · صفحة كاملة</span>
            {/* «تم» = انتهيت → المعاينة الإجبارية. لا يُعطَّل لأن الوسائط بلا تعديل:
                صورة اختيرت من الاستوديو ولم تُلمس يجب أن تمضي إلى المعاينة أيضًا
                (المعاينة إلزامية في v21). «تثبيت» وحده يبقى معطّلًا بلا تعديل. */}
            <button
              type="button"
              className="mt-apply mt-done"
              onClick={() => commit(true)}
              disabled={saving}
              aria-label="تم — انتقل إلى المعاينة"
              title="تم — انتقل إلى المعاينة"
            >
              {saving ? <Loader2 className="spin" size={14} strokeWidth={2} /> : <Check size={15} strokeWidth={2.4} />}
              تم
            </button>
          </div>

          <div className="mt-fit" ref={fitRef}>
            <div
              ref={stageRef}
              className={`mt-stage${tool === 'draw' ? ' drawing' : ' quiet'}`}
              style={stageStyle}
              onPointerDown={onDown}
              onPointerMove={(e) => { onMove(e); cropMove(e); }}
              onPointerUp={() => { drop(); cropEnd(); }}
              onPointerCancel={() => { drop(); cropEnd(); }}
              onPointerLeave={() => { drop(); cropEnd(); }}
            >
              <div className="mt-view" style={{ filter: filterCss(v.filter) }}>
                <div className="mt-rot" style={rotStyle}>
                  {media.type === 'image'
                    ? <img className="mt-media" src={media.dataUrl} alt="معاينة الوسائط" draggable={false} />
                    : <video className="mt-media" src={media.dataUrl} playsInline muted loop autoPlay />}
                </div>
                {media.overlay ? <img className="mt-ovl" src={media.overlay} alt="" draggable={false} /> : null}
              </div>
              <canvas ref={canvasRef} className="mt-canvas" aria-hidden="true" />

              {stickers.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  className="mt-sticker"
                  style={{ left: `${s.x * 100}%`, top: `${s.y * 100}%`, fontSize: px(s.size) }}
                  onPointerDown={(e) => grab(e, 'sticker', s.id)}
                  onPointerMove={drag}
                  onPointerUp={drop}
                  onDoubleClick={() => rmSticker(s.id)}
                  title="اسحب للتحريك · اضغط مرتين للحذف"
                >
                  {s.emoji}
                </button>
              ))}

              {texts.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  className="mt-text"
                  style={{ left: `${t.x * 100}%`, top: `${t.y * 100}%`, fontSize: px(t.size), color: t.color }}
                  onPointerDown={(e) => grab(e, 'text', t.id)}
                  onPointerMove={drag}
                  onPointerUp={drop}
                  onDoubleClick={() => rmText(t.id)}
                  title="اسحب للتحريك · اضغط مرتين للحذف"
                >
                  {t.text || 'اكتب نصًا…'}
                </button>
              ))}

              {/* إطار القصّ: نسبةً من مساحة العرض — يُسحب من الوسط أو من المقابض */}
              {tool === 'crop' && (
                <>
                  <span className="mt-shade" style={{ left: 0, top: 0, width: '100%', height: `${cbox.y * 100}%` }} aria-hidden="true" />
                  <span className="mt-shade" style={{ left: 0, top: `${(cbox.y + cbox.h) * 100}%`, width: '100%', bottom: 0 }} aria-hidden="true" />
                  <span className="mt-shade" style={{ left: 0, top: `${cbox.y * 100}%`, width: `${cbox.x * 100}%`, height: `${cbox.h * 100}%` }} aria-hidden="true" />
                  <span className="mt-shade" style={{ left: `${(cbox.x + cbox.w) * 100}%`, top: `${cbox.y * 100}%`, right: 0, height: `${cbox.h * 100}%` }} aria-hidden="true" />
                  <div
                    className="mt-crop"
                    style={{ left: `${cbox.x * 100}%`, top: `${cbox.y * 100}%`, width: `${cbox.w * 100}%`, height: `${cbox.h * 100}%` }}
                    onPointerDown={(e) => startCrop(e, 'move')}
                    onPointerMove={cropMove}
                    onPointerUp={cropEnd}
                  >
                    <span className="mt-crop-grid" aria-hidden="true" />
                    <span className="mt-crop-grab" aria-hidden="true"><Move size={13} strokeWidth={2.2} /></span>
                    {['nw', 'ne', 'sw', 'se'].map((h) => (
                      <button
                        key={h}
                        type="button"
                        className={`mt-crop-dot d-${h}`}
                        aria-label={`مقبض القصّ ${h}`}
                        onPointerDown={(e) => startCrop(e, h)}
                        onPointerMove={cropMove}
                        onPointerUp={cropEnd}
                      />
                    ))}
                  </div>
                </>
              )}

              {/* شريط الأدوات فوق الوسائط نفسها: أيقونات دائرية بلا قائمة منسدلة */}
              <div className="mt-rail" role="toolbar" aria-label="أدوات الوسائط">
                {TOOLS.map(({ id, label, hint, Icon }) => (
                  <React.Fragment key={id}>
                    {id === 'room' ? <span className="mt-rail-sep" aria-hidden="true" /> : null}
                    <button
                      type="button"
                      className={`mt-rail-btn${tool === id ? ' on' : ''}`}
                      aria-pressed={tool === id}
                      title={hint}
                      aria-label={label}
                      onClick={() => setTool((prev) => (prev === id ? null : id))}
                    >
                      <Icon size={18} strokeWidth={1.9} />
                    </button>
                  </React.Fragment>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-bottom">
            {active ? (
              <div className="mt-dock">
                <div className="mt-dock-bar">
                  <span className="mt-dock-name"><active.Icon size={15} strokeWidth={1.9} /> {active.label}</span>
                  {tool !== 'room' && (
                    <span className="mt-dock-act">
                      {tool === 'crop' ? (
                        <button type="button" className="mt-ic" onClick={resetCrop} disabled={!v.crop} aria-label="إلغاء القصّ" title="إلغاء القصّ">
                          <RotateCcw size={15} strokeWidth={1.9} />
                        </button>
                      ) : tool === 'fx' ? (
                        <button type="button" className="mt-ic" onClick={resetFx} disabled={!fxDirty} aria-label="إعادة الضبط" title="إعادة الضبط">
                          <RotateCcw size={15} strokeWidth={1.9} />
                        </button>
                      ) : (
                        <>
                          <button type="button" className="mt-ic" onClick={undo} disabled={!layerCount} aria-label="تراجع" title="تراجع">
                            <Undo2 size={15} strokeWidth={1.9} />
                          </button>
                          <button type="button" className="mt-ic" onClick={clearLayers} disabled={!layerCount} aria-label="مسح الكل" title="مسح الكل">
                            <Trash2 size={15} strokeWidth={1.9} />
                          </button>
                        </>
                      )}
                      {applyBtn()}
                    </span>
                  )}
                </div>
                {tool === 'draw' && (
                  <div className="mt-row">
                    {COLORS.map((c) => (
                      <button
                        key={c}
                        type="button"
                        className={`mt-color${c === color ? ' on' : ''}`}
                        style={{ background: c }}
                        onClick={() => setColor(c)}
                        aria-label={`قلم بلون ${c}`}
                      />
                    ))}
                    <span className="mt-gap" aria-hidden="true" />
                    {BRUSHES.map((b) => (
                      <button
                        key={b}
                        type="button"
                        className={`mt-brush${b === brush ? ' on' : ''}`}
                        onClick={() => setBrush(b)}
                        aria-label="سماكة القلم"
                      >
                        <i style={{ width: `${b * 320}px`, height: `${b * 320}px` }} />
                      </button>
                    ))}
                  </div>
                )}

                {tool === 'sticker' && (
                  <div className="mt-strip">
                    {STICKERS.map((em) => (
                      <button key={em} type="button" className="mt-emoji" onClick={() => addSticker(em)} aria-label={`أضف ${em}`}>
                        {em}
                      </button>
                    ))}
                  </div>
                )}

                {tool === 'text' && (
                  <>
                    <input
                      className="mt-input"
                      value={draft}
                      onChange={(e) => editText(e.target.value)}
                      placeholder="اكتب نصًا… مثلًا: من معنا هنا؟"
                      dir="rtl"
                    />
                    <div className="mt-strip">
                      {EMOJIS.map((em) => (
                        <button key={em} type="button" className="mt-emoji" onClick={() => editText(draft + em)} aria-label={`إيموجي ${em}`}>
                          {em}
                        </button>
                      ))}
                    </div>
                  </>
                )}
                {/* القصّ: نِسَب جاهزة + سحب الإطار بالإصبع */}
                {tool === 'crop' && (
                  <>
                    <div className="mt-row">
                      {RATIOS.map((r) => (
                        <button
                          key={r.id}
                          type="button"
                          className={`chip${ratioId === r.id ? ' on active' : ''}`}
                          aria-pressed={ratioId === r.id}
                          onClick={() => pickRatio(r.id)}
                        >
                          {r.label}
                        </button>
                      ))}
                    </div>
                    <em className="mt-note">اسحب الإطار أو مقابضه — والقصّ يُطبَّق على المعاينة والعارض، ويبقى قابلًا للتراجع.</em>
                  </>
                )}

                {/* التنسيق: تدوير · قلب · فلاتر */}
                {tool === 'fx' && (
                  <>
                    <div className="mt-row">
                      <button type="button" className="mt-fx" onClick={rotate} aria-label="تدوير ٩٠ درجة">
                        <RotateCw size={16} strokeWidth={1.9} /> تدوير
                      </button>
                      <button type="button" className={`mt-fx${v.flipH ? ' on' : ''}`} onClick={flipH} aria-label="قلب أفقي" aria-pressed={v.flipH}>
                        <FlipHorizontal2 size={16} strokeWidth={1.9} /> أفقي
                      </button>
                      <button type="button" className={`mt-fx${v.flipV ? ' on' : ''}`} onClick={flipV} aria-label="قلب رأسي" aria-pressed={v.flipV}>
                        <FlipVertical2 size={16} strokeWidth={1.9} /> رأسي
                      </button>
                    </div>
                    <div className="mt-row">
                      {FILTERS.map((f) => (
                        <button
                          key={f.id}
                          type="button"
                          className={`mt-filter${v.filter === f.id ? ' on' : ''}`}
                          style={{ filter: f.css === 'none' ? undefined : f.css }}
                          aria-pressed={v.filter === f.id}
                          onClick={() => pickFilter(f.id)}
                        >
                          {f.label}
                        </button>
                      ))}
                    </div>
                  </>
                )}

                {tool === 'room' && (
                  <>
                    {opened ? (
                      <div className="mt-done">
                        <span className="mt-tick"><Check size={14} strokeWidth={2.4} /></span>
                        <div>
                          <strong>فُتحت غرفة «{opened.title}»</strong>
                          <p>الدعوة وصلت دائرتك، والغرفة تُقفل تلقائيًا بعد ٦ ساعات.</p>
                        </div>
                        <button className="btn sm" type="button" onClick={() => onOpenRooms && onOpenRooms()}>إلى الغرف</button>
                      </div>
                    ) : (
                      <>
                        <input
                          className="mt-input"
                          value={room.title}
                          onChange={(e) => setRoom({ ...room, title: e.target.value })}
                          placeholder="اسم الغرفة — جلسة القرم"
                          dir="rtl"
                        />
                        <input
                          className="mt-input"
                          value={room.place}
                          onChange={(e) => setRoom({ ...room, place: e.target.value })}
                          placeholder="المكان (اختياري)"
                          dir="rtl"
                        />
                        <div className="mt-row">
                          <button className="btn sm" type="button" onClick={openRoom} disabled={saving || !room.title.trim()}>
                            {saving ? <Loader2 className="spin" size={14} strokeWidth={2} /> : <DoorOpen size={15} strokeWidth={1.8} />}
                            افتح الغرفة
                          </button>
                          <em className="mt-note">غرفة مؤقتة تنطلق من هذه اللحظة</em>
                        </div>
                      </>
                    )}
                  </>
                )}

                {tool !== 'room' && <em className="mt-note">{active.hint}</em>}
              </div>
            ) : (
              <em className="mt-note">اختر أداة من الشريط فوق الوسائط: رسم · ملصقات · نص · قصّ · تنسيق · غرفة</em>
            )}
          </div>
        </div>
      ), document.body) : null}
    </>
  );
}

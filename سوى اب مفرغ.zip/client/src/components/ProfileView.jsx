import React, { useEffect, useRef, useState } from 'react';
import {
  Save, Loader2, Shield, MapPin, BellRing, Users, DoorOpen, CalendarClock, Radio, User,
  Phone, LogOut, AtSign, Camera, Check, AlertCircle, X, ChevronDown,
} from 'lucide-react';
import Avatar from './Avatar.jsx';
import CircleView from './CircleView.jsx';
import DevicePerms from './DevicePerms.jsx';
import VaultPanel from './VaultPanel.jsx';
import { api } from '../api.js';
import { whoSees as loadWhoSees } from '../v31.js';
import { shrinkImage } from '../media.js';

const USERNAME_RE = /^[a-z][a-z0-9_]{2,19}$/;
const cleanUser = (v) => String(v || '').toLowerCase().replace(/^@+/, '').replace(/[^a-z0-9_]/g, '').slice(0, 20);

const PRIVACY = {
  states: [
    { v: 'circle', l: 'دائرتي فقط' },
    { v: 'close', l: 'الدائرة القريبة' },
    { v: 'family', l: 'العائلة' },
  ],
  location: [
    { v: 'off', l: 'متوقف' },
    { v: 'hourly', l: 'دقة الساعة' },
    { v: 'exact', l: 'دقيق أثناء النشاط' },
  ],
  whispers: [
    { v: 'circle', l: 'من الجميع' },
    { v: 'close', l: 'الدائرة القريبة فقط' },
    { v: 'off', l: 'مُعطّل' },
  ],
};

function Seg({ section, setSection, count }) {
  return (
    <div className="seg" role="tablist" aria-label="ملفي أو دائرتي">
      <button
        className={`seg-btn${section === 'me' ? ' on' : ''}`}
        onClick={() => setSection('me')}
        role="tab"
        aria-selected={section === 'me'}
      >
        <User size={15} strokeWidth={1.8} /> ملفي
      </button>
      <button
        className={`seg-btn${section === 'circle' ? ' on' : ''}`}
        onClick={() => setSection('circle')}
        role="tab"
        aria-selected={section === 'circle'}
      >
        <Users size={15} strokeWidth={1.8} /> دائرتي
        <span className="seg-count">{count}</span>
      </button>
    </div>
  );
}

export default function ProfileView({ data, actions, busy, onMessage, account, onLogout, onRestoreVault, addToast }) {
  const me = data.me;
  const [name, setName] = useState(me.name);
  const [city, setCity] = useState(me.city);
  const [username, setUsername] = useState(me.username || '');
  const [userState, setUserState] = useState('free');
  const [userMsg, setUserMsg] = useState('');
  const [avatar, setAvatar] = useState(me.avatar || '');
  const [picBusy, setPicBusy] = useState(false);

  // ٨.٢ — «من يرى أثري»: من الخادم، لا من حسابات الواجهة. تُجلب عند الطلب فقط.
  const [reachOpen, setReachOpen] = useState(false);
  const [reach, setReach] = useState({ state: 'idle', people: 0, circles: [], blocked: 0, memories: 0, limit: '' });
  useEffect(() => {
    if (!reachOpen || reach.state === 'ready' || reach.state === 'loading') return;
    let live = true;
    setReach((r) => ({ ...r, state: 'loading' }));
    loadWhoSees()
      .then((d) => { if (live) setReach({ state: 'ready', people: d.reach, circles: d.circles, blocked: d.blocked.length, memories: d.memories, limit: d.deleteLimit }); })
      .catch(() => { if (live) setReach((r) => ({ ...r, state: 'error' })); });
    return () => { live = false; };
  }, [reachOpen, reach.state]);
  const fileRef = useRef(null);
  const [privacy, setPrivacy] = useState(me.privacy);
  const [prefs, setPrefs] = useState(me.prefs);
  const [section, setSection] = useState('me');

  // فحص توفّر الاسم الجديد فقط — الاسم الحالي مقبول كما هو
  useEffect(() => {
    const u = cleanUser(username);
    const cur = String(me.username || '');
    if (!u) { setUserState('bad'); setUserMsg('اسم المستخدم مطلوب'); return undefined; }
    if (u === cur) { setUserState('free'); setUserMsg('هذا اسمك الحالي'); return undefined; }
    if (!USERNAME_RE.test(u)) { setUserState('bad'); setUserMsg('ثلاثة أحرف على الأقل، يبدأ بحرف، وحتى ٢٠ حرفًا'); return undefined; }
    setUserState('checking');
    let alive = true;
    const t = setTimeout(() => {
      api.usernameCheck(u)
        .then((d) => {
          if (!alive) return;
          if (d && d.available) { setUserState('free'); setUserMsg('متاح'); }
          else { setUserState('taken'); setUserMsg((d && d.error) || 'محجوز'); }
        })
        .catch(() => { if (alive) { setUserState('idle'); setUserMsg(''); } });
    }, 350);
    return () => { alive = false; clearTimeout(t); };
  }, [username, me.username]);

  const onPic = async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    if (!/^image\//.test(f.type || '')) return;
    setPicBusy(true);
    try {
      const small = await shrinkImage(f, 480, 0.85);
      const up = await api.uploadMedia({ type: 'image', dataUrl: small.dataUrl });
      setAvatar(up.url);
    } catch (err) { /* نُبقي الصورة السابقة */ }
    finally { setPicBusy(false); }
  };

  const dirty =
    name !== me.name ||
    city !== me.city ||
    String(avatar || '') !== String(me.avatar || '') ||
    cleanUser(username) !== String(me.username || '') ||
    JSON.stringify(privacy) !== JSON.stringify(me.privacy) ||
    JSON.stringify(prefs) !== JSON.stringify(me.prefs);

  if (section === 'circle') {
    return (
      <div className="view">
        <Seg section={section} setSection={setSection} count={data.people.length} />
        <CircleView data={data} actions={actions} busy={busy} onMessage={onMessage} />
      </div>
    );
  }

  const stats = [
    { Icon: Radio, n: data.states.length, l: 'حالة' },
    { Icon: DoorOpen, n: data.rooms.length, l: 'غرفة' },
    { Icon: Users, n: data.people.length, l: 'شخصًا' },
    { Icon: CalendarClock, n: data.meetings.length, l: 'اجتماع' },
  ];

  return (
    <div className="view">
      <Seg section={section} setSection={setSection} count={data.people.length} />

      <section className="card profile-card">
        <button type="button" className="avatar-edit" onClick={() => fileRef.current && fileRef.current.click()} disabled={picBusy} aria-label="تغيير صورة العرض">
          <Avatar name={me.name} color={me.avatarColor} size="lg" photo={avatar} />
          <span className="avatar-edit-badge">{picBusy ? <Loader2 className="spin" size={13} strokeWidth={2} /> : <Camera size={13} strokeWidth={2} />}</span>
        </button>
        <input ref={fileRef} type="file" accept="image/*" onChange={onPic} className="file-sr" tabIndex={-1} />
        <div className="grow">
          <div className="pname big">{me.name}</div>
          <div className="meta">
            <span dir="ltr">{me.handle || (me.username ? '@' + me.username : '')}</span>
            <span className="sep">·</span>
            <MapPin size={12} strokeWidth={1.8} />
            <span>{me.city}</span>
          </div>
          <span className="trust inline">{me.trust}</span>
        </div>
      </section>

      <div className="stats">
        {stats.map(({ Icon, n, l }) => (
          <div key={l} className="stat">
            <Icon size={16} strokeWidth={1.8} />
            <b>{n}</b>
            <span>{l}</span>
          </div>
        ))}
      </div>

      <section className="card account-card">
        <h3 className="card-title"><Phone size={16} strokeWidth={1.8} /> الحساب والدخول</h3>
        <div className="account-row">
          <span className="account-phone" dir="ltr">
            +968 {(account && account.display) || (me.phone ? String(me.phone).slice(3) : '—')}
          </span>
          <span className="auth-count">الدخول برقم الهاتف</span>
        </div>
        <p className="hint">الخروج يُبطل الجلسة على هذا الجهاز.</p>
        <button className="btn ghost" onClick={onLogout}>
          <LogOut size={15} strokeWidth={1.8} /> تسجيل الخروج
        </button>
      </section>

      <section className="card">
        <h3 className="card-title">البيانات الأساسية</h3>
        <div className="row2">
          <label className="field">
            <span>الاسم</span>
            <input value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="field">
            <span>المدينة</span>
            <input value={city} onChange={(e) => setCity(e.target.value)} />
          </label>
        </div>
        <label className="field">
          <span><AtSign size={13} strokeWidth={1.8} /> اسم المستخدم</span>
          <div className={`userfield${userState === 'taken' || userState === 'bad' ? ' bad' : ''}${userState === 'free' ? ' ok' : ''}`}>
            <span className="at" dir="ltr">@</span>
            <input
              value={username}
              onChange={(e) => { setUsername(cleanUser(e.target.value)); setUserMsg(''); setUserState('idle'); }}
              dir="ltr"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck="false"
              placeholder="sawa4567"
              aria-label="اسم المستخدم"
            />
            <span className="st">
              {userState === 'checking' && <Loader2 className="spin" size={14} strokeWidth={2} />}
              {userState === 'free' && <Check size={14} strokeWidth={2} />}
              {(userState === 'taken' || userState === 'bad') && <AlertCircle size={14} strokeWidth={2} />}
            </span>
          </div>
          <span className={`auth-count${userState === 'free' ? ' ok' : ''}${userState === 'taken' || userState === 'bad' ? ' bad' : ''}`}>
            {userMsg}
          </span>
        </label>
        {avatar && (
          <button type="button" className="inline-link" onClick={() => setAvatar('')}>
            <X size={14} strokeWidth={1.8} /> إزالة صورة العرض
          </button>
        )}
      </section>

      <section className="card">
        <h3 className="card-title"><Shield size={16} strokeWidth={1.8} /> الخصوصية</h3>
        <label className="field">
          <span>من يرى حالاتي</span>
          <select value={privacy.states} onChange={(e) => setPrivacy({ ...privacy, states: e.target.value })}>
            {PRIVACY.states.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
          </select>
        </label>
        <label className="field">
          <span>مشاركة الموقع</span>
          <select value={privacy.location} onChange={(e) => setPrivacy({ ...privacy, location: e.target.value })}>
            {PRIVACY.location.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
          </select>
        </label>
        <label className="field">
          <span>من يستطيع إرسال همسة</span>
          <select value={privacy.whispers} onChange={(e) => setPrivacy({ ...privacy, whispers: e.target.value })}>
            {PRIVACY.whispers.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
          </select>
        </label>
      </section>

      <section className="card">
        <h3 className="card-title"><Shield size={16} strokeWidth={1.8} /> من يرى أثري</h3>
        <button
          type="button"
          className={`reach-row${reachOpen ? ' open' : ''}`}
          onClick={() => setReachOpen((v) => !v)}
          aria-expanded={reachOpen}
        >
          <span className="reach-num">
            {reach.state === 'ready' ? `${reach.people} شخصًا` : reach.state === 'error' ? 'تعذّر الجلب الآن' : 'اعرض القائمة'}
          </span>
          <span className="reach-sub">
            {reach.state === 'ready' ? `${reach.circles.length} دائرة · ${reach.memories} أثرًا لي` : 'الدوائر الخادمية'}
          </span>
          <ChevronDown className={`chev${reachOpen ? ' up' : ''}`} size={16} strokeWidth={1.9} />
        </button>
        {reachOpen && reach.state === 'ready' && (
          <div className="reach-list">
            {reach.circles.map((c) => (
              <div className="reach-item" key={c.id}>
                <b>{c.name}</b>
                <span className="rel">{c.members.length} عضوًا</span>
              </div>
            ))}
            {!reach.circles.length && <p className="muted-note small">لا دوائر بعد — أنشئ دائرة ليصل أثرك إلى من تختار.</p>}
            {!!reach.blocked && <p className="muted-note small">{reach.blocked} محجوبًا لا يرون شيئًا من أثرك.</p>}
          </div>
        )}
        <p className="muted-note small">
          {reach.limit || 'الحذف فوري من الخادم ومن كل جهاز متصل؛ ولا يمكن سحب نسخة ظهرت سابقًا على جهاز غير متصل.'}
        </p>
      </section>

      <section className="card">
        <h3 className="card-title"><BellRing size={16} strokeWidth={1.8} /> التنبيهات</h3>
        <div className="toggle-row">
          <span>وضع الهدوء (إيقاف التنبيهات)</span>
          <button
            className={`switch${prefs.notifyQuiet ? ' on' : ''}`}
            aria-label="وضع الهدوء — إيقاف التنبيهات"
            onClick={() => setPrefs({ ...prefs, notifyQuiet: !prefs.notifyQuiet })}
            aria-pressed={prefs.notifyQuiet}
          ><i /></button>
        </div>
      </section>

      <DevicePerms />

      <VaultPanel data={data} account={account} onRestore={onRestoreVault} addToast={addToast} />

      <div className="actions sticky-actions">
        <button
          className="btn"
          disabled={busy || !dirty || userState === 'taken' || userState === 'bad' || userState === 'checking'}
          onClick={() => actions.saveMe({ name, city, privacy, prefs, username: cleanUser(username), avatar })}
        >
          {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <Save size={16} strokeWidth={1.8} />}
          {dirty ? 'احفظ التغييرات' : 'محفوظ'}
        </button>
      </div>
    </div>
  );
}

import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Phone, ShieldCheck, UserPlus, Loader2, AlertCircle, ArrowLeft, RefreshCw, Check, KeyRound,
  AtSign, Camera, X,
} from 'lucide-react';
import { api } from '../api.js';
import { shrinkImage } from '../media.js';
import { digitsOnly } from '../digits.js';

const USERNAME_RE = /^[a-z][a-z0-9_]{2,19}$/;
// ينقّي اسم المستخدم أثناء الكتابة: حروف إنجليزية صغيرة وأرقام و _ فقط
const cleanUser = (v) => String(v || '').toLowerCase().replace(/^@+/, '').replace(/[^a-z0-9_]/g, '').slice(0, 20);
const LOCAL_RE = /^[1-9]\d{7}$/;
// ينقّي الرقم كما يُكتب محليًا: يحذف 968 أو الصفر البادئ ويُبقي ٨ أرقام
const cleanLocal = (v) => digitsOnly(v)
  .replace(/^00968/, '')
  .replace(/^968/, '')
  .replace(/^0+/, '')
  .slice(0, 8);

const STEPS = [
  { key: 'phone', label: 'رقم الهاتف', Icon: Phone },
  { key: 'code', label: 'رمز التحقق', Icon: ShieldCheck },
  { key: 'profile', label: 'إنشاء الحساب', Icon: UserPlus },
];

export default function AuthView({ authInfo, onDone, notice }) {
  const [step, setStep] = useState('phone');
  const [phone, setPhone] = useState('');
  const [info, setInfo] = useState(authInfo || null);
  const [digits, setDigits] = useState(['', '', '', '', '', '']);
  const [name, setName] = useState('');
  // اسم المستخدم: قناة التواصل مع من لا يملك رقمك — والصورة: كيف يظهرك التطبيق
  const [username, setUsername] = useState('');
  const [userState, setUserState] = useState('idle'); // idle | checking | free | taken | bad
  const [userMsg, setUserMsg] = useState('');
  const [avatar, setAvatar] = useState('');
  const [avatarBusy, setAvatarBusy] = useState(false);
  const fileRef = useRef(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [triesLeft, setTriesLeft] = useState(null);
  const [resendIn, setResendIn] = useState(0);
  const boxes = useRef([]);
  const busyRef = useRef(false);
  const code = digits.join('');

  // معلومة الوضع التجريبي: تأتي مع بيانات الصفحة، وإلا نطلبها مرة واحدة
  useEffect(() => {
    if (info && info.hint) return;
    let alive = true;
    api.authDemo().then((d) => { if (alive && d) setInfo((prev) => ({ ...prev, ...d })); }).catch(() => null);
    return () => { alive = false; };
  }, [info]);

  useEffect(() => {
    if (resendIn <= 0) return undefined;
    const t = setInterval(() => setResendIn((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [resendIn]);

  const local = cleanLocal(phone);
  const phoneOk = LOCAL_RE.test(local);

  // فحص توفّر اسم المستخدم أثناء الكتابة (٣٥٠ م.ث) — لا نُرسل طلبًا لكل حرف
  useEffect(() => {
    if (step !== 'profile') return undefined;
    const u = username.trim();
    if (!u) { setUserState('idle'); setUserMsg(''); return undefined; }
    if (!USERNAME_RE.test(u)) {
      setUserState('bad');
      setUserMsg('ثلاثة أحرف على الأقل، يبدأ بحرف، وحتى ٢٠ حرفًا');
      return undefined;
    }
    setUserState('checking');
    let alive = true;
    const t = setTimeout(() => {
      api.usernameCheck(u)
        .then((d) => {
          if (!alive) return;
          if (d && d.available) { setUserState('free'); setUserMsg('متاح — هذا هو اسمك في سوى'); }
          else { setUserState('taken'); setUserMsg((d && d.error) || 'الاسم محجوز'); }
        })
        .catch(() => { if (alive) { setUserState('idle'); setUserMsg(''); } });
    }, 350);
    return () => { alive = false; clearTimeout(t); };
  }, [username, step]);

  const onUser = (e) => {
    setUsername(cleanUser(e.target.value));
    setUserMsg('');
    setUserState('idle');
  };

  // صورة العرض: تُصغَّر في الهاتف أولًا ثم تُرفع، فلا تثقل الفتح ولا تُخزَّن صورة ضخمة
  const pickAvatar = () => { if (fileRef.current) fileRef.current.click(); };

  const onAvatarFile = async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    if (!/^image\//.test(f.type || '')) { setError('اختر صورة بصيغة JPG أو PNG أو WebP'); return; }
    setAvatarBusy(true);
    setError(null);
    try {
      const small = await shrinkImage(f, 480, 0.85);
      const up = await api.uploadMedia({ type: 'image', dataUrl: small.dataUrl });
      setAvatar(up.url);
    } catch (err) {
      setError(err.message || 'تعذّر رفع الصورة');
    } finally {
      setAvatarBusy(false);
    }
  };

  const sendCode = useCallback(async (again) => {
    if (!LOCAL_RE.test(cleanLocal(phone))) { setError('أدخل رقم هاتف صحيحًا — ٨ أرقام تبدأ بـ ٧ أو ٩'); return; }
    busyRef.current = true;
    setBusy(true);
    setError(null);
    try {
      const res = await api.authOtp(cleanLocal(phone));
      setInfo((prev) => ({ ...prev, ...res }));
      if (res && res.name) setName(res.name);
      if (res && res.username) { setUsername(res.username); setUserState('free'); }
      else if (res && res.suggestedUsername && !username) setUsername(res.suggestedUsername);
      setDigits(['', '', '', '', '', '']);
      setTriesLeft(null);
      setStep('code');
      setResendIn(60);
      setTimeout(() => boxes.current[0] && boxes.current[0].focus(), 60);
      return again ? 'أُرسل رمز جديد' : null;
    } catch (e) {
      setError(e.message || 'تعذّر إرسال الرمز');
      if (again) setResendIn(0);
      return null;
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }, [phone]);

  const verify = useCallback(async (withProfile) => {
    if (code.length !== 6) { setError('الرمز ٦ أرقام'); return; }
    busyRef.current = true;
    setBusy(true);
    setError(null);
    try {
      const payload = { phone: cleanLocal(phone), code };
      if (withProfile) {
        payload.name = name.trim();
        payload.username = username.trim();
        if (avatar) payload.avatar = avatar;
      }
      const res = await api.authVerify(payload);
      if (res && res.needsProfile) {
        setStep('profile');
        if (res.name) setName(res.name);
        if (res.username) setUsername(res.username);
        else if (res.suggestedUsername && !username) setUsername(res.suggestedUsername);
        if (res.usernameError) { setUserState('taken'); setUserMsg(res.usernameError); }
        return;
      }
      onDone({ token: res.token, account: res.account, boot: res.boot, created: Boolean(res.created) });
    } catch (e) {
      setError(e.message || 'تعذّر التحقق من الرمز');
      if (e.body && e.body.field === 'username') { setUserState('taken'); setUserMsg(e.body.error || 'الاسم محجوز'); }
      const left = e.body && e.body.triesLeft;
      if (typeof left === 'number') setTriesLeft(left);
      setDigits((prev) => { const n = prev.slice(); n[5] = ''; return n; });
      setTimeout(() => boxes.current[5] && boxes.current[5].focus(), 40);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }, [code, phone, name, username, avatar, onDone]);

  // إكمال الرقم يبدأ التحقق تلقائيًا — كسلوك تطبيقات الرمز المعتاد
  useEffect(() => {
    if (step !== 'code') return;
    if (code.length !== 6 || busyRef.current) return;
    const t = setTimeout(() => { if (!busyRef.current) verify(false); }, 220);
    return () => clearTimeout(t);
  }, [code, step, verify]);

  const setDigit = (i, raw) => {
    const d = digitsOnly(raw);
    if (!d) return;
    setError(null);
    setDigits((prev) => { const n = prev.slice(); n[i] = d.slice(-1); return n; });
    if (i < 5) setTimeout(() => boxes.current[i + 1] && boxes.current[i + 1].focus(), 10);
  };

  const onKey = (i, e) => {
    if (e.key === 'Backspace') {
      e.preventDefault();
      setDigits((prev) => {
        const n = prev.slice();
        if (n[i]) n[i] = '';
        else if (i > 0) { n[i - 1] = ''; setTimeout(() => boxes.current[i - 1] && boxes.current[i - 1].focus(), 10); }
        return n;
      });
      return;
    }
    if (e.key === 'ArrowLeft' && i < 5) boxes.current[i + 1] && boxes.current[i + 1].focus();
    if (e.key === 'ArrowRight' && i > 0) boxes.current[i - 1] && boxes.current[i - 1].focus();
  };

  const onPaste = (e) => {
    const t = digitsOnly(e.clipboardData.getData('text'), 6);
    if (!t) return;
    e.preventDefault();
    setDigits(t.padEnd(6, ' ').split('').map((c) => (c === ' ' ? '' : c)));
    setTimeout(() => boxes.current[Math.min(t.length, 5)] && boxes.current[Math.min(t.length, 5)].focus(), 10);
  };

  const fillDemo = () => {
    const d = digitsOnly(info && info.demoCode, 6);
    if (d.length !== 6) return;
    setError(null);
    setDigits(d.split(''));
  };

  const back = () => {
    setError(null);
    if (step === 'code') setStep('phone');
    else if (step === 'profile') setStep('code');
  };

  const idx = STEPS.findIndex((s) => s.key === step);
  const display = (info && info.display) || local;

  return (
    <div className="app auth-screen">
      <div className="auth-card">
        <div className="auth-brand">
          <span className="auth-mark">سوى</span>
          <span className="auth-tag">دائرتك الحقيقية — في مكانها</span>
        </div>

        <ol className="auth-steps">
          {STEPS.map(({ key, label, Icon }, i) => (
            <li key={key} className={`auth-step${i === idx ? ' on' : ''}${i < idx ? ' done' : ''}`}>
              <span className="auth-step-dot">{i < idx ? <Check size={13} strokeWidth={2} /> : <Icon size={14} strokeWidth={1.8} />}</span>
              <span className="auth-step-label">{label}</span>
            </li>
          ))}
        </ol>

        {notice && notice.at && (
          <div className="auth-err auth-kick" role="status">
            <KeyRound size={16} strokeWidth={1.8} />
            <span>
              أُغلقت جلستك السابقة تلقائيًا لأن حسابك دخل من مكان آخر
              {notice.device ? ` (${notice.device})` : ''}. سوى تسمح بجلسة نشطة واحدة في كل مرة — أدخل رقمك للمتابعة.
            </span>
          </div>
        )}

        {error && (
          <div className="auth-err" role="alert">
            <AlertCircle size={16} strokeWidth={1.8} />
            <span>{error}</span>
          </div>
        )}

        {step === 'phone' && (
          <form className="auth-body" onSubmit={(e) => { e.preventDefault(); sendCode(false); }}>
            <h1 className="auth-title">ادخل برقم هاتفك</h1>
            <p className="auth-sub">نرسل رمزًا من ٦ أرقام للتحقّق من الرقم.</p>
            <label className="auth-field">
              <span className="auth-label"><Phone size={14} strokeWidth={1.8} /> رقم الهاتف</span>
              <div className={`auth-phone${phone && !phoneOk ? ' bad' : ''}`}>
                <span className="cc">+968</span>
                <input
                  value={phone}
                  onChange={(e) => { setPhone(e.target.value); setError(null); }}
                  inputMode="numeric"
                  autoComplete="tel"
                  dir="ltr"
                  placeholder="91234567"
                  aria-label="رقم الهاتف"
                />
              </div>
              <span className="auth-count">{local.length}/8</span>
            </label>
            <button className="btn btn-primary btn-block" disabled={busy || !phoneOk}>
              {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <ShieldCheck size={16} strokeWidth={1.8} />}
              {busy ? 'يُرسل الرمز…' : 'أرسل رمز التحقق'}
            </button>
            <div className="auth-demo">
              <KeyRound size={15} strokeWidth={1.8} />
              <span>{(info && info.hint) || 'وضع التجربة: رمز التحقق ثابت 123456'}</span>
            </div>
          </form>
        )}

        {step === 'code' && (
          <div className="auth-body">
            <h1 className="auth-title">أدخل رمز التحقق</h1>
            <p className="auth-sub">
              أرسلناه إلى <b dir="ltr">+968 {display}</b> — صالح ٥ دقائق.
            </p>
            <div className="otp-row" dir="ltr" onPaste={onPaste}>
              {digits.map((d, i) => (
                <input
                  key={i}
                  ref={(el) => { boxes.current[i] = el; }}
                  className={`otp-box${d ? ' on' : ''}`}
                  value={d}
                  onChange={(e) => setDigit(i, e.target.value)}
                  onKeyDown={(e) => onKey(i, e)}
                  inputMode="numeric"
                  maxLength={1}
                  autoComplete="one-time-code"
                  aria-label={`الخانة ${i + 1} من الرمز`}
                />
              ))}
            </div>
            {triesLeft !== null && <p className="auth-count">بقيت {triesLeft} محاولة قبل طلب رمز جديد</p>}
            <button className="btn btn-primary btn-block" disabled={busy || code.length !== 6} onClick={() => verify(false)}>
              {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <ShieldCheck size={16} strokeWidth={1.8} />}
              {busy ? 'يتحقّق…' : 'تحقّق وادخل'}
            </button>
            {info && info.demoCode && (
              <div className="auth-demo">
                <KeyRound size={15} strokeWidth={1.8} />
                <span>رمز التجربة <b dir="ltr">{info.demoCode}</b></span>
                <button className="btn btn-soft sm" onClick={fillDemo}><Check size={14} strokeWidth={2} /> املأ الرمز</button>
              </div>
            )}
            <div className="auth-actions">
              {resendIn > 0 ? (
                <span className="auth-count">إعادة الإرسال بعد {resendIn} ثانية</span>
              ) : (
                <button className="inline-link" disabled={busy} onClick={() => sendCode(true)}>
                  <RefreshCw size={14} strokeWidth={1.8} /> إرسال رمز جديد
                </button>
              )}
              <button className="inline-link" onClick={back}>
                <ArrowLeft size={14} strokeWidth={1.8} /> تغيير الرقم
              </button>
            </div>
          </div>
        )}

        {step === 'profile' && (
          <div className="auth-body">
            <h1 className="auth-title">أنشئ حسابك</h1>
            <p className="auth-sub">
              تأكّد الرقم <b dir="ltr">+968 {display}</b>.
            </p>

            <div className="avatar-pick">
              <button type="button" className="avatar-btn" onClick={pickAvatar} disabled={avatarBusy} aria-label="اختيار صورة العرض">
                {avatar ? (
                  <img src={avatar} alt="" />
                ) : name.trim().length >= 1 ? (
                  <span className="avatar-fallback">{name.trim().slice(0, 2)}</span>
                ) : (
                  <span className="avatar-fallback"><Camera size={20} strokeWidth={1.8} /></span>
                )}
                {avatarBusy && <span className="avatar-loading"><Loader2 className="spin" size={16} strokeWidth={2} /></span>}
              </button>
              <div className="avatar-side">
                <span className="auth-label"><Camera size={14} strokeWidth={1.8} /> صورة العرض</span>
                <div className="avatar-actions">
                  <button type="button" className="btn btn-soft sm" onClick={pickAvatar} disabled={avatarBusy || busy}>
                    {avatar ? 'تغيير الصورة' : 'اختر صورة'}
                  </button>
                  {avatar && (
                    <button type="button" className="inline-link" onClick={() => setAvatar('')} disabled={avatarBusy}>
                      <X size={14} strokeWidth={1.8} /> إزالة
                    </button>
                  )}
                </div>
                <p className="hint small">اختيارية</p>
              </div>
              <input ref={fileRef} type="file" accept="image/*" onChange={onAvatarFile} className="file-sr" tabIndex={-1} />
            </div>

            <label className="auth-field">
              <span className="auth-label"><UserPlus size={14} strokeWidth={1.8} /> الاسم</span>
              <input
                value={name}
                onChange={(e) => { setName(e.target.value); setError(null); }}
                placeholder="مثال: سالم الحارثي"
                maxLength={40}
                autoFocus
              />
            </label>

            <label className="auth-field">
              <span className="auth-label"><AtSign size={14} strokeWidth={1.8} /> اسم المستخدم</span>
              <div className={`auth-phone user${userState === 'taken' || userState === 'bad' ? ' bad' : ''}${userState === 'free' ? ' ok' : ''}`}>
                <span className="cc">@</span>
                <input
                  value={username}
                  onChange={onUser}
                  dir="ltr"
                  inputMode="text"
                  autoCapitalize="none"
                  autoCorrect="off"
                  spellCheck="false"
                  placeholder="sawa4567"
                  aria-label="اسم المستخدم"
                />
                <span className="user-state">
                  {userState === 'checking' && <Loader2 className="spin" size={15} strokeWidth={2} />}
                  {userState === 'free' && <Check size={15} strokeWidth={2} />}
                  {(userState === 'taken' || userState === 'bad') && <AlertCircle size={15} strokeWidth={2} />}
                </span>
              </div>
              <span className={`auth-count${userState === 'free' ? ' ok' : ''}${userState === 'taken' || userState === 'bad' ? ' bad' : ''}`}>
                {userMsg || 'حروف إنجليزية صغيرة وأرقام و _ · بلا رقم هاتف'}
              </span>
            </label>

            <div className="auth-note">
              <AtSign size={15} strokeWidth={1.8} />
              <div>
                من لا يملك رقمك يكتب <b dir="ltr">@{username.trim() || 'yourname'}</b> فيجدك ويبدأ محادثة
                — وهكذا تتواصل مع من تعرف بالاسم فقط، بلا تبادل أرقام.
              </div>
            </div>

            <button
              className="btn btn-primary btn-block"
              disabled={busy || name.trim().length < 2 || userState !== 'free'}
              onClick={() => verify(true)}
            >
              {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <UserPlus size={16} strokeWidth={1.8} />}
              {busy ? 'يُنشئ الحساب…' : 'إنشاء الحساب والدخول'}
            </button>
            <div className="auth-actions">
              <button className="inline-link" onClick={back}>
                <ArrowLeft size={14} strokeWidth={1.8} /> رجوع إلى الرمز
              </button>
            </div>
          </div>
        )}

        <p className="auth-foot">
          <b>أثر</b> يربط الذكرى بالمكان والشخص والوقت.
        </p>
      </div>
    </div>
  );
}

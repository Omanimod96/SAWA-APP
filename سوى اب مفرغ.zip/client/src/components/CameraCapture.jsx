import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  X, Images, RefreshCw, Type, Loader2, Camera, Video,
} from 'lucide-react';
import { ensure, hintFor } from '../permissions.js';
import { CAP_MB } from '../media.js';
import { AR, coverCrop, fitScale } from '../crop.js';

// شاشة التصوير: هي مدخل «إنشاء حالة». تفتح الكاميرا فورًا، وفي يدك ثلاثة:
//   • الدائرة البيضاء في الوسط = التصوير (صورة) أو التسجيل (فيديو) بضغطة واحدة.
//   • المستطيل بجانبها = الاستوديو: صورة أو مقطع من جهازك.
//   • X في الأعلى = خروج ورجوع إلى ما كنت فيه، بلا نشر ولا التزام.
// ملاحظة تقنية مهمة: نافذة الاستوديو تُفتح في سياق الضغطة نفسها (f.click() بلا await
// قبله). أي انتظار قبلها يُلغي «تفعيل المستخدم» في المتصفح فيُسكَت الطلب بلا رسالة —
// وهذا بالضبط ما كان يجعل زر الإنشاء يبدو معطّلًا.
const MAX_REC_SECS = 25;

// نطاق المنصة يرسل Permissions-Policy يحجب الكاميرا والميكروفون والموقع. نسأل المتصفح
// نفسه قبل أن نُتعب المستخدم برسالة خطأ: إن كان محجوبًا ننتقل فورًا إلى كاميرا الجهاز
// (منتقي الملفات مع capture) — وهي الطريقة الوحيدة التي تفتح الكاميرا فعلًا هناك.
export function cameraBlockedByPolicy() {
  try {
    const fp = document.featurePolicy || document.permissionsPolicy;
    if (fp && typeof fp.allowsFeature === 'function' && fp.allowsFeature('camera') === false) return true;
  } catch (e) { /* متصفح لا يعرف الواجهة — نجرّب الطلب العادي */ }
  return false;
}

export default function CameraCapture({ open, kind = 'image', onClose, onMedia, onText }) {
  const [mode, setMode] = useState(kind);
  const [status, setStatus] = useState('asking'); // asking | ready | blocked
  const [note, setNote] = useState('');
  const [facing, setFacing] = useState('environment');
  const [flash, setFlash] = useState(false);
  const [recording, setRecording] = useState(false);
  const [secs, setSecs] = useState(0);

  const videoRef = useRef(null);
  const capRef = useRef(null); // كاميرا الجهاز (capture) — بديل يعمل على كل الأجهزة
  const fileRef = useRef(null);
  const streamRef = useRef(null);
  const recRef = useRef(null);
  const painterRef = useRef(null); // مؤقّت رسم لوحة المقطع ٩:١٦
  const chunksRef = useRef([]);
  const timerRef = useRef(null);
  const modeRef = useRef(kind);
  const statusRef = useRef('asking');
  const aliveRef = useRef(false);
  const askRef = useRef(null); // طلب الإذن الجاري — يُلغى لحظة الخروج

  // إلغاء الطلب: بلا هذا تبقى ورقة الإذن معلّقة فوق التطبيق بعد إغلاق الشاشة،
  // فيبدو زر «+» معطّلًا ولا يعمل حتى تُجاب الورقة.
  const cancelAsk = () => {
    const ac = askRef.current;
    askRef.current = null;
    if (ac) { try { ac.abort(); } catch (e) { /* تجاهل */ } }
  };
  const askSignal = () => {
    cancelAsk();
    const ac = new AbortController();
    askRef.current = ac;
    return ac.signal;
  };

  const setStatusBoth = (v) => { statusRef.current = v; setStatus(v); };
  // اللوحة الطولية: نرسم إطار الكاميرا فيها بنسبة ٩:١٦ ونُرسل مسارها المرئي مع صوت
  // الكاميرا، فيخرج المقطع بالإطار نفسه لا مربّعًا. وإن لم يدعم المتصفح
  // captureStream نرجع null فيُسجَّل البثّ كما هو — لا نُعطّل التسجيل أبدًا.
  const stopPainter = () => {
    if (painterRef.current) { clearInterval(painterRef.current); painterRef.current = null; }
  };
  const paintStream = () => {
    stopPainter();
    try {
      const v = videoRef.current;
      const stream = streamRef.current;
      const cv = document.createElement('canvas');
      if (!v || !stream || typeof cv.captureStream !== 'function') return null;
      cv.width = 1080;
      cv.height = 1920;
      const g = cv.getContext('2d');
      if (!g) return null;
      const draw = () => {
        if (!v.videoWidth) return;
        const { sx, sy, sw, sh } = coverCrop(v.videoWidth, v.videoHeight);
        try { g.drawImage(v, sx, sy, sw, sh, 0, 0, cv.width, cv.height); } catch (e) { /* إطار قيد الجهوزية */ }
      };
      draw();
      painterRef.current = window.setInterval(draw, 40); // ٢٥ إطارًا في الثانية
      const out = cv.captureStream(25);
      return new MediaStream([...out.getVideoTracks(), ...stream.getAudioTracks()]);
    } catch (e) {
      stopPainter();
      return null;
    }
  };
  const stopStream = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
    stopPainter();
    if (recRef.current && recRef.current.state === 'recording') { try { recRef.current.stop(); } catch (e) { /* تجاهل */ } }
    recRef.current = null;
    const s = streamRef.current;
    streamRef.current = null;
    if (s) s.getTracks().forEach((t) => { try { t.stop(); } catch (e) { /* تجاهل */ } });
    const v = videoRef.current;
    if (v) { try { v.srcObject = null; } catch (e) { /* تجاهل */ } }
  };

  // تشغيل الكاميرا: إذن واحد ظاهر، ثم تيار حقيقي. وإن رفض الجهاز facingMode
  // نرجع إلى أي كاميرا متاحة بدل أن نقف عند خطأ تقني.
  const run = async (face, want) => {
    stopStream();
    setStatusBoth('asking');
    setNote('');
    setRecording(false);
    setSecs(0);
    if (cameraBlockedByPolicy()) {
      setStatusBoth('device'); // حجب من المنصة: نمضي بكاميرا الجهاز مباشرة
      setNote('');
      return;
    }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStatusBoth('device');
      setNote('');
      return;
    }
    const perm = await ensure('camera', {
      force: true,
      signal: askSignal(),
      reason: want === 'video' ? 'لتصوير مقطع لحالتك' : 'لتصوير صورة لحالتك',
    });
    if (!aliveRef.current) return;
    if (!perm.ok) {
      if (perm.reason === 'canceled') return; // أُغلق الطلب بإغلاق الشاشة — بلا رسالة
      setStatusBoth('blocked');
      setNote(hintFor(perm) || 'لم نصل إلى الكاميرا الآن.');
      return;
    }
    const withAudio = want === 'video';
    // الطلب الأول طولي ٩:١٦ (1080×1920) — كان 1280×1280 فتُحفظ الصورة مربّعة
    // ١:١ وهي لا تشبه شيئًا في التطبيق. والقصّ عند التصوير يضمن النسبة على كل جهاز.
    const tries = [
      { video: { facingMode: { ideal: face }, aspectRatio: { ideal: AR }, width: { ideal: 1080 }, height: { ideal: 1920 } }, audio: withAudio },
      { video: { facingMode: { ideal: face }, aspectRatio: { ideal: AR } }, audio: withAudio },
      { video: { facingMode: face }, audio: withAudio },
      { video: true, audio: withAudio },
      { video: true, audio: false },
    ];
    let stream = null;
    let last = null;
    for (const c of tries) {
      try { stream = await navigator.mediaDevices.getUserMedia(c); break; } catch (e) { last = e; }
      if (!aliveRef.current) return;
    }
    if (!stream) {
      const msg = String((last && last.message) || '');
      const policyHit = /permissions? policy|disallowed by permissions/i.test(msg);
      const denied = last && (last.name === 'NotAllowedError' || last.name === 'SecurityError');
      if (policyHit) { setStatusBoth('device'); setNote(''); return; }
      setStatusBoth('blocked');
      setNote(denied
        ? 'المتصفح منع الكاميرا لهذا الموقع — اسمح بها من رمز القفل في العنوان ثم أعد المحاولة.'
        : 'تعذّر تشغيل الكاميرا الآن — جرّب مرة أخرى، أو اختر من الاستوديو.');
      return;
    }
    aliveRef.current = true;
    streamRef.current = stream;
    const track = stream.getVideoTracks()[0];
    if (track) track.onended = () => { if (aliveRef.current) { setStatusBoth('blocked'); setNote('توقفت الكاميرا — اضغط «أعد المحاولة».'); } };
    // كاميرا تصرّ على إطار عريض وتتجاهل الطلب؟ نُعيد الطلب مرة واحدة بالنسبة الطولية
    // قبل الرسم على الشاشة، وإن رفضت فالقصّ عند التصوير يضمن ٩:١٦ على أي حال.
    const st = (track && track.getSettings && track.getSettings()) || {};
    const ratio = st.width && st.height ? st.width / st.height : (st.aspectRatio || 0);
    if (track && ratio > 1) {
      try { await track.applyConstraints({ aspectRatio: { ideal: AR } }); } catch (e) { /* القصّ يكفي */ }
      if (!aliveRef.current) return;
    }
    const v = videoRef.current;
    if (v) {
      v.srcObject = stream;
      try { await v.play(); } catch (e) { /* المتصفح يشغّلها تلقائيًا */ }
    }
    setStatusBoth('ready');
  };

  // دورة الحياة: فتح ⇒ كاميرا · إغلاق ⇒ إطفاء فوري للكاميرا (لا نتركها تعمل خلف الشاشة)
  useEffect(() => {
    if (!open) return undefined;
    aliveRef.current = true;
    modeRef.current = kind;
    setMode(kind);
    run(facing, kind);
    document.body.classList.add('cam-open');
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => {
      aliveRef.current = false;
      cancelAsk();
      window.removeEventListener('keydown', onKey);
      document.body.classList.remove('cam-open');
      stopStream();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const close = () => { cancelAsk(); stopStream(); onClose(); };

  const flip = () => {
    const next = facing === 'environment' ? 'user' : 'environment';
    setFacing(next);
    run(next, modeRef.current);
  };

  const switchMode = (m) => {
    modeRef.current = m;
    setMode(m);
    if (m !== kind) run(facing, m); // الفيديو يحتاج الصوت أيضًا ⇒ تيار جديد
  };

  // الصورة: إطار واحد من المعاينة نفسها (ما تراه هو ما تُنشره) — مقصوصًا ٩:١٦
  // قصًّا مركزيًا: لقطة الجهاز قد تصل مربّعة أو عريضة، والمحفوظ يبقى طوليًا كالإطار.
  const shoot = () => {
    const v = videoRef.current;
    if (!v || !v.videoWidth) { setNote('الكاميرا لم تجهز بعد — لحظة واحدة.'); return; }
    const { sx, sy, sw, sh } = coverCrop(v.videoWidth, v.videoHeight);
    const out = fitScale(sw, sh, 1440);
    const c = document.createElement('canvas');
    c.width = out.width;
    c.height = out.height;
    const g = c.getContext('2d');
    if (!g) { setNote('تعذّر تجهيز الصورة على هذا المتصفح — اختر من الاستوديو.'); return; }
    g.drawImage(v, sx, sy, sw, sh, 0, 0, c.width, c.height);
    setFlash(true);
    window.setTimeout(() => setFlash(false), 240);
    c.toBlob((blob) => {
      if (!blob) { setNote('تعذّر تجهيز الصورة — جرّب مرة أخرى.'); return; }
      onMedia(new File([blob], `sawa-${Date.now()}.jpg`, { type: 'image/jpeg' }));
    }, 'image/jpeg', 0.9);
  };

  // الفيديو: تسجيل من الكاميرا نفسها، بسقف زمني واضح يحمي من ملف ثقيل
  const startRec = () => {
    const stream = streamRef.current;
    if (!stream || !window.MediaRecorder) {
      setNote('التسجيل من الكاميرا غير مدعوم هنا — اختر مقطعًا من الاستوديو.');
      return;
    }
    try {
      const cand = ['video/webm;codecs=vp8,opus', 'video/webm', 'video/mp4'];
      const mimeType = cand.find((t) => window.MediaRecorder.isTypeSupported && window.MediaRecorder.isTypeSupported(t)) || '';
      const src = paintStream() || stream; // المسار المُسجَّل: لوحة ٩:١٦ أو البثّ كما هو
      const rec = new MediaRecorder(src, mimeType ? { mimeType } : undefined);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data && e.data.size) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        stopPainter();
        if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
        setRecording(false);
        setSecs(0);
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || 'video/webm' });
        if (!blob.size) { setNote('لم يُسجَّل مقطع — جرّب مرة أخرى.'); return; }
        if (blob.size > CAP_MB.video * 1024 * 1024) { setNote(`المقطع أطول من ${CAP_MB.video} ميجابايت — اجعله أقصر.`); return; }
        const ext = /mp4/.test(rec.mimeType || '') ? 'mp4' : 'webm';
        onMedia(new File([blob], `sawa-${Date.now()}.${ext}`, { type: rec.mimeType || 'video/webm' }));
      };
      rec.start(250);
      recRef.current = rec;
      setRecording(true);
      setSecs(0);
      timerRef.current = window.setInterval(() => {
        setSecs((s) => {
          if (s + 1 >= MAX_REC_SECS) stopRec();
          return s + 1;
        });
      }, 1000);
    } catch (e) {
      setNote('تعذّر بدء التسجيل — جرّب مرة أخرى أو اختر مقطعًا من الاستوديو.');
    }
  };

  const stopRec = () => {
    if (recRef.current && recRef.current.state === 'recording') { try { recRef.current.stop(); } catch (e) { /* تجاهل */ } }
  };

  const shutter = () => {
    if (modeRef.current === 'video') { if (recording) stopRec(); else startRec(); return; }
    shoot();
  };

  // الزر الأبيض: مع بثّ حيّ يلتقط/يسجّل، ومع حجب السياسة يفتح كاميرا الجهاز
  const onShutter = () => {
    if (statusRef.current === 'device') { openDeviceCam(); return; }
    shutter();
  };

  // الاستوديو: تُفتح نافذة الجهاز في هذه الضغطة نفسها. accept يقبل الصورة والمقطع معًا
  // لأن صاحب الحالة قد يغيّر رأيه في اللحظة الأخيرة.
  const openStudio = () => {
    const f = fileRef.current;
    if (!f) return;
    try { f.value = ''; } catch (e) { /* تجاهل */ }
    f.setAttribute('accept', 'image/*,video/*');
    f.click();
  };

  // كاميرا الجهاز: نفس قاعدتنا — f.click() في الضغطة نفسها، بلا انتظار قبلها
  const openDeviceCam = (mode2) => {
    const f = capRef.current;
    if (!f) return;
    const m = mode2 || modeRef.current;
    try { f.value = ''; } catch (e) { /* تجاهل */ }
    f.setAttribute('accept', m === 'video' ? 'video/*' : 'image/*');
    f.setAttribute('capture', m === 'video' ? 'camcorder' : 'environment');
    f.click();
  };

  const onPicked = (file) => {
    if (!file) return;
    const kindOf = String(file.type || '').startsWith('video/') ? 'فيديو' : String(file.type || '').startsWith('image/') ? 'صورة' : '';
    if (!kindOf) { setNote('هذا الملف ليس صورة ولا مقطعًا — اختر غيره.'); return; }
    onMedia(file);
  };

  if (!open) return null;
  const ready = status === 'ready';
  const device = status === 'device'; // الكاميرا الحيّة محجوبة ⇒ كاميرا الجهاز مباشرة
  const armed = ready || device;
  const retry = () => run(facing, modeRef.current);

  return createPortal(
    <div className="cam" role="dialog" aria-modal="true" aria-label="تصوير حالة">
      {/* مسرح الكاميرا: صندوق ٩:١٦ في الوسط — ما تراه هو ما يُنشر بالضبط.
          قبله كانت الكاميرا تملأ الشاشة بحسب مقاس النافذة، فتصل اللقطة مربّعة
          بينما المعاينة مقصوصة، فيرى المستخدم شيئًا ويُنشر غيره. */}
      <div className="cam-stage">
        <div className="cam-box">
          <video
            ref={videoRef}
            className={`cam-video${device ? ' hide' : ''}${facing === 'user' ? ' mirror' : ''}`}
            playsInline
            muted
            autoPlay
          />
          {!device && <i className="cam-ar" aria-hidden="true">٩:١٦</i>}
        </div>
      </div>
      <span className="cam-shade" aria-hidden="true" />

      <div className="cam-top">
        <button className="cam-icon" onClick={close} aria-label="رجوع وخروج" title="رجوع">
          <X size={20} strokeWidth={2} />
        </button>
        {onText && (
          <button className="cam-word" onClick={() => { cancelAsk(); stopStream(); onText(); }} title="اكتب حالة نصية">
            <Type size={14} strokeWidth={1.8} /> حالة نصية
          </button>
        )}
      </div>

      {status === 'asking' && (
        <div className="cam-mid">
          <Loader2 className="spin" size={26} strokeWidth={2} />
          <p>نجهّز الكاميرا…</p>
        </div>
      )}

      {device && (
        <div className="cam-mid">
          <div className="cam-note">
            <span className="cam-block-icon"><Camera size={20} strokeWidth={1.8} /></span>
            <strong>صور بضغطة واحدة</strong>
            <p>الدائرة للتصوير · والمستطيل للاستوديو.</p>
          </div>
        </div>
      )}

      {status === 'blocked' && (
        <div className="cam-mid">
          <div className="cam-block">
            <span className="cam-block-icon"><Camera size={22} strokeWidth={1.8} /></span>
            <strong>لم تُفتح الكاميرا</strong>
            <p>{note || 'يمكنك اختيار صورة أو مقطع من الاستوديو.'}</p>
            <div className="row2">
              <button className="btn" onClick={() => run(facing, modeRef.current)}>
                <RefreshCw size={15} strokeWidth={1.8} /> أعد المحاولة
              </button>
              <button className="btn ghost" onClick={openStudio}>
                <Images size={15} strokeWidth={1.8} /> من الاستوديو
              </button>
            </div>
            {onText && (
              <button className="cam-link" onClick={() => { cancelAsk(); stopStream(); onText(); }}>أو اكتب حالة نصية</button>
            )}
          </div>
        </div>
      )}

      <div className={`cam-bottom${armed ? '' : ' dim'}`}>
        <div className="cam-modes" role="tablist" aria-label="نوع الالتقاط">
          <button
            role="tab"
            aria-selected={mode === 'image'}
            className={`cam-chip${mode === 'image' ? ' on' : ''}`}
            onClick={() => switchMode('image')}
            disabled={!armed}
          >
            <Camera size={13} strokeWidth={1.8} /> صورة
          </button>
          <button
            role="tab"
            aria-selected={mode === 'video'}
            className={`cam-chip${mode === 'video' ? ' on' : ''}`}
            onClick={() => switchMode('video')}
            disabled={!armed}
          >
            <Video size={13} strokeWidth={1.8} /> فيديو
          </button>
        </div>

        <div className="cam-controls">
          {/* المستطيل: الاستوديو — صورة أو مقطع من الجهاز */}
          <button className="cam-studio" onClick={openStudio} aria-label="من الاستوديو: صورة أو مقطع" title="من الاستوديو">
            <Images size={22} strokeWidth={1.8} />
          </button>

          {/* الدائرة البيضاء: التصوير / التسجيل */}
          <button
            className={`cam-shutter${recording ? ' rec' : ''}${device ? ' device' : ''}`}
            onClick={onShutter}
            disabled={!armed}
            aria-label={device
              ? 'افتح كاميرا الجهاز'
              : mode === 'video' ? (recording ? 'أوقف التسجيل' : 'ابدأ التسجيل') : 'التقط صورة'}
          >
            {device ? <Camera className="cam-dev-icon" size={26} strokeWidth={1.8} /> : <span className="cam-lens" />}
          </button>

          <button
            className="cam-flip"
            onClick={device ? retry : flip}
            aria-label={device ? 'جرّب المعاينة الحيّة مرة أخرى' : 'بدّل الكاميرا'}
            title={device ? 'جرّب المعاينة الحيّة مرة أخرى' : 'بدّل الكاميرا'}
          >
            <RefreshCw size={19} strokeWidth={1.8} />
          </button>
        </div>

        <p className="cam-hint">
          {device
            ? (mode === 'video'
              ? 'الدائرة للتسجيل · والمستطيل للاستوديو'
              : 'الدائرة للتصوير · والمستطيل للاستوديو')
            : recording
              ? <>جارٍ التسجيل <b>{secs} ث</b></>
              : mode === 'video' ? 'اضغط الدائرة للتسجيل' : (note || 'اضغط الدائرة للتصوير')}
        </p>
      </div>

      {flash && <span className="cam-flash" aria-hidden="true" />}
      <input
        ref={fileRef}
        type="file"
        className="hidden-input"
        onChange={(e) => onPicked(e.target.files && e.target.files[0])}
      />
      <input
        ref={capRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden-input"
        onChange={(e) => onPicked(e.target.files && e.target.files[0])}
      />
    </div>,
    document.body,
  );
}

import React, { useEffect, useRef, useState } from 'react';
import { DoorOpen, Users, Clock, MessageCircle, ArrowRight, Send, CheckCheck, Loader2, Lock } from 'lucide-react';
import Avatar from './Avatar.jsx';
import { formatLeft } from '../useToast.js';
import { dayLabel, timeOf } from './roomUtils.js';

// دردشة الغرفة: تُفتح فوق نافذة الحالات، وتعود إلى الغرف بزر الرجوع.
export default function RoomChat({ room, actions, busy, onClose }) {
  const [draft, setDraft] = useState('');
  const endRef = useRef(null);
  const messages = room.messages || [];
  const closed = room.status !== 'open';
  const others = (room.roster || []).filter((p) => p.id !== 'u-me');
  const readKey = useRef(null);

  // تعليم رسائل الغرفة كمقروءة عند فتحها أو عند وصول رسالة جديدة
  const key = `${room.id}:${room.unread}`;
  useEffect(() => {
    if (room.unread > 0 && readKey.current !== key) {
      readKey.current = key;
      actions.readRoom(room.id);
    }
  }, [key, room.id, room.unread, actions]);

  // تحديث دوري أثناء فتح الدردشة حتى تظهر رسائل بقية الأعضاء
  useEffect(() => {
    const t = setInterval(() => { if (!document.hidden) actions.refresh(); }, 6000);
    return () => clearInterval(t);
  }, [actions]);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
  }, [messages.length, room.id]);

  const send = async () => {
    const text = draft.trim();
    if (!text || busy || closed) return;
    setDraft('');
    const done = await actions.sendRoomMessage(room.id, text);
    if (!done) setDraft(text);
  };

  return (
    <div className="view chat-view">
      <div className="chat-head">
        <button className="iconbtn" onClick={onClose} aria-label="رجوع إلى الغرف">
          <ArrowRight size={18} strokeWidth={1.8} />
        </button>
        <div className="room-icon"><DoorOpen size={17} strokeWidth={1.8} /></div>
        <div className="grow">
          <div className="pname">{room.title}</div>
          <div className="meta">
            <span>{closed ? 'غرفة مغلقة' : 'مفتوحة الآن'}</span>
            <span className="sep">·</span>
            <Users size={12} strokeWidth={1.8} />
            <span>{room.members.length} من {room.capacity} داخل الغرفة</span>
          </div>
        </div>
        <span className="timer">
          <Clock size={13} strokeWidth={1.8} />
          {closed ? 'انتهت' : formatLeft(room.msLeft)}
        </span>
      </div>

      <div className="room-notice">
        <MessageCircle size={15} strokeWidth={1.8} />
        <div>
          دردشة جماعية للغرفة — كل من دخلها ({room.members.length}) يرى الرسائل، ومنهم {others.length} من دائرتك.
        </div>
      </div>

      <div className="chat-body">
        {messages.length === 0 && (
          <div className="empty">
            <div className="circle"><MessageCircle size={22} strokeWidth={1.8} /></div>
            <strong>لا رسائل بعد</strong>
          </div>
        )}
        {messages.map((m, i) => {
          const prev = messages[i - 1];
          const showDay = !prev || dayLabel(prev.at) !== dayLabel(m.at);
          if (m.from === 'sys') {
            return (
              <React.Fragment key={m.id || i}>
                {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
                <div className="sysnote">{m.text}</div>
              </React.Fragment>
            );
          }
          const mine = m.from === 'u-me';
          const sender = (room.roster || []).find((p) => p.id === m.from);
          return (
            <React.Fragment key={m.id || i}>
              {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
              <div className={`bubble-row${mine ? ' mine' : ''}`}>
                {!mine && <Avatar name={sender ? sender.name : 'عضو'} color={sender ? sender.color : '#94A3B8'} photo={sender && sender.avatar} size="sm" />}
                <div className={`bubble${mine ? ' mine' : ''}`}>
                  {!mine && <span className="bubble-name">{sender ? sender.name.split(' ')[0] : 'عضو'}</span>}
                  <span>{m.text}</span>
                  <span className="b-time">
                    {timeOf(m.at)}
                    {mine && <CheckCheck size={13} strokeWidth={2} />}
                  </span>
                </div>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={endRef} />
      </div>

      {closed ? (
        <div className="closed-note">
          <Lock size={15} strokeWidth={1.8} /> أُقفلت الغرفة — الدردشة محفوظة للقراءة فقط.
        </div>
      ) : (
        <div className="chat-bar">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
            placeholder={`اكتب رسالة إلى غرفة «${room.title}»…`}
            aria-label="نص رسالة الغرفة"
          />
          <button className="send-btn" onClick={send} disabled={busy || !draft.trim()} aria-label="إرسال">
            {busy ? <Loader2 className="spin" size={18} strokeWidth={2} /> : <Send size={18} strokeWidth={1.8} />}
          </button>
        </div>
      )}
    </div>
  );
}

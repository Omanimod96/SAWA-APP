import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  DoorOpen, Lock, Plus, Users, MapPin, Hourglass, Archive, CheckCircle2, Loader2, NotebookPen,
  Clock, MessageCircle, Crown, Sparkles, Map as MapIcon,
} from 'lucide-react';
import Avatar, { AvatarRow } from './Avatar.jsx';
import { formatLeft } from '../useToast.js';
import { useTick, senderName, listStamp } from './roomUtils.js';

const ATHAR_PREVIEW = 3; // آثار الغرف: آخر ثلاث ظاهرة، والباقي بضغطة — نافذة الهاتف أضيق

function CreateRoom({ onCreate, busy }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: '', place: '', capacity: '8', hours: '6', kind: 'نشاط' });

  const submit = async () => {
    if (!form.title.trim()) return;
    const done = await onCreate({ ...form, capacity: Number(form.capacity), hours: Number(form.hours) });
    if (done) { setForm({ title: '', place: '', capacity: '8', hours: '6', kind: 'نشاط' }); setOpen(false); }
  };

  if (!open) {
    return (
      <button className="composer-trigger" onClick={() => setOpen(true)}>
        <Plus size={18} strokeWidth={2} />
        <span>افتح غرفة مؤقتة</span>
        <Hourglass size={16} strokeWidth={1.8} />
      </button>
    );
  }

  return (
    <div className="card composer">
      <div className="field">
        <span>اسم الغرفة</span>
        <input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="جلسة القرم" />
      </div>
      <div className="row2">
        <label className="field">
          <span>المكان</span>
          <input value={form.place} onChange={(e) => setForm({ ...form, place: e.target.value })} placeholder="كورنيش القرم" />
        </label>
        <label className="field">
          <span>النوع</span>
          <select value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            <option>نشاط</option>
            <option>مناسبة</option>
            <option>مساعدة</option>
            <option>درس</option>
          </select>
        </label>
      </div>
      <div className="row2">
        <label className="field">
          <span>السعة</span>
          <select value={form.capacity} onChange={(e) => setForm({ ...form, capacity: e.target.value })}>
            {[4, 6, 8, 12, 20].map((n) => <option key={n} value={n}>{n} أشخاص</option>)}
          </select>
        </label>
        <label className="field">
          <span>تُقفل بعد</span>
          <select value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })}>
            {[2, 4, 6, 12, 24].map((n) => <option key={n} value={n}>{n} ساعات</option>)}
          </select>
        </label>
      </div>
      <div className="actions">
        <button className="btn ghost" onClick={() => setOpen(false)}>إلغاء</button>
        <button className="btn" onClick={submit} disabled={busy || !form.title.trim()}>
          {busy ? <Loader2 className="spin" size={16} strokeWidth={2} /> : <DoorOpen size={16} strokeWidth={1.8} />}
          افتح الغرفة
        </button>
      </div>
    </div>
  );
}

function RoomCard({ room, actions, busy, onOpenChat, variant, flash }) {
  const [noteOpen, setNoteOpen] = useState(false);
  const [note, setNote] = useState('');
  const full = room.members.length >= room.capacity;
  const closingSoon = room.msLeft < 60 * 60 * 1000;
  const isNew = variant === 'new';

  const addNote = async () => {
    if (!note.trim()) return;
    const done = await actions.addMemory(room.id, note);
    if (done) { setNote(''); setNoteOpen(false); }
  };

  return (
    <article className={`card room${closingSoon ? ' urgent' : ''}${isNew ? ' discover' : ''}${flash ? ' flash' : ''}`}>
      <header className="room-head">
        <div className={`room-icon${isNew ? ' muted' : ''}`}>
          {room.mine ? <Crown size={18} strokeWidth={1.8} /> : <DoorOpen size={18} strokeWidth={1.8} />}
        </div>
        <div className="grow">
          <div className="pname">{room.title}</div>
          <div className="meta">
            {isNew ? (
              <span>بإدارة {senderName(room, room.owner)}</span>
            ) : (
              <>
                <span className={`room-tag${room.mine ? ' mine' : ''}`}>{room.mine ? 'أنشأتها' : 'منضم إليها'}</span>
                <span className="sep">·</span>
                <span>{room.kind}</span>
              </>
            )}
            {room.place && (
              <>
                <span className="sep">·</span>
                <MapPin size={12} strokeWidth={1.8} />
                <span>{room.place}</span>
              </>
            )}
          </div>
        </div>
        <span className="timer">
          <Clock size={13} strokeWidth={1.8} />
          {formatLeft(room.msLeft)}
        </span>
      </header>

      <div className="room-body">
        <div className="members">
          <AvatarRow members={room.members} people={room.roster} max={6} />
          <span className="mcount">{room.members.length} / {room.capacity}</span>
        </div>
        <div className="bar"><i style={{ width: `${Math.min(100, room.fill)}%` }} /></div>
      </div>

      {room.agenda && room.agenda.length > 0 && (
        <ul className="agenda">
          {room.agenda.map((a, i) => (
            <li key={i}><CheckCircle2 size={14} strokeWidth={1.8} /> {a}</li>
          ))}
        </ul>
      )}

      <div className="actions">
        {room.joined ? (
          <button className="btn sm chat-cta" disabled={busy} onClick={() => onOpenChat(room.id)}>
            <MessageCircle size={15} strokeWidth={1.8} />
            دردشة الغرفة
            {room.unread > 0 && <span className="t-count">{room.unread}</span>}
          </button>
        ) : (
          <button className="btn sm" disabled={busy || full} onClick={() => actions.joinRoom(room.id)}>
            <Users size={15} strokeWidth={1.8} />
            {full ? 'ممتلئة' : 'انضم للدردشة'}
          </button>
        )}
        {room.joined && room.status === 'open' && (
          <button className="btn sm ghost" disabled={busy} onClick={() => setNoteOpen((v) => !v)}>
            <NotebookPen size={15} strokeWidth={1.8} /> أثر
          </button>
        )}
        {room.mine && room.status === 'open' && (
          <button className="btn sm danger" disabled={busy} onClick={() => actions.closeRoom(room.id)}>
            <Lock size={15} strokeWidth={1.8} /> اقفل
          </button>
        )}
      </div>

      {noteOpen && (
        <div className="whisper">
          <input
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="خلاصة سريعة تُحفظ في أثر…"
            onKeyDown={(e) => { if (e.key === 'Enter') addNote(); }}
          />
          <button className="btn sm" onClick={addNote} disabled={busy || !note.trim()}>حفظ</button>
        </div>
      )}

      {room.memories && room.memories.length > 0 && (
        <ul className="memory">
          {room.memories.slice(-3).map((m, i) => (
            <li key={i}><span className="dotm" />{m.text}</li>
          ))}
        </ul>
      )}

      {room.last && (
        <div className="room-last">
          <MessageCircle size={13} strokeWidth={1.8} />
          <span className="who">{senderName(room, room.last.from)}:</span>
          <span className="txt">{room.last.text}</span>
          <span className="t-time">{listStamp(room.last.at)}</span>
        </div>
      )}
    </article>
  );
}

// غرفة أُقفلت: لم تعد دردشة، صارت أثرًا — مكان وزمان وخلاصات محفوظة
function AtharRoomCard({ room, onOpenChat }) {
  const memories = room.memories || [];
  return (
    <article className="card archive">
      <header className="room-head">
        <div className="room-icon muted"><Archive size={17} strokeWidth={1.8} /></div>
        <div className="grow">
          <div className="pname">{room.title}</div>
          <div className="meta">
            <span>{room.place || 'مكان غير محدد'}</span>
            <span className="sep">·</span>
            <span>حضر {room.members.length} من {room.capacity}</span>
            <span className="sep">·</span>
            <span>{room.messageCount} رسالة</span>
          </div>
        </div>
        {room.closesAt && <span className="t-time">{listStamp(room.closesAt)}</span>}
      </header>
      <ul className="memory">
        {memories.slice(-3).map((m, i) => (
          <li key={i}><span className="dotm" />{m.text}</li>
        ))}
        {memories.length === 0 && (
          <li><span className="dotm" />أُقفلت الغرفة دون خلاصات مكتوبة.</li>
        )}
      </ul>
      <div className="actions">
        <button className="btn sm ghost" onClick={() => onOpenChat(room.id)}>
          <MessageCircle size={15} strokeWidth={1.8} /> قراءة دردشة الغرفة
        </button>
      </div>
    </article>
  );
}

function SectionHead({ title, count, hint, icon: Icon }) {
  return (
    <div className="section-head rooms-sec">
      <div>
        <h3>{Icon && <Icon size={15} strokeWidth={1.9} />}{title}</h3>
        {hint && <p className="sec-hint">{hint}</p>}
      </div>
      <span className="pill-count">{count}</span>
    </div>
  );
}

function EmptyRow({ Icon, text }) {
  return (
    <div className="empty small">
      <div className="circle"><Icon size={20} strokeWidth={1.8} /></div>
      <strong>{text}</strong>
    </div>
  );
}

export default function RoomsPanel({ data, actions, busy, flashId, onOpenChat, onGoAthar }) {
  useTick(1000);
  const [showAllAthar, setShowAllAthar] = useState(false);
  const wrapRef = useRef({});
  const rooms = data.rooms || [];

  // المجموعات الثلاث كما طُلب: جديدة · انضممت إليها · صارت أثرًا
  const fresh = useMemo(() => rooms.filter((r) => r.status === 'open' && !r.joined), [rooms]);
  const inside = useMemo(() => {
    const list = rooms.filter((r) => r.status === 'open' && r.joined);
    // ما أنشأته أولًا، ثم الأقرب انتهاءً — الأهم أعلى القائمة
    return list.sort((a, b) => (a.mine === b.mine ? a.msLeft - b.msLeft : a.mine ? -1 : 1));
  }, [rooms]);
  const athar = useMemo(
    () => rooms
      .filter((r) => r.status !== 'open' && r.joined)
      .sort((a, b) => Date.parse(b.closesAt || 0) - Date.parse(a.closesAt || 0)),
    [rooms]
  );

  // غرفة طُلبت من بطاقة حالة أو قصة ولم أكن داخلها: نبرز مكانها وننزلق إليها.
  // القرار في النافذة (RoomsSheet) لأن هذه اللوحة تُفكَّك عند فتح الدردشة.
  useEffect(() => {
    if (!flashId) return undefined;
    const go = setTimeout(() => {
      const el = wrapRef.current[flashId];
      if (el && el.scrollIntoView) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }, 90);
    return () => clearTimeout(go);
  }, [flashId, rooms]);

  const shownAthar = showAllAthar ? athar : athar.slice(0, ATHAR_PREVIEW);
  const card = (r, variant, i) => (
    <div
      key={r.id}
      ref={(el) => { wrapRef.current[r.id] = el; }}
      className={`fade-up d${(i % 3) + 1}`}
    >
      <RoomCard
        room={r}
        actions={actions}
        busy={busy}
        onOpenChat={onOpenChat}
        variant={variant}
        flash={flashId === r.id}
      />
    </div>
  );

  return (
    <div className="rooms-panel">
      <CreateRoom onCreate={actions.createRoom} busy={busy} />

      <section id="rooms-new" className="rooms-group g-new">
        <SectionHead title="غرف جديدة" count={fresh.length} icon={Sparkles} hint="مفتوحة الآن ولم تنضم إليها بعد" />
        {fresh.length === 0
          ? <EmptyRow Icon={Sparkles} text="لا غرف جديدة الآن" />
          : fresh.map((r, i) => card(r, 'new', i))}
      </section>

      <section id="rooms-inside" className="rooms-group g-inside">
        <SectionHead title="غرف انضممت إليها" count={inside.length} icon={Users} hint="مفتوحة وأنت داخلها — تتحدّث وتنتهي مع الوقت" />
        {inside.length === 0
          ? <EmptyRow Icon={Users} text="لست داخل غرفة الآن" />
          : inside.map((r, i) => card(r, 'inside', i))}
      </section>

      <section id="rooms-athar" className="rooms-group g-athar">
      <SectionHead title="صارت أثرًا" count={athar.length} icon={Archive} hint="أُقفلت غرفها فبقيت خلاصاتها هنا" />
      {athar.length === 0 ? (
        <p className="muted-note">لا شيء في أثر بعد.</p>
      ) : (
        <>
          {shownAthar.map((r) => (
            <div key={r.id} className="fade-up d1"><AtharRoomCard room={r} onOpenChat={onOpenChat} /></div>
          ))}
          {athar.length > ATHAR_PREVIEW && (
            <button className="ghost-btn wide" onClick={() => setShowAllAthar((v) => !v)}>
              {showAllAthar ? 'اختصار الآثار' : `عرض باقي الآثار (${athar.length - ATHAR_PREVIEW})`}
            </button>
          )}
          {onGoAthar && (
            <button className="ghost-btn wide athar-link" onClick={onGoAthar}>
              <MapIcon size={14} strokeWidth={1.9} /> افتح خريطة أثر
            </button>
          )}
        </>
      )}
      </section>
    </div>
  );
}

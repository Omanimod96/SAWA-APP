import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowRight, Send, Loader2, ThumbsUp, ThumbsDown, HelpCircle, VenetianMask,
  BadgeCheck, Lock, Sparkles, ShieldOff, Trash2,
} from 'lucide-react';
import Avatar from './Avatar.jsx';

const timeOf = (iso) => {
  try { return new Date(iso).toLocaleTimeString('ar-OM', { hour: '2-digit', minute: '2-digit' }); }
  catch (e) { return ''; }
};

function dayLabel(iso) {
  const d = new Date(iso);
  const same = (a, b) => a.toDateString() === b.toDateString();
  if (same(d, new Date())) return 'اليوم';
  if (same(d, new Date(Date.now() - 864e5))) return 'أمس';
  try { return d.toLocaleDateString('ar-OM', { day: 'numeric', month: 'long' }); }
  catch (e) { return ''; }
}

// قناع بلا اسم: للمستخدم أن يعرف القرب لا الهوية
function MaskAvatar({ size = 'md' }) {
  return (
    <span className={`mask-avatar ${size === 'sm' ? 'sm' : ''}`} aria-hidden="true">
      <VenetianMask size={size === 'sm' ? 15 : 19} strokeWidth={1.7} />
    </span>
  );
}

// سجلّ المحادثة: التقييم والسؤال وباب الكشف تُرسم كأحداث لا كفقاعات كلام
function Event({ m }) {
  if (m.kind === 'like' || m.kind === 'dislike') {
    const liked = m.kind === 'like';
    return (
      <div className={`wevent react${liked ? ' good' : ' bad'}`}>
        {liked ? <ThumbsUp size={14} strokeWidth={2} /> : <ThumbsDown size={14} strokeWidth={2} />}
        {m.mine ? (liked ? 'أعجبتك الهمسة' : 'لم تعجبك الهمسة') : (liked ? 'أعجبته الهمسة' : 'لم تعجبه الهمسة')}
      </div>
    );
  }
  if (m.kind === 'ask') {
    return (
      <div className="wevent ask">
        <HelpCircle size={14} strokeWidth={2} />
        {m.mine ? 'سألت: من صاحب الهمسة؟' : 'يسأل: من أنت؟'}
      </div>
    );
  }
  if (m.kind === 'deny') {
    return (
      <div className="wevent deny">
        <ShieldOff size={14} strokeWidth={2} /> {m.mine
          ? 'فضّلت أن تبقى مجهولًا — لم تُكشف هويتك.'
          : 'فضّل البقاء مجهولًا — لم تُكشف هويته.'}
      </div>
    );
  }
  if (m.kind === 'reveal') {
    return (
      <div className="wevent reveal">
        <Sparkles size={15} strokeWidth={1.9} />
        <div>
          <b>كُشفت الهوية</b>
          <p>{m.text}</p>
        </div>
      </div>
    );
  }
  return null;
}

export default function WhisperThread({ thread, actions, busy, onClose, toast }) {
  const messages = thread.messages || [];
  const revealed = thread.revealed && thread.peer;
  const person = thread.peer || null;
  const [draft, setDraft] = useState('');
  const [confirmDel, setConfirmDel] = useState(false);
  const endRef = useRef(null);
  const readOnce = useRef(null);

  // تعليم الهمسة كمقروءة مرة واحدة لكل محادثة (لا حلقة تحديث)
  useEffect(() => {
    if (readOnce.current === thread.id) return;
    readOnce.current = thread.id;
    if (thread.unread > 0 && actions.whisperRead) actions.whisperRead(thread.id);
  }, [thread.id, thread.unread, actions]);

  useEffect(() => {
    if (endRef.current) endRef.current.scrollIntoView({ block: 'end' });
  }, [messages.length, thread.id]);

  // بعد سؤالي أو رسالتي: نتحقّق مرة أخرى بعد مهلة قصيرة بدل انتظار نبض التحديث الطويل،
  // فيظهر الجواب في وقته بدل أن يبدو أن أحدًا لا يجيب.
  useEffect(() => {
    const last = messages[messages.length - 1];
    const waiting = thread.revealState === 'asked' || (last && last.mine && last.kind === 'text');
    if (!waiting || !actions.refresh) return undefined;
    const t = setTimeout(() => { actions.refresh(); }, 22000);
    return () => clearTimeout(t);
  }, [thread.id, thread.revealState, messages.length, actions]);

  const send = async () => {
    const text = draft.trim();
    if (!text || busy) return;
    setDraft('');
    const done = await actions.whisperSend(thread.id, text);
    if (!done) setDraft(text);
  };

  const ask = async () => {
    const done = await actions.whisperAsk(thread.id);
    if (!done && toast) toast('تعذّر إرسال السؤال الآن', 'error');
  };

  const react = (kind) => {
    if (busy) return;
    actions.whisperReact(thread.id, kind);
  };

  const askState = thread.revealState;
  const outgoing = thread.direction === 'out';
  // صياغة الزرّ تتبع الاتجاه: الوارد يسأل «من صاحب الهمسة؟»، والصادر بابُه غير مفتوح أصلًا.
  const askLabel = outgoing ? (revealed ? 'عرّفت بنفسك' : 'أنت من بدأها')
    : revealed ? 'عرّف بنفسه'
      : askState === 'asked' ? 'سألته — بانتظار جوابه'
        : askState === 'declined' ? 'فضّل البقاء مجهولًا'
          : 'من صاحب الهمسة؟';

  return (
    <div className="view chat-view whisper-view">
      <div className="chat-head whisper-head">
        <button className="iconbtn" onClick={onClose} aria-label="رجوع إلى المحادثات">
          <ArrowRight size={18} strokeWidth={1.8} />
        </button>
        {revealed
          ? <Avatar name={person.name} color={person.color} size="sm" photo={person.avatar} />
          : <MaskAvatar size="sm" />}
        <div className="grow">
          <div className="pname">
            {revealed ? person.name : 'همسة مجهولة'}
            {revealed
              ? (person.verified ? <BadgeCheck size={15} strokeWidth={2} className="verified" /> : null)
              : <span className="anon-tag"><Lock size={11} strokeWidth={2.2} /> بلا اسم</span>}
          </div>
          <div className="meta">
            <span>{thread.hint}</span>
            {thread.fromState ? (
              <>
                <span className="sep">·</span>
                <span className="w-src">عن: {thread.fromState}</span>
              </>
            ) : null}
          </div>
        </div>
      </div>

      <p className="wnote">
        {revealed ? (
          <>
            <Sparkles size={14} strokeWidth={1.9} />
            <span>{outgoing
              ? 'عرّفت بنفسك — صارت الهمسة محادثة عادية بينكما.'
              : 'عرّف بنفسه — صارت الهمسة محادثة عادية بينكما.'}</span>
          </>
        ) : (
          <>
            <VenetianMask size={14} strokeWidth={1.8} />
            <span>{outgoing
              ? 'أنت بدأت هذه الهمسة بلا اسم. لا يراها غيركما، وهو لا يعرف أنك أنت من كتبها — يسألك إن أراد.'
              : 'وصلتك هذه الهمسة من شخص تعرفه، لكنه لم يكتب باسمه. لا يراها غيركما، وهو لا يعرف أنك تبحث عن اسمه.'}</span>
          </>
        )}
      </p>

      <div className="chat-body">
        {messages.length === 0 && (
          <div className="empty"><div className="circle"><VenetianMask size={22} strokeWidth={1.8} /></div>
            <strong>لا رسائل بعد</strong><p>اكتب أول همسة.</p></div>
        )}
        {messages.map((m, i) => {
          const prev = messages[i - 1];
          const showDay = !prev || dayLabel(prev.at) !== dayLabel(m.at);
          const mine = m.mine;
          const isEvent = m.kind && m.kind !== 'text';
          return (
            <React.Fragment key={m.id || i}>
              {showDay && <div className="daysep">{dayLabel(m.at)}</div>}
              {isEvent ? <Event m={m} /> : (
                <div className={`bubble-row${mine ? ' mine' : ''}`}>
                  {!mine && <div className="bub-ava">{revealed
                    ? <Avatar name={person.name} color={person.color} size="sm" photo={person.avatar} />
                    : <MaskAvatar size="sm" />}</div>}
                  <div className={`bubble${mine ? ' mine' : ''}`}>
                    <span>{m.text}</span>
                    <span className="b-time">{timeOf(m.at)}</span>
                  </div>
                </div>
              )}
            </React.Fragment>
          );
        })}
        <div ref={endRef} />
      </div>

      {thread.peerAsked && (
        <div className="wask">
          <div className="wask-head">
            <HelpCircle size={15} strokeWidth={2} />
            <b>صاحب الهمسة يسأل: «من أنت؟»</b>
          </div>
          <p>هو لا يعرفك، وأنت من بدأت الهمسة. عرّف بنفسك، أو ابقَ مجهولًا كما بدأت.</p>
          <div className="row2">
            <button className="btn btn-primary sm" disabled={busy}
              onClick={() => actions.whisperReveal(thread.id, true)}>
              <Sparkles size={15} strokeWidth={1.9} /> أعرّف بنفسي
            </button>
            <button className="btn btn-soft sm" disabled={busy}
              onClick={() => actions.whisperReveal(thread.id, false)}>
              <ShieldOff size={15} strokeWidth={1.9} /> أبقى مجهولًا
            </button>
          </div>
        </div>
      )}

      <div className="whisper-bar">
        <div className="wacts" role="group" aria-label="إجراءات الهمسة">
          <button
            type="button"
            className={`wact like${thread.reaction === 'like' ? ' on' : ''}`}
            onClick={() => react('like')}
            disabled={busy}
            aria-pressed={thread.reaction === 'like'}
            title="أعجبني"
          >
            <ThumbsUp size={18} strokeWidth={1.9} />
            <em>أعجبني</em>
          </button>
          <button
            type="button"
            className={`wact dislike${thread.reaction === 'dislike' ? ' on' : ''}`}
            onClick={() => react('dislike')}
            disabled={busy}
            aria-pressed={thread.reaction === 'dislike'}
            title="لم يعجبني"
          >
            <ThumbsDown size={18} strokeWidth={1.9} />
            <em>لم يعجبني</em>
          </button>
          <button
            type="button"
            className={`wact ask${!revealed && (askState === 'asked' || askState === 'declined') ? ' on' : ''}`}
            onClick={ask}
            disabled={busy || revealed || askState === 'asked' || askState === 'declined' || thread.direction !== 'in'}
            aria-label={askLabel}
            title={askLabel}
          >
            <HelpCircle size={18} strokeWidth={1.9} />
            <em>{askLabel}</em>
          </button>
        </div>

        <div className="wline">
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') send(); }}
            placeholder={revealed ? `اكتب إلى ${person.name}…` : 'اكتب همسة… صاحبها لا يعرف أنك تعرف'}
            aria-label="نص الهمسة"
          />
          <button className="send-btn" onClick={send} disabled={busy || !draft.trim()} aria-label="إرسال">
            {busy ? <Loader2 className="spin" size={18} strokeWidth={2} /> : <Send size={18} strokeWidth={1.8} />}
          </button>
        </div>
      </div>

      <div className="wfoot">
        <span className="muted">
          <Lock size={12} strokeWidth={2} /> همسة خاصة — لا تُعرض على الحالة ولا يراها غيركما
        </span>
        <button
          className={`ghost-btn${confirmDel ? ' danger' : ''}`}
          disabled={busy}
          onClick={() => {
            if (!confirmDel) {
              setConfirmDel(true);
              setTimeout(() => setConfirmDel(false), 4000);
              return;
            }
            actions.whisperDelete(thread.id);
          }}
        >
          {confirmDel
            ? <><ShieldOff size={13} strokeWidth={2} /> اضغط مرة أخرى للتأكيد</>
            : <><Trash2 size={13} strokeWidth={1.9} /> حذف المحادثة</>}
        </button>
      </div>
    </div>
  );
}

import React from 'react';
import { Bell, BellRing, DoorOpen, MessageSquareDashed, Archive, CalendarClock, CheckCheck, Info, MapPin } from 'lucide-react';
import Sheet from './Sheet.jsx';
import { fmtWhen, countdown } from '../datetime.js';

const ICONS = {
  room: DoorOpen,
  whisper: MessageSquareDashed,
  memory: Archive,
  athar: MapPin,
  meeting: CalendarClock,
  reminder: BellRing,
  info: Info,
};

function ago(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'الآن';
  if (m < 60) return `قبل ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `قبل ${h} ساعة`;
  return `قبل ${Math.floor(h / 24)} يوم`;
}

export default function NotificationsSheet({ notifications, onClose, onReadAll, onOpenWhisper }) {
  const unread = notifications.filter((n) => !n.read).length;
  return (
    <Sheet title="الإشعارات" onClose={onClose}>
      <div className="notif-head">
        <span>{unread > 0 ? `${unread} جديد` : 'لا جديد'}</span>
        <button className="ghost-btn" onClick={onReadAll}>
          <CheckCheck size={15} strokeWidth={1.8} /> تعليم الكل كمقروء
        </button>
      </div>

      {notifications.length === 0 ? (
        <div className="empty">
          <div className="circle"><Bell size={20} strokeWidth={1.8} /></div>
          <p>لا إشعارات بعد.</p>
        </div>
      ) : (
        <ul className="notifs">
          {notifications.map((n) => {
            const Icon = ICONS[n.kind] || Bell;
            // إشعار الهمسة قابل للضغط: يفتح محادثة الهمس نفسها (ومعها عدّاد الغير مقروء)
            const wid = n.kind === 'whisper' && n.meta && n.meta.whisperId ? n.meta.whisperId : null;
            const inner = (
              <>
                <div className="nicon"><Icon size={16} strokeWidth={1.8} /></div>
                <div className="grow">
                  <p>{n.text}</p>
                  {n.meta && n.meta.at && (
                    <span className="when-line">
                      <CalendarClock size={12} strokeWidth={1.8} /> {fmtWhen(n.meta.at)}
                      {n.meta.place ? ` · ${n.meta.place}` : ''}
                      {!n.read && new Date(n.meta.at).getTime() > Date.now()
                        ? ` · ${countdown(new Date(n.meta.at).getTime() - Date.now())}` : ''}
                    </span>
                  )}
                  <span className="meta">
                    {ago(n.at)}
                    {wid ? ' · اضغط لفتح الهمسة' : ''}
                  </span>
                </div>
              </>
            );
            return (
              <li key={n.id} className={`${n.read ? '' : 'unread'}${n.kind === 'reminder' ? ' reminder' : ''}`}>
                {wid && onOpenWhisper
                  ? <button className="notif-tap" onClick={() => onOpenWhisper(wid)}>{inner}</button>
                  : inner}
              </li>
            );
          })}
        </ul>
      )}
    </Sheet>
  );
}

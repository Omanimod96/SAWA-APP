import {
  Bell, Home, Users, CalendarDays, User, Moon, Sun, Share2, MessageCircle, MapPin,
} from 'lucide-react';

export function TopBar({ me, unread, onBell, theme, onToggleTheme, onShare }) {
  return (
    <header className="topbar">
      <div className="brand">
        <div className="brand-mark" aria-hidden="true">
          <Users size={18} strokeWidth={1.8} />
        </div>
        <div>
          <div className="brand-name">سوى</div>
          <div className="brand-sub">دائرتك الحقيقية · {me.city}</div>
        </div>
      </div>
      <button className="iconbtn" onClick={onShare} aria-label="مشاركة التطبيق">
        <Share2 size={18} strokeWidth={1.8} />
      </button>
      <button className="iconbtn" onClick={onToggleTheme} aria-label="تبديل الوضع الليلي">
        {theme === 'dark' ? <Sun size={18} strokeWidth={1.8} /> : <Moon size={18} strokeWidth={1.8} />}
      </button>
      <button className="iconbtn" onClick={onBell} aria-label="الإشعارات">
        <Bell size={18} strokeWidth={1.8} />
        {unread > 0 && <span className="dot" />}
      </button>
    </header>
  );
}

// أيقونة واحدة بسيطة لكل تبويب — بلا شرائط ولا دوائر مرفوعة
const TABS = [
  { id: 'states', label: 'الحالات', Icon: Home },
  { id: 'athar', label: 'أثر', Icon: MapPin, featured: true },
  { id: 'chats', label: 'المحادثات', Icon: MessageCircle },
  { id: 'meetings', label: 'الاجتماعات', Icon: CalendarDays },
  { id: 'me', label: 'أنا', Icon: User },
];

export function BottomNav({ tab, setTab, badges }) {
  return (
    <nav className="bottomnav" aria-label="التنقل الرئيسي">
      {TABS.map(({ id, label, Icon, featured }) => {
        const n = (badges && badges[id]) || 0;
        return (
          <button
            key={id}
            className={`navitem${tab === id ? ' active' : ''}${featured ? ' featured' : ''}`}
            onClick={() => setTab(id)}
            aria-current={tab === id ? 'page' : undefined}
          >
            <Icon size={21} strokeWidth={1.8} />
            <span>{label}</span>
            {n > 0 ? <span className="badge">{n}</span> : null}
          </button>
        );
      })}
    </nav>
  );
}

import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Loader2, RefreshCw, WifiOff, Share2, Check } from 'lucide-react';
import { api } from './api.js';
import { useToast } from './useToast.js';
import { TopBar, BottomNav } from './components/Shell.jsx';
import StatesView from './components/StatesView.jsx';
import ChatsView from './components/ChatsView.jsx';
import MeetingsView from './components/MeetingsView.jsx';
import ProfileView from './components/ProfileView.jsx';
import AtharView from './components/AtharView.jsx';
import NotificationsSheet from './components/NotificationsSheet.jsx';
import AuthView from './components/AuthView.jsx';
import { PermissionHost, PermissionIntro } from './components/PermissionSheet.jsx';
import CallScreen from './components/CallScreen.jsx';
import { useCall } from './useCall.js';
import { introSeen } from './permissions.js';
import { readCache, saveCache, clearCache } from './cache.js';
import { autoSave, applySnapshot } from './vault.js';
import { getToken, setToken, readAccount, saveAccount, clearSession } from './auth.js';

export default function App() {
  // بيانات الإقلاع محقونة في الصفحة نفسها من الخادم عند هذا الطلب (فتح بطلب واحد)،
  // ثم نتدرّج إلى الذاكرة المحلية حين لا تكون محقونة.
  const [data, setData] = useState(
    () => (typeof window !== 'undefined' && window.__SAWA_BOOT__) || readCache('bootstrap', 12 * 3600 * 1000)
  );
  const injected = typeof window !== 'undefined' && Boolean(window.__SAWA_BOOT__);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState('states');
  const [sheet, setSheet] = useState(null);
  const [installTip, setInstallTip] = useState(false);
  const [permIntro, setPermIntro] = useState(false);
  const [chatWith, setChatWith] = useState(null);
  // محادثة الهمس المفتوحة: معرّفها وحده، والبيانات تأتي معها من الخادم (بلا هوية صاحبها)
  const [whisperWith, setWhisperWith] = useState(null);
  const [theme, setTheme] = useState(() => localStorage.getItem('sawa.theme') || 'light');
  // الدخول بالهاتف: نرسم من بطاقة الحساب المحفوظة فورًا ثم نتحقق من الجلسة بهدوء
  const [account, setAccount] = useState(() => readAccount());
  const [authChecked, setAuthChecked] = useState(false);
  // «جلسة واحدة نشطة»: إن دخل الحساب من مكان آخر، يُغلق الخادم هذه الجلسة، ونُبقي
  // السبب هنا لنعرضه في شاشة الدخول بدل طرد صامت بلا تفسير.
  const [kicked, setKicked] = useState(null);
  const { toasts, addToast } = useToast();

  const load = useCallback(async () => {
    setRefreshing(true);
    try {
      const d = await api.bootstrap();
      if (!d || !Array.isArray(d.states)) throw new Error('bad payload');
      setData(d);
      saveCache('bootstrap', d);
      setError(null);
      return d;
    } catch (e) {
      setError(e.message || 'تعذّر الاتصال بالخدمة');
      return null;
    } finally {
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    if (!account) return; // لا نطلب بيانات العرض قبل الدخول
    if (injected) {
      // البيانات وصلت مع الصفحة نفسها — لا نطلبها مرة ثانية، ونحفظها للفتحات القادمة
      try {
        if (window.__SAWA_BOOT__ && Array.isArray(window.__SAWA_BOOT__.states)) {
          saveCache('bootstrap', window.__SAWA_BOOT__);
        }
      } catch (e) { /* الذاكرة ممتلئة — نتجاهل */ }
      return;
    }
    load();
  }, [load, injected, account]);

  // نهاية الجلسة: نمسح الرمز ونُظهر السبب إن كان «دخول من مكان آخر»
  const endSession = useCallback((body) => {
    clearSession();
    setAccount(null);
    setData(null);
    if (body && body.code === 'session_replaced') {
      setKicked({ at: body.endedAt || null, device: body.newDevice || '' });
    }
  }, []);

  // التحقق من الجلسة عند كل فتح: 401 يعني جلسة منتهية أو مُبطلة، وغيرها (انقطاع شبكة)
  // نحتفظ بالحساب المحفوظ حتى لا يُطرد المستخدم بسبب الشبكة.
  useEffect(() => {
    let alive = true;
    (async () => {
      if (!getToken()) {
        if (alive) { setAccount(null); saveAccount(null); setAuthChecked(true); }
        return;
      }
      try {
        const s = await api.authSession();
        if (!alive) return;
        if (s && s.account) {
          setAccount(s.account);
          saveAccount(s.account);
          if (s.boot && Array.isArray(s.boot.states)) { setData(s.boot); saveCache('bootstrap', s.boot); }
        } else if (alive) { clearSession(); setAccount(null); }
      } catch (e) {
        if (alive && e && e.status === 401) endSession(e.body);
      } finally {
        if (alive) setAuthChecked(true);
      }
    })();
    return () => { alive = false; };
  }, [endSession]);

  // نبض الجلسة: كل ٣٠ ثانية (وفي كل عودة إلى التطبيق) نسأل الخادم: هل ما زالت جلستي
  // هي النشطة؟ فإن دخل الحساب من مكان آخر نخرج فورًا — لا ننتظر إعادة تحميل الصفحة.
  useEffect(() => {
    if (!account) return undefined;
    let alive = true;
    const beat = async () => {
      if (document.hidden) return;
      try {
        await api.authSession();
      } catch (e) {
        if (alive && e && e.status === 401) endSession(e.body);
      }
    };
    const t = setInterval(beat, 30000);
    const onShow = () => { if (!document.hidden) beat(); };
    document.addEventListener('visibilitychange', onShow);
    window.addEventListener('focus', onShow);
    return () => {
      alive = false;
      clearInterval(t);
      document.removeEventListener('visibilitychange', onShow);
      window.removeEventListener('focus', onShow);
    };
  }, [account, endSession]);

  const onAuthenticated = useCallback(({ token, account: acc, boot, created }) => {
    if (token) setToken(token);
    if (acc) { setAccount(acc); saveAccount(acc); }
    setAuthChecked(true);
    setKicked(null); // دخول جديد = سبب الإغلاق السابق لم يعد ذا معنى
    if (boot && Array.isArray(boot.states)) { setData(boot); saveCache('bootstrap', boot); }
    if (acc) addToast(created ? `أهلًا ${acc.name} — أُنشئ حسابك` : `أهلًا بعودتك ${acc.name}`, 'success');
  }, [addToast]);

  const logout = useCallback(async () => {
    try { await api.authLogout(); } catch (e) { /* نُكمل الخروج محليًا */ }
    clearSession();
    clearCache();
    setAccount(null);
    setData(null);
    setChatWith(null);
    setTab('states');
    setSheet(null);
  }, []);

  useEffect(() => {
    document.body.classList.toggle('dark', theme === 'dark');
    document.documentElement.style.colorScheme = theme;
    localStorage.setItem('sawa.theme', theme);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#08111F' : '#1D4ED8');
  }, [theme]);

  useEffect(() => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;
    setInstallTip(isIOS && !standalone);
  }, []);

  // أذونات الجهاز: سؤال واحد عند أول دخول فقط — ثم لا نُعيده أبدًا.
  // القرار يبقى في هذا الجهاز (localStorage) ولا يُرسل إلى الخادم.
  useEffect(() => {
    if (!account || introSeen()) return undefined;
    const t = setTimeout(() => setPermIntro(true), 900);
    return () => clearTimeout(t);
  }, [account]);

  useEffect(() => {
    if (!account) return undefined;
    const t = setInterval(() => { if (!document.hidden) load(); }, 45000);
    return () => clearInterval(t);
  }, [load, account]);

  // خزنة الجهاز: بعد كل تغيير نكتب نسخة في ملف المستخدم على جهازه (إن اختار ملفًا).
  // مهلة قصيرة تجمع التغييرات المتتابعة في كتابة واحدة، والحفظ صامت بلا أي نافذة.
  useEffect(() => {
    if (!account || !data) return undefined;
    const flush = async () => {
      const res = await autoSave(data, account);
      if (res && (res.at || res.error)) window.dispatchEvent(new Event('sawa:vault'));
    };
    const t = setTimeout(flush, 1800);
    const onHide = () => { if (document.hidden) { clearTimeout(t); flush(); } };
    document.addEventListener('visibilitychange', onHide);
    return () => { clearTimeout(t); document.removeEventListener('visibilitychange', onHide); };
  }, [data, account]);

  const run = useCallback(
    async (fn, successMsg) => {
      setBusy(true);
      try {
        const d = await fn();
        if (d) setData(d);
        if (successMsg) addToast(successMsg, 'success');
        return true;
      } catch (e) {
        addToast(e.message || 'حدث خطأ غير متوقع', 'error');
        return false;
      } finally {
        setBusy(false);
      }
    },
    [addToast]
  );

  const unread = useMemo(
    () => (data && Array.isArray(data.notifications) ? data.notifications.filter((n) => !n.read).length : 0),
    [data],
  );

  const badges = useMemo(() => {
    if (!data) return {};
    return {
      // الغرف صارت داخل نافذة الحالات: عدّاد الحالات يجمع ما لم يُرَ من الحالات ورسائل الغرف
      states: (data.states.filter((s) => !s.seen && s.author !== 'u-me' && s.msLeft).length || 0)
        + ((data.roomsUnread || 0) || data.rooms.reduce((sum, r) => sum + (r.unread || 0), 0)),
      chats: (data.chatsUnread || 0) + (data.whispersUnread || 0),
      meetings: data.meetings.filter((m) => m.status === 'voting').length || 0,
    };
  }, [data]);

  const goTab = useCallback((id) => {
    setTab(id);
    if (id !== 'chats') { setChatWith(null); setWhisperWith(null); }
  }, []);

  const goChat = useCallback((personId) => {
    setWhisperWith(null);
    setChatWith(personId);
    setTab('chats');
  }, []);

  // فتح محادثة همس: نُغلق أي محادثة عادية معروضة، لأن العرض واحد في الشاشة
  const goWhisper = useCallback((id) => {
    if (!id) return;
    setChatWith(null);
    setWhisperWith(id);
    setTab('chats');
  }, []);

  const actions = useMemo(() => ({
    createState: (p) => run(() => api.createState(p), 'نُشرت حالتك إلى دائرتك'),
    markSeen: (id) => api.seenState(id).then((d) => { if (d) setData(d); return true; }).catch(() => false),
    deleteState: (id) => run(() => api.deleteState(id), 'حُذفت حالتك'),
    // مشاركة حالة: نرفع الوسائط أولًا إن وُجدت ثم ننشر الحالة
    shareStory: (p) => run(async () => {
      let media = null;
      if (p && p.media && p.media.dataUrl) {
        const up = await api.uploadMedia({ type: p.media.type, dataUrl: p.media.dataUrl });
        media = { ...up, durationMs: (p.media && p.media.durationMs) || 0 };
        // قصّ/تنسيق الوسائط (تدوير · قلب · فلتر · إطار) يُحفظ مع الحالة كما اختاره صاحبه
        if (p.media.view) media = { ...media, view: p.media.view };
        if (p.media.dims) media = { ...media, w: p.media.dims.w, h: p.media.dims.h };
        // طبقات الرسم والملصقات على المقاطع: تُرفع صورة شفافة وتُخزَّن مع الوسائط
        if (p.media.overlay) {
          const ov = await api.uploadMedia({ type: 'image', dataUrl: p.media.overlay });
          media = { ...media, overlay: ov.url };
        }
      }
      return api.createState({ ...p, media });
    }, 'نُشرت حالتك — اضغطها لتراها كما يراها الآخرون'),
    sendMessage: (personId, text, media) => run(() => api.sendMessage(personId, text, media)),
    readChat: (personId) => run(() => api.readChat(personId)),
    respond: (id, choice) => run(() => api.respond(id, choice), 'سُجّل ردّك'),
    whisper: (id, to, text) => run(() => api.whisper(id, to, text), 'أُرسلت الهمسة — صارت محادثة في تبويب المحادثات'),
    // الهمسة كمحادثة: كل إجراء يعيد بيانات كاملة، فلا تبقى الواجهة على حال قديم
    whisperStart: (to, text, stateId) =>
      run(() => api.whisperStart(to, text, stateId), 'فُتحت محادثة همسة — تابعها من المحادثات'),
    whisperSend: (id, text) => run(() => api.whisperSend(id, text)),
    whisperReact: (id, kind) => run(() => api.whisperReact(id, kind)),
    whisperAsk: (id) => run(() => api.whisperAsk(id), 'أرسلنا سؤالك — هو من يقرر أن يعرّف بنفسه'),
    whisperReveal: (id, yes) => run(
      () => api.whisperReveal(id, yes),
      yes ? 'عرّفت بنفسك — صار يعرف من أنت' : 'بقيت مجهولًا — لن يُكشف اسمك',
    ),
    // قراءة الهمسة وحدها بلا إشعار: تُستدعى عند فتحها فقط
    whisperRead: (id) => api.whisperRead(id)
      .then((d) => { if (d) { setData(d); saveCache('bootstrap', d); } return true; })
      .catch(() => false),
    whisperDelete: async (id) => {
      const done = await run(() => api.whisperDelete(id), 'حُذفت محادثة الهمسة');
      // لا نُبقي شاشة مفتوحة على محادثة حُذفت
      if (done) setWhisperWith(null);
      return done;
    },
    createRoom: (p) => run(() => api.createRoom(p), 'فُتحت غرفة مؤقتة'),
    joinRoom: (id) => run(() => api.joinRoom(id), 'انضممت إلى الغرفة — الدردشة صارت متاحة'),
    sendRoomMessage: (id, text) => run(() => api.sendRoomMessage(id, text)),
    // قراءة الدردشة وحدها بلا إشعار — تُستدعى كلما فتحتها
    readRoom: (id) => api.readRoom(id).then((d) => { if (d) { setData(d); saveCache('bootstrap', d); } return true; }).catch(() => false),
    refresh: () => api.bootstrap().then((d) => { if (d) { setData(d); saveCache('bootstrap', d); } return true; }).catch(() => false),
    closeRoom: (id) => run(() => api.closeRoom(id), 'أُقفلت الغرفة وأُرشفت في أثر'),
    addMemory: (id, text) => run(() => api.addMemory(id, text), 'أُضيف أثر جديد'),
    createMeeting: (p) => run(
      () => api.createMeeting(p),
      p && p.kind === 'fixed'
        ? 'أُضيف الموعد وتشغّل التذكير قبل يوم وقبل ساعة'
        : 'طُرح الاجتماع للتصويت',
    ),
    vote: (id, slotId) => run(() => api.vote(id, slotId), 'صوّتت للموعد'),
    confirmMeeting: (id, p) => run(
      () => api.confirmMeeting(id, p),
      p && p.at ? 'تأكّد الاجتماع على الموعد المحدَّد' : 'تأكّد الاجتماع',
    ),
    // «أثر»: نرفع الصورة أولًا ثم ننشئ الأثر، ثم نحدّث الملخّص والإشعارات
    createAthar: async (payload) => {
      try {
        let media = null;
        if (payload && payload.media && payload.media.dataUrl) {
          const up = await api.uploadMedia({ type: 'image', dataUrl: payload.media.dataUrl });
          media = { type: 'image', url: up.url };
          if (payload.media.view) media.view = payload.media.view;
          if (payload.media.dims) { media.w = payload.media.dims.w; media.h = payload.media.dims.h; }
        }
        const res = await api.createAthar({ ...payload, media });
        // الإشعار والإغلاق فورًا بعد الاستجابة، والتحديث في الخلفية: انتظار
        // دورة شبكة ثانية (bootstrap) كان يُبقي نموذج النشر معلّقًا ثوانٍ إضافية
        // بلا سبب — والمستخدم يقرأ التعليق أنه «زرّ لا يعمل».
        addToast('وثّقت أثرًا جديدًا — صار ومضة على الخريطة', 'success');
        load().catch(() => {});
        return res;
      } catch (e) {
        throw new Error(e.message || 'تعذّر نشر الأثر');
      }
    },
    saveMe: (p) => run(() => api.saveMe(p), 'حُفظت الإعدادات'),
    // التواصل باسم المستخدم: أضف شخصًا بلا رقم هاتف ثم افتح محادثته مباشرة
    addByUsername: async (username) => {
      try {
        const res = await api.addByUsername(username);
        if (res) setData(res);
        const added = res && res.added ? res.added : null;
        addToast(
          added && added.created ? `أُضيف @${username} إلى دائرتك` : `فُتحت محادثة @${username}`,
          'success'
        );
        return added ? added.personId : null;
      } catch (e) {
        addToast(e.message || 'تعذّر إيجاد هذا الاسم', 'error');
        return null;
      }
    },
    readAll: () => run(() => api.readAll()),
    invite: (p) => run(() => api.invite(p), 'أُرسلت الدعوة'),
  }), [run, load, addToast]);

  // ── المكالمة (v32): قناة واحدة على مستوى التطبيق كلّه ──
  // سبب وجوده هنا: قناة الإشارات واحدة لكل حساب، فنسخة في كل شاشة = رنين يُقرأ
  // مرّتين. الواجهة ترسم من state، والأزرار تنادي actions.
  const { state: callState, local: callLocal, remote: callRemote, online: onlineList, actions: callActions } = useCall({
    onChatChanged: () => { load(); },
    onCallEnded: ({ call, local }) => {
      const c = call || {};
      // فعلٌ فعله صاحب الجهاز (رفض/إنهاء) لا يُعلَّق عليه برسالة خطأ
      if (!local && c.status === 'missed') addToast('مكالمة فائتة من ' + ((c.caller && c.caller.name) || 'طرف'), 'error');
      else if (!local && c.status === 'rejected') addToast('رُفضت المكالمة', 'error');
      load();
    },
    onNotice: (msg, type) => addToast(msg, type || 'error'),
  });

  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: 'سوى', url });
      else { await navigator.clipboard.writeText(url); addToast('نُسخ رابط التطبيق', 'success'); }
    } catch (e) { /* أغلق المستخدم نافذة المشاركة */ }
  };

  // رمز محفوظ بلا بطاقة حساب (متصفح جديد): ننتظر نتيجة التحقق بدل وميض شاشة الدخول
  if (!account && !authChecked && getToken()) {
    return (
      <div className="app center-screen">
        <div className="empty">
          <div className="circle"><Loader2 className="spin" size={22} strokeWidth={1.8} /></div>
          <strong>نتحقق من جلستك…</strong>
        </div>
      </div>
    );
  }

  // بوابة الدخول: لا واجهة تطبيق قبل حساب
  if (!account) {
    return <AuthView authInfo={data && data.auth} onDone={onAuthenticated} notice={kicked} />;
  }

  if (error && !data) {
    return (
      <div className="app center-screen">
        <div className="empty">
          <div className="circle"><WifiOff size={24} strokeWidth={1.8} /></div>
          <strong>تعذّر الوصول إلى الخدمة</strong>
          <p>{error}</p>
          <button className="btn" style={{ marginTop: '1rem' }} onClick={load}>
            <RefreshCw size={16} strokeWidth={1.8} /> إعادة المحاولة
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <TopBar
        me={data ? data.me : { city: '…' }}
        unread={unread}
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === 'dark' ? 'light' : 'dark'))}
        onBell={() => setSheet('notifications')}
        onShare={share}
      />

      <main className={`content${tab === 'athar' ? ' flush' : ''}`}>
        {refreshing && data && (
          <div className="sync-bar" role="status" aria-label="تحديث البيانات">
            <span className="sync-dot" />
            <span>يُحدَّث بهدوء…</span>
          </div>
        )}
        {!data ? (
          <div>
            <div className="skeleton" />
            <div className="skeleton" />
            <div className="skeleton" />
          </div>
        ) : tab === 'states' ? (
          <StatesView
            data={data}
            actions={actions}
            busy={busy}
            goTab={goTab}
            onError={(m) => addToast(m, 'error')}
            onOpenWhisper={goWhisper}
          />
        ) : tab === 'chats' ? (
          <ChatsView
            data={data}
            actions={actions}
            busy={busy}
            toast={addToast}
            call={{ state: callState, actions: callActions, online: onlineList }}
            activeId={chatWith}
            onOpen={goChat}
            onClose={() => setChatWith(null)}
            whisperId={whisperWith}
            onOpenWhisper={goWhisper}
            onCloseWhisper={() => setWhisperWith(null)}
          />
        ) : tab === 'athar' ? (
          <AtharView
            data={data}
            actions={actions}
            dark={theme === 'dark'}
            onError={(m) => addToast(m, 'error')}
          />
        ) : tab === 'meetings' ? (
          <MeetingsView data={data} actions={actions} busy={busy} />
        ) : (
          <ProfileView
            data={data}
            actions={actions}
            busy={busy}
            onMessage={goChat}
            account={account}
            onLogout={logout}
            addToast={addToast}
            onRestoreVault={(doc) => {
              setData((prev) => {
                const next = applySnapshot(prev, doc);
                saveCache('bootstrap', next);
                return next;
              });
            }}
          />
        )}
      </main>

      {installTip && (
        <div className="notice install-tip">
          <Share2 size={15} strokeWidth={1.8} />
          <div>لتثبيت سوى على iPhone: زر المشاركة ← «إضافة إلى الشاشة الرئيسية».</div>
          <button className="iconbtn sm" onClick={() => setInstallTip(false)} aria-label="إخفاء">
            <Check size={14} strokeWidth={2} />
          </button>
        </div>
      )}

      <BottomNav tab={tab} setTab={goTab} badges={badges} />

      {busy && (
        <div className="busy-chip">
          <Loader2 className="spin" size={14} strokeWidth={2} /> يعمل…
        </div>
      )}

      {sheet === 'notifications' && data && (
        <NotificationsSheet
          notifications={data.notifications}
          onClose={() => setSheet(null)}
          onReadAll={async () => { await actions.readAll(); }}
          onOpenWhisper={(wid) => { setSheet(null); goWhisper(wid); }}
        />
      )}

      {account && callState.phase !== 'idle' && (
        <CallScreen state={callState} actions={callActions} local={callLocal} remote={callRemote} />
      )}

      <div className="toast-wrap" aria-live="polite">
        {toasts.map((t) => (<div key={t.id} className={`toast ${t.type}`}>{t.msg}</div>))}
      </div>

      {/* أذونات الجهاز: ورقة الطلب الواحدة + السؤال الأول عند الدخول */}
      <PermissionHost />
      <PermissionIntro open={permIntro} onClose={() => setPermIntro(false)} onNotice={addToast} />
    </div>
  );
}

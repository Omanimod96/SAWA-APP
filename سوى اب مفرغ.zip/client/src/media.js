// أدوات الوسائط: قراءة الملفات، ضغط الصور، وتسجيل الصوت
export const TYPE_OF = (file) => {
  const t = String(file && file.type ? file.type : '');
  if (t.startsWith('image/')) return 'image';
  if (t.startsWith('video/')) return 'video';
  if (t.startsWith('audio/')) return 'audio';
  return null;
};

export const CAP_MB = { image: 6, video: 12, audio: 6, doc: 8 };

// المستندات: تُشارَك في المحادثات (‏pdf, Word, Excel, PowerPoint, نص, csv, zip)
const DOC_MIME = /^application\/(pdf|msword|vnd\.(ms-|openxmlformats-officedocument\.)|zip)/;
const DOC_EXT = /\.(pdf|docx?|xlsx?|pptx?|txt|csv|zip|rtf|odt|ods|odp)$/i;

export const isDoc = (file) => DOC_MIME.test(String((file && file.type) || '')) || DOC_EXT.test(String((file && file.name) || ''));

// النوع الموسّع: يضمّ المستندات — تستخدمه المحادثات دون أن تختلط بأنواع الحالة
export function TYPE_OF_ANY(file) {
  const t = TYPE_OF(file);
  if (t) return t;
  return isDoc(file) ? 'doc' : null;
}

export const DOC_KIND = { pdf: 'PDF', doc: 'Word', xls: 'Excel', ppt: 'PowerPoint', zip: 'ملف مضغوط', txt: 'نص' };

export function docLabel(name, mime) {
  const ext = String(name || '').split('.').pop().toLowerCase();
  const m = String(mime || '');
  if (ext === 'pdf' || m.includes('pdf')) return 'مستند PDF';
  if (/^(docx?|rtf|odt)$/.test(ext)) return 'مستند Word';
  if (/^(xlsx?|ods)$/.test(ext)) return 'جدول Excel';
  if (/^(pptx?|odp)$/.test(ext)) return 'عرض PowerPoint';
  if (ext === 'zip') return 'ملف مضغوط';
  if (ext === 'csv') return 'جدول CSV';
  return 'مستند';
}


export function fmtSize(bytes) {
  const n = Number(bytes) || 0;
  if (n < 1024) return `${n} بايت`;
  if (n < 1024 * 1024) return `${Math.round(n / 1024)} ك.ب`;
  return `${(n / (1024 * 1024)).toFixed(1)} م.ب`;
}

export function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(new Error('تعذّر قراءة الملف'));
    fr.readAsDataURL(blob);
  });
}

// تصغير الصور قبل الرفع حتى تبقى الحالة سريعة
export function shrinkImage(file, max = 1500, quality = 0.86) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        const keepOriginal = scale === 1 && file.size <= 1.2 * 1024 * 1024 && /image\/(jpeg|png|webp)/.test(file.type || '');
        if (keepOriginal) {
          blobToDataUrl(file)
            .then((out) => { URL.revokeObjectURL(url); resolve({ dataUrl: out, mime: file.type, size: file.size }); })
            .catch(() => { URL.revokeObjectURL(url); reject(new Error('تعذّر قراءة الصورة')); });
          return;
        }
        let out;
        const keepPng = file.type === 'image/png';
        try { out = c.toDataURL(keepPng ? 'image/png' : 'image/jpeg', quality); } catch (e) { out = c.toDataURL('image/png'); }
        URL.revokeObjectURL(url);
        resolve({ dataUrl: out, mime: out.slice(5, out.indexOf(';')), size: Math.round((out.length * 3) / 4) });
      } catch (e) {
        URL.revokeObjectURL(url);
        reject(new Error('تعذّر معالجة الصورة'));
      }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('صيغة الصورة غير مدعومة')); };
    img.src = url;
  });
}

// مدة الفيديو/الصوت بالملي ثانية (لضبط وقت عرض الحالة)
export function mediaDurationMs(url, type = 'video') {
  return new Promise((resolve) => {
    try {
      const el = document.createElement(type === 'audio' ? 'audio' : 'video');
      el.preload = 'metadata';
      el.onloadedmetadata = () => resolve(Number.isFinite(el.duration) ? Math.round(el.duration * 1000) : 0);
      el.onerror = () => resolve(0);
      el.src = url;
    } catch (e) { resolve(0); }
  });
}

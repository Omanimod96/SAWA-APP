// إطار «سوى» الطولي: ٩:١٦ — الإطار نفسه في الكاميرا والمعاينة والعارض والمكان.
// هذا الملف رياضيات خالصة بلا DOM حتى يُفحص مباشرة (qa/crop_math_test.mjs).
export const AR = 9 / 16;

// قصّ مركزي (cover) من إطار الكاميرا إلى ٩:١٦:
//   • الإطار أعرض من المطلوب ⇒ نقصّ من الجانبين.
//   • الإطار أعلى من المطلوب  ⇒ نقصّ من الأعلى والأسفل.
// النتيجة = ما يراه المستخدم في المعاينة تمامًا (الاختبار في qa/camera_ui_test.py
// يقيس نسبة الصورة المحفوظة فعليًا من المتصفح).
export function coverCrop(vw, vh, ar = AR) {
  const w = Math.max(1, Math.round(Number(vw) || 0));
  const h = Math.max(1, Math.round(Number(vh) || 0));
  let sw;
  let sh;
  if (w / h > ar) {
    sh = h;
    sw = Math.round(h * ar);
  } else {
    sw = w;
    sh = Math.round(w / ar);
  }
  sw = Math.max(1, Math.min(sw, w));
  sh = Math.max(1, Math.min(sh, h));
  return { sx: Math.round((w - sw) / 2), sy: Math.round((h - sh) / 2), sw, sh };
}

// بعُد الصورة المحفوظة: نُصغّر إن كانت أكبر من السقف، ولا نُكبّر أبدًا (بلا تمويه).
export function fitScale(sw, sh, max = 1440) {
  const long = Math.max(sw, sh);
  const k = long > max ? max / long : 1;
  return { width: Math.max(1, Math.round(sw * k)), height: Math.max(1, Math.round(sh * k)) };
}

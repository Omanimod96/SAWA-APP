// جلسة الدخول في المتصفح: رمز الجلسة + بطاقة الحساب للرسم الفوري قبل أي طلب.
// نخزّن الرمز وحده (لا كلمة سر ولا رمز تحقق) — والخادم هو من يتحقق منه في كل مرة.
const TOKEN_KEY = 'sawa.token';
const ACCOUNT_KEY = 'sawa.account';

let memo = null;

export function getToken() {
  if (memo !== null) return memo;
  try { memo = localStorage.getItem(TOKEN_KEY) || null; } catch (e) { memo = null; }
  return memo;
}

export function setToken(token) {
  memo = token || null;
  try {
    if (token) localStorage.setItem(TOKEN_KEY, token);
    else localStorage.removeItem(TOKEN_KEY);
  } catch (e) { /* تخزين ممتلئ أو وضع خاص — نتابع بالذاكرة */ }
}

export function readAccount() {
  try {
    const raw = JSON.parse(localStorage.getItem(ACCOUNT_KEY) || 'null');
    return raw && raw.phone ? raw : null;
  } catch (e) { return null; }
}

export function saveAccount(account) {
  try {
    if (account) localStorage.setItem(ACCOUNT_KEY, JSON.stringify(account));
    else localStorage.removeItem(ACCOUNT_KEY);
  } catch (e) { /* تجاهل */ }
}

export function clearSession() {
  setToken(null);
  saveAccount(null);
}

// إعدادات عرض الوسائط: تدوير · قلب · فلتر · قصّ.
// الفكرة: لا نُعيد ترميز الأصل، بل نحفظ الإعدادات مع الوسائط وتُطبَّق بنفس
// الطريقة في المحرّر والمعاينة والعارض — فيبقى «القص» و«التنسيق» قابلين
// للتراجع حتى بعد النشر.
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const num = (v, d) => (Number.isFinite(Number(v)) ? Number(v) : d);

export const FILTERS = [
  { id: 'none', label: 'أصلي', css: 'none' },
  { id: 'warm', label: 'دافئ', css: 'saturate(1.16) sepia(0.16) brightness(1.04)' },
  { id: 'cool', label: 'بارد', css: 'saturate(1.06) hue-rotate(-12deg) brightness(1.02)' },
  { id: 'mono', label: 'رمادي', css: 'grayscale(1) contrast(1.06)' },
  { id: 'pop', label: 'حيوي', css: 'saturate(1.45) contrast(1.06)' },
];

// نسب القصّ الجاهزة — «حرّ» يعني إطارًا يسحبه المستخدم كما يشاء
export const RATIOS = [
  { id: 'free', label: 'حرّ', r: null },
  { id: '1:1', label: 'مربّع', r: 1 },
  { id: '4:5', label: '٤:٥', r: 4 / 5 },
  { id: '9:16', label: '٩:١٦', r: 9 / 16 },
  { id: '16:9', label: '١٦:٩', r: 16 / 9 },
];

export const DEFAULT_VIEW = { rot: 0, flipH: false, flipV: false, filter: 'none', crop: null };

export const normCrop = (c) => {
  if (!c) return null;
  const x = clamp(num(c.x, 0), 0, 1);
  const y = clamp(num(c.y, 0), 0, 1);
  const w = clamp(num(c.w, 1), 0.08, 1 - x);
  const h = clamp(num(c.h, 1), 0.08, 1 - y);
  // إطار يغطّي كل الصورة = لا قصّ (نُنظّف الحالة)
  if (x < 0.004 && y < 0.004 && w > 0.996 && h > 0.996) return null;
  return { x, y, w, h };
};

export const normView = (v) => {
  const src = v && typeof v === 'object' ? v : {};
  const rot = [0, 90, 180, 270].includes(Number(src.rot)) ? Number(src.rot) : 0;
  return {
    rot,
    flipH: !!src.flipH,
    flipV: !!src.flipV,
    filter: FILTERS.some((f) => f.id === src.filter) ? src.filter : 'none',
    crop: normCrop(src.crop),
  };
};

export const patchView = (v, p) => normView({ ...normView(v), ...(p || {}) });

export const isPlainView = (v) => {
  const n = normView(v);
  return n.rot === 0 && !n.flipH && !n.flipV && n.filter === 'none' && !n.crop;
};

export const filterCss = (id) => (FILTERS.find((f) => f.id === id) || FILTERS[0]).css;

// أبعاد العرض بعد التدوير: ٩٠/٢٧٠ تبدّل العرض والارتفاع
export const viewDims = (v, dims) => {
  if (!dims || !dims.w || !dims.h) return null;
  const n = normView(v);
  const swap = n.rot % 180 !== 0;
  return { w: swap ? dims.h : dims.w, h: swap ? dims.w : dims.h, swap, srcW: dims.w, srcH: dims.h };
};

// نسبة الإطار النهائي (بعد القصّ) — تُستخدم لتوسيط الوسائط في المساحة المتاحة
export const frameRatio = (v, dims) => {
  const n = normView(v);
  const d = dims && dims.w && dims.h ? { w: dims.w, h: dims.h } : null;
  if (!d) return null;
  const vw = n.rot % 180 ? d.h : d.w;
  const vh = n.rot % 180 ? d.w : d.h;
  const c = n.crop || { x: 0, y: 0, w: 1, h: 1 };
  return (c.w * vw) / (c.h * vh);
};

// أبعاد إطار الوسائط كما تُخزَّن مع الحالة (تُقرأ في العارض)
export const viewPayload = (v, dims) => {
  const n = normView(v);
  const out = { view: n };
  if (dims && dims.w && dims.h) { out.w = Math.round(dims.w); out.h = Math.round(dims.h); }
  return out;
};

// ─────────────────────────────────────────────────────────────────────────────
// v31.js — واجهة «من يرى أثري» وبصمات جهات الاتصال المحلية.
//
// ما يجري هنا لا يجري على الخادم: تطبيع الرقم وبصمته يحدثان على الجهاز (٢.١ و ٢.٢)،
// والخادم لا يستلم إلا بصمة، ولا يحتفظ بها (٢.٣).
// ─────────────────────────────────────────────────────────────────────────────
import { api } from './api.js';

// ٢.١ — التطبيع إلى E.164 على الهاتف: أرقام عربية إلى لاتينية، ثم رمز الدولة.
const CC_DEFAULT = '968';
export function toE164(input, cc = CC_DEFAULT) {
  const AR = '٠١٢٣٤٥٦٧٨٩';
  let s = String(input || '').replace(/[٠-٩]/g, (d) => String(AR.indexOf(d)));
  s = s.replace(/[^\d+]/g, '');
  if (s.startsWith('+')) return s;
  if (s.startsWith('00')) return `+${s.slice(2)}`;
  if (s.startsWith(cc) && s.length > 8) return `+${s}`;
  if (s.startsWith('0')) return `+${cc}${s.slice(1)}`;
  return `+${cc}${s}`;
}

const b64 = (buf) => {
  const bytes = new Uint8Array(buf);
  let out = '';
  for (let i = 0; i < bytes.length; i += 1) out += String.fromCharCode(bytes[i]);
  return btoa(out);
};
const fromB64 = (str) => Uint8Array.from(atob(str), (c) => c.charCodeAt(0));

// ٢.٢ — بصمة HMAC-SHA256 بمفتاح دوري يسلمه الخادم للحساب المسجَّل وحده.
export async function fingerprint(keyB64, phone) {
  const key = await crypto.subtle.importKey(
    'raw', fromB64(keyB64), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'],
  );
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(toE164(phone)));
  return b64(sig);
}

// بصمات دفعة واحدة من أرقام قائمة على الجهاز — ثم تُطرح فورًا بعد المطابقة (٢.٣).
export async function fingerprintsOf(keyB64, numbers) {
  const out = [];
  for (const n of numbers || []) {
    try { out.push(await fingerprint(keyB64, n)); } catch (e) { /* رقم غير صالح يُسقط وحده */ }
  }
  return out;
}
export const canFingerprint = () => !!(typeof crypto !== 'undefined' && crypto.subtle && crypto.subtle.sign);

// «من يرى أثري»: الأثر المرئي لي مع من، وحدود الحذف — من الخادم لا من الواجهة.
export async function whoSees() {
  const d = await api.v31WhoSees();
  return {
    circles: d.circles || [],
    people: d.people || [],
    blocked: d.blocked || [],
    reach: d.reach || 0,
    memories: d.memories || 0,
    deleteLimit: d.deleteLimit || 'الحذف فوري من الخادم ومن كل جهاز متصل. نسخة ظهرت سابقًا على جهاز غير متصل لا يمكن سحبها.',
  };
}

// فهرس الخريطة: مربّعات بعدّادات فقط — لا نصوص ولا أسماء (٤.٣).
export async function grid(since) {
  const d = await api.v31Grid(since);
  return { cells: d.cells || [], purges: d.purges || [], syncedAt: d.syncedAt };
}

// دخول مربّع ⇒ نطلب سجله الكامل، والخادم يرشّحه بهويتي لحظة القراءة (١.٥).
export async function cell(gx, gy) {
  const d = await api.v31Cell(gx, gy);
  return d.items || [];
}

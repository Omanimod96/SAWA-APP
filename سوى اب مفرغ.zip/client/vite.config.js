import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// المسارات نسبية (./) كي يعمل الموقع من أي مجلد نشر على المنصة
export default defineConfig({
  base: './',
  plugins: [react()],
  build: {
    outDir: 'dist',
    emptyOutDir: true,
    chunkSizeWarningLimit: 1500,
  },
});

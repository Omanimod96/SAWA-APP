// خدمة العمل — تجعل فتح «سوى» فوريًا وتُبقيها صالحة بلا شبكة.
//
// السبب: وكيل الساندبوكس يخدم الطلب الواحد في ~٢ ثانية ويُسلسل الطلبات، فكل طلب
// إضافي تأخير ملموس. عامل الخدمة يخزّن «الصدفة» كاملة في الزيارة الأولى فيصير
// الفتح التالي من الذاكرة: صفر طلبات، بلا انتظار.
const VERSION = 'sawa-v32'; // v32: الاتصال الصوتي والمرئي — شاشة مكالمة واحدة، ورنين وارد، وسطر مكالمة في المحادثة
const SHELL = VERSION + '-shell';
const DATA = VERSION + '-data';
const FILES = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-512-maskable.png',
  './icons/apple-touch-icon.png',
];
const API_FRESH_MS = 60000; // بيانات الـ API تُقدَّم فورًا من الذاكرة إن كان عمرها أقل من دقيقة

// ── أدوات التخزين ──
async function put(cacheName, request, response) {
  try {
    const c = await caches.open(cacheName);
    const headers = new Headers(response.headers);
    headers.set('x-sawa-at', String(Date.now()));
    const body = await response.clone().blob();
    await c.put(request, new Response(body, { status: response.status, statusText: response.statusText, headers }));
  } catch (e) { /* التخزين ممتلئ أو الطلب غير قابل للتخزين — نتجاهل */ }
}

function ageMs(res) {
  const at = Number((res && res.headers.get('x-sawa-at')) || 0);
  return at ? Date.now() - at : Infinity;
}

const offline = (json) =>
  new Response(json ? JSON.stringify({ error: 'offline' }) : 'غير متصل', {
    status: 503,
    headers: { 'Content-Type': json ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8' },
  });

// ── التثبيت: نخزّن الصدفة مقدّمًا (كل ملف على حدة: ملف مفقود لا يُفشل البناء) ──
self.addEventListener('install', (e) => {
  e.waitUntil(
    (async () => {
      const c = await caches.open(SHELL);
      await Promise.all(FILES.map((u) => c.add(new Request(u, { cache: 'reload' })).catch(() => null)));
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(keys.filter((k) => k !== SHELL && k !== DATA).map((k) => caches.delete(k)));
      await self.clients.claim();
    })()
  );
});

self.addEventListener('message', (e) => {
  if (e.data === 'skip-waiting') self.skipWaiting();
});

// ── الصدفة: من الذاكرة فورًا، والتحديث يجري بهدوء في الخلفية ──
async function shellFirst(req) {
  const cache = await caches.open(SHELL);
  const hit = (await cache.match('./')) || (await cache.match('./index.html'));
  const net = fetch(req)
    .then((res) => { if (res && res.ok) put(SHELL, './', res); return res; })
    .catch(() => null);
  if (hit) { net.catch(() => null); return hit; } // فوري — لا ننتظر الشبكة
  const res = await net;
  return res || offline(false);
}

// ── بيانات الـ API: فورية إن كانت حديثة، وشبكة عند التقادم مع الاحتفاظ بنسخة ──
async function apiFirst(req) {
  const cache = await caches.open(DATA);
  const hit = await cache.match(req);
  const net = fetch(req)
    .then((res) => { if (res && res.ok) put(DATA, req, res); return res; })
    .catch(() => null);
  if (hit && ageMs(hit) < API_FRESH_MS) { net.catch(() => null); return hit; }
  const res = await net;
  return res || hit || offline(true);
}

// ── من الذاكرة أولًا مع تحديث خلفي (أيقونات، manifest، خطوط) ──
async function cacheFirst(req, cacheName) {
  const cache = await caches.open(cacheName);
  const hit = await cache.match(req);
  const net = fetch(req)
    .then((res) => { if (res && res.ok) put(cacheName, req, res); return res; })
    .catch(() => null);
  if (hit) { net.catch(() => null); return hit; }
  const res = await net;
  return res || offline(false);
}

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return; // الطلبات المُغيِّرة للبيانات تمرّ إلى الشبكة مباشرة

  const url = new URL(req.url);
  const sameOrigin = url.origin === self.location.origin;

  // التنقّل: الصدفة كاملة من الذاكرة
  if (req.mode === 'navigate') {
    e.respondWith(shellFirst(req));
    return;
  }

  // عامل الخدمة نفسه لا يُخزَّن (المتصفح يدير تحديثه بنفسه)
  if (sameOrigin && url.pathname.endsWith('/sw.js')) return;

  if (sameOrigin) {
    // وسائط العرض (صور/صوت) ثابتة المحتوى — من الذاكرة دائمًا
    if (url.pathname.startsWith('/api/media/')) {
      e.respondWith(cacheFirst(req, DATA));
      return;
    }
    if (url.pathname.startsWith('/api/')) {
      e.respondWith(apiFirst(req));
      return;
    }
    // أيقونات وmanifest وملفات ثابتة أخرى
    e.respondWith(cacheFirst(req, SHELL));
    return;
  }

  // خطوط Google وغيرها من الأصول الخارجية الثابتة — من الذاكرة مع تحديث خلفي
  if (/fonts\.(googleapis|gstatic)\.com$/.test(url.hostname)) {
    e.respondWith(cacheFirst(req, SHELL));
  }
});
